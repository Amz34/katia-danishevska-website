# Katia Danishevska — Complete Codebase Bundle for Claude Inspection

- **Live Origin (Cloudflare Pages):** https://katia-danishevska.pages.dev/
- **GitHub Repository:** https://github.com/Amz34/katia-danishevska-website
- **Design Archetype:** Zero-Motion Swiss Editorial Quiet Luxury
- **Typography Tokens:** Geist & Geist Mono
- **Client Profile:** Katia Danishevska · Strategic Talent Partner | Digital Assets & FinTech | Executive Search

---

## File: `index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="color-scheme" content="light">
  <script>
    try {
      var s = localStorage.getItem('color-scheme');
      if (s === 'dark') {
        document.querySelector('meta[name="color-scheme"]').content = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.querySelector('meta[name="color-scheme"]').content = 'light';
        document.documentElement.setAttribute('data-theme', 'light');
      }
    } catch (e) {
      document.documentElement.setAttribute('data-theme', 'light');
    }
  </script>

  <title>Katia Danishevska | Strategic Talent Partner</title>
  <meta name="description" content="Strategic Talent Partner specializing in Digital Assets, FinTech, and Executive Search across Switzerland, Europe, and global financial hubs.">
  <link rel="canonical" href="https://katia-danishevska.pages.dev/">

  <!-- Social & Link Previews -->
  <meta property="og:site_name" content="Katia Danishevska">
  <meta property="og:title" content="Katia Danishevska | Strategic Talent Partner">
  <meta property="og:description" content="Talent acquisition and executive hiring for digital assets and fintech. Around ten years of experience, including nearly six years at AMINA Bank in Zug.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://katia-danishevska.pages.dev/">
  <meta property="og:image" content="https://katia-danishevska.pages.dev/assets/og-card.jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Katia Danishevska | Strategic Talent Partner">
  <meta name="twitter:description" content="Talent acquisition and executive hiring for digital assets and fintech.">
  <meta name="twitter:image" content="https://katia-danishevska.pages.dev/assets/og-card.jpg">

  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="apple-touch-icon" href="assets/apple-touch-icon.png">

  <!-- Typography: Geist & Geist Mono -->
  <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-sans/style.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-mono/style.min.css">

  <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <a href="#main" class="skip-link button-sm">Skip to content</a>
  <div id="scroll-progress-bar" class="scroll-progress-bar" aria-hidden="true"></div>
  <div id="nav-sentinel" class="nav-sentinel" aria-hidden="true"></div>

  <!-- Floating Translucent Header -->
  <header class="site-nav-wrap">
    <nav id="site-nav" class="site-nav" aria-label="Primary">
      <a href="index.html" class="brand-mark" aria-label="Katia Danishevska Home">
        <span class="brand-badge" aria-hidden="true">KD</span>
        <span class="title-4">Katia Danishevska</span>
      </a>

      <ul class="nav-links">
        <li><a href="index.html" class="nav-link title-4" aria-current="page">Overview</a></li>
        <li><a href="experience.html" class="nav-link title-4">Experience</a></li>
        <li><a href="mandates.html" class="nav-link title-4">Focus</a></li>
        <li><a href="#corridors" class="nav-link title-4">Corridors</a></li>
        <li><a href="#methodology" class="nav-link title-4">Methodology</a></li>
        <li><a href="#connect" class="nav-link title-4">Connect</a></li>
      </ul>

      <div class="nav-actions">
        <button id="theme-toggle" type="button" class="icon-btn" aria-label="Toggle color theme" aria-pressed="false">
          <span class="icon-crossfade" aria-hidden="true">
            <span class="theme-icon-sun">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><circle cx="128" cy="128" r="48"/><path d="M128 36v-12M128 232v-12M63 63l-9-9M202 202l-9-9M36 128H24M232 128h-12M63 193l-9 9M202 54l-9 9"/></svg>
            </span>
            <span class="theme-icon-moon">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><path d="M210.7 152.6A92 92 0 0 1 103.4 45.3a92 92 0 1 0 107.3 107.3Z"/></svg>
            </span>
          </span>
        </button>

        <button id="menu-toggle" type="button" class="icon-btn menu-toggle" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mobile-drawer">
          <span class="hamburger-lines" aria-hidden="true">
            <span></span>
            <span></span>
            <span></span>
          </span>
        </button>
      </div>
    </nav>
  </header>

  <!-- Full-Height Mobile Navigation Panel -->
  <aside id="mobile-drawer" class="mobile-drawer" aria-label="Mobile menu" aria-hidden="true">
    <a href="index.html" class="mobile-drawer-link heading-5"><span>Overview</span><span class="mono-meta caption-4 text-muted">01</span></a>
    <a href="experience.html" class="mobile-drawer-link heading-5"><span>Experience</span><span class="mono-meta caption-4 text-muted">02</span></a>
    <a href="mandates.html" class="mobile-drawer-link heading-5"><span>Focus</span><span class="mono-meta caption-4 text-muted">03</span></a>
    <a href="#corridors" class="mobile-drawer-link heading-5"><span>Corridors</span><span class="mono-meta caption-4 text-muted">04</span></a>
    <a href="#methodology" class="mobile-drawer-link heading-5"><span>Methodology</span><span class="mono-meta caption-4 text-muted">05</span></a>
    <a href="#connect" class="mobile-drawer-link heading-5"><span>Connect</span><span class="mono-meta caption-4 text-muted">06</span></a>
  </aside>

  <main id="main" tabindex="-1">

    <!-- 1. HERO: SWISS EDITORIAL ARCHITECTURE -->
    <section class="hero" aria-labelledby="hero-title">
      <div class="container">
        <div class="hero-grid">
          <div class="hero-copy">
            <div class="hero-role-line">
              <span class="status-dot" aria-hidden="true"></span>
              <span class="caption-1">Strategic Talent Partner · Zürich Metropolitan Area</span>
            </div>

            <h1 id="hero-title" class="heading-1 hero-gradient-text">
              Talent acquisition &amp;<br>
              executive hiring for<br>
              digital assets and fintech.
            </h1>

            <p class="body-2 hero-sub">
              Around ten years of talent acquisition across digital assets, financial technology, and executive search, including nearly six years at AMINA Bank in Zug.
            </p>

            <div class="hero-actions">
              <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-with-icon button-md">
                <span>Connect on LinkedIn</span>
                <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M40 128h176M144 56l72 72-72 72"/></svg>
              </a>

              <a href="assets/Katia-Danishevska-Executive-Dossier.pdf" download="Katia-Danishevska-Career-Summary.pdf" class="btn-pdf-download button-md" aria-label="Download Katia Danishevska Career Summary as PDF">
                <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 32h112l48 48v144a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8V40a8 8 0 0 1 8-8Z"/><path d="M160 32v48h48M128 120v64M96 152l32 32 32-32"/></svg>
                <span>Download Career Summary (PDF)</span>
              </a>

              <a href="experience.html" class="btn btn-secondary button-md">View Career Dossier</a>
            </div>

            <dl class="hero-proof-strip">
              <div>
                <dt class="caption-4 text-muted">Experience</dt>
                <dd class="title-2 tabular-nums mt-1">~10 Years</dd>
              </div>
              <div>
                <dt class="caption-4 text-muted">Swiss Banking Tenure</dt>
                <dd class="title-2 tabular-nums mt-1">5 yrs 10 mos</dd>
              </div>
              <div>
                <dt class="caption-4 text-muted">Current Role</dt>
                <dd class="title-2 mt-1">SwissChain</dd>
              </div>
              <div>
                <dt class="caption-4 text-muted">Education</dt>
                <dd class="title-2 mt-1">MSc in HRM</dd>
              </div>
            </dl>
          </div>

          <!-- Editorial Dossier Card (Exact Order Matching Attached Reference) -->
          <div class="dossier-frame" aria-label="Executive profile summary">
            <div class="dossier-inner">
              <div class="dossier-top">
                <div class="dossier-monogram" aria-hidden="true">KD</div>
                <div style="text-align: right;">
                  <div class="mono-meta caption-4 text-teal">ZÜRICH · ZUG · LJUBLJANA</div>
                  <div class="mono-meta caption-5 text-muted mt-1">Swiss &amp; European Talent Corridors</div>
                </div>
              </div>

              <div>
                <div class="title-2">Katia Danishevska</div>
                <p class="body-6 text-secondary mt-1">
                  Senior Strategic Talent Partner specializing in Digital Assets, FinTech, and Executive Leadership Mandates.
                </p>
              </div>

              <div class="dossier-list">
                <div class="dossier-row">
                  <span class="caption-4 text-muted">Present</span>
                  <span class="body-5">SwissChain · Senior Talent Partner</span>
                </div>
                <div class="dossier-row">
                  <span class="caption-4 text-muted">2020 to 2025</span>
                  <span class="body-5">AMINA Bank · Zug (FINMA-Regulated)</span>
                </div>
                <div class="dossier-row">
                  <span class="caption-4 text-muted">Agency Background</span>
                  <span class="body-5">ManpowerGroup IT · ISG · Adecco</span>
                </div>
                <div class="dossier-row">
                  <span class="caption-4 text-muted">Credentials</span>
                  <span class="body-5">MSc in HRM · University of Ljubljana</span>
                </div>
              </div>

              <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; border-top: 1px solid var(--border-hairline); padding-top: 12px;">
                <span class="caption-4 text-secondary">Focus</span>
                <span class="caption-3 text-teal">Digital Assets · FinTech · Leadership</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 2. GUIDING STATEMENT -->
    <section class="tagline-section section-band" aria-label="Guiding principle">
      <div class="container">
        <p id="tagline-reveal" class="heading-2 tagline-text">
          I connect companies with the right people, from experienced specialists and managers to senior leaders across fintech, blockchain and digital-asset businesses.
        </p>
      </div>
    </section>

    <!-- 3. PERSPECTIVE & PRACTICE PILLARS -->
    <section id="about" class="section reveal-block" aria-labelledby="about-heading">
      <div class="container">
        <div class="grid-asymmetric">
          <div>
            <span class="caption-3 text-teal">Perspective</span>
            <h2 id="about-heading" class="heading-3 mt-1">
              Grounded in European markets and Swiss regulated finance
            </h2>
            <div style="display: flex; flex-direction: column; gap: 16px; margin-top: 24px;" class="text-secondary">
              <p class="body-3">
                Throughout my career across Switzerland, Slovenia, and wider international markets, I have partnered closely with founders, functional heads, and hiring committees navigating complex talent landscapes.
              </p>
              <p class="body-3">
                Spending nearly six years inside regulated Swiss digital asset banking at AMINA Bank in Zug and now at SwissChain has shaped how I calibrate hiring: precision over volume, multicultural fluency, and genuine relationships with senior specialists.
              </p>
              <p class="body-3">
                Whether building foundational engineering and compliance teams or placing department leadership, every hire balances immediate operational priorities with long-term team culture.
              </p>
            </div>
            <div class="mt-4">
              <a href="mandates.html" class="btn btn-secondary btn-with-icon button-sm">
                <span>Explore Functional Areas of Focus</span>
                <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M40 128h176M144 56l72 72-72 72"/></svg>
              </a>
            </div>
          </div>

          <div class="grid-2" style="gap: 16px;">
            <article class="card card-interactive">
              <div class="card-icon-box" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><circle cx="128" cy="128" r="88"/><path d="M128 40v176M40 128h176"/></svg>
              </div>
              <h3 class="title-2">Digital Assets &amp; Web3</h3>
              <p class="body-6 text-secondary mt-1">
                Specialist and leadership hiring for blockchain protocols, MPC custody infrastructure, and regulated digital finance.
              </p>
            </article>

            <article class="card card-interactive">
              <div class="card-icon-box" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><path d="M32 208h192M56 168l48-48 36 36 60-76"/></svg>
              </div>
              <h3 class="title-2">Regulated FinTech Growth</h3>
              <p class="body-6 text-secondary mt-1">
                Talent acquisition for high-velocity financial technology ventures, cross-border trading, and institutional banking.
              </p>
            </article>

            <article class="card card-interactive">
              <div class="card-icon-box" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><path d="M128 32L32 80l96 48 96-48-96-48Z"/><path d="M32 128l96 48 96-48M32 176l96 48 96-48"/></svg>
              </div>
              <h3 class="title-2">Executive &amp; Leadership</h3>
              <p class="body-6 text-secondary mt-1">
                Recruitment for department heads, directors, and selected functional leaders calibrated directly with company executives.
              </p>
            </article>

            <article class="card card-interactive">
              <div class="card-icon-box" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><circle cx="128" cy="128" r="96"/><path d="M128 32a96 96 0 0 1 0 192M128 80a48 48 0 0 1 0 96"/></svg>
              </div>
              <h3 class="title-2">Governance &amp; Operations</h3>
              <p class="body-6 text-secondary mt-1">
                Building compliance, regulatory risk, operational finance, and business development capabilities across European frameworks.
              </p>
            </article>
          </div>
        </div>
      </div>
    </section>

    <!-- 4. STATIC SWISS EXECUTIVE TALENT CORRIDOR MATRIX -->
    <section id="corridors" class="section section-band reveal-block" aria-labelledby="corridors-heading">
      <div class="container">
        <div style="max-width: 680px; margin-bottom: 24px;">
          <span class="caption-3 text-teal">Market Corridors &amp; Geographic Scope</span>
          <h2 id="corridors-heading" class="heading-3 mt-1">
            Swiss-rooted, European-connected talent corridors
          </h2>
          <p class="body-3 text-secondary mt-2">
            Structured search corridors engineered for regulatory rigor, technical depth, and cross-border leadership placement.
          </p>
        </div>

        <div class="corridor-matrix-grid">
          <!-- Column 1: Zürich & Zug (Crypto Valley) -->
          <article class="corridor-card">
            <div>
              <div class="corridor-card-header">
                <span class="corridor-tag">Swiss Banking &amp; Digital Assets</span>
                <h3 class="title-1 mt-1">Zürich &amp; Crypto Valley (Zug)</h3>
                <p class="body-6 text-secondary">
                  Specialized placement of department heads, senior compliance officers, and technology specialists across Swiss digital banking and institutional custody.
                </p>
              </div>

              <ul class="corridor-list">
                <li>Regulatory Compliance &amp; Financial Crime Risk</li>
                <li>General Counsel &amp; Legal Affairs</li>
                <li>Custody Infrastructure &amp; Security Engineering</li>
                <li>Institutional Business Development &amp; Client Coverage</li>
              </ul>
            </div>

            <div class="corridor-compliance-badge">
              Swiss Institutional Standard · FINMA Regulated Background
            </div>
          </article>

          <!-- Column 2: European Engineering Corridors -->
          <article class="corridor-card">
            <div>
              <div class="corridor-card-header">
                <span class="corridor-tag">Distributed Systems &amp; Labs</span>
                <h3 class="title-1 mt-1">Ljubljana · London · DACH</h3>
                <p class="body-6 text-secondary">
                  Connecting high-density technical engineering clusters in Central Europe and the UK with Swiss, European, and global digital asset ventures.
                </p>
              </div>

              <ul class="corridor-list">
                <li>Software Architects &amp; Technical Leads</li>
                <li>Blockchain &amp; Distributed Systems Specialists</li>
                <li>Senior Protocol &amp; Infrastructure Engineers</li>
                <li>Product Management &amp; Growth Operators</li>
              </ul>
            </div>

            <div class="corridor-compliance-badge">
              Deep Technical Calibration · Direct Network Referencing
            </div>
          </article>

          <!-- Column 3: Global Expansion Corridors -->
          <article class="corridor-card">
            <div>
              <div class="corridor-card-header">
                <span class="corridor-tag">Cross-Border Scope</span>
                <h3 class="title-1 mt-1">Singapore · UAE · Global Markets</h3>
                <p class="body-6 text-secondary">
                  Connecting international professionals navigating cross-border regulatory harmonization, regional market expansion, and liquidity partnerships.
                </p>
              </div>

              <ul class="corridor-list">
                <li>Regional Business Leads &amp; Market Heads</li>
                <li>Institutional Operations &amp; Clearing</li>
                <li>Risk Management &amp; International Governance</li>
                <li>Strategic Partnerships &amp; Ecosystem Growth</li>
              </ul>
            </div>

            <div class="corridor-compliance-badge">
              Cross-Border Mobility · Multi-Jurisdictional Experience
            </div>
          </article>
        </div>

        <!-- Practice Standards Strip -->
        <div class="metrics-strip">
          <div class="metric-box">
            <div class="metric-value">~10 Years</div>
            <div class="metric-tag">Established Talent Network</div>
          </div>
          <div class="metric-box">
            <div class="metric-value">5y 10m</div>
            <div class="metric-tag">Swiss Banking Tenure (Zug)</div>
          </div>
          <div class="metric-box">
            <div class="metric-value">Structured</div>
            <div class="metric-tag">Candidate Calibration</div>
          </div>
          <div class="metric-box">
            <div class="metric-value">100%</div>
            <div class="metric-tag">Professional Discretion</div>
          </div>
        </div>
      </div>
    </section>

    <!-- 5. REPRESENTATIVE SEARCH MANDATES & DISCRETION PROTOCOL -->
    <section id="track-record" class="section reveal-block" aria-labelledby="track-record-heading">
      <div class="container">
        <div style="max-width: 680px; margin-bottom: 24px;">
          <span class="caption-3 text-teal">Search Scope</span>
          <h2 id="track-record-heading" class="heading-3 mt-1">
            Representative leadership &amp; specialist search profiles
          </h2>
          <p class="body-3 text-secondary mt-2">
            Key functional areas and leadership appointments executed across digital banking, institutional custody, and financial technology platforms.
          </p>
        </div>

        <div class="placement-case-grid">
          <article class="placement-case-card">
            <span class="mono-meta caption-4 text-teal">DIGITAL BANKING &amp; GOVERNANCE · ZUG</span>
            <h3 class="title-2 mt-1">Compliance &amp; Legal Leadership</h3>
            <p class="body-6 text-secondary mt-2">
              Sourcing senior regulatory officers, legal counsels, and financial crime specialists experienced in European banking regulations and AML governance.
            </p>
            <div class="mono-meta caption-5 text-muted mt-3">Core Scope: Regulatory Governance &amp; AML</div>
          </article>

          <article class="placement-case-card">
            <span class="mono-meta caption-4 text-teal">INSTITUTIONAL INFRASTRUCTURE · ZÜRICH</span>
            <h3 class="title-2 mt-1">Engineering &amp; Custody Leadership</h3>
            <p class="body-6 text-secondary mt-2">
              Identifying software engineering directors, distributed systems architects, and cryptography specialists building institutional digital asset custody solutions.
            </p>
            <div class="mono-meta caption-5 text-muted mt-3">Core Scope: Blockchain &amp; Core Infrastructure</div>
          </article>

          <article class="placement-case-card">
            <span class="mono-meta caption-4 text-teal">MARKET EXPANSION · DACH &amp; EUROPE</span>
            <h3 class="title-2 mt-1">Institutional Sales &amp; Growth</h3>
            <p class="body-6 text-secondary mt-2">
              Recruiting relationship leaders and business development heads with proven institutional coverage across asset managers, family offices, and brokerages.
            </p>
            <div class="mono-meta caption-5 text-muted mt-3">Core Scope: Institutional Client Coverage</div>
          </article>
        </div>

        <!-- Discretion Protocol Banner -->
        <div class="discretion-banner">
          <div>
            <span class="caption-3 text-teal">Discretion &amp; Trust</span>
            <h3 class="heading-4 mt-1">Mutual Discretion &amp; Relationship Governance</h3>
            <p class="body-5 text-secondary mt-2">
              In specialized sectors like Swiss private banking and digital asset technology, discretion is essential. Every search is handled with thoughtful confidentiality, direct communication, and thorough referencing within established industry networks.
            </p>
          </div>
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <div class="dossier-row">
              <span class="caption-4 text-muted">Direct Sourcing</span>
              <span class="body-5">Close stakeholder alignment</span>
            </div>
            <div class="dossier-row">
              <span class="caption-4 text-muted">Confidentiality</span>
              <span class="body-5">Candidate trust protected</span>
            </div>
            <div class="dossier-row">
              <span class="caption-4 text-muted">Network Depth</span>
              <span class="body-5">Swiss &amp; European relationships</span>
            </div>
            <div class="mt-2">
              <a href="mandates.html" class="btn btn-secondary button-sm">Explore Areas of Focus</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 6. CAREER PROGRESSION -->
    <section class="section section-band reveal-block" aria-labelledby="journey-heading">
      <div class="container">
        <div style="display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 24px; margin-bottom: 40px;">
          <div style="max-width: 640px;">
            <span class="caption-3 text-teal">Career Progression</span>
            <h2 id="journey-heading" class="heading-3 mt-1">
              Consistent progression across specialist sourcing and executive hiring
            </h2>
          </div>
          <a href="experience.html" class="btn btn-secondary btn-with-icon button-sm">
            <span>Full Career Timeline</span>
            <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M40 128h176M144 56l72 72-72 72"/></svg>
          </a>
        </div>

        <ol class="timeline">
          <li class="timeline-entry is-current">
            <span class="timeline-node" aria-hidden="true"></span>
            <div class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h3 class="title-1">Senior Talent Acquisition Partner</h3>
                  <p class="body-5 text-teal mt-1">SwissChain · Ljubljana, Slovenia</p>
                </div>
                <span class="mono-meta caption-2 text-muted">October 2025 to Present</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Leading end-to-end recruitment for senior, specialist and leadership positions across digital assets, fintech, technology, compliance, operations, and finance.
              </p>
            </div>
          </li>

          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <div class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h3 class="title-1">Talent Acquisition Partner · 3 Successive Roles</h3>
                  <p class="body-5 text-accent mt-1">AMINA Bank · Zug, Switzerland</p>
                </div>
                <span class="mono-meta caption-2 text-muted">January 2020 to October 2025 (5 yrs 10 mos)</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Served nearly six years inside Swiss digital asset banking across three promotions: Talent Acquisition Specialist, TA Partner for Banking &amp; Digital Assets, and TA Partner for Digital Assets &amp; FinTech. Recruited department heads, specialists, and institutional finance personnel.
              </p>
            </div>
          </li>

          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <div class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h3 class="title-1">Recruitment Consultant &amp; Sourcing Foundations</h3>
                  <p class="body-5 text-secondary mt-1">ManpowerGroup · ISG International · Adecco Slovenia</p>
                </div>
                <span class="mono-meta caption-2 text-muted">June 2014 to December 2019</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Built international recruitment and technical sourcing capabilities across IT, technology, and business management following a Master Degree in Human Resource Management at the University of Ljubljana.
              </p>
            </div>
          </li>
        </ol>
      </div>
    </section>

    <!-- 7. SPLIT ACCORDION: COLLABORATION METHODOLOGY -->
    <section id="methodology" class="section reveal-block" aria-labelledby="method-heading">
      <div class="container">
        <div class="grid-asymmetric">
          <div>
            <span class="caption-3 text-teal">How We Collaborate</span>
            <h2 id="method-heading" class="heading-3 mt-1">
              Clear alignment from first intake to offer close
            </h2>
            <p class="body-3 text-secondary mt-2">
              Every search prioritizes honest market calibration, direct candidate relationships, and structured communication with hiring committees.
            </p>
          </div>

          <div class="split-accordion" role="region" aria-label="Search methodology details">
            <div class="split-acc-item is-open">
              <h3>
                <button type="button" class="split-acc-trigger title-2" aria-expanded="true">
                  <span>01 · Business calibration before sourcing begins</span>
                  <svg class="split-acc-chevron" width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 96l80 80 80-80"/></svg>
                </button>
              </h3>
              <div class="split-acc-panel">
                <div class="split-acc-inner">
                  <p class="split-acc-content body-5">
                    Partnering directly with hiring managers to define hiring priorities, candidate requirements, compensation parameters, and team dynamics.
                  </p>
                </div>
              </div>
            </div>

            <div class="split-acc-item">
              <h3>
                <button type="button" class="split-acc-trigger title-2" aria-expanded="false">
                  <span>02 · Direct sourcing and international talent pipelines</span>
                  <svg class="split-acc-chevron" width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 96l80 80 80-80"/></svg>
                </button>
              </h3>
              <div class="split-acc-panel">
                <div class="split-acc-inner">
                  <p class="split-acc-content body-5">
                    Reaching high-quality candidates through proactive direct sourcing, trusted referrals, and established professional networks across Switzerland and Europe.
                  </p>
                </div>
              </div>
            </div>

            <div class="split-acc-item">
              <h3>
                <button type="button" class="split-acc-trigger title-2" aria-expanded="false">
                  <span>03 · Structured evaluation and ongoing counsel</span>
                  <svg class="split-acc-chevron" width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 96l80 80 80-80"/></svg>
                </button>
              </h3>
              <div class="split-acc-panel">
                <div class="split-acc-inner">
                  <p class="split-acc-content body-5">
                    Sharing market insight on candidate profiles and availability while coordinating thoughtful interview stages and transparent stakeholder feedback.
                  </p>
                </div>
              </div>
            </div>

            <div class="split-acc-item">
              <h3>
                <button type="button" class="split-acc-trigger title-2" aria-expanded="false">
                  <span>04 · Thoughtful offer stewardship &amp; close</span>
                  <svg class="split-acc-chevron" width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 96l80 80 80-80"/></svg>
                </button>
              </h3>
              <div class="split-acc-panel">
                <div class="split-acc-inner">
                  <p class="split-acc-content body-5">
                    Supporting offer negotiations and candidate onboarding to build long-term alignment and sustainable team architecture.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 8. DIRECT CONNECT & NOTE PREPARATION -->
    <section id="connect" class="section section-band reveal-block" aria-labelledby="connect-heading">
      <div class="container">
        <div class="grid-asymmetric">
          <div>
            <span class="caption-3 text-teal">Direct Contact</span>
            <h2 id="connect-heading" class="heading-2 mt-1">
              Start a conversation
            </h2>
            <p class="body-3 text-secondary mt-2" style="max-width: 520px;">
              I'm glad to hear from hiring leaders and experienced professionals in digital assets and fintech across European and international time zones.
            </p>

            <div class="hero-actions mt-4">
              <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-with-icon button-md">
                <span>Message on LinkedIn</span>
                <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M180 76L76 180M96 76h84v84"/></svg>
              </a>

              <button id="copy-linkedin-btn" type="button" class="btn btn-secondary btn-with-icon button-md" data-copy-value="https://www.linkedin.com/in/katia-danishevska-122224445" data-copied="false">
                <span data-copy-label>Copy LinkedIn URL</span>
                <span class="icon-crossfade" aria-hidden="true">
                  <span class="copy-icon-default">
                    <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><rect x="40" y="88" width="128" height="128" rx="12"/><path d="M88 88V52a12 12 0 0 1 12-12h104a12 12 0 0 1 12 12v104a12 12 0 0 1-12 12h-36"/></svg>
                  </span>
                  <span class="copy-icon-check">
                    <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="22" stroke-linecap="round" stroke-linejoin="round"><path d="M40 144l56 56L216 80"/></svg>
                  </span>
                </span>
              </button>
            </div>
            <p id="copy-linkedin-status" class="caption-4 text-teal mt-2" aria-live="polite"></p>

            <div class="mt-4 pt-3" style="border-top: 1px solid var(--border-hairline);">
              <span class="caption-4 text-muted">Direct Download</span>
              <div class="mt-1">
                <a href="assets/Katia-Danishevska-Executive-Dossier.pdf" download="Katia-Danishevska-Career-Summary.pdf" class="btn-pdf-download button-sm">
                  <svg width="14" height="14" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 32h112l48 48v144a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8V40a8 8 0 0 1 8-8Z"/><path d="M160 32v48h48M128 120v64M96 152l32 32 32-32"/></svg>
                  <span>Katia-Danishevska-Career-Summary.pdf (44 KB)</span>
                </a>
              </div>
            </div>
          </div>

          <!-- Honest Note Preparer Panel -->
          <div class="card">
            <h3 class="title-1">Prepare a note</h3>
            <p class="body-6 text-secondary mt-1">
              This site runs statically and does not send emails. Write your message, format it here, and copy it directly to paste into LinkedIn.
            </p>

            <form id="note-form" class="form-grid mt-3">
              <div class="field-group">
                <label for="note-name" class="caption-1">Your name <span aria-hidden="true">*</span></label>
                <input id="note-name" name="name" type="text" class="field-input" autocomplete="name" required placeholder="Your full name">
              </div>

              <div class="field-group">
                <label for="note-topic" class="caption-1">Topic</label>
                <select id="note-topic" name="topic" class="field-select">
                  <option value="Executive and leadership hiring">Executive and leadership hiring</option>
                  <option value="Digital assets and fintech hiring">Digital assets and fintech hiring</option>
                  <option value="Candidate introduction">Candidate introduction</option>
                  <option value="Professional conversation">Professional conversation</option>
                </select>
              </div>

              <div class="field-group">
                <label for="note-details" class="caption-1">Your note <span aria-hidden="true">*</span></label>
                <textarea id="note-details" name="details" class="field-textarea" rows="4" required placeholder="Share brief context about the role, organization, or topic..."></textarea>
              </div>

              <div class="form-actions mt-2">
                <button id="note-submit" type="submit" class="btn btn-primary button-md">
                  <span>Copy Note for LinkedIn</span>
                </button>
              </div>
            </form>

            <div id="note-status" class="callout callout-info mt-2 hidden" role="status" aria-live="polite"></div>
            <textarea id="note-output" class="field-textarea mt-2 hidden" rows="6" readonly aria-label="Formatted note output"></textarea>
            <div id="note-link-wrap" class="mt-2 hidden">
              <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="btn btn-secondary button-sm">
                <span>Open LinkedIn to Send</span>
                <svg width="14" height="14" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M180 76L76 180M96 76h84v84"/></svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

  </main>

  <!-- Official Az. Consultant Footer with Plain Text Unlinked Attribution -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-top">
        <div style="display: flex; align-items: center; gap: 12px;">
          <span class="brand-badge" aria-hidden="true">KD</span>
          <span class="caption-2 text-secondary">© 2026 Katia Danishevska</span>
        </div>

        <div class="footer-links">
          <a href="experience.html" class="footer-text-link caption-2">Experience</a>
          <a href="mandates.html" class="footer-text-link caption-2">Focus</a>
          <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="footer-text-link caption-2">LinkedIn</a>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="privacy-dialog">Privacy</button>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="legal-dialog">Terms &amp; Notice</button>
          <span class="caption-2 text-muted">Crafted by Az. Consultant</span>
        </div>
      </div>

      <div class="footer-disclaimer">
        <p class="caption-5 text-muted" style="max-width: 760px;">
          <strong>Disclaimer:</strong> Independent personal website redesign concept prepared by Az. Consultant in response to Katia Danishevska's public LinkedIn post. All biography, tenure, and education details originate exclusively from publicly visible LinkedIn profile records, with no confidential data or official endorsement implied.
        </p>
        <a href="design-notes.html" class="caption-4 text-secondary">View Design &amp; Architecture Notes</a>
      </div>
    </div>
  </footer>

  <!-- Native Dialogs -->
  <dialog id="privacy-dialog" class="site-dialog" closedby="any" aria-labelledby="privacy-title">
    <div class="dialog-head">
      <h2 id="privacy-title" class="heading-5">Privacy Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close privacy notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This static preview operates without analytics trackers, marketing cookies, or third party behavioral scripts. Theme preference is stored solely in your browser local storage and can be reset at any time.
    </p>
  </dialog>

  <dialog id="legal-dialog" class="site-dialog" closedby="any" aria-labelledby="legal-title">
    <div class="dialog-head">
      <h2 id="legal-title" class="heading-5">Terms &amp; Concept Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close terms and notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This site is an independent design submission created by Az. Consultant for evaluation by Katia Danishevska. Company names appear strictly as historical career references from public LinkedIn records.
    </p>
  </dialog>

  <script defer src="js/main.js"></script>
</body>
</html>

```

## File: `experience.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="color-scheme" content="light">
  <script>
    try {
      var s = localStorage.getItem('color-scheme');
      if (s === 'dark') {
        document.querySelector('meta[name="color-scheme"]').content = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.querySelector('meta[name="color-scheme"]').content = 'light';
        document.documentElement.setAttribute('data-theme', 'light');
      }
    } catch (e) {
      document.documentElement.setAttribute('data-theme', 'light');
    }
  </script>

  <title>Career Progression | Katia Danishevska</title>
  <meta name="description" content="Verified ten-year career progression of Katia Danishevska across SwissChain, AMINA Bank in Zug, ManpowerGroup, ISG, Adecco, and the University of Ljubljana.">
  <link rel="canonical" href="https://katia-danishevska.pages.dev/experience.html">

  <meta property="og:site_name" content="Katia Danishevska">
  <meta property="og:title" content="Career Progression | Katia Danishevska">
  <meta property="og:description" content="Ten-year career progression in recruitment across Slovenia, Switzerland and international markets.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://katia-danishevska.pages.dev/experience.html">
  <meta property="og:image" content="https://katia-danishevska.pages.dev/assets/og-card.jpg">

  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="apple-touch-icon" href="assets/apple-touch-icon.png">

  <!-- Typography: Geist & Geist Mono -->
  <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-sans/style.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-mono/style.min.css">

  <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <a href="#main" class="skip-link button-sm">Skip to content</a>
  <div id="scroll-progress-bar" class="scroll-progress-bar" aria-hidden="true"></div>
  <div id="nav-sentinel" class="nav-sentinel" aria-hidden="true"></div>

  <header class="site-nav-wrap">
    <nav id="site-nav" class="site-nav" aria-label="Primary">
      <a href="index.html" class="brand-mark" aria-label="Katia Danishevska Home">
        <span class="brand-badge" aria-hidden="true">KD</span>
        <span class="title-4">Katia Danishevska</span>
      </a>

      <ul class="nav-links">
        <li><a href="index.html" class="nav-link title-4">Overview</a></li>
        <li><a href="experience.html" class="nav-link title-4" aria-current="page">Experience</a></li>
        <li><a href="mandates.html" class="nav-link title-4">Focus</a></li>
        <li><a href="index.html#connect" class="nav-link title-4">Connect</a></li>
      </ul>

      <div class="nav-actions">
        <button id="theme-toggle" type="button" class="icon-btn" aria-label="Toggle color theme" aria-pressed="false">
          <span class="icon-crossfade" aria-hidden="true">
            <span class="theme-icon-sun">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><circle cx="128" cy="128" r="48"/><path d="M128 36v-12M128 232v-12M63 63l-9-9M202 202l-9-9M36 128H24M232 128h-12M63 193l-9 9M202 54l-9 9"/></svg>
            </span>
            <span class="theme-icon-moon">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><path d="M210.7 152.6A92 92 0 0 1 103.4 45.3a92 92 0 1 0 107.3 107.3Z"/></svg>
            </span>
          </span>
        </button>

        <button id="menu-toggle" type="button" class="icon-btn menu-toggle" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mobile-drawer">
          <span class="hamburger-lines" aria-hidden="true"><span></span><span></span><span></span></span>
        </button>
      </div>
    </nav>
  </header>

  <aside id="mobile-drawer" class="mobile-drawer" aria-label="Mobile menu" aria-hidden="true">
    <a href="index.html" class="mobile-drawer-link heading-5"><span>Overview</span><span class="mono-meta caption-4 text-muted">01</span></a>
    <a href="experience.html" class="mobile-drawer-link heading-5"><span>Experience</span><span class="mono-meta caption-4 text-muted">02</span></a>
    <a href="mandates.html" class="mobile-drawer-link heading-5"><span>Focus</span><span class="mono-meta caption-4 text-muted">03</span></a>
    <a href="index.html#connect" class="mobile-drawer-link heading-5"><span>Connect</span><span class="mono-meta caption-4 text-muted">04</span></a>
  </aside>

  <main id="main" tabindex="-1">
    <section class="section" style="padding-top: 144px;">
      <div class="container">
        <div style="max-width: 680px;">
          <a href="index.html" class="caption-2 text-secondary">← Back to Overview</a>
          <h1 class="heading-1 hero-gradient-text mt-2">Career Progression</h1>
          <p class="body-2 text-secondary mt-3">
            Around ten years in recruitment across Slovenia, Switzerland and international markets.
          </p>
          <div style="display: flex; flex-wrap: wrap; gap: 12px; margin-top: 24px;">
            <a href="assets/Katia-Danishevska-Executive-Dossier.pdf" download="Katia-Danishevska-Career-Summary.pdf" class="btn-pdf-download button-md" aria-label="Download Katia Danishevska Career Summary as PDF">
              <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 32h112l48 48v144a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8V40a8 8 0 0 1 8-8Z"/><path d="M160 32v48h48M128 120v64M96 152l32 32 32-32"/></svg>
              <span>Download Career Summary (PDF)</span>
            </a>
            <a href="mandates.html" class="btn btn-secondary button-md">View Areas of Focus</a>
          </div>
        </div>

        <ol class="timeline mt-6">
          <!-- 1. SwissChain -->
          <li class="timeline-entry is-current">
            <span class="timeline-node" aria-hidden="true"></span>
            <article class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h2 class="heading-5">Senior Talent Acquisition Partner</h2>
                  <p class="body-4 text-teal mt-1">SwissChain · Ljubljana, Slovenia</p>
                </div>
                <span class="mono-meta caption-2 text-muted">October 2025 to Present</span>
              </div>
              <ul style="display: flex; flex-direction: column; gap: 8px; margin-top: 16px;" class="body-5 text-secondary">
                <li>End-to-end recruitment for senior, specialist and leadership positions across digital assets, fintech and financial services.</li>
                <li>Targeted international sourcing; pipelines in business development, technology, compliance, operations and finance.</li>
                <li>Advise hiring managers on candidate profiles, market availability, and recruitment priorities.</li>
                <li>Maintain relationships with senior professionals and support interview evaluation and offer negotiations.</li>
              </ul>
            </article>
          </li>

          <!-- 2. AMINA Bank -->
          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <article class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h2 class="heading-5">AMINA Bank AG · Three Progressive Roles</h2>
                  <p class="body-4 text-accent mt-1">Zug, Switzerland · 5 years 10 months total tenure</p>
                </div>
                <span class="mono-meta caption-2 text-muted">January 2020 to October 2025</span>
              </div>

              <div style="display: flex; flex-direction: column; gap: 20px; margin-top: 20px;">
                <div>
                  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 8px;">
                    <h3 class="title-2">Talent Acquisition Partner, Digital Assets &amp; FinTech</h3>
                    <span class="mono-meta caption-3 text-muted">June 2023 to October 2025</span>
                  </div>
                  <p class="body-5 text-secondary mt-1">
                    Recruitment for senior professionals, department heads and selected leadership roles. Recruitment insight and support through evaluation, interviews and offer negotiations.
                  </p>
                </div>

                <div style="padding-top: 16px; border-top: 1px solid var(--border-hairline);">
                  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 8px;">
                    <h3 class="title-2">Talent Acquisition Partner, Banking &amp; Digital Assets</h3>
                    <span class="mono-meta caption-3 text-muted">December 2021 to June 2023</span>
                  </div>
                  <p class="body-5 text-secondary mt-1">
                    Full-cycle recruitment for specialist and professional roles across banking, technology and digital assets through direct sourcing, referrals and networks.
                  </p>
                </div>

                <div style="padding-top: 16px; border-top: 1px solid var(--border-hairline);">
                  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 8px;">
                    <h3 class="title-2">Talent Acquisition Specialist</h3>
                    <span class="mono-meta caption-3 text-muted">January 2020 to December 2021</span>
                  </div>
                  <p class="body-5 text-secondary mt-1">
                    Sourcing, screening and pipeline building for business, technology and financial services roles, from identification through offer coordination.
                  </p>
                </div>
              </div>
            </article>
          </li>

          <!-- 3. ManpowerGroup -->
          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <article class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h2 class="heading-5">Recruitment Consultant, IT &amp; Technology</h2>
                  <p class="body-4 text-secondary mt-1">ManpowerGroup · Ljubljana, Slovenia</p>
                </div>
                <span class="mono-meta caption-2 text-muted">January 2018 to December 2019</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Sourced and interviewed candidates for technical and business roles across IT, software development, and technology teams.
              </p>
            </article>
          </li>

          <!-- 4. ISG International -->
          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <article class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h2 class="heading-5">Recruitment Consultant &amp; Talent Acquisition Specialist</h2>
                  <p class="body-4 text-secondary mt-1">ISG International Service Group</p>
                </div>
                <span class="mono-meta caption-2 text-muted">June 2015 to December 2017</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Sourced and screened candidates for specialist and management positions, coordinated interviews and worked with clients on hiring requirements across industries.
              </p>
            </article>
          </li>

          <!-- 5. Adecco Slovenia -->
          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <article class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h2 class="heading-5">Recruitment Specialist</h2>
                  <p class="body-4 text-secondary mt-1">Adecco Slovenia · Ljubljana, Slovenia</p>
                </div>
                <span class="mono-meta caption-2 text-muted">June 2014 to March 2015</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Recruited across business functions: reviewing applications, identifying candidates and coordinating interviews with hiring managers.
              </p>
            </article>
          </li>

          <!-- 6. Education -->
          <li class="timeline-entry">
            <span class="timeline-node" aria-hidden="true"></span>
            <article class="card">
              <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px;">
                <div>
                  <h2 class="heading-5">Master's Degree in Human Resource Management</h2>
                  <p class="body-4 text-teal mt-1">University of Ljubljana</p>
                </div>
                <span class="mono-meta caption-2 text-muted">2012 to 2014</span>
              </div>
              <p class="body-5 text-secondary mt-2">
                Master of Science in Human Resource Management, specializing in organizational behavior, strategic talent acquisition, and European labor markets.
              </p>
            </article>
          </li>
        </ol>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-top">
        <div style="display: flex; align-items: center; gap: 12px;">
          <span class="brand-badge" aria-hidden="true">KD</span>
          <span class="caption-2 text-secondary">© 2026 Katia Danishevska</span>
        </div>

        <div class="footer-links">
          <a href="experience.html" class="footer-text-link caption-2" aria-current="page">Experience</a>
          <a href="mandates.html" class="footer-text-link caption-2">Focus</a>
          <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="footer-text-link caption-2">LinkedIn</a>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="privacy-dialog">Privacy</button>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="legal-dialog">Terms &amp; Notice</button>
          <span class="caption-2 text-muted">Crafted by Az. Consultant</span>
        </div>
      </div>

      <div class="footer-disclaimer">
        <p class="caption-5 text-muted" style="max-width: 760px;">
          <strong>Disclaimer:</strong> Independent personal website redesign concept prepared by Az. Consultant in response to Katia Danishevska's public LinkedIn post. All biography, tenure, and education details originate exclusively from publicly visible LinkedIn profile records, with no confidential data or official endorsement implied.
        </p>
        <a href="design-notes.html" class="caption-4 text-secondary">View Design &amp; Architecture Notes</a>
      </div>
    </div>
  </footer>

  <dialog id="privacy-dialog" class="site-dialog" closedby="any" aria-labelledby="privacy-title">
    <div class="dialog-head">
      <h2 id="privacy-title" class="heading-5">Privacy Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close privacy notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This static preview operates without analytics trackers, marketing cookies, or third party behavioral scripts.
    </p>
  </dialog>

  <dialog id="legal-dialog" class="site-dialog" closedby="any" aria-labelledby="legal-title">
    <div class="dialog-head">
      <h2 id="legal-title" class="heading-5">Terms &amp; Concept Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close terms and notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This site is an independent design submission created by Az. Consultant for evaluation by Katia Danishevska. Company names appear strictly as historical career references from public LinkedIn records.
    </p>
  </dialog>

  <script defer src="js/main.js"></script>
</body>
</html>

```

## File: `mandates.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="color-scheme" content="light">
  <script>
    try {
      var s = localStorage.getItem('color-scheme');
      if (s === 'dark') {
        document.querySelector('meta[name="color-scheme"]').content = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.querySelector('meta[name="color-scheme"]').content = 'light';
        document.documentElement.setAttribute('data-theme', 'light');
      }
    } catch (e) {
      document.documentElement.setAttribute('data-theme', 'light');
    }
  </script>

  <title>Areas of Focus | Katia Danishevska</title>
  <meta name="description" content="Recruitment for specialists, managers and senior leaders in fintech, blockchain and digital assets.">
  <link rel="canonical" href="https://katia-danishevska.pages.dev/mandates.html">

  <meta property="og:site_name" content="Katia Danishevska">
  <meta property="og:title" content="Areas of Focus | Katia Danishevska">
  <meta property="og:description" content="Recruitment for specialists, managers and senior leaders in fintech, blockchain and digital assets.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://katia-danishevska.pages.dev/mandates.html">
  <meta property="og:image" content="https://katia-danishevska.pages.dev/assets/og-card.jpg">

  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="apple-touch-icon" href="assets/apple-touch-icon.png">

  <!-- Typography: Geist & Geist Mono -->
  <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-sans/style.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-mono/style.min.css">

  <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <a href="#main" class="skip-link button-sm">Skip to content</a>
  <div id="scroll-progress-bar" class="scroll-progress-bar" aria-hidden="true"></div>
  <div id="nav-sentinel" class="nav-sentinel" aria-hidden="true"></div>

  <header class="site-nav-wrap">
    <nav id="site-nav" class="site-nav" aria-label="Primary">
      <a href="index.html" class="brand-mark" aria-label="Katia Danishevska Home">
        <span class="brand-badge" aria-hidden="true">KD</span>
        <span class="title-4">Katia Danishevska</span>
      </a>

      <ul class="nav-links">
        <li><a href="index.html" class="nav-link title-4">Overview</a></li>
        <li><a href="experience.html" class="nav-link title-4">Experience</a></li>
        <li><a href="mandates.html" class="nav-link title-4" aria-current="page">Focus</a></li>
        <li><a href="index.html#connect" class="nav-link title-4">Connect</a></li>
      </ul>

      <div class="nav-actions">
        <button id="theme-toggle" type="button" class="icon-btn" aria-label="Toggle color theme" aria-pressed="false">
          <span class="icon-crossfade" aria-hidden="true">
            <span class="theme-icon-sun">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><circle cx="128" cy="128" r="48"/><path d="M128 36v-12M128 232v-12M63 63l-9-9M202 202l-9-9M36 128H24M232 128h-12M63 193l-9 9M202 54l-9 9"/></svg>
            </span>
            <span class="theme-icon-moon">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><path d="M210.7 152.6A92 92 0 0 1 103.4 45.3a92 92 0 1 0 107.3 107.3Z"/></svg>
            </span>
          </span>
        </button>

        <button id="menu-toggle" type="button" class="icon-btn menu-toggle" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mobile-drawer">
          <span class="hamburger-lines" aria-hidden="true"><span></span><span></span><span></span></span>
        </button>
      </div>
    </nav>
  </header>

  <aside id="mobile-drawer" class="mobile-drawer" aria-label="Mobile menu" aria-hidden="true">
    <a href="index.html" class="mobile-drawer-link heading-5"><span>Overview</span><span class="mono-meta caption-4 text-muted">01</span></a>
    <a href="experience.html" class="mobile-drawer-link heading-5"><span>Experience</span><span class="mono-meta caption-4 text-muted">02</span></a>
    <a href="mandates.html" class="mobile-drawer-link heading-5"><span>Focus</span><span class="mono-meta caption-4 text-muted">03</span></a>
    <a href="index.html#connect" class="mobile-drawer-link heading-5"><span>Connect</span><span class="mono-meta caption-4 text-muted">04</span></a>
  </aside>

  <main id="main" tabindex="-1">
    <section class="section" style="padding-top: 144px;">
      <div class="container">
        <div style="max-width: 680px;">
          <a href="index.html" class="caption-2 text-secondary">← Back to Overview</a>
          <h1 class="heading-1 hero-gradient-text mt-2">Areas of Focus</h1>
          <p class="body-2 text-secondary mt-3">
            Recruitment for specialists, managers and senior leaders in fintech, blockchain and digital assets.
          </p>
          <div style="display: flex; flex-wrap: wrap; gap: 12px; margin-top: 24px;">
            <a href="assets/Katia-Danishevska-Executive-Dossier.pdf" download="Katia-Danishevska-Career-Summary.pdf" class="btn-pdf-download button-md" aria-label="Download Katia Danishevska Career Summary as PDF">
              <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M48 32h112l48 48v144a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8V40a8 8 0 0 1 8-8Z"/><path d="M160 32v48h48M128 120v64M96 152l32 32 32-32"/></svg>
              <span>Download Career Summary (PDF)</span>
            </a>
            <a href="experience.html" class="btn btn-secondary button-md">View Career Progression</a>
          </div>
        </div>

        <div class="grid-2 mt-6" style="gap: 24px;">
          <article class="card">
            <span class="mono-meta caption-3 text-teal">01 · LEADERSHIP</span>
            <h2 class="title-1 mt-2">Executive &amp; Department Heads</h2>
            <p class="body-5 text-secondary mt-2">
              Recruitment for department heads and selected leadership roles, defined together with hiring managers and founders to secure experienced leaders for growing businesses.
            </p>
            <ul style="display: flex; flex-direction: column; gap: 6px; margin-top: 12px;" class="body-6 text-secondary">
              <li>· Functional department leadership</li>
              <li>· Regional and market leads</li>
              <li>· Senior management calibration</li>
            </ul>
          </article>

          <article class="card">
            <span class="mono-meta caption-3 text-teal">02 · ENGINEERING</span>
            <h2 class="title-1 mt-2">Technology &amp; Digital Assets</h2>
            <p class="body-5 text-secondary mt-2">
              Technology roles across digital assets and financial services, from software architecture and blockchain engineering to technical leadership.
            </p>
            <ul style="display: flex; flex-direction: column; gap: 6px; margin-top: 12px;" class="body-6 text-secondary">
              <li>· Software engineering &amp; architecture</li>
              <li>· Blockchain &amp; distributed systems</li>
              <li>· Security &amp; technical infrastructure</li>
            </ul>
          </article>

          <article class="card">
            <span class="mono-meta caption-3 text-teal">03 · GOVERNANCE</span>
            <h2 class="title-1 mt-2">Compliance, Finance &amp; Operations</h2>
            <p class="body-5 text-secondary mt-2">
              Building resilient talent pipelines across regulatory compliance, operations, finance and business development roles.
            </p>
            <ul style="display: flex; flex-direction: column; gap: 6px; margin-top: 12px;" class="body-6 text-secondary">
              <li>· Regulatory compliance &amp; risk</li>
              <li>· Financial operations &amp; treasury</li>
              <li>· Core institutional processes</li>
            </ul>
          </article>

          <article class="card">
            <span class="mono-meta caption-3 text-teal">04 · STRATEGIC SOURCING</span>
            <h2 class="title-1 mt-2">Cross-Border Talent Pipelines</h2>
            <p class="body-5 text-secondary mt-2">
              Targeted international talent sourcing connecting high-caliber candidates across Switzerland, Slovenia, and wider European markets.
            </p>
            <ul style="display: flex; flex-direction: column; gap: 6px; margin-top: 12px;" class="body-6 text-secondary">
              <li>· Direct sourcing &amp; network referrals</li>
              <li>· Cross-cultural recruitment fluency</li>
              <li>· Market intelligence &amp; availability</li>
            </ul>
          </article>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-top">
        <div style="display: flex; align-items: center; gap: 12px;">
          <span class="brand-badge" aria-hidden="true">KD</span>
          <span class="caption-2 text-secondary">© 2026 Katia Danishevska</span>
        </div>

        <div class="footer-links">
          <a href="experience.html" class="footer-text-link caption-2">Experience</a>
          <a href="mandates.html" class="footer-text-link caption-2" aria-current="page">Focus</a>
          <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="footer-text-link caption-2">LinkedIn</a>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="privacy-dialog">Privacy</button>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="legal-dialog">Terms &amp; Notice</button>
          <span class="caption-2 text-muted">Crafted by Az. Consultant</span>
        </div>
      </div>

      <div class="footer-disclaimer">
        <p class="caption-5 text-muted" style="max-width: 760px;">
          <strong>Disclaimer:</strong> Independent personal website redesign concept prepared by Az. Consultant in response to Katia Danishevska's public LinkedIn post. All biography, tenure, and education details originate exclusively from publicly visible LinkedIn profile records, with no confidential data or official endorsement implied.
        </p>
        <a href="design-notes.html" class="caption-4 text-secondary">View Design &amp; Architecture Notes</a>
      </div>
    </div>
  </footer>

  <dialog id="privacy-dialog" class="site-dialog" closedby="any" aria-labelledby="privacy-title">
    <div class="dialog-head">
      <h2 id="privacy-title" class="heading-5">Privacy Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close privacy notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This static preview operates without analytics trackers, marketing cookies, or third party behavioral scripts.
    </p>
  </dialog>

  <dialog id="legal-dialog" class="site-dialog" closedby="any" aria-labelledby="legal-title">
    <div class="dialog-head">
      <h2 id="legal-title" class="heading-5">Terms &amp; Concept Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close terms and notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This site is an independent design submission created by Az. Consultant for evaluation by Katia Danishevska. Company names appear strictly as historical career references from public LinkedIn records.
    </p>
  </dialog>

  <script defer src="js/main.js"></script>
</body>
</html>

```

## File: `design-notes.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="color-scheme" content="light">
  <script>
    try {
      var s = localStorage.getItem('color-scheme');
      if (s === 'dark') {
        document.querySelector('meta[name="color-scheme"]').content = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.querySelector('meta[name="color-scheme"]').content = 'light';
        document.documentElement.setAttribute('data-theme', 'light');
      }
    } catch (e) {
      document.documentElement.setAttribute('data-theme', 'light');
    }
  </script>

  <title>Design &amp; Architecture Notes | Az. Consultant</title>
  <meta name="description" content="Engineering, typography, motion, accessibility, and edge deployment architecture prepared by Az. Consultant for Katia Danishevska.">
  <link rel="canonical" href="https://katia-danishevska.pages.dev/design-notes.html">

  <meta property="og:site_name" content="Katia Danishevska">
  <meta property="og:title" content="Design &amp; Architecture Notes | Prepared by Az. Consultant">
  <meta property="og:image" content="https://katia-danishevska.pages.dev/assets/og-card.jpg">
  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">

  <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-sans/style.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-mono/style.min.css">
  <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <a href="#main" class="skip-link button-sm">Skip to content</a>
  <div id="scroll-progress-bar" class="scroll-progress-bar" aria-hidden="true"></div>
  <div id="nav-sentinel" class="nav-sentinel" aria-hidden="true"></div>

  <header class="site-nav-wrap">
    <nav id="site-nav" class="site-nav" aria-label="Primary">
      <a href="index.html" class="brand-mark" aria-label="Katia Danishevska Home">
        <span class="brand-badge" aria-hidden="true">KD</span>
        <span class="title-4">Katia Danishevska</span>
      </a>

      <ul class="nav-links">
        <li><a href="index.html" class="nav-link title-4">Overview</a></li>
        <li><a href="experience.html" class="nav-link title-4">Experience</a></li>
        <li><a href="mandates.html" class="nav-link title-4">Focus</a></li>
        <li><a href="design-notes.html" class="nav-link title-4" aria-current="page">Craft Notes</a></li>
      </ul>

      <div class="nav-actions">
        <button id="theme-toggle" type="button" class="icon-btn" aria-label="Toggle color theme" aria-pressed="false">
          <span class="icon-crossfade" aria-hidden="true">
            <span class="theme-icon-sun">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><circle cx="128" cy="128" r="48"/><path d="M128 36v-12M128 232v-12M63 63l-9-9M202 202l-9-9M36 128H24M232 128h-12M63 193l-9 9M202 54l-9 9"/></svg>
            </span>
            <span class="theme-icon-moon">
              <svg width="18" height="18" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"><path d="M210.7 152.6A92 92 0 0 1 103.4 45.3a92 92 0 1 0 107.3 107.3Z"/></svg>
            </span>
          </span>
        </button>

        <button id="menu-toggle" type="button" class="icon-btn menu-toggle" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mobile-drawer">
          <span class="hamburger-lines" aria-hidden="true"><span></span><span></span><span></span></span>
        </button>
      </div>
    </nav>
  </header>

  <aside id="mobile-drawer" class="mobile-drawer" aria-label="Mobile menu" aria-hidden="true">
    <a href="index.html" class="mobile-drawer-link heading-5"><span>Return to Overview</span><span class="mono-meta caption-4 text-muted">01</span></a>
    <a href="experience.html" class="mobile-drawer-link heading-5"><span>Experience</span><span class="mono-meta caption-4 text-muted">02</span></a>
    <a href="mandates.html" class="mobile-drawer-link heading-5"><span>Focus</span><span class="mono-meta caption-4 text-muted">03</span></a>
  </aside>

  <main id="main" tabindex="-1">
    <section class="section" style="padding-top: 144px;">
      <div class="container">
        <div style="max-width: 680px;">
          <a href="index.html" class="caption-2 text-secondary">← Return to Personal Website</a>
          <h1 class="heading-1 hero-gradient-text mt-2">Design &amp; Architecture Notes</h1>
          <p class="body-2 text-secondary mt-3">
            Technical brief prepared by Az. Consultant outlining the visual choices, factual calibration, accessibility safeguards, and edge delivery architecture behind this redesign proposal.
          </p>
        </div>

        <!-- Architecture Wiring -->
        <div class="mt-6">
          <h2 class="heading-4 mb-3">System Architecture Wiring</h2>
          <div class="arch-pipeline">
            <article class="arch-node">
              <span class="mono-meta caption-3 text-teal">01 · SEMANTIC CORE</span>
              <h3 class="title-2">Zero Runtime HTML &amp; CSS</h3>
              <p class="body-6 text-secondary">
                Pure layered CSS tokens with zero client framework runtime, eliminating render blocking compilers and preserving instant paint across European and Asian networks.
              </p>
            </article>

            <article class="arch-node">
              <span class="mono-meta caption-3 text-teal">02 · ZERO-MOTION EDITORIAL</span>
              <h3 class="title-2">Quiet Luxury &amp; Instant Read</h3>
              <p class="body-6 text-secondary">
                Removed CPU-intensive canvas particle waves in favor of instant Swiss typographic layout, sub-140ms hover transitions, and immediate readability for executive partners.
              </p>
            </article>

            <article class="arch-node">
              <span class="mono-meta caption-3 text-teal">03 · COLOR &amp; ACCESSIBILITY</span>
              <h3 class="title-2">System Aware Light &amp; Dark</h3>
              <p class="body-6 text-secondary">
                Native color scheme meta wiring with early inline FOUC prevention, cross tab sync, native modal dialogs, keyboard focus rings, and inert drawer traps.
              </p>
            </article>

            <article class="arch-node">
              <span class="mono-meta caption-3 text-teal">04 · EDGE DELIVERY</span>
              <h3 class="title-2">Cloudflare Edge &amp; OG Logo</h3>
              <p class="body-6 text-secondary">
                Hardened response headers, dedicated custom 404 route, and verified 1200x630 plus 600x600 monogram assets for clean WhatsApp and LinkedIn previews.
              </p>
            </article>
          </div>
        </div>

        <div class="grid-2 mt-6">
          <article class="card">
            <h2 class="heading-5">Why This Direction Fits Katia's Brand</h2>
            <p class="body-5 text-secondary mt-2">
              Her career spans Swiss digital asset banking at AMINA Bank (Zug) and senior talent acquisition at SwissChain. Instead of generic dark gradients or synthetic portraits, the visual language pairs Swiss typographic restraint with warm alabaster light surfaces and calibrated dark graphite panels.
            </p>
          </article>

          <article class="card">
            <h2 class="heading-5">Collaboration Readiness</h2>
            <p class="body-5 text-secondary mt-2">
              Every section, text token, domain link, and contact endpoint can be wired directly to a custom domain and live mail relay on handoff. Prepared cleanly by Az. Consultant with full static portability.
            </p>
          </article>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-top">
        <div style="display: flex; align-items: center; gap: 12px;">
          <span class="brand-badge" aria-hidden="true">KD</span>
          <span class="caption-2 text-secondary">© 2026 Katia Danishevska</span>
        </div>

        <div class="footer-links">
          <a href="experience.html" class="footer-text-link caption-2">Experience</a>
          <a href="mandates.html" class="footer-text-link caption-2">Focus</a>
          <a href="https://www.linkedin.com/in/katia-danishevska-122224445" target="_blank" rel="noopener noreferrer" class="footer-text-link caption-2">LinkedIn</a>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="privacy-dialog">Privacy</button>
          <button type="button" class="footer-text-link caption-2" data-open-dialog="legal-dialog">Terms &amp; Notice</button>
          <span class="caption-2 text-muted">Crafted by Az. Consultant</span>
        </div>
      </div>

      <div class="footer-disclaimer">
        <p class="caption-5 text-muted" style="max-width: 760px;">
          <strong>Disclaimer:</strong> Independent personal website redesign concept prepared by Az. Consultant in response to Katia Danishevska's public LinkedIn post. All biography, tenure, and education details originate exclusively from publicly visible LinkedIn profile records, with no confidential data or official endorsement implied.
        </p>
      </div>
    </div>
  </footer>

  <dialog id="privacy-dialog" class="site-dialog" closedby="any" aria-labelledby="privacy-title">
    <div class="dialog-head">
      <h2 id="privacy-title" class="heading-5">Privacy Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close privacy notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This static preview operates without analytics trackers, marketing cookies, or third party behavioral scripts.
    </p>
  </dialog>

  <dialog id="legal-dialog" class="site-dialog" closedby="any" aria-labelledby="legal-title">
    <div class="dialog-head">
      <h2 id="legal-title" class="heading-5">Terms &amp; Concept Notice</h2>
      <form method="dialog">
        <button type="submit" class="icon-btn" aria-label="Close terms and notice">
          <svg width="16" height="16" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="20" stroke-linecap="round" aria-hidden="true"><path d="M56 56l144 144M200 56L56 200"/></svg>
        </button>
      </form>
    </div>
    <p class="body-5 text-secondary">
      This site is an independent design submission created by Az. Consultant for evaluation by Katia Danishevska. Company names appear strictly as historical career references from public LinkedIn records.
    </p>
  </dialog>

  <script defer src="js/main.js"></script>
</body>
</html>

```

## File: `404.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="color-scheme" content="light dark">
  <script>
    try {
      var s = localStorage.getItem('color-scheme');
      if (s === 'dark' || s === 'light') {
        document.querySelector('meta[name="color-scheme"]').content = s;
        document.documentElement.setAttribute('data-theme', s);
      }
    } catch (e) {}
  </script>

  <title>Page Not Found | Katia Danishevska</title>
  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-sans/style.min.css">
  <link rel="stylesheet" href="css/main.css">
</head>
<body style="min-height: 100vh; display: flex; flex-direction: column; justify-content: space-between;">
  <main id="main" class="container" style="margin-block: auto; max-width: 560px; text-align: center; padding-block: 64px;">
    <div class="dossier-frame">
      <div class="dossier-inner" style="align-items: center;">
        <div class="dossier-monogram" aria-hidden="true">KD</div>
        <span class="mono-meta caption-3 text-teal">404 · ROUTE NOT FOUND</span>
        <h1 class="heading-3">This page does not exist</h1>
        <p class="body-5 text-secondary">
          The page you requested has moved or is unavailable. Return to the main overview to explore Katia Danishevska's executive profile and career record.
        </p>
        <div style="display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;">
          <a href="index.html" class="btn btn-primary button-sm">Return to Overview</a>
          <a href="experience.html" class="btn btn-secondary button-sm">Career Dossier</a>
        </div>
      </div>
    </div>
  </main>

  <footer class="site-footer">
    <div class="container footer-top">
      <span class="caption-2 text-secondary">© 2026 Katia Danishevska</span>
      <span class="caption-2 text-muted">Crafted by Az. Consultant</span>
    </div>
  </footer>
  <script defer src="js/main.js"></script>
</body>
</html>

```

## File: `css/main.css`
```css
/* ==========================================================================
   Katia Danishevska — Design System & Layout Styles
   Tokens: B1 Typography (Geist / Geist Mono), B2 Spacing, B3 Radii,
           B4 Flat Surfaces, B7 Motion, Layered Surfaces & Tactile Craft
   ========================================================================== */

@layer reset, tokens, base, typography, components, utilities;

@layer tokens {
  :root {
    color-scheme: light dark;

    /* B2 Strict Spacing Scale */
    --sp-0: 0px;
    --sp-25: 2px;
    --sp-50: 4px;
    --sp-75: 8px;
    --sp-100: 12px;
    --sp-200: 16px;
    --sp-300: 24px;
    --sp-400: 32px;
    --sp-500: 40px;
    --sp-600: 48px;
    --sp-700: 64px;
    --sp-800: 80px;
    --sp-900: 96px;

    /* B3 Radii Scale */
    --r-sm: 6px;
    --r-md: 8px;
    --r-lg: 12px;
    --r-xl: 16px;
    --r-2xl: 24px;
    --r-full: 9999px;

    /* Motion Curves */
    --ease-smooth: cubic-bezier(0.22, 1, 0.36, 1);
    --ease-snappy: cubic-bezier(0.2, 0, 0, 1);

    /* Typography */
    --font-sans: 'Geist', system-ui, -apple-system, sans-serif;
    --font-mono: 'Geist Mono', ui-monospace, monospace;

    /* Light Mode Palette — Swiss Architectural Stone */
    --bg-canvas: #F7F6F2;
    --bg-band: #EFECE5;
    --bg-surface: #FFFFFF;
    --bg-elevated: #FFFFFF;
    --bg-subtle: #EAE7DF;
    --bg-nav: rgba(255, 255, 255, 0.84);
    --bg-drawer: rgba(247, 246, 242, 0.96);

    --ink-primary: #111316;
    --ink-secondary: #4B525C;
    --ink-muted: #68707A;
    --ink-faint: rgba(17, 19, 22, 0.28);

    --accent: #1D4ED8;
    --accent-soft: rgba(29, 78, 216, 0.08);
    --accent-text: #1E40AF;
    --teal: #0F766E;
    --teal-soft: rgba(15, 118, 110, 0.10);
    --error: #B91C1C;
    --error-soft: rgba(185, 28, 28, 0.08);

    --btn-primary-bg: #111316;
    --btn-primary-ink: #FFFFFF;
    --btn-primary-hover: #242830;

    --border-hairline: rgba(17, 19, 22, 0.09);
    --border-strong: rgba(17, 19, 22, 0.18);

    --shadow-border:
      0 0 0 1px rgba(0, 0, 0, 0.06),
      0 1px 2px -1px rgba(0, 0, 0, 0.06),
      0 2px 4px 0 rgba(0, 0, 0, 0.04);
    --shadow-border-hover:
      0 0 0 1px rgba(0, 0, 0, 0.11),
      0 4px 12px -2px rgba(0, 0, 0, 0.08),
      0 2px 4px 0 rgba(0, 0, 0, 0.04);
    --shadow-nav:
      0 0 0 1px rgba(0, 0, 0, 0.07),
      0 8px 24px -6px rgba(0, 0, 0, 0.08);

    --hero-grad-start: #000000;
    --hero-grad-end: #666666;
    --scrollbar-track: #EFECE5;
    --scrollbar-thumb: #9CA3AF;

    accent-color: var(--accent);
    scrollbar-color: var(--scrollbar-thumb) var(--scrollbar-track);
  }

  /* Reflect system preference when no explicit override */
  @media (prefers-color-scheme: dark) {
    :root:not(:has(> head > meta[name="color-scheme"][content="light"])) {
      color-scheme: dark;
      --bg-canvas: #000000;
      --bg-band: #131209;
      --bg-surface: #181818;
      --bg-elevated: #1F1F1F;
      --bg-subtle: #272727;
      --bg-nav: rgba(24, 24, 24, 0.84);
      --bg-drawer: rgba(0, 0, 0, 0.96);

      --ink-primary: #F5F6F7;
      --ink-secondary: #A3A9B2;
      --ink-muted: #78808A;
      --ink-faint: rgba(245, 246, 247, 0.28);

      --accent: #60A5FA;
      --accent-soft: rgba(96, 165, 250, 0.12);
      --accent-text: #93C5FD;
      --teal: #2DD4BF;
      --teal-soft: rgba(45, 212, 191, 0.12);
      --error: #F87171;
      --error-soft: rgba(248, 113, 113, 0.12);

      --btn-primary-bg: #F5F6F7;
      --btn-primary-ink: #111316;
      --btn-primary-hover: #FFFFFF;

      --border-hairline: rgba(255, 255, 255, 0.09);
      --border-strong: rgba(255, 255, 255, 0.18);

      --shadow-border: 0 0 0 1px rgba(255, 255, 255, 0.08);
      --shadow-border-hover: 0 0 0 1px rgba(255, 255, 255, 0.16);
      --shadow-nav:
        0 0 0 1px rgba(255, 255, 255, 0.10),
        0 12px 32px -8px rgba(0, 0, 0, 0.65);

      --hero-grad-start: #FFFFFF;
      --hero-grad-end: #9B9B9B;
      --scrollbar-track: #181818;
      --scrollbar-thumb: #52525B;
    }
  }

  /* Explicit dark override from <meta name="color-scheme"> or [data-theme="dark"] */
  :root:has(> head > meta[name="color-scheme"][content="dark"]),
  :root[data-theme="dark"] {
    color-scheme: dark;
    --bg-canvas: #000000;
    --bg-band: #131209;
    --bg-surface: #181818;
    --bg-elevated: #1F1F1F;
    --bg-subtle: #272727;
    --bg-nav: rgba(24, 24, 24, 0.84);
    --bg-drawer: rgba(0, 0, 0, 0.96);

    --ink-primary: #F5F6F7;
    --ink-secondary: #A3A9B2;
    --ink-muted: #78808A;
    --ink-faint: rgba(245, 246, 247, 0.28);

    --accent: #60A5FA;
    --accent-soft: rgba(96, 165, 250, 0.12);
    --accent-text: #93C5FD;
    --teal: #2DD4BF;
    --teal-soft: rgba(45, 212, 191, 0.12);
    --error: #F87171;
    --error-soft: rgba(248, 113, 113, 0.12);

    --btn-primary-bg: #F5F6F7;
    --btn-primary-ink: #111316;
    --btn-primary-hover: #FFFFFF;

    --border-hairline: rgba(255, 255, 255, 0.09);
    --border-strong: rgba(255, 255, 255, 0.18);

    --shadow-border: 0 0 0 1px rgba(255, 255, 255, 0.08);
    --shadow-border-hover: 0 0 0 1px rgba(255, 255, 255, 0.16);
    --shadow-nav:
      0 0 0 1px rgba(255, 255, 255, 0.10),
      0 12px 32px -8px rgba(0, 0, 0, 0.65);

    --hero-grad-start: #FFFFFF;
    --hero-grad-end: #9B9B9B;
    --scrollbar-track: #181818;
    --scrollbar-thumb: #52525B;
  }

  /* Explicit light override */
  :root:has(> head > meta[name="color-scheme"][content="light"]),
  :root[data-theme="light"] {
    color-scheme: light;
  }
}

@layer reset {
  *, *::before, *::after {
    box-sizing: border-box;
  }

  html {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    scroll-behavior: smooth;
  }

  @media (prefers-reduced-motion: reduce) {
    html {
      scroll-behavior: auto;
    }
  }

  body {
    margin: 0;
    font-family: var(--font-sans);
    background-color: var(--bg-canvas);
    color: var(--ink-primary);
    overflow-x: clip;
    transition-property: background-color, color;
    transition-duration: 300ms;
    transition-timing-function: var(--ease-smooth);
  }

  h1, h2, h3, h4, h5, h6, p, ul, ol, dl, dd, figure {
    margin: 0;
  }

  ul, ol {
    padding: 0;
    list-style: none;
  }

  a {
    color: inherit;
    text-decoration: none;
  }

  button, input, textarea, select {
    font: inherit;
    color: inherit;
  }

  img, svg, canvas {
    display: block;
    max-width: 100%;
  }
}

@layer typography {
  /* Named text styles mapped strictly to Tailwind scale steps */
  .heading-1 {
    font-size: 2.25rem;
    line-height: 2.5rem;
    font-weight: 600;
    letter-spacing: -0.03em;
    text-wrap: balance;
  }

  @media (min-width: 768px) {
    .heading-1 {
      font-size: 3.75rem;
      line-height: 1;
    }
  }

  .heading-2 {
    font-size: 2.25rem;
    line-height: 2.5rem;
    font-weight: 600;
    letter-spacing: -0.025em;
    text-wrap: balance;
  }

  @media (min-width: 768px) {
    .heading-2 {
      font-size: 3rem;
      line-height: 1;
    }
  }

  .heading-3 {
    font-size: 1.875rem;
    line-height: 2.25rem;
    font-weight: 600;
    letter-spacing: -0.02em;
    text-wrap: balance;
  }

  @media (min-width: 768px) {
    .heading-3 {
      font-size: 2.25rem;
      line-height: 2.5rem;
    }
  }

  .heading-4 {
    font-size: 1.5rem;
    line-height: 2rem;
    font-weight: 600;
    letter-spacing: -0.015em;
    text-wrap: balance;
  }

  @media (min-width: 768px) {
    .heading-4 {
      font-size: 1.875rem;
      line-height: 2.25rem;
    }
  }

  .heading-5 {
    font-size: 1.5rem;
    line-height: 2rem;
    font-weight: 600;
    letter-spacing: -0.01em;
    text-wrap: balance;
  }

  .heading-6 {
    font-size: 1.25rem;
    line-height: 1.75rem;
    font-weight: 600;
    letter-spacing: -0.01em;
    text-wrap: balance;
  }

  .title-1 { font-size: 1.25rem; line-height: 1.75rem; font-weight: 500; text-wrap: balance; }
  .title-2 { font-size: 1.125rem; line-height: 1.75rem; font-weight: 500; }
  .title-3 { font-size: 1rem; line-height: 1.5rem; font-weight: 500; }
  .title-4 { font-size: 0.875rem; line-height: 1.25rem; font-weight: 500; }
  .title-5 { font-size: 0.75rem; line-height: 1rem; font-weight: 500; }

  .body-1 { font-size: 1rem; line-height: 1.5rem; font-weight: 600; text-wrap: pretty; }
  .body-2 { font-size: 1rem; line-height: 1.5rem; font-weight: 500; text-wrap: pretty; }
  .body-3 { font-size: 1rem; line-height: 1.5rem; font-weight: 400; text-wrap: pretty; }
  .body-4 { font-size: 0.875rem; line-height: 1.25rem; font-weight: 600; text-wrap: pretty; }
  .body-5 { font-size: 0.875rem; line-height: 1.25rem; font-weight: 500; text-wrap: pretty; }
  .body-6 { font-size: 0.875rem; line-height: 1.25rem; font-weight: 400; text-wrap: pretty; }

  .button-lg { font-size: 1.125rem; line-height: 1.75rem; font-weight: 600; }
  .button-md { font-size: 1rem; line-height: 1.5rem; font-weight: 600; }
  .button-sm { font-size: 0.875rem; line-height: 1.25rem; font-weight: 600; }
  .button-xsm { font-size: 0.75rem; line-height: 1rem; font-weight: 600; }

  .caption-1 { font-size: 0.875rem; line-height: 1.25rem; font-weight: 500; }
  .caption-2 { font-size: 0.875rem; line-height: 1.25rem; font-weight: 400; }
  .caption-3 { font-size: 0.75rem; line-height: 1rem; font-weight: 600; }
  .caption-4 { font-size: 0.75rem; line-height: 1rem; font-weight: 500; }
  .caption-5 { font-size: 0.75rem; line-height: 1rem; font-weight: 400; }

  .mono-meta {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
  }

  .tabular-nums {
    font-variant-numeric: tabular-nums;
  }

  /* B5 Hero Gradient Text (sole permitted gradient) */
  .hero-gradient-text {
    background: linear-gradient(90deg, var(--hero-grad-start), var(--hero-grad-end));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
}

@layer base {
  :where(a:any-link, button, input, textarea, select, summary):focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  [inert], [inert] * {
    opacity: 0.5;
    pointer-events: none;
    user-select: none;
  }

  .skip-link {
    position: fixed;
    inset-block-start: -100px;
    inset-inline-start: var(--sp-200);
    z-index: 200;
    padding: var(--sp-100) var(--sp-200);
    border-radius: var(--r-md);
    background-color: var(--btn-primary-bg);
    color: var(--btn-primary-ink);
    box-shadow: var(--shadow-nav);
    transition-property: inset-block-start;
    transition-duration: 200ms;
    transition-timing-function: var(--ease-smooth);
  }

  .skip-link:focus {
    inset-block-start: var(--sp-200);
  }

  .visually-hidden:where(:not(:focus-within, :active)) {
    position: absolute !important;
    clip-path: inset(50%) !important;
    overflow: hidden !important;
    width: 1px !important;
    height: 1px !important;
    margin: -1px !important;
    padding: 0 !important;
    border: 0 !important;
    white-space: nowrap !important;
  }
}

@layer components {
  /* Scroll Progress Hairline (modern-web-guidance: scroll-progress-indicator) */
  .scroll-progress-bar {
    position: fixed;
    inset-block-start: 0;
    inset-inline-start: 0;
    width: 100%;
    height: 2px;
    background-color: var(--teal);
    transform-origin: 0 50%;
    transform: scaleX(0);
    z-index: 90;
    pointer-events: none;
  }

  @media (prefers-reduced-motion: no-preference) {
    @supports (animation-timeline: scroll()) {
      @keyframes doc-scroll-progress {
        from { transform: scaleX(0); }
        to { transform: scaleX(1); }
      }

      .scroll-progress-bar {
        animation: doc-scroll-progress auto linear;
        animation-timeline: scroll(root block);
      }
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .scroll-progress-bar {
      display: none;
    }
  }

  /* Layout Container */
  .container {
    width: 100%;
    max-width: 1120px;
    margin-inline: auto;
    padding-inline: var(--sp-200);
  }

  @media (min-width: 768px) {
    .container {
      padding-inline: var(--sp-400);
    }
  }

  .section {
    padding-block: var(--sp-700);
  }

  @media (min-width: 768px) {
    .section {
      padding-block: var(--sp-900);
    }
  }

  .section-band {
    background-color: var(--bg-band);
    border-block: 1px solid var(--border-hairline);
  }

  /* Floating Glass Navigation (B7 Navigation) */
  .nav-sentinel {
    position: absolute;
    top: 0;
    left: 0;
    width: 1px;
    height: 80px;
    pointer-events: none;
  }

  .site-nav-wrap {
    position: fixed;
    inset-block-start: var(--sp-200);
    inset-inline: 0;
    z-index: 70;
    display: flex;
    justify-content: center;
    padding-inline: var(--sp-200);
    pointer-events: none;
  }

  .site-nav {
    pointer-events: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--sp-300);
    padding: var(--sp-75) var(--sp-100);
    border-radius: var(--r-xl);
    background-color: var(--bg-nav);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    box-shadow: var(--shadow-border);
    transition-property: box-shadow, background-color, transform;
    transition-duration: 350ms;
    transition-timing-function: var(--ease-smooth);
    max-width: 100%;
  }

  .site-nav.is-elevated {
    box-shadow: var(--shadow-nav);
  }

  .brand-mark {
    display: inline-flex;
    align-items: center;
    gap: var(--sp-100);
    min-height: 44px;
    padding-inline: var(--sp-75);
    border-radius: var(--r-md);
    transition-property: opacity;
    transition-duration: 250ms;
    transition-timing-function: var(--ease-smooth);
  }

  .brand-mark:hover {
    opacity: 0.82;
  }

  .brand-badge {
    width: 32px;
    height: 32px;
    border-radius: var(--r-md);
    background-color: var(--btn-primary-bg);
    color: var(--btn-primary-ink);
    display: grid;
    place-items: center;
    font-weight: 600;
    font-size: 0.875rem;
    letter-spacing: -0.04em;
    position: relative;
  }

  .brand-badge::after {
    content: "";
    position: absolute;
    top: 5px;
    right: 5px;
    width: 5px;
    height: 5px;
    border-radius: var(--r-full);
    background-color: var(--teal);
  }

  .nav-links {
    display: none;
    align-items: center;
    gap: var(--sp-50);
  }

  @media (min-width: 820px) {
    .nav-links {
      display: flex;
    }
  }

  .nav-link {
    display: inline-flex;
    align-items: center;
    min-height: 40px;
    padding-inline: var(--sp-100);
    border-radius: var(--r-md);
    color: var(--ink-secondary);
    transition-property: color, background-color;
    transition-duration: 250ms;
    transition-timing-function: var(--ease-smooth);
    white-space: nowrap;
  }

  .nav-link:hover {
    color: var(--ink-primary);
    background-color: var(--bg-subtle);
  }

  .nav-link[aria-current="page"],
  .nav-link.is-active {
    color: var(--ink-primary);
    background-color: var(--bg-subtle);
  }

  .nav-actions {
    display: flex;
    align-items: center;
    gap: var(--sp-75);
  }

  /* Icon Toggle & Contextual Cross-Fade */
  .icon-btn {
    position: relative;
    display: inline-grid;
    place-items: center;
    min-width: 40px;
    min-height: 40px;
    border: 0;
    border-radius: var(--r-md);
    background-color: var(--bg-subtle);
    color: var(--ink-primary);
    cursor: pointer;
    box-shadow: var(--shadow-border);
    transition-property: background-color, transform, box-shadow;
    transition-duration: 250ms;
    transition-timing-function: var(--ease-snappy);
  }

  .icon-btn:hover {
    box-shadow: var(--shadow-border-hover);
  }

  .icon-btn:active {
    transform: scale(0.96);
  }

  .icon-crossfade {
    position: relative;
    width: 18px;
    height: 18px;
  }

  .icon-crossfade > span {
    position: absolute;
    inset: 0;
    display: grid;
    place-items: center;
    transition-property: opacity, transform, filter;
    transition-duration: 300ms;
    transition-timing-function: var(--ease-snappy);
  }

  /* Light vs Dark Icon state driven cleanly via CSS color-scheme / data-theme */
  .theme-icon-sun {
    opacity: 1;
    transform: scale(1);
    filter: blur(0px);
  }
  .theme-icon-moon {
    opacity: 0;
    transform: scale(0.25);
    filter: blur(4px);
  }

  @media (prefers-color-scheme: dark) {
    :root:not(:has(> head > meta[name="color-scheme"][content="light"])) .theme-icon-sun {
      opacity: 0;
      transform: scale(0.25);
      filter: blur(4px);
    }
    :root:not(:has(> head > meta[name="color-scheme"][content="light"])) .theme-icon-moon {
      opacity: 1;
      transform: scale(1);
      filter: blur(0px);
    }
  }

  :root[data-theme="dark"] .theme-icon-sun,
  :root:has(> head > meta[name="color-scheme"][content="dark"]) .theme-icon-sun {
    opacity: 0;
    transform: scale(0.25);
    filter: blur(4px);
  }

  :root[data-theme="dark"] .theme-icon-moon,
  :root:has(> head > meta[name="color-scheme"][content="dark"]) .theme-icon-moon {
    opacity: 1;
    transform: scale(1);
    filter: blur(0px);
  }

  /* Contextual Copy Button Crossfade */
  .copy-icon-default {
    opacity: 1;
    transform: scale(1);
    filter: blur(0px);
  }
  .copy-icon-check {
    opacity: 0;
    transform: scale(0.25);
    filter: blur(4px);
    color: var(--teal);
  }
  [data-copied="true"] .copy-icon-default {
    opacity: 0;
    transform: scale(0.25);
    filter: blur(4px);
  }
  [data-copied="true"] .copy-icon-check {
    opacity: 1;
    transform: scale(1);
    filter: blur(0px);
  }

  /* Architecture Diagram Grid (design-notes.html) */
  .arch-pipeline {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-200);
  }
  @media (min-width: 768px) {
    .arch-pipeline {
      grid-template-columns: repeat(4, minmax(0, 1fr));
    }
  }
  .arch-node {
    background-color: var(--bg-surface);
    border-radius: var(--r-xl);
    padding: var(--sp-300);
    box-shadow: var(--shadow-border);
    display: flex;
    flex-direction: column;
    gap: var(--sp-100);
  }

  /* Menu Open / Close morph icon (B7) */
  .menu-toggle {
    display: inline-grid;
  }

  @media (min-width: 820px) {
    .menu-toggle {
      display: none;
    }
  }

  .hamburger-lines {
    width: 18px;
    height: 12px;
    position: relative;
  }

  .hamburger-lines span {
    position: absolute;
    left: 0;
    width: 100%;
    height: 1.5px;
    background-color: currentColor;
    border-radius: 2px;
    transition-property: transform, opacity;
    transition-duration: 350ms;
    transition-timing-function: var(--ease-smooth);
  }

  .hamburger-lines span:nth-child(1) { top: 0; }
  .hamburger-lines span:nth-child(2) { top: 5.25px; }
  .hamburger-lines span:nth-child(3) { top: 10.5px; }

  .menu-toggle[aria-expanded="true"] .hamburger-lines span:nth-child(1) {
    transform: translateY(5.25px) rotate(45deg);
  }
  .menu-toggle[aria-expanded="true"] .hamburger-lines span:nth-child(2) {
    opacity: 0;
    transform: scaleX(0);
  }
  .menu-toggle[aria-expanded="true"] .hamburger-lines span:nth-child(3) {
    transform: translateY(-5.25px) rotate(-45deg);
  }

  /* Mobile Full-Height Drawer (B7) */
  .mobile-drawer {
    position: fixed;
    inset: 0;
    z-index: 65;
    background-color: var(--bg-drawer);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: var(--sp-800) var(--sp-300) var(--sp-500);
    gap: var(--sp-200);
    opacity: 0;
    pointer-events: none;
    transition-property: opacity;
    transition-duration: 350ms;
    transition-timing-function: var(--ease-smooth);
  }

  .mobile-drawer.is-open {
    opacity: 1;
    pointer-events: auto;
  }

  .mobile-drawer-link {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-block: var(--sp-200);
    border-bottom: 1px solid var(--border-hairline);
    opacity: 0;
    transform: translateY(24px);
    transition-property: opacity, transform, color;
    transition-duration: 450ms;
    transition-timing-function: var(--ease-smooth);
  }

  .mobile-drawer.is-open .mobile-drawer-link {
    opacity: 1;
    transform: translateY(0);
  }

  /* Buttons — B2 (8px/12px base, optical icon padding) & tactile press */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--sp-75);
    min-height: 44px;
    padding: var(--sp-75) var(--sp-200);
    border-radius: var(--r-md);
    border: 0;
    cursor: pointer;
    text-decoration: none;
    white-space: nowrap;
    transition-property: background-color, color, transform, box-shadow;
    transition-duration: 250ms;
    transition-timing-function: var(--ease-snappy);
  }

  .btn:active:not(:disabled) {
    transform: scale(0.96);
  }

  .btn-with-icon {
    padding-inline-start: var(--sp-200);
    padding-inline-end: 14px;
  }

  .btn-primary {
    background-color: var(--btn-primary-bg);
    color: var(--btn-primary-ink);
    box-shadow: var(--shadow-border);
  }

  .btn-primary:hover:not(:disabled) {
    background-color: var(--btn-primary-hover);
    box-shadow: var(--shadow-border-hover);
  }

  .btn-secondary {
    background-color: var(--bg-surface);
    color: var(--ink-primary);
    box-shadow: var(--shadow-border);
  }

  .btn-secondary:hover:not(:disabled) {
    background-color: var(--bg-subtle);
    box-shadow: var(--shadow-border-hover);
  }

  .btn-sm {
    min-height: 36px;
    padding: var(--sp-75) var(--sp-100);
    border-radius: var(--r-md);
  }

  .btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  /* Hero Section (Asymmetric Split + Flux Canvas) */
  .hero {
    position: relative;
    min-height: min(92vh, 840px);
    display: flex;
    align-items: center;
    padding-block: 96px var(--sp-600);
    overflow: hidden;
  }

  @media (min-width: 768px) {
    .hero {
      padding-block: 120px var(--sp-700);
    }
  }

  .flux-canvas {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 0;
  }

  .hero-grid {
    position: relative;
    z-index: 2;
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-400);
    align-items: center;
  }

  @media (min-width: 960px) {
    .hero-grid {
      grid-template-columns: 1.25fr 0.75fr;
      gap: var(--sp-600);
    }
  }

  .hero-copy {
    max-width: 680px;
  }

  .hero-sub {
    max-width: 680px;
    margin-top: var(--sp-300);
    color: var(--ink-secondary);
  }

  .hero-role-line {
    display: inline-flex;
    align-items: center;
    gap: var(--sp-100);
    margin-bottom: var(--sp-300);
    color: var(--ink-secondary);
  }

  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: var(--r-full);
    background-color: var(--teal);
    flex-shrink: 0;
  }

  .hero-actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--sp-200);
    margin-top: var(--sp-400);
  }

  .hero-proof-strip {
    margin-top: var(--sp-500);
    padding-top: var(--sp-300);
    border-top: 1px solid var(--border-hairline);
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: var(--sp-200);
  }

  @media (max-width: 480px) {
    .hero-proof-strip {
      grid-template-columns: 1fr;
      gap: var(--sp-200);
    }
  }

  /* Concentric Architectural Dossier Card (Hero Visual Anchor) */
  .dossier-frame {
    padding: var(--sp-100);
    border-radius: var(--r-2xl);
    background-color: var(--bg-surface);
    box-shadow: var(--shadow-border);
  }

  .dossier-inner {
    padding: var(--sp-300);
    border-radius: var(--r-lg);
    background-color: var(--bg-band);
    box-shadow: var(--shadow-border);
    display: flex;
    flex-direction: column;
    gap: var(--sp-300);
  }

  .dossier-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--sp-200);
  }

  .dossier-monogram {
    width: 56px;
    height: 56px;
    border-radius: var(--r-lg);
    background-color: var(--btn-primary-bg);
    color: var(--btn-primary-ink);
    display: grid;
    place-items: center;
    font-size: 1.25rem;
    font-weight: 600;
    letter-spacing: -0.04em;
    position: relative;
  }

  .dossier-monogram::after {
    content: "";
    position: absolute;
    top: 10px;
    right: 10px;
    width: 7px;
    height: 7px;
    border-radius: var(--r-full);
    background-color: var(--teal);
  }

  .dossier-list {
    display: flex;
    flex-direction: column;
    gap: var(--sp-100);
    padding-block: var(--sp-200);
    border-block: 1px solid var(--border-hairline);
  }

  .dossier-row {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: var(--sp-200);
  }

  /* Zero-Motion Swiss Entrance — Instant Crisp Render */
  .hero-stagger {
    opacity: 1;
    transform: none;
    filter: none;
  }

  /* B11 Mandatory Tagline Reveal */
  .tagline-section {
    padding-block: var(--sp-800);
  }

  @media (min-width: 768px) {
    .tagline-section {
      padding-block: var(--sp-900);
    }
  }

  .tagline-text {
    max-width: 680px;
    text-wrap: balance;
  }

  .tagline-word {
    color: var(--ink-primary);
  }

  .tagline-word.is-lit {
    color: var(--ink-primary);
  }

  @media (prefers-reduced-motion: reduce) {
    .tagline-word {
      color: var(--ink-primary);
      transition: none;
    }
  }

  /* Zero-Motion Immediate Render — No Scroll Lag */
  .reveal-block {
    opacity: 1;
    transform: none;
  }

  .js-ready .reveal-block {
    opacity: 1;
    transform: none;
  }

  .js-ready .reveal-block.is-visible {
    opacity: 1;
    transform: none;
  }

  /* Surface Cards — Layered Shadows + Concentric Math */
  .card {
    background-color: var(--bg-surface);
    border-radius: var(--r-xl);
    padding: var(--sp-300);
    box-shadow: var(--shadow-border);
    transition-property: box-shadow, transform;
    transition-duration: 300ms;
    transition-timing-function: var(--ease-smooth);
  }

  .card-interactive:hover {
    box-shadow: var(--shadow-border-hover);
    transform: translateY(-2px);
  }

  .card-icon-box {
    width: 40px;
    height: 40px;
    border-radius: var(--r-md);
    background-color: var(--bg-subtle);
    color: var(--ink-primary);
    display: grid;
    place-items: center;
    margin-bottom: var(--sp-200);
    box-shadow: var(--shadow-border);
  }

  /* Grids */
  .grid-2 {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-400);
  }

  @media (min-width: 768px) {
    .grid-2 {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  .grid-3 {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-300);
  }

  @media (min-width: 768px) {
    .grid-3 {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }
  }

  .grid-asymmetric {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-400);
    align-items: start;
  }

  @media (min-width: 960px) {
    .grid-asymmetric {
      grid-template-columns: 1.15fr 0.85fr;
      gap: var(--sp-500);
    }
  }

  /* Interactive Canvas Atlas Container */
  .atlas-shell {
    padding: var(--sp-100);
    border-radius: var(--r-2xl);
    background-color: var(--bg-surface);
    box-shadow: var(--shadow-border);
  }

  .atlas-toolbar {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: var(--sp-100);
    padding: var(--sp-100) var(--sp-200);
  }

  .segmented {
    display: inline-flex;
    padding: var(--sp-50);
    border-radius: var(--r-lg);
    background-color: var(--bg-subtle);
    gap: var(--sp-50);
  }

  .segmented-btn {
    min-height: 36px;
    padding: var(--sp-50) var(--sp-200);
    border: 0;
    border-radius: var(--r-md);
    background-color: transparent;
    color: var(--ink-secondary);
    cursor: pointer;
    transition-property: background-color, color, transform, box-shadow;
    transition-duration: 250ms;
    transition-timing-function: var(--ease-snappy);
  }

  .segmented-btn:active {
    transform: scale(0.96);
  }

  .segmented-btn[aria-pressed="true"] {
    background-color: var(--bg-surface);
    color: var(--ink-primary);
    box-shadow: var(--shadow-border);
  }

  .corridor-canvas-box {
    position: relative;
    border-radius: var(--r-lg);
    background-color: var(--bg-band);
    box-shadow: var(--shadow-border);
    overflow: hidden;
  }

  #corridor-canvas {
    width: 100%;
    height: 360px;
    cursor: pointer;
  }

  .atlas-readout {
    padding: var(--sp-200);
    display: flex;
    flex-direction: column;
    gap: var(--sp-75);
  }

  /* Node Selector Chips for Keyboard & Screen Reader Parity */
  .hub-chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--sp-75);
    margin-top: var(--sp-200);
  }

  .hub-chip {
    min-height: 36px;
    padding: var(--sp-75) var(--sp-100);
    border: 0;
    border-radius: var(--r-md);
    background-color: var(--bg-subtle);
    color: var(--ink-secondary);
    cursor: pointer;
    box-shadow: var(--shadow-border);
    transition-property: background-color, color, transform, box-shadow;
    transition-duration: 200ms;
    transition-timing-function: var(--ease-snappy);
  }

  .hub-chip:hover {
    color: var(--ink-primary);
    box-shadow: var(--shadow-border-hover);
  }

  .hub-chip:active {
    transform: scale(0.96);
  }

  .hub-chip[aria-pressed="true"] {
    background-color: var(--btn-primary-bg);
    color: var(--btn-primary-ink);
  }

  /* Split Accordion Component */
  .split-accordion {
    display: flex;
    flex-direction: column;
  }

  .split-acc-item {
    background-color: var(--bg-surface);
    box-shadow: var(--shadow-border);
    transition-property: margin, border-radius, box-shadow, background-color;
    transition-duration: 320ms;
    transition-timing-function: var(--ease-smooth);
    border-radius: 0;
  }

  .split-acc-item:first-child {
    border-top-left-radius: var(--r-xl);
    border-top-right-radius: var(--r-xl);
  }

  .split-acc-item:last-child {
    border-bottom-left-radius: var(--r-xl);
    border-bottom-right-radius: var(--r-xl);
  }

  .split-acc-item.is-open {
    border-radius: var(--r-xl);
    margin-block: var(--sp-100);
    box-shadow: var(--shadow-border-hover);
  }

  .split-acc-item.is-before-open {
    border-bottom-left-radius: var(--r-xl);
    border-bottom-right-radius: var(--r-xl);
  }

  .split-acc-item.is-after-open {
    border-top-left-radius: var(--r-xl);
    border-top-right-radius: var(--r-xl);
  }

  .split-acc-item:first-child.is-open {
    margin-block-start: 0;
  }

  .split-acc-item:last-child.is-open {
    margin-block-end: 0;
  }

  .split-acc-trigger {
    width: 100%;
    min-height: 56px;
    padding: var(--sp-200) var(--sp-300);
    border: 0;
    background: transparent;
    text-align: left;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--sp-200);
    cursor: pointer;
    color: var(--ink-primary);
  }

  .split-acc-chevron {
    transition-property: transform;
    transition-duration: 300ms;
    transition-timing-function: var(--ease-snappy);
    flex-shrink: 0;
    color: var(--ink-secondary);
  }

  .split-acc-item.is-open .split-acc-chevron {
    transform: rotate(180deg);
  }

  .split-acc-panel {
    display: grid;
    grid-template-rows: 0fr;
    transition-property: grid-template-rows;
    transition-duration: 320ms;
    transition-timing-function: var(--ease-smooth);
  }

  .split-acc-item.is-open .split-acc-panel {
    grid-template-rows: 1fr;
  }

  .split-acc-inner {
    overflow: hidden;
  }

  .split-acc-content {
    padding: 0 var(--sp-300) var(--sp-300);
    color: var(--ink-secondary);
  }

  /* Career Timeline */
  .timeline {
    position: relative;
    display: flex;
    flex-direction: column;
    gap: var(--sp-300);
    padding-inline-start: var(--sp-400);
  }

  .timeline::before {
    content: "";
    position: absolute;
    inset-block: var(--sp-100);
    inset-inline-start: 7px;
    width: 1px;
    background-color: var(--border-strong);
  }

  .timeline-entry {
    position: relative;
  }

  .timeline-node {
    position: absolute;
    inset-inline-start: calc(-1 * var(--sp-400));
    top: 26px;
    width: 15px;
    height: 15px;
    border-radius: var(--r-full);
    background-color: var(--bg-canvas);
    border: 3px solid var(--ink-muted);
  }

  .timeline-entry.is-current .timeline-node {
    border-color: var(--teal);
  }

  /* Form Controls (modern-web-guidance forms + validate-input-after-interaction) */
  .form-grid {
    display: flex;
    flex-direction: column;
    gap: var(--sp-200);
  }

  .field-group {
    display: flex;
    flex-direction: column;
    gap: var(--sp-75);
  }

  .field-input,
  .field-textarea,
  .field-select {
    width: 100%;
    min-height: 48px;
    padding: var(--sp-100) var(--sp-200);
    border-radius: var(--r-md);
    border: 1px solid var(--border-strong);
    background-color: var(--bg-canvas);
    color: var(--ink-primary);
    font-size: max(1rem, 1em);
    transition-property: border-color, box-shadow, background-color;
    transition-duration: 200ms;
    transition-timing-function: var(--ease-snappy);
  }

  .field-textarea {
    min-height: 120px;
    resize: vertical;
  }

  .field-input:user-invalid,
  .field-textarea:user-invalid,
  .field-input[aria-invalid="true"],
  .field-textarea[aria-invalid="true"] {
    border-color: var(--error);
    background-color: var(--error-soft);
  }

  .field-error {
    color: var(--error);
    min-height: 16px;
  }

  .form-status {
    padding: var(--sp-200);
    border-radius: var(--r-md);
    background-color: var(--teal-soft);
    color: var(--ink-primary);
    box-shadow: var(--shadow-border);
  }

  /* Skeleton Bar for calm submit feedback */
  .skeleton-lines {
    display: flex;
    flex-direction: column;
    gap: var(--sp-100);
    padding: var(--sp-200);
    border-radius: var(--r-md);
    background-color: var(--bg-band);
  }

  .skeleton-bar {
    height: 12px;
    border-radius: var(--r-sm);
    background-color: var(--bg-subtle);
  }

  /* Native Modal <dialog> (modern-web-guidance html/accessibility) */
  dialog.site-dialog {
    margin: auto;
    width: min(560px, calc(100vw - 32px));
    padding: var(--sp-400);
    border: 0;
    border-radius: var(--r-2xl);
    background-color: var(--bg-surface);
    color: var(--ink-primary);
    box-shadow: var(--shadow-nav);
  }

  dialog.site-dialog::backdrop {
    background-color: rgba(0, 0, 0, 0.56);
    backdrop-filter: blur(6px);
  }

  .dialog-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--sp-200);
    margin-bottom: var(--sp-200);
  }

  /* Footer & Official Disclaimer */
  .site-footer {
    border-top: 1px solid var(--border-hairline);
    padding-block: var(--sp-600) var(--sp-500);
    background-color: var(--bg-canvas);
  }

  .footer-top {
    display: flex;
    flex-direction: column;
    gap: var(--sp-300);
    justify-content: space-between;
  }

  @media (min-width: 768px) {
    .footer-top {
      flex-direction: row;
      align-items: center;
    }
  }

  .footer-links {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--sp-300);
  }

  .footer-text-link {
    color: var(--ink-secondary);
    background: transparent;
    border: 0;
    padding: var(--sp-50) 0;
    cursor: pointer;
    transition-property: color;
    transition-duration: 200ms;
    transition-timing-function: var(--ease-smooth);
  }

  .footer-text-link:hover {
    color: var(--ink-primary);
  }

  .footer-disclaimer {
    margin-top: var(--sp-300);
    padding-top: var(--sp-300);
    border-top: 1px solid var(--border-hairline);
    display: flex;
    flex-direction: column;
    gap: var(--sp-100);
  }

  @media (min-width: 768px) {
    .footer-disclaimer {
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      gap: var(--sp-400);
    }
  }
}

@layer utilities {
  .text-secondary { color: var(--ink-secondary); }
  .text-muted { color: var(--ink-muted); }
  .text-accent { color: var(--accent-text); }
  .text-teal { color: var(--teal); }
  .mt-1 { margin-top: var(--sp-75); }
  .mt-2 { margin-top: var(--sp-200); }
  .mt-3 { margin-top: var(--sp-300); }
  .mt-4 { margin-top: var(--sp-400); }
  .mt-6 { margin-top: var(--sp-600); }
  .mb-2 { margin-bottom: var(--sp-200); }
  .mb-3 { margin-bottom: var(--sp-300); }
  .mb-4 { margin-bottom: var(--sp-400); }
  .hidden { display: none !important; }
}

  /* ==========================================================================
     Zero-Motion Swiss Editorial & Executive Practice Additions
     ========================================================================== */

  .btn-pdf-download {
    display: inline-flex;
    align-items: center;
    gap: var(--sp-100);
    padding: var(--sp-100) var(--sp-300);
    border-radius: var(--r-md);
    background-color: var(--bg-surface);
    color: var(--ink-primary);
    border: 1px solid var(--border-strong);
    box-shadow: var(--shadow-border);
    font-size: 0.875rem;
    font-weight: 500;
    text-decoration: none;
    transition: background-color 140ms var(--ease-snappy), border-color 140ms var(--ease-snappy);
    cursor: pointer;
  }

  .btn-pdf-download:hover {
    background-color: var(--bg-subtle);
    border-color: var(--ink-primary);
    color: var(--ink-primary);
  }

  /* Static Talent Corridor Matrix */
  .corridor-matrix-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-300);
    margin-top: var(--sp-400);
  }

  @media (min-width: 920px) {
    .corridor-matrix-grid {
      grid-template-columns: repeat(3, 1fr);
    }
  }

  .corridor-card {
    background-color: var(--bg-surface);
    border-radius: var(--r-xl);
    padding: var(--sp-400);
    box-shadow: var(--shadow-border);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: var(--sp-300);
    border-top: 3px solid var(--teal);
    transition: box-shadow 150ms var(--ease-snappy);
  }

  .corridor-card:hover {
    box-shadow: var(--shadow-border-hover);
  }

  .corridor-tag {
    display: inline-block;
    padding: var(--sp-50) var(--sp-100);
    border-radius: var(--r-sm);
    background-color: var(--teal-soft);
    color: var(--teal);
    font-family: var(--font-mono);
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    width: fit-content;
  }

  .corridor-list {
    list-style: none;
    padding: 0;
    margin: var(--sp-200) 0 0 0;
    display: flex;
    flex-direction: column;
    gap: var(--sp-100);
  }

  .corridor-list li {
    font-size: 0.875rem;
    color: var(--ink-secondary);
    display: flex;
    align-items: flex-start;
    gap: var(--sp-75);
    line-height: 1.45;
  }

  .corridor-list li::before {
    content: "—";
    color: var(--teal);
    font-weight: 700;
    margin-right: 2px;
  }

  .corridor-compliance-badge {
    font-size: 0.75rem;
    font-family: var(--font-mono);
    color: var(--ink-muted);
    border-top: 1px solid var(--border-hairline);
    padding-top: var(--sp-100);
  }

  /* Executive Placement Metrics & Discretion Strip */
  .metrics-strip {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: var(--sp-100);
    margin-top: var(--sp-400);
  }

  @media (min-width: 768px) {
    .metrics-strip {
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: var(--sp-200);
    }
  }

  .metric-box {
    background-color: var(--bg-surface);
    border-radius: var(--r-lg);
    padding: var(--sp-200);
    box-shadow: var(--shadow-border);
    min-width: 0;
    overflow-wrap: break-word;
    word-break: break-word;
  }

  .metric-value {
    font-size: 1.85rem;
    font-weight: 700;
    letter-spacing: -0.03em;
    color: var(--ink-primary);
    font-feature-settings: "tnum";
    line-height: 1.1;
  }

  .metric-tag {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--ink-muted);
    margin-top: var(--sp-50);
    font-weight: 600;
  }

  /* Verified Case Summaries & Discretion Banner */
  .placement-case-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-200);
    margin-top: var(--sp-300);
  }

  @media (min-width: 768px) {
    .placement-case-grid {
      grid-template-columns: repeat(3, 1fr);
    }
  }

  .placement-case-card {
    background-color: var(--bg-surface);
    border-radius: var(--r-lg);
    padding: var(--sp-300);
    box-shadow: var(--shadow-border);
    border-left: 3px solid var(--ink-primary);
  }

  .discretion-banner {
    background-color: var(--bg-surface);
    border-radius: var(--r-xl);
    padding: var(--sp-400);
    box-shadow: var(--shadow-border);
    margin-top: var(--sp-400);
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--sp-300);
  }

  @media (min-width: 768px) {
    .discretion-banner {
      grid-template-columns: 1.2fr 0.8fr;
      align-items: center;
    }
  }

```

## File: `js/main.js`
```javascript
/**
 * Katia Danishevska — Core Interactive & Accessibility Behaviors
 * Zero-motion Swiss editorial implementation.
 * Follows modern web accessibility, form validation, and minimal motion standards.
 */

(function () {
  'use strict';

  var htmlEl = document.documentElement;
  htmlEl.classList.add('js-ready');

  // =========================================================================
  // 1. DARK / LIGHT THEME OVERRIDE (Swiss Editorial Light Default)
  // =========================================================================
  var metaColorScheme = document.querySelector('meta[name="color-scheme"]');
  var themeToggleBtn = document.getElementById('theme-toggle');

  function getStoredScheme() {
    try {
      return localStorage.getItem('color-scheme');
    } catch (err) {
      return null;
    }
  }

  function setStoredScheme(val) {
    try {
      if (val === null) localStorage.removeItem('color-scheme');
      else localStorage.setItem('color-scheme', val);
    } catch (err) {
      // Storage blocked; keep in-memory state active
    }
  }

  function getResolvedScheme() {
    var stored = getStoredScheme();
    if (stored === 'dark') return 'dark';
    return 'light';
  }

  function syncThemeUI() {
    var resolved = getResolvedScheme();

    if (metaColorScheme) {
      metaColorScheme.setAttribute('content', resolved);
    }

    htmlEl.setAttribute('data-theme', resolved);

    if (themeToggleBtn) {
      var nextLabel = resolved === 'dark' ? 'Switch to Swiss light mode' : 'Switch to dark mode';
      themeToggleBtn.setAttribute('aria-label', nextLabel);
      themeToggleBtn.setAttribute('aria-pressed', resolved === 'dark' ? 'true' : 'false');
    }

    window.dispatchEvent(new CustomEvent('themechange', { detail: { theme: resolved } }));
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', function () {
      var current = getResolvedScheme();
      var target = current === 'dark' ? 'light' : 'dark';
      setStoredScheme(target);
      syncThemeUI();
    });
  }

  window.addEventListener('storage', function (e) {
    if (e.key === 'color-scheme') syncThemeUI();
  });

  syncThemeUI();

  // =========================================================================
  // 2. FLOATING NAVIGATION & MOBILE DRAWER (with inert background trap)
  // =========================================================================
  var siteNav = document.getElementById('site-nav');
  var navSentinel = document.getElementById('nav-sentinel');
  if (siteNav && navSentinel) {
    var navElevateObserver = new IntersectionObserver(function (entries) {
      var atTop = entries[0] ? entries[0].isIntersecting : true;
      siteNav.classList.toggle('is-elevated', !atTop);
    }, { threshold: 0 });
    navElevateObserver.observe(navSentinel);
  }

  var menuToggle = document.getElementById('menu-toggle');
  var mobileDrawer = document.getElementById('mobile-drawer');
  var mainEl = document.getElementById('main');
  var footerEl = document.querySelector('footer.site-footer');
  var lastFocusedBeforeDrawer = null;

  function setDrawerState(open) {
    if (!menuToggle || !mobileDrawer) return;
    menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    mobileDrawer.classList.toggle('is-open', open);
    mobileDrawer.setAttribute('aria-hidden', open ? 'false' : 'true');

    if (mainEl) mainEl.inert = open;
    if (footerEl) footerEl.inert = open;

    if (open) {
      lastFocusedBeforeDrawer = document.activeElement;
      document.body.style.overflow = 'hidden';
      var links = mobileDrawer.querySelectorAll('.mobile-drawer-link');
      if (links[0]) links[0].focus();
    } else {
      document.body.style.overflow = '';
      if (lastFocusedBeforeDrawer && typeof lastFocusedBeforeDrawer.focus === 'function') {
        lastFocusedBeforeDrawer.focus();
      }
    }
  }

  if (menuToggle && mobileDrawer) {
    menuToggle.addEventListener('click', function () {
      var isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
      setDrawerState(!isOpen);
    });

    mobileDrawer.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        setDrawerState(false);
      });
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && menuToggle.getAttribute('aria-expanded') === 'true') {
        setDrawerState(false);
      }
    });
  }

  // =========================================================================
  // 3. ZERO-MOTION CONTENT RENDERING (Immediate readability)
  // =========================================================================
  var revealBlocks = document.querySelectorAll('.reveal-block');
  revealBlocks.forEach(function (el) {
    el.classList.add('is-visible');
  });

  var taglineEl = document.getElementById('tagline-reveal');
  if (taglineEl) {
    taglineEl.classList.add('is-lit');
  }

  // =========================================================================
  // 4. SCROLL PROGRESS INDICATOR
  // =========================================================================
  var progressEl = document.getElementById('scroll-progress-bar');
  if (progressEl && !CSS.supports('animation-timeline', 'scroll()')) {
    var pTicking = false;
    window.addEventListener('scroll', function () {
      if (!pTicking) {
        pTicking = true;
        requestAnimationFrame(function () {
          pTicking = false;
          var maxScroll = document.documentElement.scrollHeight - window.innerHeight;
          var pct = maxScroll > 0 ? Math.min(1, Math.max(0, window.scrollY / maxScroll)) : 0;
          progressEl.style.transform = 'scaleX(' + pct + ')';
        });
      }
    }, { passive: true });
  }

  // =========================================================================
  // 5. COPY LINK BUTTON
  // =========================================================================
  var copyBtn = document.getElementById('copy-linkedin-btn');
  var copyStatus = document.getElementById('copy-linkedin-status');
  if (copyBtn) {
    var copyTimer = null;
    copyBtn.addEventListener('click', function () {
      var url = copyBtn.getAttribute('data-copy-value');
      if (!url) return;

      var finish = function () {
        copyBtn.dataset.copied = 'true';
        var labelSpan = copyBtn.querySelector('[data-copy-label]');
        if (labelSpan) labelSpan.textContent = 'LinkedIn link copied';
        if (copyStatus) copyStatus.textContent = 'LinkedIn profile link copied to clipboard.';
        clearTimeout(copyTimer);
        copyTimer = setTimeout(function () {
          copyBtn.dataset.copied = 'false';
          if (labelSpan) labelSpan.textContent = 'Copy LinkedIn URL';
        }, 2200);
      };

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(finish, finish);
      } else {
        finish();
      }
    });
  }

  // =========================================================================
  // 6. HONEST NOTE PREPARER (Formats note and copies to clipboard for LinkedIn)
  // =========================================================================
  var noteForm = document.getElementById('note-form');
  if (noteForm) {
    var noteStatus = document.getElementById('note-status');
    var noteOutput = document.getElementById('note-output');
    var noteLinkWrap = document.getElementById('note-link-wrap');

    noteForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var nameEl = document.getElementById('note-name');
      var topicEl = document.getElementById('note-topic');
      var detailsEl = document.getElementById('note-details');

      var name = (nameEl ? nameEl.value : '').trim();
      var topic = topicEl ? topicEl.value : '';
      var details = (detailsEl ? detailsEl.value : '').trim();

      if (!name || !details) {
        if (noteStatus) {
          noteStatus.classList.remove('hidden');
          noteStatus.textContent = 'Please add your name and a brief note.';
        }
        return;
      }

      var note = 'Hello Katia,\n\nTopic: ' + topic + '\n\n' + details + '\n\n' + name;

      var finishCopy = function () {
        if (noteStatus) {
          noteStatus.classList.remove('hidden');
          noteStatus.textContent = 'Note copied to clipboard! Paste it into a LinkedIn message to Katia.';
        }
        if (noteLinkWrap) noteLinkWrap.classList.remove('hidden');
        if (noteOutput) {
          noteOutput.classList.remove('hidden');
          noteOutput.value = note;
        }
      };

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(note).then(finishCopy, function () {
          if (noteOutput) {
            noteOutput.classList.remove('hidden');
            noteOutput.value = note;
            noteOutput.select();
          }
          if (noteStatus) {
            noteStatus.classList.remove('hidden');
            noteStatus.textContent = 'Copy the formatted note below and paste it into LinkedIn:';
          }
          if (noteLinkWrap) noteLinkWrap.classList.remove('hidden');
        });
      } else {
        finishCopy();
      }
    });
  }

  // =========================================================================
  // 7. NATIVE <dialog> MODALS (Privacy, Terms & Notices)
  // =========================================================================
  document.querySelectorAll('[data-open-dialog]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id = btn.getAttribute('data-open-dialog');
      var dlg = id ? document.getElementById(id) : null;
      if (dlg && typeof dlg.showModal === 'function') {
        dlg.showModal();
      }
    });
  });

  document.querySelectorAll('dialog.site-dialog').forEach(function (dlg) {
    dlg.addEventListener('click', function (e) {
      if (e.target === dlg) dlg.close();
    });
  });

})();

```

## File: `_headers`
```text
/*
  X-Frame-Options: SAMEORIGIN
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), geolocation=(), microphone=()
  Cross-Origin-Opener-Policy: same-origin-allow-popups

/assets/*
  Cache-Control: public, max-age=86400
  Access-Control-Allow-Origin: *
  Cross-Origin-Resource-Policy: cross-origin

```

## File: `robots.txt`
```text
User-agent: *
Allow: /
Sitemap: https://katia-danishevska.pages.dev/sitemap.xml

```

## File: `sitemap.xml`
```html
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://katia-danishevska.pages.dev/</loc>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://katia-danishevska.pages.dev/experience.html</loc>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://katia-danishevska.pages.dev/mandates.html</loc>
    <priority>0.8</priority>
  </url>
</urlset>

```

## File: `dossier-print.html`
```html
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Katia Danishevska | Career Summary</title><style>
@font-face{font-family:'Geist';src:url(data:font/woff2;base64,d09GMgABAAAAALCEABIAAAAB7GAAALAYAAHmZgAAAAAAAAAAAAAAAAAAAAAAAAAAGoJiG4GfEBypKgZgAJEACIEkCZwMEQgKhNY4hJZaATYCJAOePAuPIAAEID9tZXRhLwWLeAfIawyBVlurw5EIaXLfyOgMwAE9xSTfDOo42espYRsDtdebdficEhx8gG3Tifj1ZgmRf+emz/7//////9+UTGJst/172/4BBFDEVDWrsipQMzM4RZTatIp718OxZQwYhcMVCk6YA7bbKftG7JaDXPVIICbNVMu3rtrRDC3Fi8OcYus4eaDds5RyHndd0zTRi0vtC5ozPIaDUrBzecXNtC3VO9XCZJ6qKy/itH09tGjEMppCjdNNUnriIKhwi6JYJJRO3ERneNxrh/kCUqn6SJVUydQp1AmUV7y5Sv2duqlThsNcG3mlmInrGCqZ3Fm+DzRKXD5bYaixcefAAg7wewT9CC48tVbXuf96rzij2AjiWKfSi9JYnLzlk1W0tiNafCf/cBMXxeZeuyZMetmgRrRyzVYSmH4XnbRJdDXPqkdmF/VZvcqSv6Y/1Qd+h2YvS0Rwb4hQSZXMFvIY+DkgfBAHveikSqpcMhZ1zD8l/+6foPYKSpOUlKR4wuH6mOeUdtVqSmiR+yb//oXpfoH9Msmk9YJwt+yzWoit/DTxkWZYMnVffCiGJ/5lWDWTXF1bEY81fdDftNvNYDC03+JbePJrOnMuItKCTP3K9hSQweEU8A8RFVN0bUfuUxH1+eXpeTr//39UzU4n5wLYz8KHifXzfJ79ufe+LCIiiSCJiIgtCCK2pbbuqO6WjG90N6XLzozfaW2lRTe66qaLZVRVlVY3o6GbMZtRVHdVo6pqUnQB/19rn+f2VE0nrIBRhRXx/CUgvzpGrg0qIEcOuwMot6Ly9w3wc+snMBwtnQMG22AVLPJte+9te3tLtrEERo4YkYqo6IkFRuGZ6N154Z2YlyLnRepVaF/o3X2v9HvwDPfaA5L907WwNbqqrkIh5B3//H7gzn1veWV5tSxUg0U0LHbBHI2CTfCDRYtiSWX6FyMQyiG05/5c671j+QskTIXvVNe4urraVpEmDNy9ZJMFgOwBK/srLKG42RGYep9ujoXcBx6CMLs0YVncZiSxYlBgzlSrwZHZ+UfAsFPSMPXiND7n6pz2516HkNHorztcHUqxo6IxooqxVO5w1dE5cGGsMNZjrED3o03+hdexQqAA/v0yzc9ugJSq+hHSbr7ZPqeQATSHUJ5A7ZdzGJZvnOuPOQzO7SVCSIFcb6oJtX3YXGkKq6/aNudPlLPGgDFuwmGzkPKH8mb5+yUfMbuZcPclW1SILWLydHqoS0bdKikn4sOIyehvuhPrQTE9//uy9XnOufe+9zIT3xaKhKa/9TBkz0QzM3LNr8DIEayyql12ytMyKwmVTLHZabGf5V9qya1K2uRF0VORmQmwe2pl96qVtO7wQFS71RRBUX9un3uYEYQsSlnMSoS4KdjgqTj+oYXXy5sNgAf/wP3886LuIgKw0mg8oglMYPyVf18/fq7qVX0IUP9wJ2lKhimDWQByR0KvEbPOnJArzTlA/9Gm8jClrMJTf4HuChRA3dluOWH9ohRfPMweZm3Tk8KwkolNjfkD6tS0HjgNWoF9pyYWQADPy9/+nkFgmbU96CsehNlE0kq25AYJpJTC9c8f5v50Gp/w2kQbEJIQIJIQ0XFjeD+kXIV8d+W13e7s4G3rK5rr/7Dtv5NzmdxcawdAQm1q92r+ic7v5xRS2yegUNPBw6Y9xJCBkRqcs2vc+6rAAKqY09jgz94lZZbsO3UWyKg2IACbwgQUAPD/36bZ/jtXP5LG9jl61sIorG4VnmDrBSrTdZqRFWv8rD2WZkEjLZEWaEJeh7mDDqiKizLAVHGVok/R9gRV/n8ztS99r6uLaACkBhD1Z5rSOPz5PDLfubQB8hvjoon+9+ur7nu3X1e9qkZ3VTeANiDBBikakBLZADkSKVOvDNBogPwkSM0BNXP2zHjKBORovtPs2UM7hpT5zthsrc+czTbb0ELZhBNOEm6SbRBtlm8e7P/Z1NqZDcmHSo6UA6CiYmzT9H9XUjyzsuxZS3ZmN7SSD2TelQ6kEMoOKQfIr9/wxjlYh1A5ZKoBm/LK+qrj7oqyAPI/VcsW4Mc76ahd3e6RzqnptI50h/F1jUTi+69E4kJIDiEtJY8HkhzoTIfUukpFFavKRKGatuSN5AA4QU78omr5jlxHorK+Mjx9e396di61KhwYv7Nf4fg41XaGOvSllUTG5nhe3HMpxgQqugEFEhjO7Epn/1LwQEHvTN46T1S+fEOFCSa4IqjG5LjcF6rlkLlC4WELEVHTJscTnitMaert3Q2rzgr17u++ZSillCIiEkLwgoQQpDOznzm/l3/PSJC9t23ghBBMcM3WGOEKI4wxYjHu9vX4KoU6UTEoL0JGBacp4LVlvwb/Nhh4louMDAkQpu/ruod+Tj8HGJugSfsWyVOUW8ybcIMpzcdfHfnZT6tDTZma/Ss1E0FNYqlRVASk+Nj5up8x9x2tP7vrr2GJSDlmorIe4DrUDRlCc4k6mfssWjb8ZxIYB/hBkEvAzCEeEC8XIZc8gzz3AvYyClDoaD8oB+0D5Y0D4LzzHSjv/QDKxzEBlYU5gMqdGFTJzEG1nCeo3psB6qxpQZ0/I6gxs4L63XygJq0N1HUbAXX7toMmKCFoQhODZnpy0MxOBZqcckCzr2sQXHQyCiregsyA0D33ojf2+9YBEAqq1Z5xHsoiq7TBiPsxCHAJcAtwTxie/RUD81mdhAahz+nOVNrZztUARpt9774c+lRUA2fqqsdkr3UNEQTchMUbCWII52PGP2cjf/EgfsKsXWlGMEnyspsPGb/OWwPGb7XlmAB4hiNLIU+Bpom0SLzlUmyW7ohSoBBAsRl4BvwqsAHxKmy/HbTDxVFodizzZShgqU1MwPq2hB3JSovLATpuXxPxbBNg4DwY+Zc8LyY9LPpmYMXOHYu0wLtiITI5OlEJLcMaoSIPqQVUS0QHaRRJCaJTnXcz1QJ4s6mBobP3XwHJN598efbsLPx73i/d+tMLFH7x6C/dZrf5zsIzr+7SrT9fqwr/vEWWzh5trbx7/CtXWZ4rfHccKN368XGt8Klx2jv7aTneba6wfFW69ZOjsvDtcaR0tlv+tjzYsla+XFb3HxVna1fqUP3n0vlnD5U3GqJCUESLTn1ucjXozh8MBbzudn+mxEa3lJrYIDVuy48cZh7znvjHxP78qDS2N3SmyxeHB3cntr0hK+aAlfy2wx4MIBMfFPdvmrvMzl1xoC3ariW2e8++Xlsrht3N9nqMmR6p8fgsqGKM9FZjk/ON7FKB8JTjUQaNbCqv5BW7jn3C4fH03S7ZLm0ekQO6hBCU0vCACyHYIDyEFVlKBS8lYEEHpzM2KCUWKE1EXnx3YnJmjHj9CLxP1wbrUKeL0yQWBY1RCUyBOAnDcdKgJrjdrGKTnPNQxLYvESBxJyoa670Mly0mEZhyIgAPCWH8cQf87y6LihbjtMGKJVHZ7e38SYGAiKVshdMctg3C13fXRtg3zVENgsKxTGi90GoLXMeNzSjgEOCLqMHzhSsihsP/2nPhxCA7nllUsdpUZkidyhCZGzogNQyL38VMA4UfS1v+Y8VCRSMoHhvN30L9oE8YiJtP5qqSyqgvpCMjNXtHDSQ0EgZ5g9FocnycjFoclpeKmSzbVqlawkCD7DIBKi9rpNpUHCvULVIiFEJVjPhSkHV/hIxYquPjWGCkH9IdRNMXscfhxcEIeGR/docYFtfGQatdT1cYBpER5T7LLomQua0EWCZ9w6oDu/XSHwcOWT3lV9ToH6FFzXCl3WLrpPDdu+CcmgxghTAoHEmCSa/FkF2r8nncxlqbxPgzaOBct5N5ImGMY0JUbS2G7KG1zFBD1+HB4gWfoF48Anz8Kp0oL/yj5YT0kImm2Ti3BZVamnQSsJJzSuX6WvRR7Jdql3gClzyfUwsRHhlRc++H3FVxCbHAFrSwoO6GIIIJA1HCpCLjYEEnd+PjaxrgAwFlQidbYoSJXPaCclQkmxA5ioTVLQhgtAQxKPI2G5oOSBTMcYa8Ny6eLBQxntQGMxISTjBTNEFBb8pNFHQDNCK12SZvQKSVoLlffrGCrk4UmKKtaSN0F8227ioOcAynE6hE5HgQv9xyq9pJgqDpvirU7dIFeITm13I0J+SRcYxwYIC460WIEbYO5kbq0or8MFqRE6oBdGCLbIIqCZD8CAj1QDkMECkAHa8UAcwQ1YHU41BbwUquKUVLJ/LqePvyLvYBVJjRE1nBM8sxdP8RqEuiPeT5FkidrHzHKJoHXwS2yF5QZFOqW6wxhknzaAhyRiwZBlmW9286w2NyOpJesmIonCBc7ZqFpXQFK1aTJ58E5e4zIyTyxVXVsxbCXhG9Xkh7wK2nMKJ57pb//ydFueXBfNnNFhldMRCT41+GQ8MOJyKin2MSeYb72qlAEKliG0G+0eCwJUEZQ7uAXgP3QzhfPCVM1pMul1TUIVMkDEFHJUpglEirXQUXARld8s5HNfHOYFYlCjPHzx59VpHsvMIJF+H0vkKuHY0714Rwf4LaO7G0SFHgMZueTJGABZxQTt178+o8r8MOqJEnrEUqwtwiXSAdl+RVjRbmF9a0diyfapoP+Zs2BnbU6FzQvtQmOKxqV6UffDe8j9YAaV3Q/mg9NkD8pnzB13H+YXyaU3wJWrtT9FmiFL0Llq5mekESGnd4/9w4d6MEtpW9MFtCZVH1DafD74VmofGJIv+FP30ZugilTAiaMK58i70n7BPL7TVoW1wrdGJVv69KEPgF08eIQolvFTxS77u1JQdryyU/0/xM8VkgYv2C1+vk2aObdU17JHqtE6OajSJs1xjaDxwHf0IGuKJPRj+Q20zRp+dryiU/6/tMkVjwFvC0dW06ocVrv03eG5579st2gqA5B4E0DYJJsHjaydlP226HNs2hOeX+bE4S20f2n/JFWPjVfX8YOPtJqLMfdaACPXuIvb5yID3bH9vvkKNOVICgjB7ZYPsMnp/yx/2WuYKyiaLsnwk8J8IH3s+hiN7Z11rDUL03bWZjRRW+0l+lp8v/PGgSF4baRDH3LjdYs+zgpx9szMNKCfqXORRjgLOPhoT4RHw6PhdfjK/sfj049WB9+lkzqUDGoDWGGk8cspF+c/wNtaG32tShYRMOkY3lBBueBSIoAAKJLAan3YQp+NCCIPowYqd0Yq9nr2HxXzQRmVogGnilTWhyHWPmkkuc/amTSxhRkDRaZlzMkha8TccgZ85o+eo3tb7al4I1GBYWhvl7TFgM5h+FCtsTETuoqPp3BNJ/eHm7bdbcf3brboEKmc3PmzM5dsAkZKyARwhGlSLjxGyZdpHDrv83hc+hjtXSyljGiktBquFVbBXJ+VhQ/geb5mWdqUh5mJmUuErNTrWUuFpZ1pNXHvG1vO3iwBHN5Q+QB8Q0uS33uTtEBMXV/Xa6u+q26VrcM9cDbRZo94doHTrFeeKpeC9N8H0ikaltKYlKXrGxOFRKxhyuODdV1pwWf3UvD3XWlj/11JkuL3qaPq97l3fe9Z+fGBpeeT44YUVGnGMdjTpVPf3nAhvki4utxaTbqCsY/G7tSRje1uGE14dHaB/SQ6u8Q6fXDbSTP6SdZ8ZhzueP6zdfFXDR8CjLo49fNAuNjY05aHzc8vNlgoozGZZT89KxZe3LxI71LK/eUMnlUoW/moYWkf5QCgMjqpvoYuSxh1tJ2hRWogt1mVxmF54toc3ojTlpSeyiwoylnmAMgQWPAShuoy5l8r9PI3hG1utvqxb2w826hSuz8Utq7RHRYz29paUZbstuXnJz2bXVvmIXdXbvKDnlxy2cquodKPkRpqPS+nOQ7j6AGGBSvKpmLJnIFkSPcJFvBvrN29xW5lL4YMrEkoVs5Jhd+dJhZqRhMXdMALKRY3bl0WFmpDUAgUAgED8D92OYvdMQsXuui8L9xgqne8BX5vGJ6Q3A8yIdfZDRGeC/w3n5NKMaZ9z3G/Nl5srn24tZZhKhqhzGPESRF+ElxITxiCSRUchwILOZI4XQpIglpITdX6qBT5lmf5UWrap1vhBJlx5kISMoSHh7qJ8/ySWfdRRMDcaRSSCrIxs5ZldFXEmjhptxrygdBDWD9PglpE3fYeedoiV198Vn3XgT6iXISpbctGza4svnSsyDKBtF19lcYSfICdXc9woL96qG772DOn5sJQMncBKncBqP0WW6r+TPFvkzEr4AAAAAAAAAULgk/VUrmDTwA1ab5CtdnEkH8uTkZy1zZiOO8XIv0vcZsoyQiDUbtuwo2HPgSMmJMxcqrtTcuPM0y2YZMmXJlmOXffY74KAixR546JE2nREkjG/i44gzDQlkPDuyMxnJTFZysiu5ycvu7El+CnIn3enJk7zJUN5n2BE/+p86Pzk++mrOqdFrKa1F3epT3/rVv3MKV9tA29vRvlsIUbRjJ0PDnkMv2t4GaAJbINjSXtuc6P7G3Wt3LxxobG4xe3LYQUIzVQuLX9i/VSTdKKw9gg2HAZXjqWoyLjPKg5xMfEWD+C1ICiuY3k78841XFeuvSMJhOXCOStxq32s9njeZBZ0B3DgeUW6H/K4U9WCvnGkno0gK5dwmigQpbGotv+8FysTSTIiNMxZpv5geu7wcs6XeYjW9OFj0R2ArI3W8ggkedu8kgZfbRO9Lk5tNVMkN7gA+tJCiuC8XHSt8nKejHQGfC59alU1e76N2RIYM2BjqZ7ndx3V4yB900tsErxio6+WBM+/l82cQSZzcuY9L6gprR0R6Bu6O70A1H92N1N+RnPaTxWhurwO9qjcyFVic5oirfBcF0Sj2E9OazCwp3Ld4m63ZDnwklWK12PslgeJ9S5R8BV4c5qGXdrL6qrOCW40PixLtoqcGIgoITjd7JkKwgOBUZdmVrZBCOR0DV8yCo+rGzpzU8UHue+hu93nIEkurt9xq66zrphUao1wze5tstY3Jv+y6XnvTzJZGZbAnSY3yGQXf+z7iPgcdcUzmkt8unWQ9rBUby+RIOjt3Qm6mMHMV3At0qCXIxjWpyzSHxoHiXUOX0iS5dmC1k22OxlAr7c/u6Fw55QsNt06mwcpqZP2Q3Pvl6/f0ov6GGm3ig7fIxy/vso7p2337EvsQdl3JlRZk+dOq1rl110jhQ49NB717A7uv9dpO7qffsx/MlwvzBJiSeV1NwEjpZx630Xd9gcLdZNiKW28QnXcjx84bu29pZpTyxeOBLB6ydSuEJq9PJ6p9xSRC+fCgxeUk8HI+3rQvxw2flefcnHB8BHG2zv2zEHM+3eb187FbOCgSxG6ZcWwpZerF8Ep+vT1h9Ht69nkSOwm71rHeAvkRv+fuUC0ueWnidJ23HN69/B04uUfC45x0EBX3i7NGaKzsHMbw3ForbZQ+X+UmuAVvNc9dq9/NtNmMP5eE98XOcMj2ldYM27XXp1Pz8n29F5+BkFN35yvwcg8x48s5RmR5v+IguMv+twnLPeDwiYyUPciGr1Cq2kNIvkhK1HrQWuSgUM9uXVAsGbaPanRifNBzFX+7UmGtA2mFx94/iMUZr/TRYtgs1vM5W6+VTN+TVsZdz+XhTizzJYaOMcBp41G7QFU9Ucs14WWDfefoDqMEn8HWMwVKBd079GwBP/hOQROTMrGt+XtTrRIf8tZXlnw16c3e2o4VaPUwAXGfpU2XjSvv2GSWKXabB1bqC4jqyOLLHxyn1e0fY5/Z96Bhf6WNdT7E9P31RhP99fF8f35KPCAHwiLizDLPIlnyrLNJnUezU6cJDApOmy59SIbQjJkyZ8naIJh8MiILaWYWerOymEx2FuPJyWLYXVk4zc1iNHlZ+LM7i0H3ZCE97UFgeaAwBe6gsqAOZ2H0Yxb96rII5lMWquNZUCey4H7JggaycBxaFrjL8oCHowRqhrLojUUWvZFloY3cg4asBLMZysIajyzsmZ2FPmnpyoxQMIctNKGYIhqRT0IheYtm3HiHB9X3MYxdZJJD9kIMJ/sVD6qTMX4jTycXrD7RB9OGhBjW0o7+SIlh7bX6DUtWQV/dsCKGvp16NCCXZk12oeDiB/2mCFyMhlYYhla51WXOOGyhI3520K/6YDon3UCfxsYGmGDDChKWCRuWo8QKZcpTQkBsL0RBVYBOpoiC8SuySMRsH0TCLkCqTQe9oF6oPqOsxuNQZEKC6cwj3Z/baXO78z3Rv8fRYysMHuYw8y8sHBs2zIB82Hg3x0oyHsfqA1dq8qDaNqB2PZW3cdhqOs/oc/jnjQrRiYggYhYIGTnECj9hzR3iIYRndYmXQJki4okjRRGZaxG2xQgS3bcX43/4E2xGbLFVttkmqX6SdDujDBQFtBoG71Sm404zcEZvha9UBY5KF5m6pA7q37S+O7RIAid096WkghPkN5SEsKLIVtLCU5ke62agx9S0iBN9yuAZQjwXuhfKTGOl4vuXCvmSKThChRglUgaOpSpQXHXHOA+9QPHWH5MCDIWWMC3gxGmFFo02UL6zHpx4G6AlUT84K20EZZWtcEtxDEZ+Ngu9ZJuNoBwL0Euh+xF20IOYVGQRtBRbDpUKb4KrXVFcV1Jp9RG49xco3xX39Qsz0u0T9NJrL8Ke+uJIXtr34m98i1EDDsDtXwexPAX0oGeoDTrJ2Ag7oxFDT+8Oyhge/Mb/18ShCT+D8tVvoDEj0AHMDCNYAooVjGaNExbbuLfYgXHZxeqwBwRsQoJ0Q9GGDM+UojAWN9REJxppmMo7MVM0zJWtksy0qiYd1Vprwoqu2Zq+dWkVtqwzO7aZQ6fhxHnJqYvUmbuya5DcIez+q0TJPbLCY4radwCFZ1TJc5rCS2DyCtRGjQLTVtHRJXr67iOQgoGhDGUsmFkKVtY2bGy19eoLds6kgavg5u6Bhyfy8hYaNXavSVP3mzUnAYEqLVq636otatdRpVNn94OCZV26ox49Sa/eQp++Kv36cwMGkyHD0YiRHowaLRnHilTPbFLJJIM1JDObdJJIoceeGXkUk0epWpOnkoqOU8cUIx/yKCaP0vEP/6sSsJqfaSAfilBgZZ9qepBHW9rRlna0oIwWlI3bSGDMiD8d6Zz2mfCxYv0CoEBn3xSdMIRBpByHhhdQJCwhF8JKLTWOZNAJrH4ILBS/njAzYbPSDLNFwDKh90TzGVpgIaFFpJ0tFk2IExibos0Iw5YNclt9jhSQA/7P3UvPPsVMHHKMnlIakmtEgUSoJo1dVkdgleyRLPLIICuL+//Q08kNTbhSRLZhBQJ75zi0YHmAQ2IwP7QAKluhYk0M450+aPElONrtF380sUpBJbq4UValmTg/WLCPVotiIjJpTCbNDG1MKVB0m8admMY8TfkVtiq0PCIaHSIyR5oZVJXHIv0enLcxGleKs3Y73+NkmBi+2JF8MmhIDnD5K4aZtDjAA1wqBjla8sgfadAxLBsPJDXwANfQA1yuh1NeUCX8ClbDWB5Skx14NQVM3JIUD6l5i4SeBY7eBRn2rBnSJVcM62hxw8lWw1PFw6h7DAP20+pTf0YNUDR+44ZWCnUajHcCUMMVo9DSSJliYdwzQn9cFfkkIu5QXR4e1BUx6qgxzg6zKYphmcpkaVBVHqob64coy5QB6J5HYJOU0ZZ+9KU73ehNL6opo4ymlKrpLUwHquijViCpoCmlanoF65010p4K2qvH/U9PNT2qpKjKUWuHtKE1behIC7rQlbbUh9VOOP0uzIPjUqcXkEYQG5j41F/AX95UP/URafkXlRK9hKxbzJ+wOPh0/9ReaD91uLa6B8rdvlVtrFkDU9eLhqThH05Lhk6jkq39c3r9Todc24SIlN6VVRNCpHZjJRpwHROcilL4iU9WlvOQo2WKHmKIKhppas8r/s2cuKdbfeQiiXbWXAfkuK/GVglv64e5kyuphUPqxNl3tLacEZh4U9WPm6L0LrnYleNB8jfbMnOGWd6yrMyZ9RXHsKg7mSyKRd2bc9l05kftrYJqz1rGmeXN0oQcLVTyzN+fjJ7iUtYmvrovzQZv7iH/hw5CldOW96A1pw20ypualp96BVmdG3ub0FvkzEmNpvRMpINmIihfP0IzBUlxVrJjxV3iA2w6NtKlUiBefKZ/EosIOLJqPlnPCVf1tzUjcvFjCprsl1m3iocYcD2J0Ul2EwKlPUa/UI+mVMSuzY+zn2egp+7n8/LKoofYnX4M4Ipiz+y6ZtmHWHEYqhHnZEW/cYmm1FireyxYRIJITiSO2BsOYUQMkWMBiBJWynJVCibnetr7d63pmS7cHVO5iLPMeutqSpP9gxJ9UTBPjgRV1BtCz3DcoJKCTVl1WYMPp3IoGEMMymJK/WRHQfL9pkUzE0wyyepc1zIi59Fj1JYXz62I+9zKnyfxx/Fr0Lp4JQsSIBIgoAJaO6fsCjNszDqpddZZV9KZFDI3sYiAE6MR2SfhyGqI0Uko+dFkpp/mJMWkIGoIqdjn1Y1H5d8sRvURVNHPO3rwC1Oq6L6OWojYHTHmPJemmf8p2r5oIyl8N9CutO5jddMj0z9SqNfYmOeYM2ceM8pGYkziCAOchI4gSlgpSwBPCa5aLwmTcz1t/bunkNpSvR6bKtIdUVzEWWYd7wrqsj81+GkyuJ1MFQVzJFBU4tmQaIWkIDDFk222yp82s11e/GE0EeUiZxbY9H6aY+E2qV1udvCwaMpwar1MsjrXtXwf/q/4IKfIL2eZvIUPq41Hi2mbsK0MgHObTrM+PS2ndmkHAFihYOZJXCR7gwYaQJu2TXtFhU0VqiBPPuTuflhJnTv5IZ4EOM+PhPD/dq+t8v/V3i+WqnAtXt9eW74p2+HmPe1mR5w03yJLPGeVdd5Uq9Y2++yw175VOrQ6dX4bHXOwyaSznfM8F7hpA4fOPt/a1rt3l77Pl9WEkZYVVRjzr4Tg6YqKOMMszQh54FhlcxqD56rbLQeDh8izwKnGFicCZ4mvcZHvXvzj9664AJ9/tL9JMMH01wuAb591yR3ceHaQ2XHwgKQWDwsF64SKvwiNYKETpjAIR5hEUGARccmVTGR3ryEz/j+ScqTMrH36qnd9NyWT2taAfv3/ws/FtroRz1xsa5UQLlbsYvNd7AIXm+9iW6s8CQTknAY5jjyFoY4aPlT0hyfY6cqmY2hUvQT0XObhYJcONdH22mfNKNhIG25n2Rl2WrED1dwI695UI2regdnMxUQTVh1UyEQPlZmhD27Dg60ezOjgsXRLBlCSTPlQnqHXcLdkEHS3t93efd/ZR1o5u7Zaaeszw902TCKWp6c9HRzZ8VVfsY2+vgNFExy8DwmHDYfGw/Cf4mB7CD/0Hg4dOnY2fdru2Sf2DCCmk+nDmQUXWiYkOjJzDhJ+ZP2S7UP2Nzle5PyQy02uF7md5H6QByUD8imAhZbDR9mM+WHiozpxAYYpIRFwgFFoGPTAsvMN87+jfGdsBjgMcfHwGREwZlL5xGJmJMyh4zC0S55hFLrwSqdYM2WB+Ukkh0oa14WEcO+qF1W0fl9LVGTJkGyTEXxEh7FUkRaP2RRiYvv8W8fTIN10BnbwBPgkPSk+Zqx0bD92QJdkHXM5eBA2J5QnBqLUNx8Wn7jIXJ7auQKfhCg77WpFWuGTCepvooTvIBnBqsGiAjrxfcf7x5rjH8dXX40azSU1HUzRlMKnMHR3NPlVs7u0CHQsJwEZ30/509qRhyJwzbIfkp4q0G83jgLnLJ3Xmbbl9tHWPojN1xuArpEZfXxcen5OxzylgAXlEOh8tgyAcvSCNscYZrCaY2RDO0fv7pYF7dxq5nH1VUtHb+noLx3W4jP+uNFeiL377oF7yC7bgR3cdTu6W3b77tp98H6AgavqNbjmukY33HTL7VHVtWp4rzSr7gtLgOE0gqQzmCw2h8vjC4SieqUe7bFEKpMrlCq1Rquj9FbWNrZ29vVa2UKAbCGgXQ0YeAfmf4I2d8APHSl4rPkTpB0OEAKfoByUO7St2FbMxD2fGw8DUKP2aD7TLEjvwl1Nj6TTBM3qrPWig8mh90YvvS2oplME3cZYd48hmVCHahLtRfUFZXSWw+hXDLWle7RDOsm2k/YFzeuoYfYrhyo61tEPM0js705fgGTjNoFev6rQ4S5DbGccOJzf+lWB+kIF5kEgdhydKtzlNp+tt7VT63tre08p3noEMoX/kwxANoAcALID5AiQE0DOAeQ8QDsHnC6179q7/bSX+N59f7zOS3rfvldv4A0/3a1/jw/TUm/lMWkcmuDEJzvbU576vC/wRv6A9slXcuVXd03Xdl3Xd7kXdsDBh54NvLNhoRat7rnvO1/+N+1+94c//eVvUc/uTZ94rMtNrz3R67/QzxY5UZIVVdMN07Id1/ODMIqTNMvfEH3jumm7fhin+bZ3nTZ408l0eKtF4dv+A/gHNOlkAgkhhCJXq6+ha7V2D3ysZF//ghUC7mpbEpvRN0fq3UEU7ZfVuqJON2IgUpGIEU7/Td//q0UOIgLVSYZqlWrqEP12k38Wq3Zx1bu0ml1e7a6sblfxl/EP+0+UGy/b7FqWr6GGG2m0sX5uRzvLKJMcp1TxkKQZBFX3Qj5kjyWgvlj3CeltBsGZZU4fv/3D2SWx5ePNQVvpxvpmMGvn7BdAb2PzC9xS4m7TrKjjyoFjrSs4Qq1fpHfaLfW7A29S4DGtOdzRGT5eCO42kdUMILm/b49MoI4sBvcz+SRQR+En/aw/B8gx5FN8IOS4/Vv/qUHInK+scqhjzrf1G/tWglB+ltMyW0AoSIKXhYFQHYuE5WNF6KqwZD43tgRhaflylgnxEgH6K6NZ7Ls4BncQZD7+jQpq1a4Cgs6LN19+/AVAR+qpO/3r1n/uMAJ5AfJ38+DF/H9jOoKwh0X0CZsYEA4xJLIs32jU8OYDSX/++TMQIsxU00w3w0yzhYuYjInmCIag7gQUrgK7zfBjY8FoXuoH/tp7dB+MYtMZx70J8xgBjESX2h9l9IstUOzWwv/9YMPu+g12TTvsut9hjf6Ac8hKcA77CzhHrALnmNXgHPcSOCXWgHPCy+CctBac09aBc8ar4JzzGjjnvQ7OBRvBKfMGOOXeBMfeNnDc/AucgzaB6zp3cLdtADyYEMDDzwQ8RpmCR5AQPMaJIPnXYisgOepFmyE55RXvQlJqvVpIztpgC6RjYYJghepphit4QTmh5AcXpEoQUlJqYWhFa0RhNaMVR21YWBLecoi04wSVcVidpJicy8YJiBP/6v5svfTKa33e6DfgX4PeGfLeByM+GqXzyZjxhnwS+k20N7xt+7AxRs0CZCGaJWpasP+gjCj0A1lqpRT5ChxwynkXXLQ9++56Y6jcz1kI6SNDxJWnVGsV2uugsypdnaFanUG77HO1n9nvUU+ZoMZFr5ib9k8TzXVBN+tMd++8CW/2uw3t/YYhQpNw6bfLA3N66ub6NGKqIVOcw0JwQ2j4aToBOwzwiRkVfnNq00nN9LubLZGHlRIhyR9pvXxzFPpXO+S8ZGUv9JMK16W7QatAa8hh9/WI3kw96je/O+4v5KQOPaUk5nTgpnSL187XJPnFiMlFo41qNksPLlH0BbsbP3wtCWKvNcc46s0p0zwtPGrjigxoQosShP3nNsqf4Y+uV+SetL0FHtbBUiYelpL28py/6G0akyAX8Id41l8NdVEiXNJIXTNzAsfc/l8u9Jok2s81RsdMbIBo/EG+86aCn814b+8nHRvd9+r2em8WXXkli2uuk/ujM5Xvzy53Zd0qNGu9Xa/tbILk+pZQNgmhdHlShSLlAUW2ysmy9gGDhgxLeQzGKUwLjldjxoodN2HJAEqQjHWrt5ONh/9QS67nB2EUJ2m/Wm+2u/3hyPGzrqx1YYEWwvwD8ddYU80Faqm1ttrrYK9zRok4i69bECRhu8NzWIgXL5nuAfayqpOlKapaDnZJTlTTO17FHiv5i1M1DSQMAk+PuBSK7SrujSJrv0bjbct7j00zD9Sb6EXARbMXQG8VXNw+yNDIvCrBQ8OvoYa2blbv9QiQP6r8E4Y+FzS8AT6MIIAxbGGHZbp8MTgoItxfnupUN0ED/ehFA54yz5yXoy6Q6axfBK/LN/7zLT3/4Qhym+yPvPv/GWyPNFIGfAagl00LuAULKDDAFQjkhDqt/qf5j7ajW8uFj3SVGemol4HOUOOI0+7zlNW2+XZm81rMzqxxrXsSRdiEn1lWKfJud/pPmG2OplW29hzcAnpstcDZasrG0ZVnP+raM/MVv5DxHyEjME06jJmx5UAH/awjIqGkYcVO92U1dZNdOyUUqVSr37rtMLfXz5nDPS99sdPeurG+V//XqBuqsWucGu82PmiyW3cYgepfP3Z/Jw1uoeLrpKpMdNbHYAFhtOc86UUf+WrCk2vXGZC9aJsHrn80QEFqOwcuzYI2oRhLprP+VgmcmpYQT7/BbRIKQLs4ZXPubsZ4r3yVVZtOHapQrev5r+ipnf6q0TW2jWPjSpHVfG3pxmdHK+jA3XWGw8+c46LV7j8Dmvk44c3MpCz/B7T/XwMNdEATwuRfQZgZg6lhufwPf5eaTg9Aqwx9YOJHMJqojfe/UL7g4nccjv7vW4Em7o874kzcHKfjFBBNggUIKUD4K7wKT8OTMBm2BUcwBggI0wIv1ARiSPj8A/jo8+G5D9O4a+jD1fcP/7evfyN7MHP2bW/UDiDDIBegA1Zu8+ZWs8bdXzvA3DGHlDnnndjx3D/fwlLjFppnI21z5v3H6Svr7Vkv6m+o4UYa7dsbpPmlnipFAWwbRQfYLgLYvv81PS0+tH3t7+BXX3p+kLtq+MX69vnvpB/+lb5z+w2/sM7+0d5lvf8KzVVtNjI8VPyx8N2NhvunE+oVNT843a+UXEFExGSsefIyRYhIcy0QI1aCLbZJlS5TruNKnFGqcjn4U4YkNhy5wUuffQkjOhIq0lJrXfXQ2wADDdNqvXZdNtnmuDvMNsfC2MQ/AxK9HzdUcECiVPFy73oe/pusmOjdzadF+2Jd3dyO3PYh7TodzHLa/bqWDcOHsZjiMiFkTsWGHSczrf/veVbiJfleok1WLshGhfLske+srTUy6pVB40aMmTDJJxlIDxkiR221UyENhQgqVaZZdZAmu22306Dr1LgeAR3iNWOfmPlKGsDNIZD4xjIC8ihQJ8A5Lm4ZYxsTfJPgnTjfjjsPZy7hYoJFNElUq6kTyZcSJ4NT6TMYshhzoNlMuazr1BeyFXAU62oUjOptMdhheIOhTqPdVvIZ5zXGY60WawRMarbHmJ2GbdBht1E7DNllxJwJR0w5mmdtdtJWz9miJWyLXlF+wl+ANZsu3Sp+67QePF7DMfFIFwoRg6CAIHEYotMsMDaXN3+eo4Tp/ifHRGIJghL7//5nc0S/fWCc/u7kb5fe5AeewGGXvY8PpIYcw3y81S9z7sKlK3fuvUJEfCKQkKijhzB8lQK2ToiZk5dPHQE/Nge7xfl5b1PPQ05KyyRfowJNCjUrEtjvnP3BVaxFiVal2pRph9ehXKcKQZW6VOlRrRdRCEmfLAjIgtNlcaKdnCoTno+M/EffOwbe4xhm6AO2IZQ+dP0Y3mIaQPOGSzxcM8I9ExSxwCE2OGYAyjhgnz7MStVVFCs11QiEuMt5K/kC/FU8FVprtdfriOhs0FZnWpfNemwVMqPfrAHbDdqmz7ynHLOBAcvLV1HBSMdixCMZ8zGbwJnSkYKG0ebebeskj3+aJmDkPkFrm8ZpnpZxjGYMg8zU5E/eFMzuKZw9s3d2TfbkqO6Aib7wG0U56CLoZWDV79ryk654hxE61o6Nf8z13aXkerrYg9pAQwL5dxHZkrJb2+vrbLUJ7fvxu2YlARBPvqfA1wuM3n2lfvjlebTEtbcwQvrwSo7x0pZ+KYdyaKwl3ghKW6DC4CoSOM9GFRliARwKoDsW01cnXMOECMFlnm7a5p0td0EKc3cM+vYemyZ2lLfjwo0Gg+Oivm0h5hLOTN69jdkkriSalEHYMW79kZZcuTYkTcKZ0WuQo9yPnFKDDvwepUy/ypoG7A171EfeUkTd/u0buUmfR+X17TcdhIU8+6w4e1NkEIkd15Q/BTVhT96jQt8NGCHd5h/k0pDIc7jsfgon6IQH1bY6yJE+h8S9Jy621MbEKGEaP72IFyMZYvULJYW0sy4qyVW5R+qAOcVpRQX0QBljt+oWN73WzdHWqrG2vSSrqFUNGnlZtgoHhCRqnmFd+jeVKusNqTpWcSKx01/V817PMmXa8mHTxG31olZndXjwnWx04mdjeBUt0OHzgkYbI3v0jjkBYS6SixGpnDitTq85AKfmkMMLKcWxOGtDpiAU2nBULoozKuy5Z9ZokNe9EeX5FajkUtIpY4gqU5ejU3QhlloDQvslDsriFLGa15bfP0FehUsXMHoaoVASxu44GJauo01vjVh9ZikpQubGEX+RRCqO0BOAFvFLbvHNzWlBSuH7wKirkIHNqxArXEgpU5fT8AJJPXg4RGIb4+uuz7Jq9QGDWsYJSnbc8l93XhRj+wbJilNkTDZ7JF47IOWOxlWcMo4uR694lESaFVDESc6qY5TfWroNdUZGHStnWh7yDA6x6Ly7mDLioAMUCz1oqV5pvzFmyFlaEomdQqrxBZZhItM42vWMzaHH0BwDo8ocwnk5P4mJibkJ55z0KLUm5Tnt3+Q3X7qvypAjY+a5R4VAqBQYjQWBKkGiWlCoETSaCBaaCjaaCU67TYjuh0qdfd31gpr05SnQpW8hmuQNf9e53WSl4d/ZNscEay7jjqT89EUC3cmGFzjgFgfc4YCXcMDLOOAVHPAqDngNB7yOA97AoWQHWDZWtGsOLDM0sg807Ulolnfsle2hQrwnnY3sNxwcDNCRUYnz0qv3OlY2kqMD349oDnuPrG1Y3O9kpTM9/0olDByqpjfwJUfAe67bHmMC9OOoOY3kfPQcVidmTyDAd1Xm85Fmcp4tJ8AyBrxzgvZhVPEU9fXlimdkjFQUW5N7ZJbZh6iNRpinxD6n2xPjsgh/aAbcZHPlTGnmyjNlPgcxy+KmyPjwkvDsy97S4/OjtGPAcjqD9bgIo66KUSctKTXwh+EkebjzxzLMzs1almYrdYNsuUukjppLP9ha6apyGOh8E5KFZOiEirGz4k6JRsthkOshvRoFQkOSfpw3veayP1mFXDawlwFRngynRN+kllBVjK6HBBplYkCIVKz+QbSbZoje8i/1QFEoUglwWZ7PN7mqsU8XV+gD1AgdWLyGM0G4lo3kYzz6GstijXixwZMrkWUdo0Wfly28BSMtHTvKNnMv3rwzzePODrObUHHz7VsasNm1Bg333gv6TbOtHsta5z1Nn1eG3/mC22Zz6bvFYlM/6XvguddWuH84deFpnoB9nWE6IzuEmjX3xOSBj1nbdJLWJyL9gYsN+4K070It81VPPUR2ZdIF82zO7xcDCwZ5YAg7d1nmjbWVqlUeyaNt2HiuEetxZIxVKxuURIhPnzgzLu8VeHdhrpQ56WzN0z3PkKG7Mk914Xnd6l/kxbvDbE9Qo5+6XFPeSxizcWB+DnmFEsDkMQmDqMPEXEHcaRJCXiQdJuUK0s6DMzgmOQlZMrkBQZ5NYZhAkUxpQFDm8UpzuJ1qGJiaK6g7TUPIh6bDtFxB26kdnnCxG4amNyDosw5ACDAkMxoQjHn/BJmj9XSaatHsMjNY43OF1wLYjUW2KbxZWnFlZdZr6AqxyTS2mdYdqL1hX38zBytztDKnNcwbzpnBJTO4Zga3ugIydyvzsIqeKLvwyiy8MwufzMK3jszPyrB7a2nLN/x7oPZ5qZeKbHQdebHGqrrJUEfaNcX65lhStypbYZDB0oF10De/8G9ax88HfQ9w6z8D9xyAG98MXPZY4APeH2jwOvDpbSVlKYbjZZWGxIEcDyvih5MaTxy2jS9FO1Ix/iNaLA5xEiHegKLP80/zOb8vwuCvNsEbaDjWJI41f4hjWQgfqPRj4Wex8HOPPxqclk28AoLxeBGkhj4mXg5W4o+ABE74KRJZvkYIlrbFEW2GfwNJ4JSQ8YiC8liZoCoGA8WzCYyCQQimS5AxQ4bLF8ATyavE4KIM4k+lU34oA2KR5SNKYgxJXopY+Epo88S0HtpGGtoo+Rd4i9SVFcPupIpFqifxGiUJNhW5TnQM0jDiWw49xRNJ7qH2KqSAONUiq1YJUiwkW3NC6U8I3gghZPoyOmJItRkNUmPs/iDISCVWmFp2mGAuuXlNWjAhY5U3tM7uiS5QF2ikCl9YoYy0cgAit+Q9U6CMA9HtIiDhjY7odJOpXWBYLVGCSvsUs4cF61ifCmNIiMmZxJQmmHmucvJmDWaI+JSlRcopV8Ja95Qas1Fn0ps544S0LhBR0TRtcCek1IBSIdULt1qEyY5XF81DknREI9oiipVRruIi6aUhH5XK0lZ04hndM3kES6BvTRovJD1QVwdNzDJaQAKgHqCnDKCDnYRobynASjrnlkUvpRSiUtCQD7njWK2kLgDBlHsRon9DYI7+/USWf/vYIOy1i3c60UwQtUtsvaHDjTet/8pqiHUcsPP+UhMUxQYqqABuybXCllymopJmyiRIupEOCyhl4JQygjDUtp4CXJdZK8KZLkS9A3QpvU0F0ZweOKKfOq5BkAHz/Jh4joqvfaQlAWs8DdDBDUpm3MUp3JcHyzppLkvo5IuuwiymJRY+ocKSo4Je6ubCL0kJ5BipgI28uGFURQkaNoJkH4R3Mcgz3/L/ipYKmPazgVoWA5l4xCRgIM4r5UKRzfxfZyAvn/wpBwRnRWrNky/zhVQspSRRXOQvSEnTTRM93NzPtFjYGYmHGSM1N25M9cJYt9KUQMNVJuEq1TiLTGxhgpwVCxmlq0ALM8SurUavL5Un2f2rTM+2l+ZTMpNZ+l5fLMs+QaWQMEZR5JSNofBagGIlNrqyW16C8FMGWd32ZRLYCK6F7ibEWNsHmzHQeYuSmO3jeOL2FtX29FRYGGVtg1CW5q7yveQELgwSN05KFd0oxC81iU/3l+qeAGFwXkhTYlueZkc+xcTGMm7AKi2CkQtPkmiBaTOoVu/0MiXWFjHzgpfvx5TMTCFV6CSUHalK2O1zG/BSwY4WHaXIIK8LSwmCXHvghqg7M5ABoJWYFz3dYidEm3IF5djblaGhCFoutJU8K9RRc9lfL8GYrp62a4D7iuGQip1M1M8PRjzTdJhlXDQevMpLNt65dV5y0CEzQEadrRnwVioOkiD8nVXLyCTuz3fdypdf9Z/Uu0a9oXbqJ/yTOuJEKsNOxGoM1H3Xn7Lf/QJuo2sfNN60qK1gk6y2pRzukSTM5hw+B804YdGD2QqDG38oSNoQpMF/dxjdMK40kPfnEqKBRRSiaYO8ik0G1UgiPVD8rsAwSnATzxxD74PFNufWeiDz7AXRNSuIvHmT70j02wmkJoJIhkKLG4uyRPKNwC4nyUC/H6siIrbvW/qUdgiVd1YdKerRx0GR6sIrnYhCVivK3MAUV7oL9E1wYaomAl/HeustQsnZXL+R2CPrNnaNN8CXzSLs5ESzwp3zH5JIRZzElmWt8NfLDP0MWlL4KdipoXX7tkz4Oc94tZz6j32Cq5OUCQqtYoeuavrNAknb+hGBa/enPVotWTru2Ut02Gi3semm8++gerEstRNs6Lg2FfWGPsds6wVMIoWhh1HTaJrZ7pM2AFhwLNIkDVJz6tNTYIzbABsrWz3GNmNFWoqLkZjA2KflJ5cj9GwTpC6Xcn2M6wH6drTZNzBie/y/iSLdouqf8lUFcdsQzyzk+c5Kvig5siX8KyL8IzWOvDIbOr1P/prLJC9KsU1LAPNjZ7Cm1xddZxb3j82z4swpb4EeDdRVsu2nuGOH9d/wxIhoun2gSXvaFpvI6LvK1bYAGPxbPWwj4bQlsG0WZiqrJiMfG8hHjT5RemRfZDqFFNU/SR4czwVquy0MPGKJYqvxNrAPjnyTwkVvRpTwQpzKKnTOQhzpBq/CNHgKXjnrGxkxXVeUqV6blxn3SJlg+7ehjIUr0vlKXKm8uO99nHNf6k6KuEg6NmVEniRv/5kcN3akWhsgMWKl9eUEtRaDTyHyIJl7Lnh9VzaUsrw99W8I7EupkgqMyVYSeyBf6Mzao93pMG6TeXvCs/wSCt7YMmonC2PiBpbFhM5wp69KKwEL6Gp0uqLk3Fd2qUOA6dK7BZg1iIzd5U4FfV4f+jzynKkhNby3xQXDtlrLjRksqRYqJM2HO/FV3XD2XQYaEUmZ91FQ2swcWIHUFfJ3JkXZlxgcZKE8l6udbEeOAUHtvScwqMtOlmCVW5n07+ZtskDfoZkhK+XmWgUdAk8qBQ8Q2DQFCgzfMLCLnWUYX/WjlRotpT7PhYVa1u0mx7u1T8e9Pucxi+2BiYvpSiZB0AgJJQR4iIA4TgJXJArHoTR5GAhV7MJVP01v3AgSWsy07GzZ5Uf/xTlgRZA3Dqeb9OYAiydM0CLsajCqQ6QhGmTR6WC9ETt7O/TVa8sQJEaDJPxqHJWCFvqLAe7CcF5+ywul4uWmMFgMMDWbHP1NRXDWzaXA2GSIweDQePhJdYE0Ks3OQJdG2tUk8EfDprgjlNLd2wMWTzLDCxcn6JyUYV0Ji/qzGA9pzjcDKvhW2hUzySgh6crm7m501vglfkcGb+uqMuRLh1nUngFsL9kwwzINLDniz7Z8zl0RjNystuTe9Fm26NshKqi+kePIqlIvOt9Nt8K0TIWXOjOnueBaP29AC84aI6/yYTWSHBV+X4yDFFpzisi3QMgGNow7mO1Yz/co0CnTZ8WqdNxRdFC4YnhQ5809IoqF5IGyBVOIyzVTZi1siu/yXtAeywaA8l2HlWGJhBTzYMfSRMu7i9TAJ76zqQp/6fLAVzJxunaj7h2NsV3VfwVA5wPfWVckfi9HzkbKhVLhSRS8kQ2YkzqD3flJE6KSZLVDQYuFHxmre/3XR7aoYirn3G4WDvjd8Y2TVpqStpL/U+FFYzBiNx5QInxiCjnYtivKV9WN0ue1MhuwCYpb0KsKNqVvMeeuDu7HFv0bNWoD3kiLA6sFJW/kXCmt1pZTbZbR8NUE20wmmZGX75nkfW+Nf55pFq/OkclOLLYlKJSTN13Nv14Zj186NKSLD8fGWJ4RGdbPlk/+qFLNQ8PHv0bxNqAlLFalzucn3tad5qqAYQSbZbXHxp6xi5rUfL/r/tGuIDYFu7OUM7aNeC/q+LwUUkemluR9b01+PkGYFO2AsZTHNokIrpdKPqytZmVYWBFORPCZnbzoexsiILQo3xS/jw/Ok0l7xrnfXhvovFqBkQJULhEDDxNXypljX6SXkBBONdt3Ribe3M2hkhe+GfFh+0Ryirn+IoC8Cr/zDP9rgH5P6o/06zD5XSWoMMjrRj5mfCwW53gGzdrTjNfzseGLhIJ+3mD6XPX6UCsuWuqnY0C8f4mEp21kz/y5JEK/xsTp0hUwK5+QlpQllaiOMj9t8H3HnwX9iQdJ+HFMCi+uBLUc9MP3e8mIWil7dPgX/j4v/0RwCPRYle8gLISTa2+SThxdBFuKE78cytnDjsIL00El3ans6KX2Ogi+7Xdt52vX2ag39nzzUn3yTN482DH/jeeGE74JzgEvSNctGzGCUoHMFLjuoKtl4mUMcAhroRMqyEpC5PMLfKOdT66AqdnKQK1tbcg43GZ+YCn5szM2H3P9hTch/FJt/FXINHckWZ0VjHy+GHfPwUXavhvDzjYRFiykw20QIwQKaSjkpMhY2OmIcams1poH9QT+jp56V+KxM7/CVbtqRCA/8LezRIUvixrAppC9NzAJ3/dORhjv10IgaTcLRBJbM8jzJ9ML1zXAHsM8I8t8w8foVroNFgip7AduyaBG73V67fPz/Yv+yT54u3+t/LMvTLdFbYCPn+zjH2cdAnhylO5btSEmW7kINEwUY3OjUT6WoG0ouxHWXXcvuOo3AIBvsd9zYICbv0r37R3Rr/4AoiZSHZmGTAydGqEWc9L8Ra75nCpcg2EzqwnyVR+LHjV5zKx4ONKq4wWV0zZtBrabuWRuDbqBTm2Dt00k1PYVl1RDf6au6TB4zbGvlXBSX0VJUgx18QJN0fyw/niprRi6LQ2ylY0tA/+e0RKFrABDnyi56CRGt15t9W/HmHNuYbp1T+oRSsmLD5zt/mEcY8nClC5oeZSNbsLD1iaI8Yjl/M5RlVFcCZrajCj8CyjaaCtvGVXXIV8N1c50nckvdW/C1bvH/CrsGw7f236l/sLviYNYhf553N2jdlClo2mckE3YN39ssPOkMsoVI6XfwYB2ZYyKdf0RmhmGv4zy9Xinifycolvk1lrYLBRi8atRBhDbO1YDS6+AeyZFOxO7fcxZbIDjMy+XmHpVaK+sm8XyB0FL63l1wQswVjtIVgCzKxiv+CdDObmrFLggtwo2box0hfJ4C9aoo8N5E27Ab8/0rltIkukxuSfuxrGv73KYSR8+ATRZ5G4A2Y5MkpX5EZ33ySLGxpaIjv49n7lMIq9POLqai94ZNim+lXagibmk+CvW+Kugv/Dh59HXCufsdXYKyMrEco62LowXLmoZOvRH3F3geaL9XZqbV8+2HruTEhVBSZPOtXXbQt2jgIZkj62m8rVP/StI6/IWC1uUEoZuA/3tVMM185uNbDWbD3I72zt9ys4/pu2lv6Bq0SE9Q1iCx9JmdrwS8yym6bduJozXcmlM/A91DJwqdlR0SkehQmfWkfw9cC+nsuUJLTOwVQCeDGBhoC8sZ6ePzAt95+mfzk1y52kktYLyQjUA9r11eY/rPg0yrQudN972uvUET8qVH4+6wa/6NpTFErKaegPu/84XlZr6Fz0pdM1JmtBou6Ho/3xwwuXR5ETqR8nOau+2g5fTWxEN0adN9TJRuCG8/uirvtEQDzOxMBqVHBW/E4seF+w4dCWyRr4/m2n+um2XrhqQptxrWXmOShgRwac4BBJjIgXE6qjnon6NWRjnatSq0gyJXJxTkLXUfTELsIgealwaOkl1VB976cLUrg5+1dfQ9ZrBvCo11L/oZZSlWNX6Px94/CElCm8EPVUFPTvt8cTqbeso7soytZJeqViyI126/s1VxXK9XNrYuz+85+j4p/tOFpf7TlY+WfMr/O5x3LShV3uaZdkAvhHqcOkkrnq29fqrlRFL1hyd/HJV0J7d7d57vLxnbyOu8tqDy3NqZ6ZMVsiXNY/i+uvtKa4SOmUVNGLpvZD/Yfb1xX/88U9B/e3koFd/3V1I1GX9uu94ys7NtrwIG6B4BW9ma+wuk2df1hIRZhU+oVkeJPagJRjso0f5BsVuNWc69D+Q3xIw+4/aTNk9Jag5tO1IT5c+FLXY3DFaY0ezsi9KVSldwlVZOOwDaqH0PjVW9uXxik/xmBasgMTQTvJ+dEC0NqIf1OHLBg9Fma6xaVZ/7PLLux/GEeVM/JwnyccpfWaA8ntNYyFQdEGyDIylrnh+0ru0o92eIa6aqpwtzdTh1JnDlNodEgbGqRxnbZUCKOW/IWZtFjduCTYkytyXOQkK0igscxdCNE4cmKbgcg2xaKFhEerGaN3JAZDzalu+GLd49cAHhe8XnsqWfVhU8dBlpxr2RzFOyn83luApy96uPGvu3Achmwa3u6OmDF56hChucnXc2zBy5MoK/9uhbsrz6I2gbfF/I8NWN1cEH1dE6WzShuGG7ktb9oF6Nq396X15i0qQw2SCfOWiO5DgmDZBh7u6oCPTZsf4U+Op7RZsvKrBaJb4JKwxi4U16hNL6r3OWJ0FG6tWdQ0JZpIdJ9vi14eeXzhx/NnTB9brJx/Fr3g0qfC73xeRxps2ne12B2LCra683a4e7eFpo53dUmUw1aw21aaEw3XtHja3ziXNlllwee6ZLo9r2qI5YjkUvhAXbB0wcl1UfuNAfFf2r6gOrdU0JXiecgBHAgHV0Y1Oj6GbJ2mKFZqxsRIzatV6IOJKjZY05lVBdVZmjWP5u7ocvyC890QIeDF1uGjv3+BSHPU3Aken3b7+9WMpjaaTwSqZppyn826HPO4BQI6esO2w7K3m+N5BFWWIL9PlgysNr9kWUYaXga4mjpejiMLtixfJ5XJWkiDy8pntGIURi4nJjUKJoh59n+O1jF5PHYSjq6uB72xNpZRvbvpHa/X8Ijw2BN0IBxf1NvT96P/B3xfrZVdKux6sTDQPacDe3oEujpncHv6vp7TORls7+p4Q1kj9cGPBDzm4SpPLjXYkeDeZNIe7ujRHNpm9PgdeDORwauXVtw3NrlkztKOtVYkqczZwDcgKRisALdoT/NP1qiOtbcDFe4zdD4e4fu8cAtzk6/i3dcgxjy/EhfSQX0EdQ/SU8UYAAv1A7bgeoYz5FJ/ZFv9rH51e/6qu0HxK4/yBNasOzEO2RXRsKjTR6fNNdIamZtf9NoWbenpiwlYsYav6Hxf7NrpU1U4a3WQrjza6pAeFNca2xLVpKZd8YzaVu0FzDKod94Eg6AUVheCO6dM8bVuM6xjvclcUiur/vh2QJX9oTLzMaeK/nxd8Q6gS8vgaEXDajMNBCbp+nqwFKzdjo0GnwQDomIzCH9FKJEWb4qyplNO4TEtTrRJsZwu9ywVmLE6A6mCRhk8pvAcVAEmm1EZuFUTh11nayW37MrY9bAi024ptH14Yixhpdoh5rg66ehKZBFA5X1gvhXyaD958mXGS99B9N/gNsgL5JsjHmRJ0fXWCXu37KKv2eiN6mx+SA4bqhBUvfdmkYi7Zv/J/6bdjLrF/OGvLNkObINcrcYy8ZX0pyyIKBwl33LcafAu5r+R6bjnueX1nC2FNwodF/x70vaoiPh8u4kZqzjENZrYjH03qJALGRmZ9zP0+tG8IZjbTJ2eAxqtMnq90PJ17Ki84D+qEPL5OBM6bcbhqZDgvhEiQUN4wosbhekmc2MIg2TNvT86erc/twh1+sn4bo3OqJBJIgyacK1o9wnhwwRQZDwRtFl8g6P2qMCcVeCGFeMMcwWyg1ipho1lUdiLfvLawVPEb7vsYyKuQM4lCdeHhcxkYJUciYdzcYYpMUHVajRMU6092Ek/aJGAPmjPHIxDYIKWKyJfNkSmybguiaOJ/fqRNcFFSilWr5RweCPxfIghDIWXOidRXiLn4qc2iGIaB3BwGqReRJ2Q9lSHzihmDBgNj0CsGILGmyWrTNAqVukabVds0kxcDtIg5QwjCGWyRALaQPdZkxE4omXSlttFm0zYq6UrOeiM21hhq4sTESD1i2qDBQBv0iKU0Y5XpCbKoDoMsZnIZJAearDagUS6LFOlIFCUrW3mcLgjmBP2XIMpycealVOmJUMWoKkuhwCYrrzaUqqfIoy2leZXP+UdXrW+FlLDNroHNSqXWajBorfy8GFWLmD2EIOzBZomyLtJ+rYPB2FGH3rvwNfj2RrjOg/8jYcV/LocXOh6fRXiML5gwoUXPRWfURiXmqlokt6EhCHuoWayUNgo4UXjCDVpkf0LS5xn4eodKo2DzQRV7YkkBKMgcsUKBAGD+D3mVq4HVS8aMA4aQfoXUiD11hadQs9hohb6GKm4UsrtUalbQJxQxTZRsBP61fqCxPU6itWO0y7R6u1Smtut0oP30ueyabAl8fP6IOWrZsxGvy96MFMMa/t3s/QFeRJYL9NUM1NJuNiC87e0CjQbgwlE4OAlJIkfMAISsvwtLkHLZF4p82ZR9tCyn48PvvyD7nvnL3zqlxC0Q91NdiLWwkAjwcPLZo1lmI2sYFK6WFREBsdgGc6PTgIg3tzNEkJyH8OQ1EIch/sj94V5wdhlKYfBAWpmFaUB4AFXN5YFqgNeCl22KYI9aQJ9bki8NIa9lI4lBkQG8R6lsEXsMCGcoooCU8IxgP6vaV+OgmWMgBh5GiHTIoyEPZ8GBt4aoCEH69cwXUshfXw/JUinscjVA7sbGIdjQv6rBLo1LQzKA4O00LAjfdW36C4aIkWeppYFBxGTQxSxg1Bq4P2KmKGwG+VqKEKgx29AR4jAGBu++J4PcDS4TlKbx12YDnASENWQ1uKkwpW+lQLoiprXTg9UYsaN3ZPSn8amEbrMyTl+RXSlvtDhlJnK1BjBiaU1ClrUInyKN0cQa8ZWVyg6YA/8ppjU4qUJXq1fHYIEYyQqtU2pfFegTwAII4Qn4RilaBVXxpXU00lk+V64Q/rk2SSERygQgAA4hQ08BT/FLHhWqgfqoMnzuuwjlXR0+aLKH/h8D2ZvtBoSvoStYdXJYzkWSYJTQ0PHZa4m2neeY2Dxnnz0YYoNnhs9YHnzojG3kzT1bODsi0hsJC8tcU5cnL3teCX81zrX56parQt8MwMuZcxXmvr7ctvfMrHDI15B7p2ldFATskgIH1qewEQCtnTHhsA6OCc/8gp+eGZl6GcL20cToFbUmJkbtUpGHVQBp2KVWc3TVRgBJUofpVIZaAsS4k22poWabbjNoYnq+iVabZxEzNtsWEf2GRC3Xg90h6hNCdZDVllq0LDfnH7khfAJk1imUMvFwRlI0t+C3mGy/IOzM5iv4rNJ0XeJMKLFM9lEItNph2GoHNVYH5K3UgoozVMrZispztWbyK22LZxD3a/OhVV1+76rO0DH9/IFVaw7Mm2yLpxB7kIUD3b4bvW/Nkh1VHtgDZJz8uQQvVWnxM/dQeYaYQfllLoiOjmcjZ8130bwn1fvV9kYcLoHsKnM1J6FGhp40IyFbIQfw01xZk6DvpvDN5WasTCs0QyZ+HR/kSYeQITlAEtO1MsSqETSZsSjH0klHoSCdZ2OLeKB4xSr8GJNR38mYXI96TO6xRbTD3j5Ax6UkR5tH7cLRhD+EY4jNzyYT19gCuyyuFpnRVIcToxnZT5gU/KlFNJhU/cVyLUsqktsWE/fZ8Qa5zYg3ee/2HHH2H8vrP3jz9TfrUzsJDJIeN5ZgDs0qpaMw7AB3EzIj5r6ZFYBNn1kT5FabWsn2DY4WMoU0y3aUm4JKcDS1zswmxQxuqoz3TBHEzGa8pqe3s/kJ+rdKKYL1HvKXbHRRCz4Lw4IIduuUeGs07LRd/B5Z/H4WnlVbL6GY+dCq3rbWVV2h/27M8uZhWKwEYBmsuRM8hUQHtDqm37WaNxW7GHOSVIAtf+VS58m8k3RBD6x+I2W9FOoPepv7m0JRHC+n1fhSxEuwjCUTykTdNkrz7WtSu+qra7Og9v6R6E4siIBRXf2jDkvQFWuxdiDcNy4etSYYxsTavlhQLRln6XRZFhiO7ljxuMPQbonX6Wlds2t2L6hpM3Skqws6PG0axV0Nvo2sQH77stZydF65Pp9D6I7asffZyYY1ZrncqfzwGlPD2r0ncbu6OAfE/vbZNWvad/h9TvSTO9vNfzFfH2dx29onGnv/e5rO2nkyc3/rfMQ8qONKpTDe9dcT4nXPI8/XrtCjoFajRBCxj3aSjKb+Zv72XkOlTNXG4bQCPWvHhj4tmNPNeVDP17qvLdVtvTWhnUDZSI49/yNShzz1aPLJoq+XOGP9sld35NE5Rg4jb/aF+mUR0ws/dDkshyvl11cr1KmyXEFqHtkTMTg41dTQ1xcbCFNeORRw9nXFNYanhtIKpamKXFVqWeYTVWT/wOQ6IPvEel/+j4GgupqMFGYeffaqCuyIu70T77uHztZ2xgJ/N9Fw8W24nWRGk40JvO1PMrI6sT+8/wJw8OcNUBf8CQ8CL9zXAWLtpUTzmRIo7h97O1eCxuqR+1+4RGxKXy/oP1w9ONPsx36E6+pf6fP0jX59wdc/huvGfOJaD4w3gNrbTlpMR/+Oze6sCZ6+iaiJfWVlqQ54/xraEGupD2/IN9FZ3u6xQQW13V8HQCINZDJqEFEdbIVNGsgOJ/2OWDWS8i8Hs1miWqVVZn6uZgvtXnHRJcK+kZOkT8rLsmmH3XBSG5C1xLnrGW3ogjX7NtzxAJ7v08tk9jhw/I4+t3VB4CxTLFflFzKXgAWkbaxt2NCWp/zfryP7bFFRMz4M7vfc9/2jx8jj7x/5ZoKxws9XrmhZTEOrJRowhlucUsmXhLJsuhNw1Z4qLquXiPztRmy0sE3jFNkqyPJq4vWvv24jyzrNIJyEbHm42fJG+ZCd/6ZBc0TkiuhmzJPGMZCRgpIJW9uSkKWPS/VNvwiUcFLLgTNMWhJ9aP2gbVSGRCf0zx9/jqzmB48fKOCkQzKLx0v8e0sXgQ+Bi3cL5cwsOsaR9RiNDoYjoKcMp34nzyJ3m+t9iNOJwRdXCfXBu61tu2IAnCJgQX3kvZdUWVTUDTe8gbzBfLaGBpf8/gBJ0sLHsEgr2K1T4q2vsA4+mycda0PcNlOLK11+s1rtN7vGlSuFGAIBI1wJnVrqA95d9GDndys9bT2WpbLm55W+p5cGncXuBl997cHjBxCpVr9t4bbFwo43KOl0IajDKcO/Bb5drgL1IrqStcqIRUPIp4iNsa40TkBWpT1GLvoGFNeJzQq0SDiDiAZ4X6PgJOSmFdc2Pu6DhQ+Q0jc2FtVqva4Sw8OLdA4ef+s+31AHe4zub5KQCyN95wPL17+2niUkEoUOWCaTyLgId4tkyxoyoimPKCD7Ql4G5GXdKYQ0ZvvBliUQAPuQvgPAgQ19Lr/xAjjHrpCyj88pr2Dz+wIk3/dFQF3Eyd0AASA9XFAIfL3UOeGz21/LSruB3EjPfP4ofLbo8sldz+0aArZDOWMoemvdtvy4NzA5nw6uSvp+ROlKLBPgf9GBy0P6b+BT0HAEdhhg2RM83nPvXnkKEB33i2PXvLR/JC5cDCwgbbQ+UjDYwkNvvYbZCfPkphG97cYKePD4genWB4mW/YeZWHwns0guFZh58bIXgM8AL94Hn0X1PXXqTfslmaHz9bufWX3RDtwGa6rX6ib6Aze8pk2kCIWgbpou1Pwx8R0VsaKcjOyrAbYrJCETX8g31bdpDkybXW4LnrXVx7ZfTCBxSIFWSRoBV4W2tLchWwUGQPsVSHXK4uNs2fGhHBpA4gv5wwv65IX51uxioKiCDZAao3duIkIzx8BxFnsovgP2p5cCAB3w0YtKi/KBfK0cEtEvLBGABHTYLDkcDEqODFtQo4OAusjh1ArV29zb1k25Z2xWZFPr8Adx4Hz8NoDL+bVOsijiqoh9va1NjKhzL5QwZBK5CtVEy83YGP+awa62/k4bvRhExMoyR63LX74OGahK6B1tizCasFiBiSEmajL+JsvrhRomwqzT1fA6NspktDYzNgrqdzW3DPrMwYFSSRLolEhEjp6ac2t2NYGub2yfmxDTLvSXZYiBkdCxqm250YwdRLlilRFRqVAjWANVYG3EjRuRusyrz8J5RHmAz2mTy+vaOnmT1Ql9qw7uMOXsFHQ3iyCH35YCmJefOcCBGwajByNnLRSerInDblGCdR0dXLleZjJBgN4gJqvKCPIaJWrf9mIb58uO90DLLuRv0OQNLtI+7hNVJ6h7SaJ6qVTpuPkjQ8FiMo3eWmvw1TKMTJbVf7ypdADU7sA9JPXzIjmTRZFyJGIZh8KSM4U2yCYQ83WA2aQH+GKbYDYmwdSGJgstkS/9RYXru3Fjke+ayUxpE4/bDoB1He1cublDS9viMWfP1rU18upkShuiBgwOlVJfD6gQ47Y9MerVTK+XuVqjZk54vauZas3Eikx4F3M1BAvlQTkSsNuRZjmg5pc1Q2D58KtVT1myeNWxWeShd+aIG7WXP/xMJ0QTNeXvVmXUOjB8yo9j75+IZr+Wcuy71a/QybViHlsgk5h+F9eWZHCycuo/4J7e+p4cfbyTH+TCfEYhJfuf0iLSv3VsIcf6R3JsfsE36ZmZOZmsTIIuN8dZWl6d/jvxgjWmlzPuCZGFzqbf559+SDnVymrdOK2n/zgIHhSqpXVMjopfuz7aPce+lv0974WSnOKYgtLVxZyLvwtk1EQ/5okP1unkQqlGxM7/7EDpI3zeDfTqyf1cpoSb5+GZIKuAVXoiIvx0cXmopHS3Oaqn3+gJQaP4EAuoimCfocs5RzjU2VcclCvZtOIjxPk/S0gP+TwBjVTy5zxvezENYEv/4NLT7uTm3kmjc86U7snNnS0tm1z34QZLw+TTi9Ss4LPNm7xpWANoFbLKdhebog49i1PyUhYgloRslPxAFQxXBfj8qmYYCpQPDIJABHcAgj/aKX8WglYTL88j4TK5+09eNdzMwz8q3fxZAVsjkgp18i/wu0tLQuXFp8Mjdjdzt9TUztFK5b+X57i68OJRTjei/jLF32+u741Ftp29dRJci8CEBG2XmX84GOQf6bJoda4573BXMGbW6g3ICT6FzNzHYJiZWmfYFmhC9p3dB8guQltyi7svnZnK7KEkOvNeyJhw6e4l+JFBjtrlprcRlR1f8iZbZuANf6yQwOx48uAVXpblqQqzx7KR9OrgO2Ral+iJA1ObUfVuec1EMV5U+d7W09wP6nOyOBklteLfTTKJgC3m1ZLpr6z+7ljKa2ziHBu8QPw9vbq81JmTqyNksjJzMjPTvynIj03+wyrksOv+JRWV/pNNKWTAfPCCyHKKcvoh/z6dTbec3No2XfsMmyWjCn6/yCleXVoQU5xT8gIv+/tr7Llo9/paPkfFrFNLNafZAqiAc6A3tufAZ/lTdUJiFlo5R+jyM+yIKhYgPtRY+hxbBrBpxdt5XWJpAY3Hf+giHiHKYnfIVbbBM1lWOruv7ZFeG0sJjwNOPMDUonYafYm0xyeQvzbL0ZG+f8eqOtFAJu4m7ab4+rs586KoKN27RZENWG/5LfRWeYQ3sqHI+G5dBWuKJ7YCSQUsZSCOyLLv7pKiCqnzT3yeR5WIeQCoWi43Y7HCOm+ApRS6KAwrt44LCir636Z5lzoXdSdCUYXFV/2HYePU8cB/1p2loufP1X1nIUgVOfWduN1XaM+QyM/QqOfJpPP524ZrRN4+QZ/IWyNsFjXXiH8hsY2oqepYBu9yvfnyRf5lm7KvLCl5Sx8jRfKfMcVIzSWXFV1gBOm6GKk+g4xuU8lb6C39rZroka+UkXl8a1KXDXZa+r7Wu2HBibjA8ryk7OykvM2RZkVF6SslM+/TwP1XBQieEPbT2vGFxNiB1FRJmZUfRrL/lkyOZ+8pPqymmsrq5EFcFDPCo8N4KI/wGPwLfMOUy10DXgXLtO8WbxwsokBpBSRt1eO9S/JqSVJpMZLR0nVLnklQ4+v2tvjZp1unPvzm26kPVCOfXQvUXeMH0s2tKv7GAtcSoipdFt9+k/go9ByyONR6IVVWq6+legR6tcUBMUEwTDTQiiqh7su7AFU2qqgCXAbeyYL9ktAy4UCFid/9sgZIaPsLAgoDL2GzQ60X0OQ1+hqaW6hXmx08FXc9rQ9sD2RzH84Vxbe+Exk4KC/b/O8PxX9/y/z60vVvlyIdm5kDuR4IMxlucSThHkQEv11WYr79YcfjJ/UlTV69dSPx4uRnN25Z2D8P6YQ7WtLc9AshPPzCNPwdyXL3T5yVyo/qi6JOqjtJ8VCueLyukuLeVV5xKRyw1/GRcRfVXXvF61HtKndd7S75n31mmJJ8kiRReSr/+qeBR7X/xOWey9/p5X68gKB6Bk/gbcoE55LPwCZslA0bZYJVhMA9lxATWK2poLhT+8onr3zc7uP6T76+XfK4gICJFssgwKiJn5zEoBilnWHUHgDmi0WRIpVYjHHZFk84VM4mbKfXxJSAUwqczii1jbV0RFlVVmSL4TtDYQdZxLr5zU0RvXDI8JNhPuqnKBnMYzBB3vXrhHY6nUZvT0jYD+6t9Jy+owMDOmDMiWvigWviw6JuwiYTLRA03PA95jmIadLXXOBMfTc15Z2JpLzTF36SJJ8kqlssKpVbU6JagRHXVld/VzGBxGwGHjGsZI6+R/oSLKbRIPaSrIerT0430FTpq5xEv513DJ64GqwKid0VA11PI+iBTl/d0d6BAyJX51GjdX8rTOrXSxjl/SsjuvTkalO9RyumttoFgipJ0aMwSJnwEVaeRCRTWAH7hj0zW9oON9ie7d6wY/vGDgv+/HTt93nqChpNzq9+P19NpJKl6vAEX4/LSsyUcYWSnFIVSWNDtbABlrPEFoh64P0an355TEn7G4jPq37HU6B5feXPZSU9JeVnyvLXEHdRxOnLTn6DVEtJtSLOdEqt1E9mWfh8lqWRLLmxCA9IBqDsOrGbyIRFKHZUyhRI5EX5gmowwZuKSlnG+nJruVzeqbNaOszRkAE7LK9hES/n5YsUyZokM0FVDekLtg4SCTSRrTSfQWouLswAksrKLxSkXZFl7917nfZErdH45tKordQQx1cFgVWNXC6Ch1DJ4firQC8goBVfxbHSKE4+n2KHLHJqwbIaKVcTYdhUwZCq+XwpyKi8ZNZEgLVKuKKJ9yLLVQkAFS4WywG4XBUZDRVeBw2VawUONt3F4dAbHCyBwMkCMbw7cjnZVaJKN1tAIuRn31YP1km6iT0HKbl/p1byKPE1yqomCghsQlxZNB32OeDWorYiyMHG2iMAewQ2Bd/BzGa248Vv7yTIKypl1dWVcnk5AZuWV8qpLJ0NyuL40rL8oqL8stI8Fv6H6usG+vVMa6sNtqVbp9ywG/r7mUp6vDinnjsFnyLPotp6Ivi+1/d1hGfgZzyzUvb2lcMTOxdpwy0gA7j4SQzOrU2xP9UM0/vcMnH4cptsuUMWY7XGqIzYxlRlwUSSmLN2unwyzMutMx2KGsdH+UNLIt/zHrjXZssgFBZycR56t3XsRfbiGIgFF46bQ8hoZrVuttncW1D2sB2Pb39Yhn/ogP+vHA8DOWaNJ6ZvdLndiMUJZfAXj6DkenK5jIoEW9zhZqDemODtidaZsA10Re69UL7do2DSkIbaG6ole460tfrbg2KOfCKb4yHfPSWig/R7AJqanhCPNQCOBFDTExQq6rwsqSdeYMYmCAwwW+1wJUI/RSt/wiSlp/4QrbySAtRblXyjNU5qxcZIJC1NPKmsg6/pSAS+ok8A02vxtWKBmC3jhuy4NNOgzxkYaLYlHxjgAtmbxJ4qho6Jv8wFCMDmwO7EahmXzUQZfNfydO0652RbLyyDa2EZvOUjWz+QJrPLtNGxsTHhWpk9XdYPWAdvBPnLeY37J5Zl12bHxsdmHx/0aSJn8f1Ad9hynU7hBWBhAB0w/DJv5wryT1YkI2+sTreGOdXOFPu6N5B49VrKFgeiRmKQ8fpmNTFZGUFAPz+f+1sODSVLIVi6sLji/aYyg+7KfZB7vquXqevkuuqikjODQMNigjifSTc5KFyVg0yB2tyRr0vIVSyJjJn+9ekXgSPmqpb7u4wHuRvBBSnmNLjuHWRgH7xhHXgaI13IdTmNTgfuM5aWwGeOx/83lIJ5+KndUy2+1/1Hxu0FQKcfvhd8F7z5zonKwTeT8s57ypq0p6Q4tBN8vnT0GvjLVkN2FwvmIyufYTNy6Z3myF/yV+i8R4bImnZkdEJx5NLBOT4ZWATKf2n/Dhz8R96Kd79YdLPp4kXweRpjmoArgCvR8VPx8U+YPmwMPQDp5F522XubNz+dTPtr0zoufN4CHPq3BD8SKmwGrrNc09dT/Kd2ElhBBBk0IggSSEPqgX1mjrgGJFWDNeQKSE2is52UKjm3kV+jqtTUfn9fTSEQ2BVkyom56PIK3ByCkXjjNRRN9QwxUknOvkYW6ONXrw1ZJDKNQn2kSCEipIB/hzr+CoFxmnNfk2sGZ+I7QDrYEg/GX4yvzEFejocVIV8jwwvxN/phhLFjZuVN2BnY90MG8Hn0waTax9Hu1rFWJbXJwRZUyvKPZrimusczklWNSVMw1FW4BbWxx3wiobRKWFxqUEsUUqFIYYQhvol7qVWMWgwoahZLDGbUYLDMtBqJFstOVKyn09dXlO9eD2z3hZdCZIp5hEFw7fLaqrw1XoovfcdP+78Th7SoBTJ+7ISX8zwOKS6unU6j09vjYquzq7ZMrR8BNa9gFsxQhtety1cTYuOqdcESnFHJrKMZ253rp0Y0IOaVhQL2JV11XOxFN51O0+NSKUdnvoB55UlGqmSnJIz/GCKJeULCpMpBL6hZeAXzVEem1lfWURCciPo+tMfGjZGqSHGxYxEGJ3J22UZ2zaeEtQ90Q7kpnhd0TWSRuKyYxBOZ5PsyU7r/D5OuulJ/Rmtf19AVVfsmwcmbha/NvTo3kAQmsjv3gV9GinsgEUwasJNZy+tpPnLk0OHA2MiV8t+tJaXW38vxIJ7vYrDtHI4bvovOX2qEe0ZHl3huOlLdDF7ViBcUWUtLrCvDXznnOHDo8JEj7b9mvz732lzf4C3dtvKqUd2twb6IvG4hZB6Z9yXvpRYDL/eDlyMGCn6dP8jbRmOoumX6eKBvsf/QFK55xeR77bXXX/NTDyVe7zs1tvtfD/1Ir4oyIAjyT1r6P3o9gkRWbb8eMdlf1Mqqc0+UnUgtlvZPZOsnrdDu7ruu08ty/klX4l0x7BR7fv3o9f2S74rLJB+k//NPGoCEQr+cymHI07eL+CraTnj6ekznCMCm+HAMvJbuczFXw1rmpIKQB6/4pBZOJTRgGUQrSIauU0OrUSM06WX0h08aUQVwHapp3h4nTaIkKxLe2Bnz1mc/xsiKmZFk3+A9TGQlvPZsR7Fn1PbxGUzgMu940a7SWGr93wPHnyM5JxpksYbvRVnnUFVBsyy+u+Qu6pgcA+ZJuTBLsyG3cgXMte0rGBXlnI2MQIuOpw5d5t3XfXwmwjNKMWSJrj57dPAu5vviYmZkpujTyz9SZIqEN37IhD507ZiQZf9d6Rnh5JPVYFuYtePSzkupEObtS+7IzEuUYEqocS675LFebMK8pijxq5IgHrq1xOGbuBA8lPBVKVgcTtUA7431PmfhqcVWRTG+qDi9WGFVicUEj8vkQl2g9qt12WrD4gq9jGAQemROqlnMfYJQnmTGLvOEPiETmbg1nvDlisq+J7rwtIWnklawhSeLivfXsCuU0po1dXgJ/nnxhqRQUtZYEQ3JebFxnISkxmRqJlCeQYr7LCWZXUIt508TOhSxirKtGi7l5aTaFZIe99ZK9sqINPLLZUXZOoJFx21k050lFkPNDw56+qHs9JVCQL0ygy6oplQRZiwmSxnh/h/qabrIDHNfkffMFUeR6OXJC+QLVkHusu/xldd71n5ESC7KVXM+GydVXIiN/f+sOseUQY6kSlKWnAQfg8vweNHNkChytK9aoR6g/O1fkgKoMFC8rnDEkUXC9SO90D5eoieOr4h/0I7dGqQG30whdBbl365cFeaNtfv+45Kl/1fEJ0oSqamMsvTHj38CYpL+LKKmZDtO0Fn/FPUCZdSuGi32mvvtDy4TqbROYbygSrdJGdU+V2jE8RUTibH3E1ds66Sm4atcRfnXYuLtgWNu+eVOydL/WQkrqInU9NLSjNgE0S0DNuveXvNAS4MBB8cHqWAjmIdPU1P2qyNH/76JPALE0IoraPl4rCXWhtTj6WknUlNPpKUf3x9rlmZtsxy7MxYy089mZJxNz1zIMjc0hdaj9ZlTVno5K639JPc3PeW3Mu4ncYfVJnXs4eq/4jyIM/5M8vxqwsraMMsyMPJjylf4J+4Fm1M0EP8ptiSn0ZXnE+i0c3M+y7cZh7ERkEuTWeX5gjaWdsWRM4gTSsYLtwllorZOB18pOaa4h6eHMEwMtkZTIsgos2BTia5kXFE85/IrYGADVxIsvi+o2ZNPv5aO6zv+4UtmpQaFbEbORujkbpzL3pQ7hQMzg3ahJMxHinnNw6U3KKFDKKG7KKE8lKjlOZhpAzE2uTtiCq9iABS32XwFHEjgGa3oWlmH40H+H7leVSuR6DpAE140XvIkURvsNrGRQYpxGaHSYA/bxJytY9iW9lCR8f4lwg4IbFPt4QRkT9qUsZ/7p4EAse5IccdS8UAuQms+jPXm731vaUSu3qJNj4ylK0o4EdR7Z00oS2ygsZMX/vs8icqdwoGZQTfg3NOkZLzkU8JDHrUaF7RMlRlwCVuekRHFOkS5DmlQhy04f6qIJ42Q4DypbjEPOdJu6EEq/cBYQ0hSxjGeIr3zI/NWz4VSxk+8fugYRjjPCtRRrjZxoP4auV79T7I9t47ldMZP2SMmTbU5pxIbKE0R5Tw7QpiiWkzRc0xRP6bQv4yZEcU6RLkOaVBHKijg2eEuzcBUeD65y5PBILyl8XtelPy+MYXZbIOsbCT7hMiNDtmU32zghxSxjtcwteIQpeFQdQFsihaZZ5q0wGYsSTC368tDlgIh/5ICfcZLVTFzDXX70yKVIWQDMhthm2J+cus1GKq3CapUYuX2So87OE36eD28wilQzwbVtxy8ScgYr4fXbyjf1cDQXeiM4lDZeNn17V6G23hXDTxNFdlOvIMX5Istx0rEq0Q1PbuBiJRapNJgyzIbN3xmrN/vq7i+Bv1Umc74KRs0PvvisX9TJTnXUhIO0W3/jNXwxhRThQXnkVr0EXX517tXfG/MV3N6jin8VKIuKRddzy+w4GdpwosfiN39aPHl0rZkU0rT4jmKMCs3WBkGgXLRnV4KCxosM1V5H9VUvl6yGdJm65RkZOVVnqLztRTmS2Jx3j8eDrXR4warjxm3cw/k8is5aRn1QeEbRuzoeaJ0i8/xWJpe6B6aBMixJQ4CcjeoxS2lsKDBMlM19FFrYW33pJrxIsmQ/rbOeWMZ2RSLG5XID7qCY4ZVd+A3fGJw3ZFifnXz0HUHWQ6ma6tCt4AdYuZKGzqD1xczdFsGnqx2sS6dbEa+HLdWZ8i7jO4+Uz6vyHg/fyGmgMLTW6TOvX56kpC6gffHDD0Ww7vSozPNyg1Pt1ijuh7voxT7WiHvdElVUX/QPhi7GK2HH1f4QI9Gf6wI1M2ctW1qYpEFYb7mhP3LETn7bXqpU+QQHiEY4SAO42eOR7lAgK8ypaYtzuKS5ozoCZzuklbRrnSOZ8S5pIi8q6g4ud81FHYmWix3jbgB5HydZsOvVfykg46YYQtje7ZP7ISqq0RBcJ4ybnEFOZ4eHVKrlI77dx+TE+vjjNju8yn69IBSGrwSGahpoCa2LZp7pIcHp0p3k1xlag1tkVb1jOjVwbr137H+LNGN4ir4VBE50yF9k1LWR17mlVuW4Q8kBfTZFTtamgls4LWN+Dch/MdND9IIN8LotskJigW2JdceqWWEB7OxOO0LVekGFTZYhm9g6q79knUX2hc/qZ6KG/xKROwu8eKLpTChwSzDrg8C5aI1ncKCMtWNPspVvkayDVJJPXmLZ0lyFNPPpjg6bipO8BCerq+gihE7m4ubSmFCg1mG1Q4C5aI1nVAUfUd1piJqRgU1mYqgl3uygUHTUUEHTUV0Td2KdN6DU55uS1C1uVUuYgf9h29b7QYqbnJynn4D66vSypfkdrPW0yz3kUdu4FZf1RXCLXcNB7kHJD23yabRr4mfqx7nxpvJTw9bLecdHWBQ28t2L1Hc7wnCTNe3Wo73uWWqlGJZHbmTD9W48mSBpIpXrjK6ZXJ4TfjCMdBlX2zLn7+mM861q9ZX10pfEneOkr/m9hnnmmP7qsb70vHNEiY36QHZM1tkY8k9J8wsJ49sKVfR2nNVX3DpYNnHjdwPu1R1j57zJX8zdMnRv4naM7HzF+cO+VpJk9p8Ih3UfchJoUlWF+us/j1UjNpym3hy0FjsuNchGpBGIlEvoqSztivhUP5RNLGzJrks6okkqzytYU43CDjLX7RSLonW1vYv0mRNaHS9WT5r/LvT4exOzvf4AxU6tzO/KogxGfLT6un38sknenpg8JjCDz7c/+vCqXw/nCjmWj3U+u3DZ9yi5XZdv+HWb+16lleqgxhqyNZWscyVi9/puLYoZl7/z1o7xF9e2f3T1ug1+B89ZzaxOyO2Hxuxu0za3YbsHu/tJ97c1RvWpP3oUx/6C6A36z9ccfZ/xzkT7/rXOHfFeTfEu////J5zQCweg/9/ONGJx+hCN3rwJDR68Wj8adqmawQXO/mYXexmD5+wV59OE5177tCmiEdy32n+/10GMbrw2Gg+r3RZ0p196PLhmKm5vAd4KtUM0qHHxPRK0Os5UPU8VGTIkCFDhgwZci/K2Lb/noov76fKLnbhRaHjt/eEPNgYnKMGmWMu6zFl4D+VW+XgQMerMR7lpeXePlDHURynsTju1jAz8T8q7dxPOPm7zrWQJr1Kx28r5K2zV0jK52Zhlt8AUYrdWLl7MTyr/wHM8pbjp30eq2/W831vcD/avujSlH7t0uidmkgWrQpn58qxfVepfYhJQK8sMxDIyKmpACVdelTszeNv4rjJb73+N//sxhH7rfqjWd8/ntcrY/Lf/f/Wy1/Y5zjH3v/jv/WH73aZfev+g21gP9/wTTnDLunXL/je/P/rnqndrYj/H7Am/nrHezYEHvjIfysG7vdo4BIQTCCQ/b9vXteBK0A/cnIDCtTnTy2ROqxuUpJLSbCor8b0rY4OnCpNslotck35vkm29Yyr0EZXfMRUvjOf0/IrnlzWBSo53I6U8eI0GtCPs5CjX22RO3U2udhYsHbb6WsuAd8Ho1vZOP1Jc9LpmigfJ++uyripznqZa3FqUOxQOxhpx5Lx5L+rdvI2DDkYTv8iJblrDOQSxhTj8948GQd8S+guMUJx/lffvLn8gN/YcgjkQpJMvjL8PdpVD3LbyRe6/GJmCn5F7+U7tUqZW9ftlY7ytLsYjxRX4mP8x9Qgz39Mz5t1Ow4o0H1zImUY3aGNgypN8lnt0EC5nwfKZZ6B6RZMsmiW+Vb9q3vAq3Xi2IvNmRUHPa2SZq+lxF7OBr2hWozsOHuV0Ei0YhxxemrpTOHepvWgEtMldPyUduahzEU9zUloUX6tbg3zmnhmqFtswXyMCyhA2lru6u/o4zGtBrs/8VldLOH40JSk240JBbvTPFP3hn8j8Ea9UjldyvvNFGN622COIdMl+SzPZHQyN+QDuWJtweIrq0pNh+JVMpTWbFkJSOUcS1TuZN3Qx5fqiWjgO7U5fxdzfYR4fIh4VEeMl6IiitnwTHn0JjUPo52S8Qir1N5q3F18i4W8h4PbtbPe95x5pXLFCdoRTPf2mT4nUgaSKEVKIlmkroEaIYj1LVgkbe11QTecyTivEsaoy4O0BB4ntvumlEE/4ct781NxBQ3/tfHxOp2o9ghWNAaCTHQf32XpIqkmRv1V6M7ptLmFWeppmIuYzI1bhtaABfJv064QPKWJVHz5To8CqgYdSw3uxkF/7oPEcy6xVgR86XRwHtpPj+4XgcDftTMZLXKtt2iubpfU5RxbA5uLukXE4g4tud0tknrzrBC1GOFqWxcmiWB5dpZyOXzEdIkCUZaDHZC7SyK6VdKUZwae4jmwVwQM8MADD4ngKR4DJb5Dcj9KplvQDSr9VGWlQ+2zPH6GlX7hlq94LDZJwl57KibdrZNQmhJ7sQfI67txFzARG0edbL4X07116xYtFvEp0l1aRPdhcg211JHQoi9rdcOZjONrYmyoW0zA3OgCuoOW3GNLLBzoRovhC0P3/C5uIH8uJnSfbBHhGfHG43Yr2guz6d4+0+dEyphLkQi+bTi1FGrE+pbS1Fa64UzGoRzGnEcU4WC63UqspUxzKRLBt1FELYUasc7TCJdWvPpgC9JolMDdjoSFj/3cLgpejPohI+C/DEm+epE4RA5XJKaBFVhsDphzpatoQGt2r6+hvmNL72Da4lTxlQKcXcLDbJW417XFlTZMXEnuOZi95B5HDyO7Wu9AoNzhw8zEDmeLDBA5KW2lheeZRLTwscOxlD/ohwI2nsMt1puxvGh+SvN3O9453DeTc8mIo+7wxbS7LGPndbmxufQubgrvjizVn0+LKdBLoNXQK2eaYfoZY+MuyWt6fbNttlpNs0KtyLxTGZOXUJMcQytuMpzW3W+i3o1EDwOpLE/yd3cE7hFcefT7ARG7Td4tFf7VMKQ6qr1YSnkwSxdfY4GpK8IUcbmt15U/+tZVWpTuMNxpYifld2GfKOyZfCO2dhs0nQYvYEtK0MvCq3n9aAHwh958TGPcdoQQcW+fip8TLMsPrJYqsidytUhRQYU7wnauuh1pxeqakPXWOt9eRj4S5L6B4GxYW3L/7JQ0/cLELGk+10RSIShSbNIJfZ8goSOr5mJoqNUKzobVCl2hpOkXdFYpCUlGhtQJOgT0P9fSurURM4pVuefwkyGi/85hCZMQNCmKPKtQ2gvtIldbpM3lbSUEX5bUJStKuVcrOBvWFnnGQtL0CxOzpHkJI6kQFM68+3NN3KlroVIJejGsqxzjeKvwsCOnWdLTJPm8X67urG2cx0cqW9OKx2lybg0zfpwqj4vTVVDSPW4d5xVtckpD/oUQbSUrpkJ4bqRn56q6x0Ob8yI2vb0l6bleCY2lHk08ZRcF8kKfceac513LUtuW4A7KyIBSxkMFGwJ9fn67N8ZFPBPk1YzxoL9fNtaFuRuGEvGwXpnhKX5bEyPoImXsBmvg+f/afSTz/e0vGk1VcmQTp6AogwZC2hUx9gkaz1MCwlVPnmCwTfdH29ji4PT3+P7/a2CQEF3vACcvZibyiMNzpPsnH+AKnIKMvLlgvW5vT5o/vPme0y0aetr5kSavic8jJrrEO/y+9mBYJRt4SF6loUGi7+sfEag8+hGKOMqHd3Iy0j1DAAWSGPsowvrmz4c6td3GkpBq/4pyMMIVA7ESdrEv6DgmEpVNgp/r2STmIcWerGH1IOqj7b3H8f+voQFbmGJBu4XfEuMcsXAG8znAFV7WTHRVhBcWTLTxOSEFGX4MX74BQjKpotB3R1Nl7NFj1IfbE9qOl3AeOkMZM5ablBCZKaztrzpabSoU5INcHz11ZklA2cSIfTqRBnZtbCTpWFPT8NB05etr1IlMwspEOkHyKc/0eAa2Q8ePkYHgQb+zZXNij+nAHN36UAEB0TQSKuh4GOzGa1ivb41iSq+72ttCbF54Un6UDoeT7goBCwEcVJu9wpE72/hKChH+zldgS6a0YBCeYrDT5uYjYx1uFwdyYX+YL4I4Pp3eCcMlfOxgfgPp/uaMOfamlSrjQ3qvxisSLg49JIWUqx5yKnnopJoNqk74Geeeuy0i+IwoqhaYN2KUjmSX/Wyta1UlyzxLhYzMSbNf0DbyTgimQM1T2nC2nmV2ZEFEJumineLRf/HIu+XcJNyJT4tj9GRis1EoY1VR6nx7ibDVuWQyauEZGasi2cSClweougc6/qmFY5OWvH0YWK1K5pomfRdtfNdTk3Skh5+QToagT89Ds7XiWd3m0cHDzGGiZkZu9RzfqfMQhdhcpvVxxPVM2+e89JMZO2mvMCPdlDMe08WEjxWUgVO+7fZlJA/6tAoiFHUtZzV1rNNcW8JFz3GZHcXUYz2rPgjN7ZDPVyVIFgrdrIM70/iMrhVxkTlFCCIShmPXJYyvyaPMF1j8kF3nelqrs5F0lmXBQqYRXAvsTrfHeKjHveoJJCJ5DLxKdULP5jYwKUM/emGHUjB31UmP7q2M1Zg/Wa7E9Os60Q4DRSOO+LAVy3R5RV98b+6Rszt0O4R/1wRIMMiJKQeNNRqOdku8a5toalCj/vBFr4/LOpCBMqfBWZCFhjwVnf4vJg4HwQYNp1Lr9+YzrzLm58Zm3d5gfnc9Mb+HwvRP6mcLC7dFGkF3dHTCBQ3M8HIM71bRXVgIZ4zPiQhQpT8pljOEdp7ErA97lCJdUWZ9vI01cq93k8U9LAVQZ0V97h+NEMt/4rcmNWdVvrkukcaeC04bwgEu2BHULRHDQThidhpGKLP8XDzuElKI2enUk2kqLBvaX++v6M/giP2NK0MlbjH2CYAeU60+OMbHCpPbgxlmbbe7CZS5qJodMAD1Xe9O7Sw8g3RsuMX1lQKwgjclIEc5zIiY3P4K19eaKgXu0dnTAo26y1bY/KcFWCriYdVomaTSCzFtYlqdMm/TSFvneem7mY2RTaU2+QWOekY6EfZvrvH1gwuDL4PsTAXWy9kTaKIN2Shb6/y23uq9Z7ofD2Ft9yLLejuMzCSdmP4LWxQfjIe8Tq7QMYext2Z5HxBjGXIOylPflVU+k81LQN8HIgE57rzBFGDlF5E9b2u+E9VLgyXb1Y64IPiCmFvLqi9eVLqkJNj3eyQXN2LW/9Y8pdcCouc5G0gi6ZfZKuIXXWZh0VqlcpnFx8Mi3PiYMbbg1KXMoBFM01SJb/J9n2MQNcd6vhtZZphLFzB0gVYKZAd6NhrPJiKi7+Gy7nPmuHxX0USR+BE6+8tqtNxKe8fNaiVizg5tBU/ouQAoj+r7CDj1imX+ipQ/f59kt+nv8RgxLcvuyz40avGMTcOpKr3axMGSW4oO9GyIV1FV0Y/2CxTHp5r8eH12f3y43fStLLI0CgmeN3xJfyzIYP3Q50FFZq6Un9hbz3cDU+xGqgojqCMRfDr3yNcROnjNpOS6OyXJaT5vOYVji9anM4HL34blPCdDi2S77EOYV7QmdBeyfJannRdEsDUiX/6KMRCJjw9w3guAdXwjvwSby994GDl9ljwkwez4ddc8vbC5ynymycdLxbJcfiVHfRouMu3r4VJBU1dYCWqk1Na2EGhrwsFHdMVqz3gc/aG3w86Sgk9ZPPiQ1X9uXyJ2QMJTyu5TBrKkgUJ4vGEz9+vsB/2wv9u2dZlL8OW/oj8rU0Kv2h0MD3le9NGb9jntiQRixSAuZuRsuUbSsTzeDVI68iAejnR8QfhxEySGSIXxEfubrilbXLH/muI6RRKMyUY2+/wCmTyvWELKC+OjtyXWtNMdx3uO7kSnGQbSd8SFEN6822GPHcKILiMSzrypJDdjSrVr2Dd407Bksb3umOifZsVcUh4WBcZiI99GgOH+cs8LcZ4gb3eiMx5OclW8IpSa2+5gQC2py3y9tRz6Vh3XxxNkQDjY0xnmnOvM44gC/cjYLC3toqHCvR1sOSxG3BKlR0InxofFLyfZCP1W9HVI0Yokmp8ocZMcBPBQGwCCeSfVOnoBNoxe6KKKT2xnVe4zb070vhT+KZB66p2jpD4wsV5Ws3b9SetH7OvIvIX7oeZ9dUbrnWaEwc48LAQMBFOuJp9v4gWQToZm+HeABRYdqUitsFXba0hFkp5OqaO/foHG3bp+iz3fgu0rKYJ0bgp/eQrpDHQqw1uYYLrcUB5BEx08rHNCY/3wDZpl2aqTYJlTVSnEcnfRcIX9osirKnLO1BSDLvLE8UGegUT7fEAfRTYGQnUEnaCyopwj/6A/CDw2UNcUcBLBDc8xQj0OJJHIwKxUt6v3p5pLmqIugyxBMNBF/GG6hLB7oshg85l4fFcgXcU3mvAkUxeqspCw1cN9Tups3X/weiZw6fRIPxfydtZek8Qh5Tu3fkY/8QY95m6Iu0qY3Mb0fJPFORcXRsun6Es6UEpHAsoR4z+FZCDfFlY5syS9ZY2EsmvJlglg7O0TOT4wCTNLEMQkoVAg7Jit0WI0dVW0tMF7dMYd2dTkJ3nuoEAEr4NDOjhUzLxvqocc7+iKZsMiTk6HYq2eqmQswmAiT3/aH+UrcUr7veOCUjBIIae568TL2oo1+gOwZyRX3QexeifgXAOT6GhOAabUI4YxRuo/1fqR+63r4wxTjNhvVQ/zBTKUqI1eqVfMAvly2v1ZYkU1aITuGkMCEkQsiMFHFKZ3HiHaWoiM5a7YquOtPo7plngYWA+Xi3Bng0wEwS0Y5B+eiykJ9X1N11XYfU8nzPIrVLEm212iGLXyXsdjujY+ZMwVicY2PD6lx5/y4691tyIVrRZuGm8ZdZtAQPCP9VpnqWv/5mdVU0ynfJHv8siC4w1EmxO7kOPdafLBVr3ORBTCca+pNLRM7TXoVBQO8VDefY8u7FiDuGfmV9NVZDRsElHoIox+MVVR22Q2sY+RAiCBeC+CSMugxfMkxpuwguZgwUZsAyQRlwGbpIkWvWjgpEs7opcTebYmtGuJFQOg1MShvu2ADXq369YOC4sMZIR8jSASMeEid4wOMsEJe8oABeCLrUFSD7C6NlExhL7d2Fe0v8/OrqsAGW4pnxwl+pZltpc/qs7JYB4oRmr58hUY1dkja1jbXB6fYismjp4WOKeTgHpRspbPqDZ26tntBo/7RI91Qd2WgYkP5zViso2f8rO8BdHdkXxhKoDyIwQLmORVm/dNpNS8+zr0kYtIOcazxCNp2UyC1pOpSBjTGBgAfuUXtNW4dx8V+CVZQGPcQQOowb196MnkO/uyz5bAn8bOUG2m77nuaEkHgjLQxsJ8x9WzGgm8YEXh+uG9MxPxeC91N+P/6apn0s+93mbhogYmUxgWx2OxbcxFgOc5RYETrgTFAYcx0YUVNT3wdhICXAmWBxcvmaR8FpjQcEza0PauKiJVomg7qRmZSH9sUMtOJLCkDVE0JEIct9+3UsCKOTGPjeREJIz96U42EZNMmreEoatQvdG3FOdxfX5QqytlkYokRhmyHOMQOzHhSC0B2d2PkTADqL9LMcNsxF5mgS8Rl8Mm4QPWJGpgn2IPkBCL++YyIIUxHVEvKu5U7x/3JEgSxYGrlKESboEOUsYaYH7HtIjlsjZDfDnkG2cmMs8a592vF6YZk/bcL8g2sdzYOiG8db5d1wqHDkTcmp9Cos0WrEwmwn2yV87c3yKWaBnP6Hwy5UuIj/Cx+A7ENKN1ezHiEYGIxxZe6Mvh9/r6WksfqXIHYUoEksTuMdFnlSVHS3DFBCVajPRYA0DMW9YNjlRSCTpBxJjrYcmtrOfhRVSgHJmpJZF2JXzMGqJmDsuHC1EYQw0ffsVn3cVIS6/C+LIndraUpGWA43oIRUYEFShGbGq5bFJIHljsRJx420aKnDj29sg+fVIgfAE0KTw0OkbFWStMWpfbJphkNHAB15/Q8+qFoS4g4TrBHpSBFSYt5OA17GDYQ1JoUxRT3HcrQCPnKx4YdUAEAYZxajWjav9aCxQdUa8xgOCJtTdt1ry+v5u9ema3SAl82U/Y5zvvwMhUHuk91VPltPIpG5k6B+1oKlaG5W5v3FYYe8Y9l0cTFtt0lZq4sZk6OlCwdaq9Go1mIB65lyeXcOUH2ZqxvYF3g+aNpJQRZlOmvaEFMWssuEdPRxe2J6Ih2Gy1Curi3Tl8oDUx9FZhlmodzU4xRr8kDZSt6fh9VAI6EcSARslRBqwqbaZZB2BigQOooghaNVxCCtLCAgfos22MoBim80A9k92PUHcV/vwsGYNEN/jIFabZZkXoUt+ZAKGAZaDhBLfV2X5y8xmaYLLAilSBsqPdYP5wNTF9+z7x3DLbewchp9ZxZJDC0uiwkvvSMljVbsuLuo/heShR3d/fopXY1+TrraGTx9WxiEPql7h0XGWarA7SOCELV60UBXz2OfrFDi3Q6QtS46tCrB28vylwzhfgqSd/JSgWsxbJIqQJqaR6AMMtakPoLRPZoO5JDLAUpFT1ZYJfqKzSdLPlve6oVfsFic71JQui1kLm0y5EHJRapDyAZEw8umGGsgzDI/l8q8H9qs9to+XrKWNY/8KIWP1OYGYIbUs85rwTWUVUB2t2SKyJmsDcQjXHgEDDCswun/ftommpxL7UD2uFIDUQgBErwHdiQ2GD0LUQuBZHmI5cTcX1sSdtuK4ltFCRXxKK0hPWO38YzeQcUiFJ8C1/HN3MLeIipIHfd2hRbK/YHyePZ6ZUKwFDyjqjVWgznE5VtYVrZ4xLogjgeRhg0+x9fdhmfd5zNu/YpfvYJ/hPiZxGm8QNdFv0UebTJOIsFaqJ3tMop9F7MxolwucC9E9YIYVgUWz3CEKEL/Kd+THfc3aj14n2dq7hbYP9hR0/bBeEQOxA0rK6BHWnGO3h07+w/6TL3EsogS3PpLgys8TNXfUE9nWw1oPn613If69uYYlAV85BsXWew5Uem1cc6KCQoxY3pxt9Io66tYgE2sjzeK5AobbxSLuR2Oh99CJvvdEmyknXFpGImuWfbrRJlG/3FpEIs9NzG9Uneh++7DHQO9R1/KEt2UApAD0tzo2w+82unCe2ZK1hFPcs8jPRkmbdxIBykh8O6to8C1Mej/i+Z+5F2niXfxmBsM15K47h/1qewBIfcVfgEqORG7xPjuYk0Ex/Sa2a469fHB5A2hi2N6XZMaSZ37QkYYErQnIigqxt8S7SH1tiXOu8iE26qWZQNB7RP1CeIDGLjhrVwaLH45sRdqMDk++PKiGR5fksIjKxvToSn7EHJQnubP8HEKxzc79dYQsRVULRWtEzaT795oQUpBXWBBrkiB4RvGGL5xyQNtyyHtynJ4hjPnm7v138rU8rNcI1zqUQSwFHpUkKnZyy26BGy7pZwu3dnmbEA/o0Hl3UfmG2OU00Ickepolvqkrn0lL0raGZy8acjoPdpqom2ScJB9iUkIJmH7KqHuW2vNXV0WIZu1Td7xYn9lHQ5g1TmcQ4512qKZuMBvfRGzA2SwiumrZs0tLmWYsX+CKNW3G7HZi2ubtJadD9lWnSUjPlDKqPWmAVVCRwDN2JTznp9FfxDNzcA9Jyo/UKX250jdxVuzT5MyyPnl+gyETFJ5at6l+s+pbmNqEHQwHqxlRiaRdmlgMv5Jdm6OnjbhMLLycThK5jvr6hb8beFgX+XYS73Yhit3Uk9GaF2x0p0h+FUCzTdl3mEWWhvQILF+VfXBJpI9XWDCTaUBaRh/Y9PU4xPuheL88B/Zjb694DAFkx3DhFrSMCr7cBqxe2ClrT9ZfYIF6X8nmV9qt10OSIDsKHKFM45vzKnsWWnpJYEc7N3NwD0sazYYUFcsVcQXAKWH/BxM0vOJZQkE1SxmCZ/sSnu66kTU/SIF98fwEduqzBOGyxVdoNVoWmiorRZz/bkUFXx6PW9+8pSpSLRtZ62dnAnklskVFAr70p1zZeoMbpHYn6h/IL/S37y67iJpbYnSMOXoA6Y+xepsU1bBTY1SsVw8HIfJ+3r+YX6XhlxqQGkfJCsZbk16G0AjHhBDY0RZ1TNTL6XjBPqZuvFmoLIOVyqLzFObZSQXBhAySM+7iXRjvNksOnmI6rYGmZ3m8eV9a/btQPlVMygb82ilNyXPWEC1tYVWao/il9++cHe6Jo/bctVMh4kO/q29VLJPos6Viflb5FJAxHTOeNXK7LczaQRjNcS9kVFubZRiZJwcLKYt5IRwfVB9/miTw7eJCvhzujkWmLtH21s7DuQ4QUQa2JYibazeOGYMQOw7L+Ps5yTT7q8mWx5Mx3a0ZLD6UKp24Ci5jtD2zRUv8Wuluoe2Wfo9b+IlS+hevKFYsXOmJhtmQW834oSEMIYl/E4nz/xXqfpZp8s92fDCdKpl3WeRMmdFfNn7zRw01Unv3sHK00VxY9UX0CV8GIHYbVHNAs53vYB+iUT/jhcr09yM4pZWEeizwhC90imBczAV+/VK9vVrhcW2VUk0+2+02jREwLVjhVyzBXfTXcJHJjgvZAcIcrgjYJSEKo3BmN6UTl62g8PIXx03ZL5LYLlwU3HJG1Zvhstamr8uCUr+3rhCJximBBG2mkHGmkUBWvBhZFuYyzWJx0w/3b6PqLs6Pddt23tZIFvWW3yToj9XFJKXa322/ooU3BXVNkcfTtSjmlfcBspsn+gmfIM5HEUUbZTAqrRwyHJidHg4uX0l9vr5dtXYFrzChiesgO0bN9WXcT85YwXTs7XnJrJuU09kTZabd3dw6H/HS4vdpdbUQKcNaGbZy++7LUknUYvzVEp9OigXUFJhj515Rf4Ku2moQ3jKzXAsm4vCY1rdOTzfrwT/A3F+evXNw53lufbc5kQVdsVdCP/0VGlj98m6QbVFSixkFCtrSAIE78sAbUNbzDcUVOgdUhQ2bN91Zm+f1Lm0vPMfDrFUX1w38LnPxDduMNX2WpvIw85FRlO0OiyFpv3Xt1WEvx9/PFo1c/eO2Du4uLs8Nt/8pwp5jQjnXppvNssB4fSDDlfJBFeRHrszBDih1yIfIj9GGGyPeh3sdIwCDEvthuQM02hEZfEG8oWPdXidb4/GqNprvtSfLL/4WaP0PRt+X7L+1iOt83eDCaRVNLpmkBmR5o0TD8iBH7RidyeKXJwSxpRMMIvd+4TTed97EDcc4BxTcj9OlPZOT511J1NU+R30buunwKh4pm3kot339plnROB69US6BERh+vdi/nRdXStu94HLn2uOUxOy/6GXkDD+157lcswZ6x7MlQzt21M3IeOJK+Iqzm7DkX5DzIapPegPfULhGTnXPR9Y1qB+e/tOfsxPyWDtoZOVePcG//XfaShEntdnbryuPcGcmOqckBG3fp/iKvOE2mTbJRKGuae0HfRNYJ7X5lsZT5maN2Rs59yPLE2bTfpuHVQO/C2UXtQtyh1bVxNPO4YbVRmzyNZCwXHY/oKqMJWlDPa/0yEg1tFAa+mjlguns2YbgCELOEwS4cE3CwirVMGuzvn5H6z5p6IcJRlcDa6fBn2rn2TMgNSGXyZvpR1Sf5JowgMBbCJbiZ+438EE/lwLclf52za6to/AfuzI+2xTANQUsG8gy3SRapQbn68UlDfO5uM1291GXnSuap5L7Oqx4u/mJbb2GWmHWYY+9FJ3i0kiMBSxBKiNy1+poIBycjgw6mkwxhMudskaNmugsGM1X0NruGQMC2blOMFSjQPeV6WWtqmQPO3ZJfYx7i+vOA8JitRczyZn+SnzsDKVCH5T98aq536dP18oTwfuKSZBDstcoZ7JZuzNPjyMPxgiFAV9qslxOAODc5DqYWNnYXt0lcrWjWs3kYA9/8SDJ7TgE1Tev33odVXKmFhhg07lPdK2o45pbgoce7H2jTHPVasNtzEPpmaHoXTxAmx5LdRlg/h4uIbajGImCc4C9162lrb98FYRmG/Ddb1KKrTX2er2Y0qY8r0uVVyBga5YX1Hfox4tspMDwc2ZjmD5JO9FgD9hvBd33jY5Zz87IYryJB2lgEiXNBz8Wb64F78WKkkUbEicSwyHb4fJf7SWrxCpZAyqs5kCmavUSg+1gEjWE0FNG0E6DIw6S/xG5quQPOLnddY15U/ucB3B/EyqfsPWUTJy8YLVBHxR/6Re+n/kEf0ACB9ovDKLwrTb5QIW/Vk7/2G0r8RC/GGtrB2NSC2RSDJo4EENewLLb1UJDReCXJMjLZw9rpV+aivq9lDbgutdiA96KCxEkoPJimWyRPZtIp6Pv7cEAv8Txz7RAeMSs33aEQ9AjQD13v3a2TmN7HD9RziyWLHHKSurpCDwTOjcE+9RhtZvJi7NP6xeeuoPY8G36/prIP0tiu865SXQIBIIjhcpnG1NV5Z4BwgSL6c1hp3qKRimvt3KNIokyvJNu0Z1vquJ0nT1IartZoPyk0m49YGbsgRxHlqAxBgTgncK+UoE9B4fwL4GTHoK1KP7EbT+wK1lJYJ2dnwjsKOgBCEAb0kRxa1lYFQYIsZzQfsR8HEZzp9QMBnARf15xMOhx5pPi5E1pGA31KyBnORS4CmBWAtcqQUs44pEwifeHzHL4BMxK4ScsVYF819vVQsA80Z2rW7YIdEVesQxNY/3PTK8cmJ800vi2JiW9lDSkLdAK/Ryiv731KJVqWIvvorRppaxp6mwqCyQ1vcBGc0JEzoCrO5gT3thxvfSZjWV7aQn1Z9DS3cxkG+LrKCGkVDvEabj1nK3Ur43RuAWuuj0KOjs8xip3JyqElChPIyoFzgMuB8/gw8dywSgJQat1L9nMWMpQXBilwhaMT8sCs1hKA3W+cFLNy/bpjsfmWZTOX/uzROU2EuCzOayHMboHuB+N3faVBIsf2TbupVSVPd0IZMrNsuD5hSBjnR3SeJQjcTYGpWeFCwst67b3JY6dfUPsErWV60ErlNHLveAbcQ9EvJBTmBUDvFn7zPa1q1ZUWIrmjK7Ge1szLk309tlmP61lbmr9zgLMjOVTp5AVf9b133nrz9Vdv+tOHswcJuCKNSi1P/zeHymuv6rukqqf62aCoLrueO9a0e6e/8Tp89MpH6J4h1pQlJqSSfb0g50dvjizHOtec7JfwnZqaf3o58frXFNk046iT1+OsSkaVpL/hABtAON+7wzg+V2+8dvf0/mmz1NCmaTs5Z9+eE+/tEh5SYhS3FnVRf0cqvdqOLCtmVYSVSqhHhaoXoqycM9trEIq2dU0q3KG5A17+mu0QMmhxf60XDjeiL+AJAlzPli0yhoecEf4FpDz9gI8gI4fnBZsip9tOYiTewjAg4M3o2/UNWLgczwW54O99YJ7l42UC5jggDo/burPjh5MHsMn+mGe/o38bZ3f+jn5Ek6ucqgWv5KrcCpnZjd7VkVuhq7hQle/3/O7Ow9VVd6HTo13/xvBgJ6cbVPzRTZ5nTV443UKRlEIEnl9l+DMbOaQoafCWljxjnDo9ro/4r8nhbrvpmkxQxZTXNnzhkCJx5Zgt2QuqMp2BtJHrHHx4dLSrt3XXsdoJQbkETVcSlxilcguF7uZ9iMDVV4nl4zUQ52sCgvsTSGxe0zXjOCt+51a0ChnQsiYj3rA4obAAOBuNx/k87hqQ5La1HLrQS1X6lhHnENB7Gj/epbfR56PhCPOT4VU0qCvlgizxVcE3pq4cFUyGQToD3MAZVf6L7dCKY+zCgLEMEnS70eCTGnpJPgoAXDszF2OJXEj9qrU5mE6x69ZhkcJxkxMh2M7F6rbiodOAdpmfpVaZCCWX2GsP+oXmtu2yeQ93nteJYp+Mxtm9JgoBjKoNuPVkkpy/oXq7gO6dd+Ei0u0n4ugIKunphw3e48IJ1y+TSOcuVj5ujToOKMX85wFK46hhJzXVZR88TJBNz7FdHadNrRlf5KBJJPJwtvyZAbgRVBJ2NdhYIWxeJ+R4E+Klurz78b5Z1SfNiSw2sy77W/AeocwdLL79FlaCffdq4g6fYmpJAmFYgAz4bcH9f6GKny8fsLGOOnQpTqjhlPvf0WvIULgWfKu6aupFGmUS4tDA2qqqBtWwlvzQT70y57fymxF0vYydH2ijr6LEXYho5MSPbyrtygc42N0sh65RFcVAXfUae53/4U6vBX5JHVHuMAhQ87ngA1uYqpwGRIHAZV4V80nESe7OuIBbaiRXiPYFiJKzbVxR+p75NtqiHHnW1HjO+M4+9rJsNclxBoZdZDYKXb8q/qjq9Wo40VhZev3lu2Nq9VE7PALpjgqopznCLmWe2zYqr3Jp9zfdJLhWHRl2O7Ge9I2vZ0HIGgxUSR7FI8dHahcNakkIkL4RUh0X+sYWtgbQ2v6mRuHPTAJH2ftBVao7j1qgYZ8R7IIrALvnUM4frHfXYoKxxLJyPKvtPaAjQVr4AKbgLZOGQedQ03yyRwEYS46HMtyBKJxL4YTBkKUde7KKlXtpr21vox7PpD3PIpxuXCRhIrIsE9tN2+bSdwZsIePLk+Y3UQXiqITJsUgHUEQc2uliCWYVaTG36x6Qts5mpEKpOm/4roKmVqlQhoRZy36rjurh4aRrBlCDOL8I2XhoAMZ8dtS6xjCuPQ31WMf5OMSWHRGfea7D7+E9pzMtpAgThT7vf1MAdgBwNjYfBy5c54IvWs3vmE2dXNoz/Jf4Pw0qwLnJWKJoelchQFcVEr0NiPN66CHNl0qF6g4vatQl7j8niY5mfqPNct40Mk4r5M41cp3rx4ZkXUEYxs9nTTFx3EKoGIbPLoykGAD53c49xw7F945wzUI0GbVBBFH1JuwPfQATxqF0byAUBrpxpACx/LF4yS44/tyN181Ge5gdLizAXCdPEzAwd7AmsF1AEycBJiHjVpUCBF8tuCL74vPCYmoYupGwdP9tj5eJY97dTSM7ecgq/EzTlOnhlWUbvjEnTKTYrnOUScWzfb3VHfVHVSnatA2p+5kFme78M6QIFcGgLi+32tTFhU1aMp6/tWHB2MR93p+BsRRS6cbFXt5WanDSvZEMluNJqTqI/kR9/6mtkmjlyZHSz2oihPrKLnTmTdgJVdwNYRNsEcfsf5F0o7nqMXX+VtgkRpy5cgmf7G4ST2fgmbJ4tv0JV5EyHQ/p0v2hfPDKax+viewYsXzS6N84wGoc7q7I4+zlDVTkEqfkqrNdYys7SFlMkvaQ0kkx8xFleAdDqL3SpuP0RdGoi6A1ZB0LlDkepde+K4e8yqbOzeEg6p9Zq+0FTvbiJ3FY6jpW6Jvm8fip5Frh5iXiCB0WUd7INUQxjXEXvPfKe178IrsPVhhSdwr9u4cDUyqQU+FyOnaFYFDlsMRrJbKGtVrGKVTwta3Z6itean+8Ml5Qu5SpwmZdnVuhYx9RsbDdpheZ3WRxUFmbwL+NrlUJ7HTsyHgB443o8ZP136uDp8pA9cowYcWXkqV67Zz6083sSETwRQb6j3Fj7agZQB4MyEMk1B9BYqAVdnxo1313ex6HMeQH9EZcTpS7JE0Qt+mL7BRsjVFaTTr65sq/JAf7070uCT465WwhfixNTppN6RP86M6ioDQdxlA75z6zc34irClzQjZFxiUw7ohkV5bMninbrBSqo24Gp/Z5GpBJfA8qcGMrJvKcmnkXToLaJFAmsbw9AdbnC/PKuWe8Qewe/1RbSJn5+0IA6gZBvkqTmpkjw5LSsCwEbNUdX7a3KlTmZowK/+gGQgBRmio4hcQ7YOEKoPgUew058G0ZUZuYiIEEB2CEDb3Ni/ERhcY3qeCFaBHiiWuePxOAuJtYbAKYKKDc4Tp3AAuFwYoIIrKn4fsdeSY/zXTnwhxDU3qFXR5+jINYZgzf/2zBqZFDfQG7jzCg7nB+7/Zv0Jf+szN9s5SAYLWdRtJDtl9GEzLr2SDPPLgwQcXVecg9WHHgTAe8/s21P6WHtoT+YyIzWbXVSpCnosKpJTpplzYoNTzNkMfcuy+eEHDKcYbVjwqJVIxafHFWJksVMVrK/3+A/4oUe52JODw+Otyuh76SRZYwV1kW2nx2q9mI6rSgGlBKxAI+LWCm9o9/P/80ze7TDZxqRKNsQZzmtwASOFIRfk15zCvhcfn/x8nhH//54z9//Xl7cXJ5comJ6Y83yJ2SnUHRqa8KCFp+M0P+M/PdVXPl4GpkNAWOQ53XesyuBaRFpTYx5rFUq0uplS/mync2s7DYMNpuTiPOmFY9cR3JwEAcHJeIR4dciyo2sQkaC9TsKleDs5PzYOyBau0kyu81RBBfqpl8Nox3gPhoGTcoLKf+7Rj70LF9cTltialHRUgduzOHu+4UkQQ/YUHk+zVXQQFeeg7qN7oMFVAWQLIkQWVQobBoiPLYgqN6+WXXR/CGHPPaQNewO6maoCz9ZBjFv4G0bpQAzIJxYFY/euMY94/Stse9y4Q03vFPI0N5ZlDSBaXC7suzYQOeSGOHHOiL1y7mm9Cfw1HIB8/zkmtM4+eLA7jSo4JvZmEmxli6BdDw5V5nUL5hhbZOafDf8f4TTsVSS1Pb60FaBcQKF86aP05T58B9Ohc39Ps4H0/paIfx1FTM2wjxNVtDvZdTQCCLXIlAjMazx6dy4frQpIEDlSnXmyyXsQwstdmk5R2LcKEnp831y/cQra3UJftmXv5by0nnH44eJ/n3TQbxHgZdHOlMC3uju8asAenTLgjqjkDRL+Vh2CyWB7DgDYi4JSqYltcSaYYPj/kzBhkt8jSJOJVMNo1vnEXbzmqYaarWkrH9GqaS3ghGvMNIDz2clqIkJaRPbSMU/iLGm6sJBacOF6Rm7okKcrmNU0jau4ZrZZHLlwH7iirWZOtQW5bGbdIOaHdZ9Kokp6MBhw7vfo2SZLQ7ULXIjFHYZHZ37XU50HBGYny4WSSDRroxMUZyBixNT5cEtxGsaHhMiEkPpJp2h97XLJXEgwQIYkTnk9mlkgkiX64QwBKCkIyJdRdImf2l5l8hZh+JhDTkQm5RTvmuoUlF0hF/g0mHXsNajZjLIhgbVg1F0sppcZLVMz7Dv+s9aBxrsj1j89YlqRvaE1AJTiFgthtuBdFhU4yQ15VA6u5EMSwPgEqpG+BG53UeysuJ2QMemcsTVHNPxRB0hIvkic4XDXUrKUIEJs47ES3MDBtX3AX6dfSABATkz1/fWHvfOAy5/9Ybkn7An31legD+4rb4mSwYmy3f5MAOAwT8HxeVzr0yc28y+RsqlJ//jzW/0GiKHiN4148zCqV5yJ9xL9D0VU4fUkejCb5s42j2vs2pkdDzsUD75T2ZzaO7JB40AwFlJp/0AqXHUQ71o4jIP9rkXQuFvmSMZmRJTTDJLOc2Puiuc/qR2YLu1FyatljfLHpSwRc9xsuqrR+9HBsfHJdE/JjaTTB0tcWf9cYzbNDqfwEZyWGqOTVsjF2O4Guc45w+G61RvAw+DfcYOT8VzuT/rReiF80fvdIr9KVYD217yDaNYIs7+6DEU77LU8zQfFEtigSd7xYFGvB+4Io/a8nj33mUdO3gVFGEdacVGCUyHcVSynEjQZHlXNFIBFl729AbJWLyEbKLFGW8g1BNDI3yY4M+ya2iCfpec6jMzdEjNiuTJor6vXqPMkF559mispZX3SMFgeOr3ymitkIcLXuCDCbjhj8nncmlIibD3Hwj45URY/ygIbIjGNmawW1hg4YKBmMhuLvRtVlK7mkyb8oos1UxH3qZtk+QIbO9p8xcmcUKQxlZst72VvDv4kF3PPgKr+ylyJld3ThAs1M7c+hCJu7DBsV6etisZNjlFLtm9o8Wt5uGGt8K3Uv0bSAI7tSernmCvS14l2eRYC1LHeYGzk2auVcDFjJju8akcd+ShG7QXqm1chqO3S71wGxH3mlI2FOzd4fAsV2z2eDevxi2tbSyjqpQSGZixKqU20v1wNZp4F7HnQm21DUq48rSMgJZSsH173j3/V20jKJLSWd5yERzKVUVwkywzt/fwr+NBARBrFCiELO03gJXxdLUBWD0TlVeh+bQ88RVngNYq6E4Rwlca5Ljm71TsYazc5XrcLYzaZu4tN0rZTKLluVt1GYViMqsCJzE1QVehn7QKrMmfEVc0atS0AY8NLubU30J/An5/NO8Wkyd7RT9gX+XrYquIO16zK1kg6Aaio5ifLn27yXgX2vZzcW+iwbCKrhBCUuonEXXNdi28SLJoTCCIBp6E753FlZisNYPS5nr8aQ0L5I7KD+FRFYeru2dR9EeUY5lDpXTBf/7+p5iTAja1icArO8L73DulQKPzMxWfat7lLfGnubjlEPpb+psXSixZHlDq+jaj9m7yGcUaZllP55O2Bp8hMKUOkWtKdbi/lvXkGbynKnInPLkiThlZu6O8DmNmmEyJ82Ea2ZZaWRTsp6VThI5+T24PZlizXai9R74NfbnjF1mU8KKrWgNYQBamcT8eh1VtufHkR+L8Ew2GnMGnbraWjCHbHiNv5P2PmjSabLNDvEnRSK4mQma9VVktpXsGltrT/du4tV/RA/vuUDa+8B67R1sw81rFVnOzwJT5ehmp+Q9KKMOwBKT1u/NKCnPjN9PMKmgH0XQSOwKSHqASTmgHDnltm/GdScl2PosJJMZWaYpLNVSWK66sc8kr9oTrBfkFjlHed9ICBLJwkq/hVDKTEg5x+gIf2dqtGmWEy8rCm8JcFe498a8g74vvUK/o5LvdpbKW6SRMnxnEp9Rvd5Yb9L0JLqGcul+upQGUH2yulf9u2vjZgKFq1xW2ncbAvML1uOKQ4M5WGwP4ONd2UBBwGXlQF/71pQVcf32LvSuP4F56qs2poRuWw/gmtgi0KYH4PNB3IywlGzGOC5sJlTqNlPE+jbTLApmM504izYzFbZ2s56EYjbrUzUhl73ZIPIWfhiH59R8JARw2fRvRsCaCYI3bBQlOodSupDSdPlmOgg25WYGmGxBlKkv2qwH3tvqHxkLnLfSLi8knPQUjskZjlpk20tVAHlQWpOjO6kfNZg6t44m8aMmZKeVP2uKlixXMJp1SrUfpGj48eL33ko9cBMqj3pRCkaVh1Cv3fPJqu/O65bWkhpjz76niPKMiIWMjAO15BsTeHa5P4LZkRy6oUrydosdVVnQQyODurNEk9wSQPaKLOag1H9Qa9BV80p9oKowYXnd0mZVBjryQdCwSHN614mORN6NdnaNUP4frmhKElU2uLvJUDtICCkDVTBPiUqWZjYMioYFyg0xwhDfSvLW8bXDfbB8Vyv56DbJm0jZNIAsvVvZLVtd8CIvWi1TYg1QmyAczEUJVW63b/fqAeNZh5xkqupidTW9i/ICvPEaRLUURmoNGpN8xo1UmXVDrocCtKy7FtF80p/Qsbjt5tD7YS3kw+X61mAVcjoZt9sctLfcudgcPS09uh5ljxwmMKQIbWEpMXBKwIGjRmS11c1KOk7MQJR1/5Jff+nYtHCXYuSDNVbrkgu6ukXzzSU7n0hkXro8Bk1B+CqjV/qywf6ce3VrPbWft/kFwG3dCyOCKERDdMRATGhJD7GQPmIjA0gsHn7h1v2+YokqhWzY+mqSKkvSCLsEGvOWwrLSaM1UoSLFmnE/ieZY/kHSWEQWy8jZczAmq1jHxnt2DY6xjwNlHHWGP18TUvotpzjHJSpOcY2ac9ziziUe8YyXF1RctXZXtDwcau0ZzUe56rQ/+nUJ+At9UlRcUlpWXlEZsDkn83wofkFFq6quQQ+64dF5uBajrj7SgOnTqKsaG11ram5pbVuPF//eu7qxsHt6+/pxcP200TnxrVmtBS96a6Z9x0763T/97j17h/btP3Dw0OEjR48Rx7uv6ehNN99y620qyhjKxzdBosn56AnEkY8lLVfR3L8T2rSai5TME2DEF79E/tRl7lHo+LIg+tHTlaczjkdso2wAZhnX4+bpih5Vl6H2D3TbbIt17yQ9gsUKTR6wCqg5rgNsLi2xpM956GyTxkssGTJmoDwB/3vRHwf85JL5hgCxsJ9NaSWoK7oJj5Ef/CxGlxei55GV3p+ufu6TCzHNHlqIe09grxwPzGLN7j8bzQdWGoMVz6LTSoN65cFt1tVcnsz8QMVJlSadpiaz/Wk/H3nyFShUpFiJUmXwylWoRFClGhEJMolkRnSpId0caGrb6whwapZUXU5BHTbbr6YBYs5VqFrNxExadWozdg5OMO7g/3t94P/a18t7f79GTZoFZiTbsOf1TkHBsNm+XiF9mEKhYXzXR41hOCEa/I9pVlRNN0zLdlxvs2JcE1I3TMvW9UWSGaOdfQ1eEKf9UZAVVdMN07Id1/ODMIqTNMuLsqqbtuuHcZoXpbQCHJx9cXVzx0oXXk4b51uGAyCl+677M7SO6xkUweJ4owBBMSEuEpumrZTMsySpAp/jH7beYGllbRMpwu2690A6cuzEqTPnLly6cu3GrTv3HoCiarpheulVfEcBgH/6X3klSihXnhMiOqjI096ULU6kyJLUcah/bmyt8KKXiNQXU2z2nPEJ2Dk4NXBx89AfpR/UyXmRM6fNO+6NrGOLFgOu1JH+W6mzYlGtNWm9qX3RBqv2pe4c3bHDG7trwgXLrYX06TdgsNVmxXffsF6BaYXyzdhmq6MaOkTYFnv2bbvsdNgOuBYRkfY7eNv3yUeffPbFV99898NPv/CBwJE7dGEJMFIzyRl/rsHszM8ADV/AEXy2WCKVyRVKFTey2DkomU5wZmfvYJgzMjLaJ5Ep/sjfP3QGk8XmcHn88n0ttKd8p9Nz3Z54rEuvZxsIRWKJVPaPwMUuYAP7NkHUKHoxkw2V10mdTrG7yNw6rcsCXdV5XdRlndxFL9z4ARkjiZ3ehKizw7H/yBrkHw2oPSPfTasK3JmoHb3AsQTmy9AFK9JCbB7505ve9La7seuwCiR3xWRS7od1p0OEOapI0z5T3MhJ45gjnv2mENdxhRUEsGfwVWJfOGmcPE8C8MqIKyeT4gI0mgZH9UCFIheOo6cLXIAgb35/VIaHe0jT2CqWKjgw3hByS03T3Okclssw8d5J54ku6rTO5vWnq4fr3ZmfFgkmLRdHAV1N6xOD3AmN+WqeVdRxZNVVfyZepbfkKHc5LZpWkJXGKwGrmBnbE+NqbYtP7q3zVBXxq0uCNlodbLKKv4a8rh9idZLpPO+uCs7WpzB0YXuk4VQXFqji92CrVHpbVnO2jx1uXQQffhDjIOsVVpOzx3obbNrv8Njlk4aYDmWdOjoY0AFZ8HroRvvFn/+1+SE/p29iqfeW+B/61dkolB+4Vhlwt6plsZfAf9tlA+hWyfE1f+xkbA8kYOH4AXDD0u7WZrEUJgjPROPlR2jBSAHa4sBL8X8N3cQdxQ6dR0diJ+7Wm9hRx8GlOAL9Khj2Vf4s37tMOw7vL2THod8Ixm7L1RMyui2GlSoGI8QhmhrJc1wcVbqYa/jM3XoRh28RdrJhZZJEw7en2++L0AlcjXDocrON2Tm5JfAi7jyxjyTDX2q6b+maL/gVra0O4McpPTRp/D5gIEDBwDHg0BCQUKBWmAUC5TjDQnp0vMBAgILZkVtTpBWlTzVN2gZKJFZmO9KakRflKs/ymyF39tf/37cAZUVacHjiL4AH9d+SjSCi5SOxbKlU5XJLtarX9JJCIcHAIaBtN7oCBQYNY5jaCYQopZYt6bJ+iiszcigDDdVk4bYL1xYJCgVt2JhaLDZZsdLm7Vgrbbkf4lKPsCyloTjQSm1MR9BS3iA77Ouhgtj67dd4SxUUBVd9+AD8dnwjQKeyHhcoTQlJudsjtXTgQXG6rw0D5v0VWB9wAK7XSPFGvK/9CqrkOeaoUKFChQqLqFChQoUFVJijQoUZ5riIqVyiTWmHw1mDUKOWuVlGVukfauFwgk1al81DeKL+fcCT4pmQS9N/H+jkK1KB3Saef4wfhId9ZaehpMS2lzzYHS2mWkbvOD2LNFAIM9AqTqhCO7AXrjD0Tt52eHboLXUKV2+6FIn6dSVlHIRdkKg6xX9m5h3XP6yBMauPgx70lTMkIZBBIWAmwEvBEJkBcA00DHiEhB4lpUWFwxEDMhtCIINu2aQzyAiKhZNbcm0a1S26xFPEW0gHAOActNxaTAiea5AyYyg8E2olShRqFQhEDdF4unsbSPjUmNQ/NQz5PaxWf4V51JCM0+Gt0/64jSCQQSFkJrKljRgiMwKugYYBj5DQo6S0qHA4YkBmYwhk0C2bdPfHgKBYeHBLrk2jukWXeIp4C+kIgpyLlluLCcdsXkIzWoOSEBAGDEdpZQZkyGiprU0zIyBC5iRBLx8JTkrGlSpL/lMaW7HtDmn/U4lU7uvvgb7TPGeyYqYYTlCoNHoayzzKjAIZhGAExTRbvrpFdsjwx1IkMJ7F6ffrY8/w3zJtagZ3oprt079BdSYbNbhbo4c34o7Yu2pHvGuUO+Uz7oeLhhx8D2YkNUPZUDJIVF4qHyGJeOxoyAFQkLQBgK2gAoEmcOo6WSi5+JWVOJR2+ZNGeljluPKCmZTb2CIHHBI4ZBCCERTDJSYN1kmoAVpVGIZhWFNSg2B9gSp68HTi+ef/mQ8TM8Kbusem9WWespdan0Op+xkAunMj81zn/vWxedhOVf4fZzEHW7R+NPv4fOgNNIzR8RE7GkUomx1NbOjjmm/Fh/Rh0k1bqvwtzub7dSeB63aTBThfxkO24DvUEwsORbb2GUNyuZu57R74DviGNUy/+V7NUnZhIxB70/RW8AkECwVIzbeFsNq6i7TYL14XZI9xT+emuMhYtK1ExPoujHDP8tNvFHXjcbofXZ0JMmY+rUHzeAf70BRYe3fuTxRY7i0KpR+izaeNVoqVvuOCcPP84KxqiL3tzpwt3UJAp3cf/RDi6dUNW+ZGXa2c6Fnv6egv5RYEnSTdAJDSHnDFxJ2LiiJt66zyRtg6zbSB7/2+AlvD13SAEhGkFW7SnzssrehSOj3ZMDgtG0qky4YKetZpBd5/o4KalgfvcCCWUbVtLWCTxg5ZZ6DjwL+C0Hx0L4nymg4hkwLSKqTjx0JEBtjbLmmz990UQVBvfcO0IeDp9VUNOeJcgLkEXEvcDvy8HovngL5497//v+uhb6sLYvWBCJLDy1r4RHilbhK32TMcXAz0pqtXVutkpeAs3uVpGt6a8SCkmjGcqVuSVndoMIBooh6A+LIFYa4Fad9AoqtuVd8wZLrOfMiF3NCpE2lzMRdT6G6bZr0YHg0zzbUZAfmzY93Jng16GOKMXVEAA11u5uODdsh6OOSSl38hV60tSUej+fbWFUrVhE5xV0ffr7+qSENoZJj9ndD6MF1CKP9Fz6M/buV13vESMB797QCPuIclDRzAszySrd4kG/VkexQeaazTK8BVlLs7HSwOT++b/ejvNwoaBYPg3Gt7EBp9IrwqBP3i4LrfBQGP/SZrlPMsU3XQ2ug0WZpSNOuZsGmDx77I7IW2Pegaczu0ScaWIJnw87sdxAYrK31XHMQHGsfhO7vJ1VP2fFMdtX8LbemOCXssAAA=) format('woff2');font-weight:400}@font-face{font-family:'Geist';src:url(data:font/woff2;base64,d09GMgABAAAAALVsABIAAAAB8qwAALUCAAHmZgAAAAAAAAAAAAAAAAAAAAAAAAAAGoJiG4GmGhypKgZgAJEACIEkCZwMEQgKhNtYhJwtATYCJAOePAuPIAAEID9tZXRhLwWMFgfIawyBVlsmypEEVeP27l9KkTB0kwHwcnP+v1oFP8Dc1Dbq3G2Dr7Mh9OMtJWw68OkC3QYQ2J/GNNqX/f////+/K5nEmF7yeMnnHxBQFauIdW3t1s2BJgjP9MhGZJRa28KAo2v7bURBPww5MI7TMBUvGbtA1J25sB0G7CkPzJkw+lE98jRTuqt7zgoLVZ4xUI5b7c1sUGjdbopAIMJDeGbOGC85GOjHOpZSMFV4wRUuiui0ikUMso6Swjdmxm1arxcE7mIqeF+Ft8IVllNBFtk8EFMttRTlYTDxi6JNGbuPPuRpc8fNDXk4o3WnLCdLI9FRyW5qR3XF55ejPL9T3zeMmj/wm3/E3DsoTVJSkuIGP7iem/n+lD/C+ttfccTy1J96TW/TrzhikXfJpI/00jV3UrchBjaz0725q/SMf9eMNa4Y9mrVR1ONqrPBqvYbd/nhJGfHDZTZtmaSz1W7WI413fWHmBa88F8ajArvNEqCJIVJo2LW0IQLXlUULJptDpPKkl3M0zkWmZNbqqR+Sz8/5i+5LstB6ddkpkeTJ5HTyFdq19hLQBy3XkCJaCkTy3bE9XyJIlxWkVWyNIt8gPY9MWMfkXPN7N4dcBxHyUGAIBJCCCBppJo3RcxrNDG2iPV9W39NaWqMtdevzc83e0u1ZID0LInRsYnIIC4REWPFitmwS2rssmOUIDR8OkPESgkNVXS8qqbDqBJrxWhqVXXlvW/R8WqsLqrLz9tZP8mhhCuhhettujtXty3E4CPz/nyEsxtpZ46orpNAT7bHzdttDosSlY0nGKmx/Bvg1+Yf4B2HRB0I0nHFRcS7qHfRjwuOA46DPlpqRsOMnIpO1CnO2sS/fSdubUznKlwYK7fWCf/f7we/tdc+976PSWQogWE6nqG5RtFMyyopUaIm7uCa7w/07JTeNBk3CexIA4DE/9UDgCvngHNAaUrXNqWjsgLX2kTOOIAq+gMqWNu+2KHaviKeSIkStURSJLYXCJn6TAH8B8Dm2L+09QEPQZh/acKyODCOWLFf7peb5K4EjjPvbX42ZVZlB6gqXGWnCsGIc/W68P/fYd6Z/mdrGQxpbIHeckonXqAI5MQacvPETYEBiPhqy+rLtDczq+qZbjg/aIDgWk98zjoZR+zEAlgZBORmhkbNlidlboJGZnC7ao97u+pyd0ST+27LJLUEsqiSwdyfExohFARFaBOuqdbMVZXKy6FyxDhkrEsfliCEhwOTzMtF2f2oTiWnAHycVWwHTx7hP3mNg9hkRxb4aU78l3AvVAhjmyLfCElO2H1nPutFgH3cepAV6LQ3cUbnduw8gyiMA8rwA90HWMPnF1jUwk6S6n1VFKtrzh515c88gb3LkoHkBfuYHHQ+cKi8/hd1miJgsOsgxZjLwlDikgf9YOthE/IhBkgQ0eAct3afbQB/y5vzvy0/FepELK4t7V2oU4u71kQEOTPsxME/MPE/benaSYoKSIGn/PDObYAMqD0wgn5Q8q2vqK+o1VVPa/Z7S9UZYNdlPmDZ/Z5cc8q7+3BJaQBmuZBEUUtyZTO9cF9uy6trapNTelcxy6aSiSoHWAadQdt0O1+F6c6Jp0+iuFaO4xjCbPK+VrYkCwMJvFIKSX653GFyb9M3xP8uFQ0SpQohUZpxTamTZPeU023vNz8vdg8ACAQctm3cLesYjY1EmlkAA0vmVOdskj/pQFxLPZ2Ad63Zk82rWTGprVGo0rssfoG0AuOXe1Nsn567UjqDbhT87Gqlu7PX5d/JpTfUC7JZJigBLBMchAJIOiEw/vdT3+g7PlH85TTd7xQJpSqlK5Wm8zBm+Tc/vzRJac9Oa06pHaAAVCqAvWxtbBeRhQsg31m0AJMFcP++VO1/ey8aEEFSekNaHg9kT9KLkj2/xvpxC1LSjF9Oq7f6YRe7z70Ht7tvNwg0AApBlCmAlJlsiyBli5Q8xu1uUCBIeSg6lOTxC1njlyh7fnCoVzJlybLkKPvFtPop7nJapbjOy0jvZjmzm936x8Xq7/YfUTldcYC25EqH/6+1TzvdJ/g6MC84PzEmXv7qWey7OL08IZRxwG5BmIBzQEJG2dy/zrL9s6MxLksHQEVvp9JdpZfrGuvrT/7K0iwc+4A4qVZ24K834Ow1DmCXVClKfj1e6cpSyYQYJIhZ2Ks9GOlozGMeE0tGrQEpcuVMs2cas9a4dyatATACjgAwxiBI6f/Dz/KPw4cNOOWJZLRxHDAc/v+dKm0q3WOeCUhLuN4XKovDoMZR9wSkBNVBcdGCfzX/25xrxuFXMVGorEcwwURRF2v8Nuxzn9LYK/DtEiRNbQhBrMhgbRjElfQK9jp8Nyz61e51dK8/LGXwi4iIBAkhhEcIQ1E2hta2YDr6zqrPeVKWbdZP44MjOkYoHiEcYxxRmEofbtn29zO8QALuylHXKTKDHev998df0z0OXVXa7qSrogQSAkIuSAjh0O7jb9U5yFzVBVGnud593S4lAVRaSSeBUHIVdUOG0Fx29GCY/m8ShAh8EOQbRBNgCcCSPAR2yBx0y23EnaQRNsuFgaO5D3veEtLbVmHv+wQT9g05IJ6IgDSQIQvlUCiTUDLnqB111AUY9WCJPuONhmuNxhqKKrHTUbEzagN2q9qB3aZOYGfXFeyZ5YK9uJ1QGhwblxjJMmRBnFtu52MWspglEAMrwZhkm6FIReeS0T+CAjuB44AzIkgvaRnQz2olLMT15t6uoHd6tx0QbC/e+z5c76kQsY+3HUN3thMTBI7BS0Zv80b+aMh55wzBP7dr7v8w5GEu+kROHmTdpCx/JOTcIn/QCMi5bb/C0XCTaLqFEqVpLVdAH4ONVqzCaluBggBFoHIT+CowAXFX4CGe4uXLt1jUmfc2AEbQajkQ1/pkXkbjnmbl4Gj85iKe1YAAmxG0lbyQnAJPKQt/oWc/tXntIi3zhlxnuUzLns2Xa5nldsiRy+dkypU7tDdXdZKrds5uf2BqEaAODQJF0Mk/bpLj/+ol8BnlNXwfDPjDl7T3299GkPivs17e/8MBf/kQejW/xkBbv0yk/PkjZkyNd/4pD7j46bUrn7tL9IeXHCgZMQvp8ieoPf1UVJZ//jNJw7TL7tdBefuy/pw/wBYG2HLCQ/qKtla5atSodm3UgG7VZMFTfykMcIuT/7E6P6chLVaxYHL42RJ7Lqa42474temtcXoP3guLRsb5KgF2l9g5MOP/C8uDgOUVssG1DgTiQsE/M3pOKiujjRI4+pFx6l8IOdebwoBzfX1tuwSzADzcUk009s+Al13irDxsqJDfAe4owucmfTIWQOvbUXyfsBjSAnQwj7fxS9vb/rt6OLRjnIyypwUiNjjen3iRgBVIz8On9aC7DDZeN/wMOI9dzIQbEBvi07IQe82nByZWRpIqpBOkgrtjG75HrM55Epd4L03O+jFzNPk0w75weh4ik6liRfOah282QyGApKiILBLX4kkjEymC4cgDAfehnS85JTMHC3ss+WtpF1nGJ4lz5FmlZvfLsCva+gkpEp0LMMxydzFGEaw20d7/ZV08YAzggPYwXTP68jqr+jpir2aYRPqCzpAZyWBjCtcgyT1NKNL5e6l602D9tvNgXemyqYxe2Vok+0JoPjkEqktiruZLOIEoVVFMiV8Htv616fEsgEH8fLDcsK3kRPTpSzPKbe+nVqD8YrQz4nZ406Q1rnNNi82VMtuTo7l8wm1LdPgK2GhUadZOx2Wc1jDxMM2ohGtaoRFC2yhVToRD4ExUdWgUgD5kcFHidlXEJoDamFbHo17Gl+7xRwnWlPdYBEPbI3GjBFMqZqnFpR7JGcvqFdJvuEScQUmozpBCiiwkc20DfkZ989Hx7V+u/fvAu3JRVzkaQAhaglFnQxuNHnkStk8apiXtI3JOAwPo6w7yxDyjvmbxuuyGmf88L+2srmUEscxCZpRaFJbvTpB6h2+YWEJeiZpFemrqbTGgos1W14tc8ttslF4kOLuWXxbpgWqCf5HFG+QSIoUM4sRAN6xQr6kTRxc41iGgN+IRpH7bPgRTU3HXjBWWF9cvVC01M+1fYqGjIIuJLt0Ia0Wb9Q5y8aB+gXHI3Mv8YC+/vG/G0xCgVjKkL1zaNli+ZBLoN6bsIoj4wV6tYdYSo+2io0PfNcqG25s2AiuqFL46I917ANxC5u2AKCvWiIp+5hNFYBKqGmbP3ao8SF0bJjkS84p98cK+WvlSSu7z2Dc+FdBdGwwM3pviESaTkJNfNgVXVL4vKBDCza8LIfy65Za90+lMZVCZvRDeyoG1gASf8cjJov7XcX12xywOnJdHnM9GMUQZ6pq2rRF/zQopXvdRlHDAQq+N63oFEYZNXFzFXkWa5tXe0WwOmJfCsfv/NyFlgm8Cx/R2Yg5GIdcvdWwfdzlQsqushjCy6tctEXRX3fnGp7K6mT8azVW8bPEWhCRdmulNbpEL6eoCc6Nf94sasd5+DysYfnLEFNJ+V51qSgVCOTXxTgemZWC3+dxf7THtBPCKDdLLL82ICNdotR+EjYU9GfQk9482hoQL4s28MRw/N5GVNYtsJImei0kIIi/P+R9d+EvS4ss3zv2WOI+mMsxIB4l2FGAboekEwGFJKpCSg0RxsH7EA0dFGSOqYpkOK5GFjsUhzsqWbi+Ove+m5sSHlVHcKiCWwB52mxDHrTAZ9sL2zDTpcmQIDDdNm1QNujKwptOIwjwFoiuAfoi7iubuK5wgnIvUMUaF8uAdvALSAzSuBEd/8ReNvz8da0ZBwAk+c1jwuRvFVVdVYCsp76zAgowk8At9HXVifFxUhH6aPYOtvvGTyuIGmYRC2UFAy18TDs3gKt5nf33gpR98BHTBP1g3RoSG94MDXk/w69FmbJFEEmnhk8D8W//86mYkPII2bAoWJae6ck7YuDppIQ/U6MY9PyEX3siFgGN+EHe/22XyM8NMKe7UP17iPcWMzxvmk990fvXxFt4cSYyXXnwOeWWlJJ4iF8Aoudd8k2wfPBXTY2QZc7l5h4FFZrmfqD3amrnJSR6qXzebNxYONlZq/k7z80QTkODpre/XzU9Hs761zk8CEDNq2EjDcoNt+4lD54gNmo7T7bP/+4nbdwbfrFB9A6Xm7/o+T2yYEP5JgmNNxEqQF3/Rg0+mni9Homv9XQsJwt4OglQTRBhLJ089XX/V/NY6buuVveW+7iZpx49cmOVtYZFHR19bYP2Gwqw/74C8cK7TrNsGbCy93Gc2YjnGs2IrF8R09ciOjp/eHa153Le0BaajKKgDqEh6Q88BvT/TkWL9MZOyXWUGs7K4ggq/J7fNnvzCWP/mgt3/7MO6jGPoPKj38OF6aw+EsjgHISd1OdldG8nA+gnCKTg9zopz44L24kL2d0rZOqA7yaOtSvqQqtQo35CyZppvh30OuNb9VKS2YmqDGZz8bfBP/BA/x2/x507/TNaPCvxfT2AzduL0zlFz9+NyJ+DScyfxd0gEy9MduKEirNnWCnHIIVF+dUN0IMhAQkixJDn2CSQ1cWGTlyu5wsj0ZZBReZVp8gtCCJTWPqKEssKIobx01WVcuerK+PLRhwkVbTQVRZPGxEo1lco67WkmNbdcJiMsbMKAC2iJkac7GakRBdPMYkdE43cu77ppRm1PbzBRJZogfUgqJpLLLsjr/w89Cry0d8nKhz4Fzfic5tK+pUZGP7LsbwdUlDhQBlcKh3AYhve3QcH2JPGxxa89V+7+OeOdcFEbX/paJ9/6QZ6f/KK7P9zQy7/+18cdDfrZOIRribOVpi+/npmVN7oRV1uR8+q62mO/NdK4G030wj9NNe12s827l+Ku3mrP8u1qe+4RR3rFCNFrzWj1VgyTqqUh9z96Mvf/IrgPRk7XRZMygxdDHwnlDkQmmP29h7n/CgdKrzBKenNdh01364H38e4CEfgSYy6++TQe6whExHoacveLBHk73Ygu2Ydr2E2aMXEEidOqXXu0znFq9bx3x/MFauhPLCC5qM0t+ClxZ2KBocBYYCowJ4JatUkhB+k59uSUddajWg2iESc81l2SN98yqx7o7Dt86l2q94Jbecy6w/zKPkjbrdhSm+aSTeWhpDozrQhsP0glpFXg6UMQ/wrS2PhqJT2DY5wTd/bRu2/gBKCz4lQ4n6XA2cTFeJ75aFhQi03GNpUQQW4awXSgOwMz1SwXhxBlLe82PQYzMFPNcskCpdAtAAAAgB0icTMN7bd08l9y+MY9ub+79IH5fKP+i8GtIoev5C0Vqg8/cluCKNw271fdL03k3p9XYW4nVQQgMnTJFsJr7COpbKVxJJbFQOYwV4r42WKBXUqFRstE8CpHi9ZK0KLOqZehpeiCcdoQPFHZ3Vjwk5a05lGSd9gw5bhRzKrnM//Tpd84Vv9AD+pmWVMP4M+Zvt2XOkpubkPtOR7SifPSv9Bwt+wceitINI1k+nfMwEw1a5gYYA0RhspomJIFqVBA60irpBGhM21QTccMzMSs/usGaD02YCM2YTP+QpX6exiyjVehgNZ2xq7a+AAQEBAQEBAQ0MAiaQy73Qw3jMBINcpFpXAyeZwzZT/LlnuYvRCF9D86NAQcAo4aPHUEGjRp0aZDlx59BogMGTHhgumcLNly5OK6qNhlJa4oVWbMd773gxs78DRLAtU+XBvNup7evv6BoeGR0bHxCe8Zw7QqpNXu9sIoTvC2svW5U/l/kGhVNNRMcy201F0PPY03yWTPnERMQvueyW7rR9oytpMbw55w9z50d+s1phpadXzg2sVXLioe+4pdi8KvPC2GPhD7PhB3Y+2xumShluwXTOQrdoFnyubMIoRWIq95yHnhnuR7P7p8GD6msQEBg6hjBVAKEGFRIiqqZhqtzHV6g8lssdrsDmIV4hMQEhGTkJKRAygoqahpaOnoGYCMTMxs3CCNPLx85h1z3AkvOOmUBae96Iyzzjnvgpe87KJFl7zuDW96y9veccttH/jaN+7m2yJhYmHjklHQsHNwCujSn8gdomqIEo2xAigFiLAoERVVM41W5jq9wWS2WG12hwNd6OrpQwawoZGxiamZuYWllTVio/TuYwAAAAAAAACci4BbfiuvyLoAfBaWPyw0BLfCYb0ZzU9DEVZF6C+I62EopRzCxFRGk0ZS1EqEpWUe5iaELc5mmmUcOAaR5Ubb7xYWDxnROaN9rBxyDp+UEIHihnD/vA+DSWjtPTAQtR8XAu+O7PQ729vtAmeMO4XPSCOLvBv4GQ0iSqVIA6ZiVWSvOcz9fOmSSnko19OcxhUQIWbc6d7xnCm/TsSMY65ziA9GWGG2zlrKK6HsYqPBfgimLk+ga321t+iuMKl9BZsYMbZexK25kV9XmBXSnN1eOa2NiBR6RPvIg3WO67ngB6Aomv5VRKI4AiZ+K7BEzixwgzaS9864VRYkGrccn0lCWqPuetpDLAJCRus8XSCkgJCRkqwezfQjmzk9QumgCgYn5lDzB1uv01TPyTZHXpUWW26FFd01U9Az1QHlCBkescHW8roR+T0+h+zmdumpAxxrR8457IQv+apPc76qJu1HmUV+3ljfTTLMLe5Ns7ISdbEMtQhZv4fMUeRjGL+QY5xuUYx6yYCMlbiFqhIVjf7M3gpLjumou8VNvSVdk5VZcoX7Vx5qtMkkve5dC29WTLSnmKpqd+7Ylp2D0eNd8Y4sN1ZzoxUtMXrzCTbj5l2NuuMarnXldsszxkeQNykO0FlcumET0FNswi5F171s3DsQaCvyN13s3s2Nozd/Kzb5rMyojv9O6f0ZM17fhtkrdriqnDpdLIbNAu9BmCBufAmRE9kpNccI74NYsnXYzwexcZuldCNM3JhMETdMlhHHiPJG8LSRp4fY1N4yVG2Oo1h2Z4wuYKE7ZCDOmeF+tBQ/6lryZmu8MdUduzDOyuXOZQA5x3pVSvbQT0N+hXIEOfk0fF57vaikGiAF+9r96Cp3195fB1xn4EIJopl2P6ZSQcN75W20f/eG3vH6VsEgfLTaZDZ5NWwdQlLBya+BTEUzC5fcjj5uBn/tOSu8vVO5LSx0rXdtXxUREXj7ITxAeMhiNYSspXN06kgGXZxtfYNZxPxByjngVCnP1iSlxoII4yYIS4Rt387HmQ87u1GPiOe9PjTXB9JJOGeabZYZKgzEjJVnmiTtJHwsNr2YqGKK+81Pd+AZa3/mUoPn+jPkrHV30e/JGt5L9JBckfpQrNCjsuiSxVyTQEWHamrhrayNJFb3OqS9LnqkaPg4Wz+Dj0pUYx+Iums4AJJ0a5ymWu12oJ7+aRqxMYmyZMuRi+uiPPl4ClRZsGjJshUb3qhRq16D9wPalKfmoaY8lQHDDje1EWc818kHTDHlVFNPM+10088wcMaZZp5lkRS7rJ6ImpaIMz2RQW4iPW4itVmJRLMTBclPpMNLpDIvEbXZi9LyQpWJNN0SoZeJZN4kNCXKqkkg1VYCpuoTYDUkIPU+ATYkYGk2AZre64E2jQzYdCVQdNMEirYlYNvuwSY2jLx9JOA7IYHQ2QfhepxZTEv2hIcGmmliEHWkNFI7Y/rKM/kw9SJDlhblFClMR72gPuDDVGMGXIpcjSr1PqqE4IqFDD7Rpcq2ksGn6ygroSyCS7oSRgaXOhVUUcOQucKnNnHgm74pUnAgMjgkEByWy4nOlWyEn8/5mZX81jfbzA7hsdb9REUoUROTMsQizsPiJSSrpW57maFGAppA56iYM/BNB0p4rN+Ez66ZQKsQrbBuBr2GWYz23SONKxCVTxe9tiIpbwWFriLdcKwfmzdusMPIL5qyZAIDXDKppoSTjQfIHjA1OSMoxUu6oMBV2GyxwbUPf36sVIw4JibIrCnKxg6FEaUc4qEEoRJLU5KkSbr2D8/VkUknAYJuz4ig7g23Hj4n2lcxqkSplCmTchOkwhQ9FYMxZNTxcqjcOpupbNFn0dlqD9FeBwQ75DhsmT2VLrmO5oz1eTjfyNCisehHDI0ag8FkaNccKveXv6n8Yya4bqzSTYS6JZzbRp45hgmp/+tH710wSEuDkw8RANLK9IHbmBGFjDMFbkeWYFllR6aqzCDtzkKmPVmB25sNpH25yHQoH0iH8wNXXYvD0Ruxq+5Mt6fBzACNmwX25MsS8K5kGVilWU6mYHaTLpXzIJ3KFdj5HmO63BOkK72EXe0fpBtNk3W7NxTda4ax2d5hetw80vMWBbXUEk3LrQhttVVc7/oE+9QbQl96i+trtbAf1dG1XT1PP3oH+9tHOIiEULWGEAIUJQwglrBAcYQDNRmRg8UeogCKJzzo7CNKQCqiDQWRzwQKmkBPMcoIHjJBJAiBSs1CKWSFTq0plQQ2QDoYmCg7bCphVNPBUQs5qSdyIaSjSSvkpR0VRTcqjlEokUmMJKYRyaxipSEnLXHaYYubtCIsZBHXOUZayCZLcgCFXIqkA2UbPKirOtMkXWjb4UNX6EpfFgAWejAXerG0IZi1TghboQ9n0o+7MADUriiN0SCewlD+tsVpagdNIBmhuWqkYDsStUZfCFWN1d4OhnBZgc6oSFdSrLtQqreqTF+uXCQZbzCqMNSudMMlk2TEmSqrENmyi5cjp2S5ckvCxS3WRReLkSevEPnyS8TDK1qBguJUqSrEgsW0lixntmIlrVWrWa1bz+GLN3ltqsllS22RvqvLblt9Wj80ZPbL+7R++5DVTjuqD0gbQgmEtRSlYG9pykBYy1AWfL2PKiGhkUWhbaUq4WzlKhPR6KJxtkpViGigAE0bUwy2xhZL01atKrbGVY3wJpRAUBNLpFkb15iodq0rzZvSIPge1/O4EDegYBwjIxkTE5FZU1o2NlSoUKHs7KgwYUI5xJNpZCT4hh/RyqIKmdoi2u0pk609IhOKh3WhlqcrowB7RummOyNOEBTpYkSmZKVdqc8pJYrQ/dlFFBZbwWCltRRKqaYGppLE6PCexBHHSVYpTMlTSxn5PGn8SeEGFxu40kQBfEkQNtVjQ+QDCc2gybApsL8qTBwk0G8yg00K8dEWi1jCijUMVOLBQYkLDXPiLd7rBNFMpJx6yhmi2A6lQC2icqkfQZMMZBBiVdh8T2xdIuVThigsyadpFnxIHmWwXGnOR2xaR8xLMnRip9RRRjVFkP6/UafRITE+kGIysKOllropVUvVJeCDpQ74QErtAymNj1jauLJyQmdFLx9aho1oSxEwSWIpfGg1SbBQV0HUOy11HYeaLjWirmYOqUTaYsiW8JFVfAYBHGWruZYElZXBjerLTgewWkO/yQWsHG0jVBi0BEkuNuhHf/AJIfQJQnaYGtw7sIZUmJEe5468RqtCZErOssGpOpgqnB3wpNzPgV9Og5jEhpNPSCGeOJJJwocNG33UI5V3hWk58lkKJDUeqbwTLI9GKkoqze8/CxmjmqLqVeqQjJSMHgFDxrzTA7sLewqrL0KsNd66IQF9CeoCod54rYTvHvYPPUPWgt54vPeQFwzcOGAQsjp/Y8imuqmt3xiVXlN8OtV82FT7WsekVcZyCj3/DlRWW/iZ9h7P9ckamOPZJj1wClHeG1DAgLhnEl1829EadXYkdxJNdpfo1j3fJF8eSKSuz6F+zE56sJFzzOI7jlF28Uzty6Sz4BL9Wc7a8m1MjSW4PZQLnVXZO8kp4/yXAOPU8EcMvu1gzYeUdgxFTclWzdHl7Nvdlr/wYqEtT64PFVtryh9a1YrFNX8pUbDyP1BVcgH5qVRR8mO7GujyHaTrYEKGTnt0aQSwWmdttvKayzXzoGXs87LNS+lRjnQnx6JjSPfU1AQYlWcCymipME2aW2OfSZoDXnSclKV+j15RLrw/IAvL3Udz5dOFDkDvyr8UeffDkgEz92xKgi70Avonesld90IBjx4KavmvANGqfFJUjHxlT4AfBVp+rmTWfOgNeKOluutxi1VxQ22OU1n2qOZgaUF8b1IlSkdNrSvraNIqIFZp1RParUHMq6MBcGVAfiiKNBwsYAznyEdDC+7GtktV9QXoxG/kMphU+jCSQkpixoa5CzXQg+4oSCIWkzYF01e6ClUyuIKPmOjaNKe7IdWplUmNaLU4TWU1X6HgeJF6TdyQlFm42RYtyY/efWTGnoOthfBIXdI2C0alOvtGrvesdJ100mOapcDqUTX3KebWFJFKOiihRCWuOEhRIZFHf/WC3FCHJ40FvQgl3y31Hq1NrmICEk4x6rRb/qtQoi86a4JDpJ7yW1VpWj6tQ8KJqKzIjPig+ok9zknZCduinuwUBKOm3g+YkDLkaOHAgUNz/WRm7DTzvWSQKePckoJ6NsDCwyK9tJECPUpMvkncAo0AX88oiDHxPga8MLATpIkeuJFnWJvwqXInUB2xHC5G4sCSzf5YVMVJ8ldCMT6xgBy2oiGLy9SAiZUdEUwqYTWHZSOckgjNsqPVyCWVqmR3mrSXaMdlM8WmuOfGkpExKREX+onsLeEPTwh73RFgiV1UZ65OvTrUY77wVbYCAlMD5uhQFtTU1yYhBxgwwBT3j6ZL7rCCmtDZm7lshVVR5m8Am41nRNLGd8AckPBdL/8z1CY2oYlRZGHolodpVZhJS04KU5qK3E19WtMbccSZyHwkmcm8dVmzNZsJ1484IhIDNDxdJqw5UjCw82rV7W1p7sjJuhCWDPk7pv4DeO7JopQxv0LPAUdeJonAibcnN0b1x+sEvPixtxC8JHmFJd5+8cY3RTm48+ef7DLs/9/+Aj77qdgG3/yCSj0G65fkOL/heL/pDf6XEwLEiWG3k8JBJwdoSwnISSwmAJ9jg/NfdHWK4psxP9b+4KZoFCUqBOr1303T4MO2bM7gw1MyDI40eKHBfQxeaPBhgy1+BwSyqTdUrV9lwmxoHei3gOSCfaIqMNYx5/rCbXnfjdbAsepP/9FN6QjKpRxqR1nU2v8DRgpB8eJDenUHcpmN/DJOrsXA6z5Wco8bnV6O1sHRvB1dtl7LYxgXb/dYbsJ/SnMtT4HkHlRVWjyvWm3dqqOKg5EfnFOa9S2nZvc9u/5xpYD673bv9HXmlzQrLdIKX7zVvTY2YeEXZTGXYEn2fq71jtpZOwsQNiBCgTAAYQeCB0IFhACEEggNEHogrEAEzfqgsFkX5Ji1QeGzJsg5E0ARMx7kmnEg94wFeWYA1GxGg7xA6ICQgGgKFBCghGiy9gMiUjTQghmZgDUEgyWjAKORBeQ7w34xgYpITUNLJ4hEz+D5cLMQFk3g8hL2lpvIvCq0waonbSWPLjYXTyVnDxA/8TXfeXokx50Sg80+Z4bJa5pLDXrZj7W4lqIy5lQef7JsBhXqRmy7NkBW1huE76ouWH66JKix0688dn0K0SGGKx7r8ifflqw00D7S5rZAVkYYU8zKySRCVgaYT5mU7+OkpEVNnDxc6SLLN5fwen59+G18sA45nCsprQCyyoRzyWVXXHXNdRQuu4WAVOeVuxoz5UoNbqbTLwuz8sABD6nQALYTh4fVD4fNbxfmp9D87ChAVePUO2QZeIvSBZ0zASBvmx/cIkw1AK8pUGlikIUHsSuC2LbMojw9W/qzT1qugr0+OIoPjvKDw++97P/eOC9EmFO29bbdjttlu22v7bcDd+im7hjIvBSVE0465bQzzjrnvAsulr4GEiHzcNvr4c7JzcsvKCwqLikNlpVXVFZV14TG4oz3wMORaCyeSKbSmbr6hsam5pbWtgEmvfyOpWYfoJEZ5P8Ep3iAD0UrZOzbULsoAsVwh2FQfO2H9FRjnDOOw2uPYQYb3LmQPdZ1f7X+x6V4GdZQynan6XTtv/V1pbX+DheXw5mQkudYYtYOUhIvj6u/qcXByK5GIYOdK+xaBUolC33117noQ36pQhI8hri1LJRCZ+HqxzI8NaC4/ITc8LpdtiZibcfUg3V7NOUHDeLgkmUW7pKvnqmYfkJpfpKvjq34oEcgXmD1oBNdozNd6IpukpsP7c+cyKl5Okc04kWd8Xk+U4s2M/NhlmZjNhdjfi0IW744azcrstJCLmDhl/YiLtKyXp83iH3yqlg1q3UNrIk1veZX3rJfLstj+a1gyHyy64qycvJfc7A+i8MTiCTyJ+oNL2p0N7xksf1X2o1KpTPZXL4AaIbleEGUZEWFmv41CVe3HddDRVwqX3KXybSx56+YDIfOCvNn+1egv/3jDgUaSilDT7S9He3scEcgy14WZ5msqODu9ZLEYszpUOvdlSTqjzjqmONtI0RCaiJigE/1Gz41mNKsJARNp7mkTtOXqIK7S/5+rPehDTYqtMlmW2y1Lf0s+bD/TDU9UnzVG92YXiiraU0vuxnlNLNZzc6OI2h4mKVJhFUzkVeJZT3YFUcXf2dNJSRudm35eOPgJumZXc5/p1/RwnIxhLWzfACoS2s+wwUSx7Ye0uQLB4kjBpAYg5skye/6k/ZDTwJ3qfaqXjfwVb6Am+TG4I9vNBsucmAWXqa5YJcSzGK80Bfu0oQu/sv5coMulRfjooBo72h1a2CWmdeZi33FghiTzEx0EkAM1Ned2IOYqnOEZZcYE1cZ2oWfbAlibHnHyL7uEgn92bG6+SwWselt8PTxz1Sw9tsGCE6SZCk+0UIqXJj79txPPvilIyh0G+R3GnO70mVHCyQ0T5VUoCoqUjW1FdNXVIluDEk66ZdPxS/Tp1prI0tb2XK0L7gItSAQ1hRAIYfALhV+ajyCdcdD4Nde4LzylqBGPc2Vy0dJCOqcqYc9i7LYDcMuEv7fh4C45kfEaT8hzvgZcdYvxqxvZZhWRWh1lNbGaV2C1idpQ4o2pmlzHW2pp+1NtKOZdrbQrlba3UbuSF5coLesyyfWc0xZAZZQClbXBWxQF7FSl7D6LrOeZNdaa2I9tCnTS1sb+mhbYz9TB0W4pIKl2cKVBUe3TagKnmGHVBcC0y6lKUSWPRoqJLZ9RlvIHAfW4ELhOrSOtGiqDVQOthjQJqaQmQkskuXh/hvHe3fdc98DDz32xFPPPPfCK17zhrfUUEsd9c6RQRaDmP62A6+mjlEzEOpK5ky0X4XG16uJSD+SKLHoCl1S4pZ77nt47pl45IHn8X4fJC1gVKIaNTkSdHAhRCOa0Y1+DOIcSrzCSErOJDv54eVyrufWKajyMC2nm/otERpIvpoz3F3ouZu56prrblCEItm1pFVtbVe76aeEzrEJj9L0XlaQoZspS6JuF/kSij67KiNygnZsVyOuqIzF9h5H29UNQyF3/F0TlLsnUfWLsdTqkqaH2ALDvXeVUbm63cxd46mfrfOS3o0kclMjoZt1J1tr7tlxJKV9PlvvAV/Ng1SdAh3K0S+wR8kl53HQNAynlZaZdHI0GyW5bZebwg8XKOynK9SuWV1oTUwVzHR3KaviOVOWEhIwM6m72ZfkU2Mpo/Ps6u+lXMmupd7jvS7d2hp11516jr/Mt9vqDeiOPNHGaGDvTME6vSHdvWxo31HashJmunPZ9H/T0QEltMKgVjLP573dGl98DwfP/5rQDGfa1YlPTZDFvmwSldJNrVVYpTy5VbagL8vqy40z3oRaHoJxKtPEAFf/x8U8lrGJvYRG0BzrToerpf5VLfCOd73nfautsdY6H9huh5122W2PvfYpsp+f5c1CKrSozD+Sk41tXGmNb0ITS29Sk9nr3G5EnMVXLBmaTBe4hfC7PcWzlMiwPgw46OVtkGVtlA0V1te1dot1fJCrPwKUCcHz63bBOK0sHxuyWWjRWEySXVZ3Z/Cai5OA7b3y4GcFO+o+tFnauZqQZsk9mGbtuTpbdS3oaLxjWTU0YGsHdAiCBD2ciMAgM3hRJC40ud7MVKd8hQX1aAMAlzH3z/Xx5Si3iV+EjI758DnsD7r6lVvlwEW2/3ipZ/9rANMFI2sDngGovYoBx+GBAhrYi0IIsxr5b/OPKnHGiNZchb2Rj1ZMYx3nHE9aLqU4t9KQiSyK0tQTdtjtsG8qTQWqK6qqJZTU661ud0WDHNUxH7sJm8iJn7/m8pTN9bk9TdM2XSOap/PvvJ/FWb/96P2Mb7EibkPCACIUhlHMYB5r2EYIfXgGNahDI5rRgR4qUmk8o53b+Tdr2MgW/s8HSrAbewf2bh3QqOO6pPvqVE/lr+5Vjelbclvuyf35u/yjpZT7mRj9+/5+6w7daQSOEyPFRvsDi27MYhOXeCQ7eWUe5kk+CB9V7FRBdC7ia4yu7wZijgxuLMZ+qEMbxvCndK5N1dRP63TeDTs172Zh1gTxMVoJefRhCMBIcQ6rs3dihLD+J7Rw45jVbGATP0x9V7GxckbfnFtzdxblb4rNyy1+crl2XRXxEkf//8tLrZb/M9mTSxHTJ8/wa3S6hrMa1kOF8T8jkle3q/8i/3xpf8rh2wNL+aZdb/OLUc2m7/0MANyrIdWv15Hke5ZLPvfykfg4bCaE/YAo87kMgy0rWm4HID9/39cbHKps/adYQsP0y7/wDDafaX8EvQTZiktTJ9NKhXY76iRAn1LNale3JO6y7rPXvPalELOvjLQO3fdf81d2pnN914WudaOf+7V/BgQwKqYYBmCkxnAA0/Yp/v4ZGDGy5PTa0efVc+d3PK1gL6bT86fSRx/B3N0O9sJl1o9cLc5vtSu1xKrVYX/Jm1JcrAx56GalTqXe9ajXP5QagEzMbBwSJUnnl6uTPD301FeJMuUqTDPbOuttsdXePkhqe4j27G56jjveeR8IcmgMIpjgYhDjkGIV69gnKCEJDTVxoScjnOSGG3730xY9QLv7zrXa1KW2da1VjdpV4ywX6Ima9FHN6ue/TrdXTg39VLFTWSlGsYM+dgMdghdMw8CoiRjhIkRqe/b/Ny9MH8P101+Roe1GoYXmmGe+bUoTy1t3PVXvtToNGlGXXahANTYLPuohRAb9cYtDHHMilLonIKlJyqkwcjHByUdSg7pHr1aID6wBwbEBg8VHoZECe6TBFyhROUxcFHBmN6REieQgaRE0n0SZllElI1jP5nhortWhVM+pMnZheNTAOxLfKPyj8YsqILqgWELiCI4tLJ6UQIwMmJmdz4GVy4Wc0oNwGiyjQdgNxG2k3EbIabgbVbraBLzGuN5E5Y13rQqVTXW32e550CIPW6K+xRJSKa7YHk+kBTALxSuizIa42Khp8BWHgCM7zsmg7KMYICkmAtOEIC4qzlqANq+W9T4xUACHgCQPCnV/7j05UeOz79kgv3VU51JPH3hTFIQnyq8WsBWJzhGHKTbHlJkwRWLGijUbXLxbAZ+mNbR09N/RRLSsj4mThxcLmw+Vg/2M89feyqaRiICaUQG/Qk2KBBRrrl/R6hG6EkGlWpRpVa5NhZBK7aqEVetQq0udbvV6oPWmA6lRYXNy2JBMNiUbrTeCVFN6RuUF0UtqrwieY9zHeUjmEbnHWA9E5wixkSc+MFzZC57sh2Y5AN4cBHf2gfHtquVctbgA8SlFJhKdRExSJ5OJSiwxtaS0ktM5lR49jUsVKKrI5UpcqUxp5coaZ/K31uT5xjvSWEebaD6vZQqslCtPDibWf4VJf+2pZ93t27T5JPcRrbV/YLAjUF93tQmjvMb4jPMbNmiok5G8wU2+/bvQ20CJgdoLjOFKTlvg3F+lMAIW2LgPnnNHPp5SFl8+YiW374IfJTWao34mdRSWOHZOxKJ3R0INwh3fU2D9GvLuOu39L8+HI5avYYR054Xi8SYWvng1lBNjLeEBcUq6LYjiVHAdEmCYR0FJiDWASwHNmRrfL07WTIgw5HymWca1y4f1U1oejEFx1jPr2FDfjFup1djV43771CK07XJn4uRTDBpxbaKdODBbh+v+VNtcybMJtIYKavQI/NYiOmb+RA0a8PcNdfrVnqjE3rBHW3lLynXvty8smnS/z16/uVuY6XH1Z2r1qshwMDY8kZjQc5GRPSIivw/DCOlX/BBkBc8O0Tb6E1mQRTGoll2BpFPkkLjpiUtry7qmkZFNvX8er9fyKnf42shL7n2aqGSoMk/0NTCnOO2QAXog7bFZhjnueByeOcZYMtaWmzkpWVnrSGIiRxuHDODVMU2HX3Npcm9Is7aySCTzWv+ciDxqZqTTrg87Ju6pF7U6lvC9b2yjEmzG83XIgQ2WLZBtTPgXb8ycgJC4SNmMyJ+hyGjdlhsAo9NlDq+1vEwbY3nMCrnQ9V8IoW2M5FTPfbBaQwRVixyxghIREhum9uDcmfqCRtIeOK2hn7cfEUurSOVZp1v+cqSiWR48oAgMiAzcXO5sMRCqt+OtEasfLB2lIJO1iv9zDnbYRGsCygrXChu7XmxqBBL0Jm3qItvCwSRyPlzT8ir1hY4PzNTqm54kctk21g981r9dfUVpK2OPdEZ2/fr+U9bYVuvsqCJDuz40/TKPLI4ulJ8JcZdXG7o+itwVkPLBzrLLUN/L6SfOeXC9tlKT2jsmj4hh2W5MueKg0YUR8WmpMO131QwIki5J4tASqtvLayj+Atk78PQzhx6XyxgXMzLxKyBclfsT0Co6xUnnhLdUeE0sOe30+Ed59FI71JFBKzdiRAhiRkhiRShiR2jiRBjiRljiRTjiR3gSRBoHehDVr0ub1w+8oCLxaSl601pndOTRv+R+x1H0/2MWovjzHyKOkOXiCUARTZtIKGYSJmUyJmcKpmQqpst4jtQGwJy2kuH0wDKjlqus29PkaF+Za2aEjBmtuT7MccFjwQAdWZU4JYN6+FzbCE4m/Gs1L1uVsV2I43VmdKfnP6mAciqbJvJrM+A700NzFLBEVV+ZDDaCUVcE/RwAADIXZCrPVBPzY7IA5jBgvUic0np+bInq4dx6Uiu8DBk1So9eI5Oiv0alykRiKWOr6edgZiYi/IlxuEfPXPuixM69D3L6BgSdxpTV/mY4xTyX63lnLE/T1QyYSyvoZ5tHVVWGrJciLIPP3cnR+NafabsTmmUi3bHVOdlJRKSEuCj9oNuyr9rB0fEJ6Tw0QyNkGBttXLLRoB2cnC95KQqYhyXpxynTlhH7k1UOsYYHDQgccacmO0FLlBiP1hejTJ0aEHGLWtCJNtRj6pTeqcFCpMAkKMrcVLhjnyPKM/sAZ4QOTB/QjBOuZN271W1fYU6sEU82WHLpzKx1Z9HqsoW3YKChY0fZM31PH1+Y4nFnh9mNL7+p9i1iCAcUqNvLF/Q7Zk895rTKI1XLTN8TX3rP7Cx9ki408ff7FLiJs5mnk8PbSKEH5vUQ0wveNLKsOGKTMznQTdNJSi9GzjvON0SmlI+ikqmqh88iI5503gLr88fFwIBBHHBhZ8/JlLGmUrDKIjl3ADalQqzzjt4XrIQoiOCfXnC0Pu+1sG7zbiy+WO/JxbFLyEBcslyieTlvrVdy5VKg9wQV+qkvivKuQpv1hPGZdg2tFQC6uKJKBEzULgLVIkj0XoAuQY0ImJhdBGpFcLq9WAbIRYg6Gpi43QTqaUj86wAKDTQwCbsJNNLQjuujF4sk4JG0i0CzCJK8F6BL0iICJmUXgVYRlDVL9KJaAz5puwm001D2AEAHDUzGbgKdNLx7XizCsvXkksh+JTbRlUr2JnHmUdncgy7zyRGjdsZIrn2wqpDeUSv6RK3kC+yZfvCZfGMkvxjJfx/SIe2Z3kfT6EM0jT5G0+gTAnmOOfISc9YrdKTTt2g6fY+m049oOv1EIF8xR75jrvbjFbYvai97kEN9U4PQT58OKxrk1ZV/uGdL9FcU9+TdSP1voSZhCEcjBdBfAFieD9Q9geM/K3CG7wkcfVOB3ecVePCrl1kR6P85fuPX24qN5mTjpVEolOGwaiYu1OWBE23USujAgOGHYGdfNRgTMkPB64UXC3l8X04hzEnY8Cj6SlOoDa+EWgaBgTYkTvxRnPhjD58bmHhwkQ0h8cjEqJiuCu0oEB8aXGCFU9rcUj7CYelWjmAyGFlYDasmJaogKMPqQg3YaKhmGgSHQI3bii9K2ODiBHCieS+RuSCCeFMS5UrJEFvYdsCeyEMzWnEWvBKhuWVYR2wNxIB18Ka9ZEW2W3037SkJPWAWRhVbrVS9gRyesu8qnNOjbkBSFa6AQG+x6e+FQqHQZJ0TgUpy+/gjv1hNkUFNvDPKTPHDN4FWQhWzyWIJK+zc+edOjpVwDMpy3+kHpixrlk1G/Ikj5kMeyyCS7m4zyZIti3795Ct45tlVkSYzJf9PTXhYpMJAqth+jxBTQ03PLC4miSseueXrGntRvjPthTVt3ddW2+hGuIsyB9Ia288xWSVELWLB3oEzBL1P5i41iyEzIul0xXdyN4nH11Rcm8j6XZ8ui+jRd//iqfDNp7RVfaQYGtaoGVYTFbo2oSWyQ9y/pGKzUl5Hk+cXBRQA2QA2aQFWuABYm7YAdlpiPE/aHgJiSMKesgw7zT2UwJPqLhI9h1nxv54S7c91bHdTsvWJKjKBsuMeXzes4bUH6b9h2ksqM66qnyeBqFFgucgCHpkpBMck5VBgmYcqC9bw+vYQWK/KHsDMLUuigbGJGN2t0QWklUXHSiheuwWugqgiEzgaYN8dm2qqrpOWWnUc0YM6fxkpRgjunsoanncJpwd5rcgYlBu+xhArklzIqDFbIkf+h8niCjOpgBILA8C27SiDtTPDUh0qRWyalBj1ZjhrRRgZDuNh2MMg4BmpjEQBlIyGpAzyON6O0ldu3hXSSX9oUIWXdqhyRaaKWkizoxaEraYG3/DPMZKKyhtJ78Bm9HlhWiEqPLnK0aG2RiAszTXeohDrzGkXxXJGyaaUhZnn/motxhOpA9n+V3ZlWD5eLstqoa1T7aCc/qPL6SiMBcJ3hVETgvmgUZPdN6URfXoze1nb3+BA2NDofOklVxJjdaQbAuG0SlloXbSblxyfsz1zHdcXaaehWNbxbT/+TWZMz0hVijYU3Gc66rNoR9X0BQNNUjjb3GTIxmvkKSRAZKwgw1p0LAil8BKJDJgiG2XqWasS9DbwG57exLKsLiPXGGRUA6kr2PUrG3Dr2NPYU04MCoxbmtHIsgeuifqHBOp6NA+j0uP+uSjaxfNCnKYdBZs7CXTGq0kJ6kY7zebwAQ0YzLFIpYT/6aiSv76tXjntrMiJrL+TJXeg7QNv7uei9Ie4OP27pkBjCXrbBIR0mYoyqdw0op9YvqJC0qViBkJwxezwSW30N6M/hqqFw79nCAr8m+t4Gxoiq+7EGenXAgoZXxwW+/taz4+Wc53+Au6qGEzfJJ8yObqe/lq1wmBsGkh6sAXstmr0abGzcnyJRogF+mB6hy2yGxoPqpGEe3eqQoa8UsqdgMR2p1bYUwTO48omoR/vlBEGknK9hihhIOJteWrxfVqI02YpMqJ5GJCCmj/IKS+01btcl1DdGQUgWV/2XpCth6B7ED3a33VRyOlCFTUwlXtRV3pBga9EPWymuty3DrTeAZSdiNenNFswbv1SeQssWQzw6gu+SU0s4qXqWNYOL2DmWQIpg4/ZD5ZmSdmT4pkiLJOfEnuHALpd3qLVHi+Xf7MncAIkx6NCm2Ui80bSsYWIc/pTAjoGWi9Z9WqzKtWWAy3KT7pgNHYuJ6539lDYLzrvHswEkdanHxFKfJwOjAxyWa8jPdIlvNMZtRrHvVhnFYvHWINCLOuxyIzn9q9vbV+8LDtSX0r1VIHaKSZ2ApqYGrFj5r+DFDlrdAw1DySZ8xrnXGnPq+2QckNKFDM8lBAfSOxDWZkN+3ixxEmrkFKq5+AXRLl0VlwBWUdL4xuXBkesNmNIGadH04E1Y/tPenrUKt/CB8ZJw46BvH0tz9pZI5r7UFB6oyQMKkvOgeEYN+Sy4ZC7eKFO5D/FviBFPgp3CQ1O8tJsx1BnnQlHKWDecrc+6sGtW4Mj4pSccMrnt6S+jZNcnjYNxJGW8LKizngKdnvyR5njEtXYqcz1XoJ8IVaqDB78ttccaquaKmcxli+dT9iaIgkDz5Pf1wmJlyjovy/VYg+mJ3IoRqz0GZe21Tkmy7uZX6VzIdJ56HLd47OEz1QGthTLVNL6ces0VjLbA5XQOmaOdmwxbpKnojxJzazY8yzrjDJGdGM0tBjrWd6D15WWgAY4RtwViRp8mc8vUItAowtue1LU5/PIx3gsnSgE27ZeTtLE4DcQ46y0pJR9XGBBSziTJce8oaXGTK8Bx5hSdtOiqJmfn4NZtE0gg5VRyl+MsJjIWGWSy52UsBdcxgM197T9+FfCqQmWoVaFUJRO7HatzsfapuE9p4xgzgDDk1q5PQQ2lEkny68Y2CWQbew0r7oVBCNIyfLLeS+P2BmmZe1+8ix3yhGRqlTOYrtnnGIyX4gntC+lMKg/AOF45l0Rxj8PBUmhgKN0g1btM/rMVoD0pvIZdIcMjIFB37jVQXbYF7r1N6ZKGYAIi0QrY+YjpnqKs6AF01qAQLfr27IlXi/m8/Uk/PlEBZCLm2LS4WtVTHX60ZzOOhjIpsXc+zKc4XC5DY1vZeoO9QilKs1OFy6NsR+BENbYEmnaB51A+maWff7ctBztmdYJgqtMmOufwfEvkrX6lKL5Y6sr6kLlQPlKRdnc5vnBxfnEE5m+KzHuWC4a9FDtAMgOj3ovGRJYbISfhbEO8xa6mRvZmvz++/b8Bp06C0zdluMs6L1crxa/n2qFdondpMWOWwkdonVYGkF4b7Q9ubDJCLooNOiIxHYBYbn7l1mOuTW7wA/X1BSh00We7E179upseqVw4O9DtaI57NmHhYx6QujRZ7zv3jyQowDhM4eVOY1CmnNfz9LlM2uf60sVi9WzlwWZtK4nfLDm0W7FY05++/k4TmxjPyNNsxH5frRi9Fm1IWUG9+TvN1FS4qx0JFRio2RCmvTtsW/os4oYbrjO9yLeuiyf2bXlYdKziRvc3XgYohm6+zEWdoQtHmOXZwAm/QFfoYd0K/Nqg5KXwUjcnRjUq23nGb7ZMNdnvcjU7GrcCRoLhqmR4fAPBljohWwAux7WEuRk2WQv1d9AHZ0Y7mng0FZ/lh173zm/tj9bW3U37k8xtqvlk/2pROHqjfF3N3GDncz/buMMG9WoS/biMb2khoFrn5iz4tAXH1VgPaxgcvqo97W9l3HV5cC9ugx4g5SqqgsEPMq9liJHm7Roq67lFjjWSMZlTkOZLvt4aVVvs7CCIJHA2Ur5nWCEsClMC8P7JWyywVkyaFiN16cyo3zS8XYDgVTHMTruBGMncyLDgQRvuFd5iR2wtnjaQyCEgPPjschz05LTx7UfmmIylvYtegimt+eJKgwK+ow5KuwCg3FagYb2SoPLiXTyIwRTP7Xez7nTzhQC7Pi6wp+qJwXAnpwR8opR7Fj+X/u8rHB41yf0CaBKtuBulZZ5vfa1KhzTdVGvCUoYr05ZEcRmoJpDN0J3kLiolYOXig/h/pE8iNiz1rOYZrsRJSd/STxxgAdb+AkvhlI4ebUti9KKnI4oe/pROgR4q7utH36reWYPlTrz+sMl72lz4W8OVllcMe+WtoBrFsuySMKUoVMN5W1kqfKctCPA5rAMHhpAJSEO23JYrlSPiGxJj0F+p3wLm05l2u1VkzlRY/Z69oxSqTcEE+ONatNNsdAyVW/awjEsWnULuHyuPnDfWQkWLGFHRDFCQGApLeAeSL3L7hVdfdWgds//hz+UG0k/OyMHnXrVhEhayzdSocYXiwpATpDj/4KUV9y1Ea5wubXLkbDfiiOQCrtaZfwU2tZdvDIJ12AZdTcQ+QIL5L3jZ2XaYnyIdn7+Eg/RIebyrv6IPDghmEVvn/OQKbXSN2eKsmvyYY27k605XELA8VICDdar2k4nv1ChuYLrvr6FtgtSy9WZ4IcEuC47lfSFyFDHK2ccI7dmIf9EhZQEtWLwqz74ijq+jcTnYB7jyQz0/v4ep1y66PHNnOYFD1TLEnqmS3AKoQPUicOqk0xXTo1oEIrwXLjmuqfK1dMOLwJIDuv7iJBfK6tV2IuM56N4cYb1RD4BS83eod2Ihr1gLN6cYkxCOPwRQSUWUVcI+OK1lqe+jxEOkih6NNY+s8A0V3o2g8uOjnuxJ1uYyiqjiSWMYs1wxJzDcm7TO8U156M+bUIUYbu0J7oV7se6Wnl9DPX82v4hKDfqGyWl7k/SjMbNGS0m2TIcXi+CQhYPpdfG2E9zxCcnCfIqXGo/p3lHpM23c7UkhEFQl7kKcF5c08ScYfWDMt9Rvyrgs56tPoF0iwVYvDuRAHh6/AKwDFuDriWCI5n9pii+qWjSs5dgXIKe38nnZ92ZZxCDFvLKgn9Dt6oHyVlgzrG3sMDflZLwHRqPO/Dnke6NFjZUnlPBEnVUO1f0U965kkeio4mh14vx96hOfAm9AGqTTTeisthmp8Gy/Dvdy+dAhWdqWSa3RKJg/HKXp6aEo5C70kef3VDHnDEMa9JoSDg9hZbGWFNxheZYtptb40QrKswAKUVo+lXcrPOIvk41NDXSHw7Msb/JUPSpPJOurdf0rYJruQD24DrVcDP7anYB6pydZWaVcoYitrG/ndr8/ZiaTV9lC28pWyEG9scdZ15FOLxpsOi4355UIpGQ2RrjXoR4iBU64FfjTJEnZSX+XdHEnlwMnmKNwdCT3D8iXVwVxx8mMBa4Cjd3tnuGjbo3LGe+lywIeqv1rXUmvNUCktmTF2uV1rX6cszthBYKbZ2OTKjHTXuAl5jKT0ebqU5srNwMRUtzU57cFlytpo1jFnTRJTqgyTbRTcL0hjOjoQN5kiSLdOGmb71KOEVhT7vwNLdYTD5JLutysUZiegeKhek+8zy528RiXHdFjo2C9pEa0IafarbbpVHJ0ODjUP+FJSTEkJOSZcQ6iPUaA7s2huQsjPcJ1rE3MQfvdjr6yUk7EbMOixSgVjSKyW1qqjTOnmPObXSqEx00AdeBadZybONYHzCfXK5HYRKmPyAkILAEAqlB0K3/BOoffqvp1TpRn+BAyiEXq+lTLefbmexPTF87kKvHU2bzdNifWQ/4HINb2f1r5tlNPmLfWJGT4D+D6Hx53Zz3O/nEd4ByyNHj9ZHzuDN25e3aySgzs286frm0s9nf0JdqGXJxn9Xi+vr5QoXqjEFVR02YnYrlHcNDGwfvvKsp3eprKN3crHuliUFuD1u2a8Pe5AAFnqItOMlKMPi/OYxk4hDHQ86oxFiUFIYKOF+DXU6hk1JHMZHOjJO9pjqdCg0qLfKHfu6cXd2sZQRSXhxKLcPV9KtYhkHPZE9D2cwj3ZnYqw7XOWAupOXyZXRsIhZDW1Hy2BL5/iNiLyX0nhzj1E7a6ArZxojo7r17uYVc95pnxtC2H7AeL1FmpfJV2ihEm5Bl6Faqw1MUdWnpdkRorj/JD3FF9PxW8thGgYFJJ2etvDKzRKmvAXd293or98Rykv43HgQ50a1sciHqJ4yQpvi5PH6nr/znAewLsHzkcEO06uYFnyeWm/XJ/2Sclds/AIreLXoxR3ituOpNhS+69jp1aKinw3D5asnni1nnXSs/b7MDkKezAhW5kgnx3iM5SddlkecuJNnPBz2Yo7KPw35LTyszLI0MgeqOfLfOInKNunrPz24SAQSsb2bTsrM8KZHQIKXwzkJtyc5NRvWhjrBqbpPZPb5pPKMjBE8UWbRqjp3T0KfX26U6WCyDzZygDMHTe3esn0HCWhmWvjl8+vz80ZPnDg66e+8/xXqvs9dFvwtR3zOEG64HIo1IcAHPu3v0B7cY7Iy2WtCEmzQ1JLMSqs9GIFOt7L3tyILG7V1N0GaT+lD78ZgdCQFvUK3rau43LL0DRdxRhitrgGCyZ4NdNhdsBg5vdHrBXoawOZEfgseztSqd1CapjcgUtX12oZSqxdbr0y9ZygLSZaHne4RfPdpIW3Jgg1sy5/fLj2xyNw1sHEUFn7VySa3Rye2SGteEfptATALKwtuF54wJlzRlNdgIQ6gq0E6DrxjEQX0xJrhgI7GRcggfX0yeNq0quU0TmxqGSVvgMAVHQ2fy9Oq3g+Nq854mthJtWd7VmlXJhKINw/d4vo5vOD+rIs0QDanYydYbQoNKXLr7EqK3x0juaO8ZEZcXXFrPJRCZ/0opcWkShxt8h+ehFIeMjXQqMpzbQDB0J/u2GJWHOjqUc1tMPv9Wk2Ju8hSHthp9bl/n+pGRzo0+77DEgOub3/oopQspILnrIbIc47bQMG+z1S/vILrNJyH+e2Qn+bo88rzZ1UGSuaUuPqZfqUBHXEKZ1CFET6TEuJP/NNuwFNc33en3T3f37V4e3DEz2D+zQ/kXXZA92jfZ7vViRt/o7PBXI/dHNnV3Wau4ZEk/O77Ut9kFzDX5ZUc2u5uaN7nDKb+bv5eNNYVyZ9K/Ptg45OOZ9KLt0vqIQyqVAIAj9DwPJc8ZlnLaxzvcTKExP3aEMO3dlsOvVJNpFzN6TzGENApFTOcfsSOR+mT9AEPUAhe3IuIkRqVKIMPj8t9V4YE0XboHVyslMajWFjyg7qBxfLHcVviACpAwhWR0wVUpmp9sQTXT69UNLLa1A8tqlxru+VM6/HVNry30xPY0Wbyru3vHoDG+gkWh6pgSD3j57POhvnvQPDQNAcMxa2TPZH2Eze3RvBUcU/sbVCrQoP6FNAsUPXOybi3VOk9rJ4GuSoFdoX718sQXMaDWd900puvilaFMOArXwUDSfWjRlX4icT5x6AfHiif9hVRWxHmU99eR8Qv00/SBv480ob9R+7mNLf85oS8ak/6LQIrcKskQ/9Nw3HDCT0f0cal/KuyTSLxC1KHy7h0ZBzJ7d4gAGoUC0EU7TEhkLRSBdUF6qBPWD8mRyPLQMbWYWl3ZJcvnMdm/4/gO5O0k/Dxe65YJ+BrAkHK2ONKB3300iEhSdlscwVDY/176u8npuhvZdfxgDMWFr9WK1WpW8c68v7z5xd88NSFvxqu8EhGxjiMv+fbsShhviI7fOOV7tFrHSIrfbZVUSZDLGDTlDMcAMoCF/uhMKwIljZiM4mba7y+Opl8THlwmFPJIFLEQTlpQigU5OzOI1bklmWe18WQd2hKthJYCv3FaPEng4REH9PoB4YzewhBBBqPQxeDJXEaDFNpRFp/TzmcM6HQApsldw40JllZ4B4+I50ndoFHq4uF55L5WeIJlKEiLVfIhHmFArwdwFZ+krzM+CSxBEKXFiM6xcAQuo0ng5LBlblAva9wRVxZfNDnVzd7uKmOjTmVwj/TXZbFluaU8+ErNFZeqZQqXxfGXM+tOeMcm13Sa+RK9XiTR8HlSHQBI9cyy+NwQnz6g070Foo0vF7dw6YOmnKEYQAqw0W9eaZFFSftNd1dW/MgiHnEgZtxrVxV8DO/9FqPzZvyanPIkIYe+7iVmLrqusrADBH/ZU9lEwLjsAqC9gpgc+pDUFr3KOP8PGaOLUlBazJUACgeoYrByJ8CJRbBwv6NHm8JvQez3kLlCEgUga9F4no9N6ZTLyZ0eDpdiwNfovPfcnKZQJlNqgilggMzE4gjNgEJsfrlo/Vt8Cv+N4oskCDnbo4/LX2gVi8hrF38pEwd2AE11A2gJmQwB6joPjS8WkpVxSBkqgMLELAMxud8VZwfyAD5LVVAYsI4fEZPvff4Bvv/gLzZovQT5P8Jdmj4gKy2rBhnIiu3iijKzACKOpqLESAoyRWfxuwwB+hoPjibjkT1kXq2MiH9X+vDuOqtQjyXRlA2VZqohQBTWS8kUvlRIDKKXaGVrlWKjVpaXlk/G8J7WTRLR660FOtwvQmbhS1xGUOLma6mROmS7maONUaoWXT1B0SjHDMpkEja2Aq+tNXz2zF22s8tohFTYbInNakXBQp01+KPGtZQIoIgVsRhocJ9Y6Nro97ibOVo0Nkd3E4d9LVeHQedqXuNCZwKfGbxr8eW2TdDVt0SpGh9dLtGHfYaflUeGckU3fv0FFu/AM15mUQUr4gs7GuGK4LLmLWycsgSVjasEkgyV9Fpxi9UvsWHQSiAILyujNawoLPmKvUeVYK601si61DTZD0FWf9Df4dGTaEqWMFnnFNinmgbZDrYEIFMoSoaq3l5DYZMxNZNkGl/M+mF6hVzEl9WpQfVgYHAduK6s7N8iOWjD/S1T9abU7x2XjbtTFYjwcgZC6Kq8206j2y6Ngs4P/B2vtjU5DQGaGMvDU9lSPjmAgmCGanfozqvp7RsPG3b4/+nU8/vT29r3du5tJBLe23YhPW0R8Y2Yi34l+XxM99iloUt9Z+GXErun33zmTU7sDMjJ2euOL/pfTGjT/tX722+qf/9A1iLxDraNBJ5y8GxyUAEGEmLARjAhJvsjFztTgT1aT3MTalzr3tsbGy91SzGDgBw96JLJqeo6vyyAgqLVMh220II7kK3H4LJ1z+EwN/J0OEyu7v0jhqWAGINUCMBjAbmnh8iur6nfKA1mFH6Rg99rj5lUkbhymZDfk7Q6Lo5dWJRgflYddWHj7tLvS1HylB+KSxdu9XjY7CqlzaFS2RzKc98qBeWTOOxUeUUvBttTbVhaggLnd/dNdfm9Ux19u9w7tvZEtu4wGpZegXwgCjKwpLse/E8H8TeXNVobBYH/rV+9Zh0qU5fN/A2uizPgPz0F6f8Ozj6YNf7FhH1fM2YF/EhkUrk71z0Wo1IH1ctUo7nucvdokloT1CSqJeTkrr0NHFtNG5wvo2slKgqNKiaxu23dXH4NAydhq3Rimr4VYWTauohGXReRaaWOjudzU3kqHpXq6CZNbgkSuYT1S0E7EfcZIlKK4UwTIeZE8gHEE9YZNhf5VGnHOW6Zexyv1bGQqZ7slQ8o+OzLS8HIf2petuWL92JEhqXCqyliiN4GeVDHJ4+V/gjLv3z87PFwcpCxGqdFDiWberdKBMMqlQUxil6Tz2NKwqQqjbvW0Aq6avuqkocGqvImndZvcs7MxpcMNmDg38Z/yv7wlki6+oPBmOCfAh5dKrPXnG8ILqn98uID/BC6hORbC9RomXUaqF+Tpc9mG2fl+ivBzd1l072htumevrjmlvgdEhmLL5BxJMAXkBDKzyi7y70qu8ModJk/DuT5JfPf8JWWyvh9ZD6Ns2wT0g5HBjr8d/5KbxA3gKqDPx6UsvEcBpvW2Z7s3mxSzbWHrcmbze7xnc9k9oTgiQq/Xgm2dcT7llGclOXDQp1GbcCUAIYQiWpN7yrusCsZ1CxNb6K6HZEANpm0MmQ76TYqH3ITFSF4Zs/OZ8bdm82quXC7XOxm0zDyBiSGAOjH11UW40nwlxL1NibNCsZv3Xd0Glptksx1dEgOrTZC0/uOxG+FNzfs0zj860dG/BsdDt/G7SD61u+hHlkBpBi8ptDqYB9yKXhw7f7EzaGdv+7MAshsFkCx/ZScqt7vPlmUIlXxJUKeDGA6MTvLg+ffe29/71TjdoyPtYWnRhffLNpl3WUKmu5Yp0w3+yY7Q22THX173DulEgZ31dadW5KaK0v2oeOPvg95QBONQ58sud3ngobfj8/Ira8N1KLzJk/of/9nw8EbUNglxJfjg9cqxCjuym/yajmI9vCQC2xtSnYsW9Gz02Vs8yU5Yn4XZhTwUPwcIao0c74qdkz7wDMZsCsdk/L7n2RLRAQyFirKev3Ee9QmC2z+/adj/w7ONlihn88+yv30tCzWkIDX6qztr4GMf7fMgk2zduGn5r9/WLfohW3iu8zHPgvOaBbH5WujIUppgdwnoI4Xh8zZUftevZJT3lbzeg/os91q4LHm4AvLA+1dNkuo4615+07iAqfdaqEuF/L1bCuMLxl89lkob5yjDtQBCV1jpT76TQ7yMAepqiqX02tBHMnbN9InIbcFGXILQyRRq0QAgybVStUiiV2G+s9qlvOr41dLaTz8xpcPEVZhZgoLOirXBfZW7ysr+QD9LCRD9YHJizQZKmlk82Wh9a76yOnv/NpXrz0IHvxIiyIOz6ZEjBDlZ2sXJZebEuSJ3mdpyhHDP/UWW+Pijg3+iXy4fPCDfx8HHt/+d+jh8j+RQ1/8/U/gHy4y3hu2xCmCMeJaZpey5A7WqrLVjxSVZDNo6dbgsjh+u9Lb3GbmoVE5uetxom6jQoYKhL9oj/8lW1/M+e+7J2Pv4uBxY788fsKCjFnpOmbVmjFUYPF/JfxgPkciQ41s222aGEE12UdsocytoNfvXg8s2gd3H4hdURd4jLuLzG8WXwI/Azu/2ChmZif3jE+OW7rgXZhqgUAwpmY9vxlAu8pkeaWyaLSpLKamjOFvmhN2UAJwZJfld6+8IlPEmxvVriuuXWIAjZYWRD0NQNWytHgOn12cQvKt5DUCCRpZYYI6HBRiq/rVyEmvFZDbXeXrN/SS36yoeIvcq5xf7AQ/e9Ue47fKAb/VazPYSG9WVrxJspkviehbLXTFVyMxtKI3CKkSqdfJbwdokKD9FHm9XHd5YZIrQduCWMNrwFNFYiR32buaiVi+WEbD8whjLfAppr4RI86Mb7nAgXrcUbXziCQGcPyGSAsiQTvkcgEhPnNAp7Ow2RfHyVCBz7X7mieGmuQhEtHrBcA6yX0T/QlNy7SfAe48qcsISt08/lJxx+6TRV45SdMztU1m//eowJn20ItQ/NCpIXyipzrpcxmfJ+WRA+QN0g1DgKZm0bxIB8BjqWrB3JzvilnzZyORwCW1Qd0X6Ntr2BsJe/0mscga9rbrW4nflpZ9S2xtRjs+hq8oWbZ7q56uJydiSmJZ58ftx05u25eV9rH3v7SsjdukJ0suHdli+mxgnrvzTpuqRHn8/LKky1EaqZVDFLAuPOp5guMSvooOIXPSKkZL0suXZUt0prnYLe7URRXWFYLxSU/zzE6BZTR96FTX5UACyTr8Ivpd8oUFRM1fHj/pacviPcANAw+mdTLOv5feNrt5ZnPoevpsII8Irj9+MVnnxMUN4EI78KxhgVdu5GzgkUJe5PVebbBu5fZT15VVl6lmObd5kCxkK5GURhWJR6s1xe3IOUqc9HTg6ZWaSfszO6Yemob9IV3n8Cv3bDY2ehoeENjvyPxvp2FQFvSzXFjbI4mE1vi9whHJfGfIhF9AOqi3/+5bXJdLMLBYfE6O8Pn5+aGcEgOmytKMsd7b0lEvnTn6QuzC7vL7s45diwGQC3qKCksLC8FivVwrLjq1WKNMNo6aBIfCYcHcqNloItRcBzoULKNbb1k9Pm5Zq9cNC7/Cq5sX/5ntxmAU8fRLXAsVerCj2UNA7tpThHvC5ivEcbw2RHzzMwM94cEOG7EE0HJFZRaMzVEyCPU3JI8bb19mbYVbVQ2samHmwRq2ni6i2WkUWT0Zx27gcNhYcys8TjPkbQ0P+03h/jJ+GmDn87iOXtzLY1u9VuOtvkmQCm41/H6fqmcmF0+2IcytiB4FkSlUAUKBSiXCiCt/CaG37IPYWa8dU+WhxQEmLSiUclu7GJP45IqJue3G/O28cAtb4WqxoxQB5NkWotzcGdfTAdbTRAEqtVms4IQ6aFIHR62W8AAVk2dQ8vlKw9bjh8aoobF10FOrzhG8RLjWb0tK7hRB8218odTBzohOlpApFLAZK5UCYAo5o+gCSizkb+GApTrD4OII9WwSizVwPWGy6BopSGdQlQKNBkxlcBTNpif3DoMocRBx8iAG0LfE9kVRDWFBgE5rkSjY7e0M6eqR0zt7ieciXpOKp1OIBQqjgCc3CIWA+siOeGCC3OghTwBy8ngAgCTToIzLAcoEQ3JACjbb7YaADCEA5rBv1fGqKX12TnW0Mb/r1fXV0+rfn2edB8bpVZ/WZlNdMKaR2bX5VO5iavi9Q2cz0Tgei8UW88yiaCSHlfVP1krpieq5hUS26CM+4QGuikUsdv+DJJWgORQ+m0uzS5ehfsjLfzkz68+VOYycCuXKHKC4LF4vi8Z9bPlqy1jzcj2BQ3gIND2invGxfROTWjtC+QEBIGKR6RIWri/OcoD9Ve6XYv6jnMK/8ov5xaR5aQxbRAxlxz/A1Yk4fIBLLzyzD3e1nLBNiNj7BZ0qohZBTLPaImCV9EYVzxTKxcW9Jqe+VfMyL3MPVUxc7j9LEFAP0MwHig7IpVRC6Rn7h5llaHYDn8dpQJdlfthyt5QgpcoeUXB1FEodjnxaSsrRlZbqckjmzbhErlbE4cu5jIKlvcUflBG3CREvXGNQ/jjKZxVPR0VNFMk4aRlj3Cf2nhRgiuLxUqYUAGUyYGJAMajXS51UKOqUJXMAVnOtSl3bzGTWBlQqIyxmgEiqugCua65A73Xih3xPi5lZBImoVPoXe4WIbYTyq7gXzhbSAS6foxM9Le0tFssLZ4qjSgP6XJotsj1czP/umJmAJV7Y7N5YrQW8u88TuxOg2Wcbkb4mBmgNpMIm5/WYWIfCYdZcj1m3DzXXgQ5tVOtWABVkHFjbYcVaYUexutkN7Xl2Dyh4FEkPzXoKO+Cl1ayGvfZCmA+KRblKK2Kzyvw0L8mKJqKKe7mX3sGsw3n96yu69wCYuJVnfXmofFT8N6iO4ac7swrW9WpOtn6qUufQT9esjeq6XEfo4v7mglERtQ+raOMlldz6xIyFueoT0pVZ/2SxkC1F0WYxj83isXDozLOH3gsfWeTWz1HV94ul0Rk5pcVAzkpWRQ4jZ+WfWZkvF+T+UCpdZufRWAI2BV1SkbW8czFRyZq6xNWfoZ5+pHjYwGnQn57xTeJOU1kiIlsaM08q5hfn/1WY82hfm9wvv2LfjrP04ZgMCZmlEAGLVDHDUhihiGUJ9p0pYIQr7V3LqGk+yDHSDhAEZ7lxRIqYucdb9iK1V4SZa0nKaeDx2YVkb+lngvZh8hkYaFUIBjeDBOJcdXDZMsytQLafe5xaMaqHRocw9buwu0i7y9uY89y4OPVNXGxfRGPll8G3lfCBSGex7+YQZ0iBKRkbGksUfVmJGBjrxImKkX3h+c/S+/6aTFur0Ltu5aI/Ia9KnGyDwzksTytFLvQ2kKy0ml3ul3xL+J5rQxlD2934obGhulvIybmKC0hrdcyi+nbkwYsULq+hwfpQYkbBtp7XWM6wvB2mVFfoHobnDNB2mDwMvBcZjbWnsuhXfSeu3mBc9b741VUFF5SJelXufm2CXl+4aG/kbiBFi8prKXVOSqwLtoIL9AI6uZixtJ7nS1vSVlm9aR3WFadafOvG+lKRY+OKfPkF3qIib0G+b2WcQnWzGKkSSfwByz7NHLG2vS5BPhMRwRtONg4QA5HOJhkN2PAR/YjBAkZiCPQfSalnuSKV8F/t/Kv6zaa05Vf9bn1i/SVSzLdYP7biNVdKByM4vCyzqF5Vcx8rfkOiK0ivEHoboLtGZLWkTImTtDWRzrQ8c/2TTxTLfuGD27cGpvKbW+yAb912FDtqr2Rxu/R2t0I7AjncsJGbFHZIT3VIon/A6SVczZ3o7zneUh3ungRsY4i6qDZJ1D2cTuqv6V/Rd3heEj3uBwnEQdXbIYV2xA1zQLTLcDPMLXAr3LDv5L7ixFG/jRng1srSTf98WfLXZwPTlz//ZAnh2jSA6PMTDXgLLUG47yn1dB/+W2r8LuYxmRm9GeO3736TtWf8g2/uariuRX7V92q9fRtOdVcCpzYoPkEb738J1tWExYqJ6kURL4o4Dy298RY0tL2wig6Cda7UbCvcdl/VW29Upx2+hd1FHhprY84/6hs9GiMdPw4rG1jznPTd1MD81dVXB9+FwR4r0+oUVsmOXjVuSYfKWefSL6rd8EQTIhFSoy7W0M4lv5jqpIuFynb/ws2FG/5e1/7C13jz1A3fEchykplF9BYUq0GzGsFVCHkwCGayEn3k3eDhopoTE/kwt2HpJYfc2RIbdpuoIuCCLFZvENkmmnujLHILMKt4V7HfZwonvCkeVwJf8ZHietRHUTw5GU+Qkh2/1AwSiQTiIBw+BU1UJyZs+xlG2zWYF2pVKNQqVenUmmBAbeFgMh1rvoAxmjDG3mCBPePTTNQnGRmfoDI/fTGSRct5kiptNkrHf9UUqfzxUzVs9OPmWJy+LZIFQ9d6xAsKTkMDZEHSlWCZYHNTtbd6Uvxqb4vM3wprTwmaaiLdh/XG/R1ezpGe/kNcT+c86Ngb1GD7QR61ZvpAdIcWXQfaGrV8fIuNxa7lFcY3B1PeySCk1WGwZK9lza7Ns61zDut8eM2O2Q3ttspLM3W7coWVOCyHXNWfJ6rB1rF3JCS39Lkt9SuFTA63ukyCVrrNJqPNIKIJjErcpnOPLYG4lWUtXxvjhmPveNDcpfqzJYXcorLu4hx36eq600/3Df+8x1N39814PLcRQzIzmBSTH8uPWnInClqU5ezmwcZYRRARZOOpdFR+3j9AshdlFMfDNMYKsFIo6dJB9m7zck0AHmHXN9Q05uancFKAFFv1nnqlunBLc20dkecqr2bUgsX5t3hHiiv68zPn/tq9Nl4+QfZ4yBNygDweoSbIyrhNxgH5CgjjTC3VUwMAtT4avdZrMGWqMlcANV46rcanYDFkNHMDzs5g4qwymYZTVmAFdHAZ31aGY4poNKYYV+EygsuUOLGqqol1jNJYLZVVN1Io1ZBUpjoUqrtaJhFCjQKpd7CcNKKbNqjLSWURiUpyYZJ7fQXC8GoCVA62piD+T/E5Ibu9KnyoLvcWqoJaF04s2Du0X2rq/qPVhA/V59xCVVDqjc95HVZ/ZlOmxSH4zfhIYfzp5/K8ILeA25zHe2dtnaS6VoquNwhdXZ20ukZajwZg1GqLHpSWPiwqfOKOPqBUfF5z12t8N1vfYvVa8/WrIS/k+esTF/3ry2tNuxYaF3abdr8s1x+dfuds+dzA843eUa/JEL9y+IJme/ofajHaSx/HI12GdGhDs4rc5xeKYhAWcaxdluByLle0wg3PxeUHL7/u+Wx4wAaDtljzmtBqXWm+t4/mONAITFkscYyiYnq21for1MbLkS5vskBSZdOLixhxf1q+4NGbxrw52lNTelmmVia7XBoC7XeHdrkZY1L64/uHY51BxABTErmrkndhq0VEQ1eLDw7KLdakpt44fTPchuMt3h5QcTVKwf4AhAAu2io+5sq9ib9S35O1AvbjTV2jjHBP7onKTEmiKrklBVB1dXEknABV4kvmhRAPlRSSADSmSj5dLvsMppVPg/+2XHYxnW/QcKlqfQI3DE8Ui1pbGUJRB1MdSpV+TBiTb+wpqb/PaOAQNeHlK4zDPndoOGhL2xugy8vXi/x1VB0lPSily7nyzYHplCo2iYhXYLP7Yldo17m2tHaohCr0OEm2feVgyVdIbUJ1XEL88hi10L5CMgjYuz/2mf2W5ZgZjUaikcrE5ch9HfYVj2Yj2hWtiLj+qU6/f6q7f7d0XjEfDoab/+7D2Wu+7oLln7/TD9NEORROlGHoHTdWMc07qNYoNIm6CVuQXxbfLq7Cde213CgLFsIIVCrBV0togfJHuU3OzetBf63tDsm6gWajxemyw3LXUgo3n0I2ufFsGYQhasb6EMceVuI/x2XFH3tevgemqvNe3Oo5wJ7SLPCiFjSjV/Wfoiev6znfVwHjndacng5ON9/DXb5sfWGnouJ36ytWdMWaZz0Wm/PsNsstLcXZ21g7ROq2Qn1+nqGw0JCXr4/bb37fvPgevAq3bGgVHus169NbP9l6FRus8yV971mXCtsM3tPGV+qEc6HQ/q6Frr7eK/tT7g1mfU2FwHa7OvrMX/fV3ZGrKP2besIv3S/pbne4D3Qn2xst/qK79YLlwhnrmXsvnEV169/VU1OtD4qPnCzn/7Yc5zZqxI300rfWrw+lYd1GrRhqGeAc02uPPC2tGOop6iZTQyzge5JRcdtCVFTXqUgETRW1OFb5XxtjxELh4xXoWhUOV6UC0ESGE1fNpfho9fpKOfrYvAxTVQWPqIXtnd8tL/9mRBfFcHwk0wdYM3RkD/TK22gWJ5arEPDpyB41ZAObg+ACghqU7Td/3yO/Lcp64FoKtn/mvza73h78z/PfyY/VudD80/kd6Evo1ImnJ3baIdK2mbEfGkObnv24zHxzOT7at4z3dYy2iAnNTiqnkp9zJtvyjG8sM8MYTN0I6DqLZ00W2mATh6+ufLVIKWBxeXQGRyOVUjT0qy0ORiMIGo0CAWgEQdC4peUCkLHsZJmPQPCVlYNLZfB/5zHc45J8LsqrPL8/3KbvFTbZ00vV9bhzX+uv1I3ty6XyBR+37wT/dlu4WYbOjCaDRAKROBgdhcqp2d3X1wYaz8LOKwhr6ektYNREEZQ/X1rE2GKIx1tgvT1i8WjfCMLOflJYf8UPjcbBOI8wGB2dQT8OgudhZxVsy4Ko2dNT8fnsiERHZ36h1eMOYyruWZjRWExvb2HJxpjypfcJOdE1DdHoLNOnsXl7F5F/NOPXod5B+sp07AlzBMPjlZfUfdptH8lK1zxW1n/kUfhVh7mmMBXX7J5UT97LuTq3NAfrjzPGUUO71Z6a1hSJMy6PaFfiRJ2dhw8fmuuK9F8ov04uKSVfL68wVrA8ZJqLTqc5PWTWOb+4sz9ynomiU3AhZlYuLwxdWkLP9/d31Ro8fLjt79R3jr59dLD9vvVSRu209X4INHBF7+hqqNqdp5Eg5FAPjoGludcjglbj0uN+WOH2aRjI2MDD7Sxcau09hWR6cmryfcVB8KzY87/ZqKdhLvVm5MG149f7nxNrkttK9IakFdlJCxwEUbM7akF0HNTl+XkGvUQ8Q0RtMKxI4qa+JuBHirzwUWpuksmzZKxhk4gn//v52LUTyCzL+eezksQVBoMgIY8P/1QBgLWRr7DXjeirpl9E+borHycATsnBeNU00esmT6jU5EkJp7fKI5NqlS9B32XlspQG9ZhYNqTWyIY3Rb0nwxq1BDh2sYHNSdI0fDqQvDAbf2XpqwRZCRkRGXjhHowLwlu7A8WNQ5XsGxcet7KrGUc9RzNi4uR/9T88gXYOu2WJ+i9ESi/JpQUBWXJn6Q+G1FI5rDBuVCzMtUXyMoHa17qncFiU/zwCZtLvRA2wqxk/aZ5fED2vvooxlbwmh1/4AXazpISMCBFtv4uTAckLX7JBB24d4Rhl6AktauVnj1u0ctuV7VcylLA3rkCy2VfwpyYZ64y60qityKZmrf8+uejIIvQP5k3J20gM+tj/+GLMJwyvnB/thd7oZYOtSoBgG+BSJgPRzoBgqwW8KmdgrqsONAdwB6c1UL5Ka5poY06UV2mZSjDpsBfzkAMakCaXWFa3vomaY8QKFVWf+bL6HqCilwxsQFTPw60vKhrC8esBEXaaVempqvRWVsk0PBNp3rRUlLof8xR4H1Re3oPqRK0vjZaQyK7NYuYfSk8Vp9NrCLwNVQF9pr58u1yI35qWhJkJR8fY4fQs/FJFcXznKoOZ5uUTbKWQHv2p3jjrTO6KcY5RMZZN4WPptVXPOj3O8qpHOeJuNRUdz/r9n2Pefq7rz/qs02nph+tgEtG/0V+V13PxXWtv1gvK8mqqvxfJ58b+m5jwOCG3dt1LTHwHWkaXlacjer5oLq8oAf7rARDDw2jVMLpg6+fYcKMgXLWJDYjqeFgBI2H5dcgRFAQ5w95tH73DgrWnJH5ExU9pp7S/n1m3qiT/av0aHGd3/vpf+Z2PsxM0/GRabE5VZm5CVdVy7TItbQXTdZKt4GXDZ/+UfRI/GZBPsr2WkZY30bBlSPHik3K/WPxk220zZMynQikJz1OTp4Rp7V9noDtKCl6/X+PKdSr424OyO/ezE9UNBbQsWlVWgrA1NfWbIlps2h8HCLW2RM2RGwNHOyrM3eb8iqQ83kE9YvjJXRtp66ucAUegnGxLXZbshznZP2XDiDkPD+1xmTsqPBGeCk8dfrLSvYtCaKBQGggrzRYsJWdd1ordORThEGb3igdZWcMbef/aGv4tp7yReEzpViYcq/tYuT9nXUquDhvt9KMBMMiXh9mRYtFFsaa/s0lNlo2t8kvvOQ0xc21a7lqabQ9z19EMX5JzI6SXTnmDpQVuLrrYyVssDVMNpmFtllcrAmUfK38A7X/sEcYd9SVehkSUxbCaEyqP4h4DRIHQJxEF6JnLpZ87ntJzxe8EtyucNxTlOM1Qzpl1LvdBL+cNCtxcbMYBMcPLxQ+Ew1LC4SPCYR7h1CANZmSg6QVTKwzcZjSAsj0aRMBArZhGYU92FGen/tnK/apaGbHdIDeE2K4XDdF2GAYrmvFqQmvejHNGjtKBo5r8sBpqR8j6jy/HAboNs8xmH+JEz4ArMvPXLTs+oxtSdhnpDqRNJNbLmCr/4lsCgzBCAr1x0AushTCLXL2E97hWEQWdQU6Xyd+bEqKX8wYFLhcNFjl5i20H1FNeNf4xGArn4ABG8Mg9GtaxCOtchA0oIirVXig1FUTDTSZhwHCLi5UTNG1ndk5EmZ8BV8ZbxDVJM+E7SsvTiM8P3qa0QtuP+i/LHuJ46XeV+zHMNOvxO7EdqyVv90iMiJoqo6AiwG7ywcAdysMmysvfgXeHNymPbi5HGtaxCOtchA0oIpAu8e6oG3Mpz70r9ljhEBkSnretk1SsyZ3DUUhEM/ZpWqAgykxGQUKAJfJC8QkJMIMEeQN4KAzx6gYNI8pFTRGirsdDAoE70uSAm9SUF4NN+JraMMsgCoBmHBAXeDZkU5trRFGFELU89qXD0p9QbKN+aWF75ixHSXTDSu8ryld12HwZEvuCIjjR7W0/7ER1Hx+tw5uoLW3GkTXjktxz7ITq3LanPgpki5pgq2bnVOfsqzoiHeCva2s9hJKn4zXJGwO+9756NsGBnTDuxVgS4GOpG9Xt22JgU+I2nU/mGLm39E+vNGLNa52YQ4rkCXVc1cj7LcsMfm9e80bfUcq8IPVv00rpmSjI3ChR3Kw+wG+ARlg5d0PfooZ5Q42FxmIZ50u/bYboXaPa7ZC6xaSVPvaXqHC5Jq8ov5aDT/DXAL9VDcXvMwctfSkPFAPrQaaN0teDbJ10L6mWrPY9eSdCY1FthHru1ryo/qMa5g01FhqLZZyMNnvdvMVaQvT+w9qDwULqzjV57RyRB7gV1xC/RRl+YdmQAd8HxKDZB9zhRJjFVMZnS9tgUNZnanSJHKuG2EYIPjI2/dOitb0O/QrqnKQM0G9SSC8rqs90hKw//EC+FUB0fyOijXnqaYbEAXIeDrGL1OAHufENcHUcW/ieMdI1FmlGvVaQVDZ0/4noOWsFlKnE90ysMwpP9fsEcBtuRqNaavK6rn2uNXN+mXXeQGX7rlo5r7GoNhYJ24Txe413OIGD14TTAjfMiMv0N6yfhfFd5s6mo2m3QvLyfqncNSwmnXcQ2l9I7q+Wzv5JgYbd0CzXaB66aeceNcT31KLbhDoJCnOqwbk8heK3yKHF28ObeRxnl2RuIlvorjiC9AHzFhSCmxE268NHhuv03rwuVS1EzNwXwA0T1fdxg/2KML7L3NN0NO3eOnlVQXgnxEG9R89uV/mE58lNhlwVCeAys3Vja0NR8K4Z+9QWcgOm26zQuWYdw9dKw620AmnW6e0Y6oZFTV5K+K7Yg/wBfi18gWi57MusX2Mpe49tWDZgXq1Sylzd/kLNTVNjNsSv0ggr567qVSTMG7hFLuN86bHNAXpLqqvr8i7RTWWY65WNXNSrvWDMe3MDWaaUGbP/gOamibJ8c1k0wsq5W3oVNconcy9mwgY44NU690Vd3YGBuVSL173akWuqvpHcJBJ6v4+h+07KnFUp2cEe4w3wU45Ywx0a45stu8eucfs6+dKykWbSMWRDyNt3GBq3b5Z0LgoYJln3F4cJVBtwjrneaH+glq6ji8OOHM3O7EAquHHUiafmnNuxJ130Mp3ep7fk9GZ2o4s3+Vh9yLMACWwzZtC5KiboiPB5wGYpoyV1Nu1RFqw2bl8hW1pWnXGSLrX3KAuKHbdvIkvr7Hrwpy0tzejBRmqdDTfuyra/o7wsLk9Wx7tWB+Ff456yoVL1Kl4XftBxC3rE9dvT1I8LAbc3+z3I79BjPCj9L30pKeYt3LS/zdk1Gi7scWgLMZvD1/nHSEX0J7YXp0c75I4HbT3wNwnzdFqleX76RaVg/4kX6E+m2ZTzr6pwsG2Pjmi+9+JRjvHO5pihLDR+/bhmBfHZ8F7HTrZbgRvqyu2clh3Hea6qv3F3Re/z/iEdDoHLFxpkJ5641trmvuw6JDrPR+qPY+18VA9fg2wedLs6ZQkNqDutqqkbZMGvkCqAoqf9Vzr6a8se2wlQg15xX3fjXhHRG8GiN72M3vIuetuT5jvRu+7uudfe/6Fn7nt2PSE7A//AXRv8d22oasN/ro2M2uix2ZhydXwT0BE78P+PoBt0k27RbbpDd+EefLbvy2NuziO+8QbexFt4G+/gXbyX3d8mTN3fmIFUV/LjjT27DbpF/3pRb5r9Nv9212laArDcJJa/E0T3bbfh+oDoNUXjAZoReaguXiqJRCKRSCQ6PiX4WXg7Pv+CNxb18lQI98s32sfBc/qV1LItPlBvA/7oKrcaH2Tb3fAzTU+HLX6ybdA2/Uyw3JjzF5c0H+OC+zK3lD2/J3Fk3S87St/XHL+TCH7sf3Kyir2I8B7UV9Wbi+GvvpCKSSyW9mGae7sUqmoEKI7D0Cd2Cv22nFt6LHLFCz3Rl5WWBwkp2Kk2hUBOk8JIUDFOizYdtev3uMAdBfdI/uuM19VERkd/Kab9X8T37o/p05/G9Oq3GFzA4nznXt+d6Zc/aOzs7HnA8zfTyfiElr999xJppNFLlZ+0QPiiPpCPwHj51/++OUbgnD/vfAQ62y/QTqCQA+Wvj71fzO4V2AvqeeUVj18Zmc8NSQZhPcKRWiRLPZaYZJsIlrMsKymO9qqrZXSsRDvQXnp2hRG3veNs1SkXLVUwocSgwyJg8LS2BhOKIbDqtOU1F02eu0unhxhOa+Btjw5soqyEu3tSdcrYrbFyN6NdKC+/NBYpnFRCxOowEJR9sHcK6u4qcKJo+SvZQueePpBj4TLJousJHxmpymUlVn1YpVb9QGE1B1R4xb3K8as5PaS2qZYYYc6ePTgqAJlcqaNM0fL4AGbViAmeUh73wJKEeMZ0cJcUy7DUJIa3fXJgyFmWlZR4ULX4AXnMPdB9BGRYT55Zbj8D3R5Gp4k2E1BxgSIVDCqRCL0rOG1CMWeFYeNYKKRtTi8klQfiUxGwlLpbsPrCWP2Q8VCUmiz1K+oFhpt5UkNL25ygX5IUK4n1Ku8MgLoWqEixKufGSoq12WpLFcvMvsqwlbOszBSzIXcH3R2KlXc+j6u4UFEDqzLU3aJ3ecnSyPaqfbArNiQNnroTZcuW+JS0BIFFJ4HY3GKLKp8/IdWcOJNH1cdnuuzqXHOZvVl2RnkHKTsy7oZ3ypyzV6lLvIMThnL2bAWuDC4aoYJ0Yjr/rhfGTod6xl2c095Mtd5LJBmU7DGP4OzJknosMciJomTM0g+Ili0G0SUrZ23pnwiBWjMo0iBmAcnAMRmeTfyxCuZU85spbE3mxAAzIAePGnYE1A/wpG9ur/eDQqgz9Baz9W0ufItj64ngQE3k+iFlDp1AW+AduzebDQxSdZpB9jiLCPy5xt4Buod2JcDbaprYyldqK3NHbyEXMQ3zl+YcO8gJzp72eAYzZ2Sb+fWmoJw29QQRR9WZm0T2gOKKbwEy0eHG/zxodSITYbk2WhOpYvt/EDLTFpt0K04kRViyEiAAFlhggQ0egn51BeVUw/QSSQZbuo8AInVttcJIJ3pr5IXc6OROKshNqk7SQG5DaT7r4gKzELgAI1KfOucsEiLN3l3YIVWg/+h/+BbUT7KM1N4wUAHa0yhIQ5b6zfbCxUtWWE/62NI2A+iNpFjpjLVuDRdKNEtj/aDa3JbldhzI382wlbNjWbGZuB0+7tmAizdTrfcSSYbHDDkbG+w3VpolEkXJmNY1CkSXrORb9MdkAxRM8WbMKSxIJo9peiwEyLRtaSTsRTFeLZOCXcXIIxIpgIKOdGpz8tBecM4/EOGUcDxb0CZEtUsky8QzAgRdhD53/AEEICt6bmcB76ZyagM58Ky9SGeDEl1bOzziBCHyx2xr5ZZZKxrNpT8EcFbSMGeZ0I4+oBNo6kwQfmq04FBiW8uAVaKwMymQAig8mwTqtYof/hkdSx+fwXfyfb6KcNSQux35fo57RXdknXtK+Tm/d+1UnxRVYnFkTJ7pRlAFAMfpVdvuUj6id5tTfThCmpFEUmVe8H/TkXsWHqVaYVo8E+oMFWGknOH5McVIZHeYZGMb8K9oYDTCqIOP6tTD09ojrRsV8t8Dq2ZPhVA9emu4JhrrAyAifgLR/hmFzj0NobOAd7GXWS96hByUp/DO8EGzWi7OzEVasFaZBbRstfpTCfidNudPQ6XP9r+is9M5s5LcOWuh1Ep6CUsjSUkG0alxBXFwZrD59krA9FnXeCch+aO99yPJwg1yHo4F5oq/lgsm0yJOJfexVnN0ahVQUteDdsKMvxI7rtRj3LFb9HdxBeaKvxayYos4lcxH69hG2cCaU1Z0tWfyZfRCZQLcuSNX6juJ5u90QuQsosi6N3Whs6kp3UUrb5uSEPXHZ64EwB3HYoG4AnPFXws5KhZx4tzHWo1yahVQHg8A38hP1Qf39YA6DxX7vrQndHSwZN/AeHK/wMi9PeOpC5P38sjp/LUQI3WEZ5Jhfv8U59qjzeG046F3jwq7/lvAJXhT6ykuneyb7pZTh/Cf3XqjUjQBV+biPNsbMjHvRREw0J8Vhqd8QrsKY4DdA9jNKiIejsVZCRznhoItoX1JD2e3+4fizHYyj+pPJSB0VOJDvhu2B1GEHzePSUwEJ8AJjrMWRotz+j91HyKvr0JXY1tLjmziBBjKoB6TdoON0wiNl7ECy1VPnmCwTff9bRro4OTw5/j3PtagIbpeAjx9ZorIc47eIuO/+8KyYFKQkTcXmOfhdlf+/MLvFFW6oEOtb7L5nvDcLwW0V43cJgV8oyUEVmU9D8lr6iskpmL9bQLGY9pCEed2dDwyPp+wCiQeqLEyzmbwoZvstqkxJNs/Kx+CcEWPrYRRTjMqDpmJ0ibtX+ptG3guB0vWsHoWub/9/VP8vY8ziIUpFsQt/A4b55DUccxnAe/xpWlE2wTz3ISJNqyaJCDjT+H1Ae5QRrXv0v3Y1oyOd5F72x1lh4s5C626iHHJjVIITBXGdthqta0o+tufWe5D6zhukDYxYrchaWDXhs4kY1ZXDTO0XflYFzkSSRihSDYR7z1r0wmYDhW38kB40HeWbI7toxKYo1s/1IGCaBowlexwOdiNF2k8vxTKUfM8Vt5uLOPB98vP69HRZHwBYUmACermoFB/tE3P1OCB0r9+BcSSKS1YhKfozfRA1BRSsdwe7v7mc/LFsWmnq43QVywWgB2eLDZGMzeIGINnuzu095dm4IE1rdSMN/ma2i5iLg4dkULKX9BDTiX3RmooicUzrtwBjYAAWpViwbCx/f/sPcq7x2WRy0wkca9OvM/vUfTa+YQbvfe0+UzWZHZeICCVjEP0oqSCVXqiULjkECAOsecTxKaseElFpQvdq4Ruz6bJqEVPikt5TRgKnR0hywpo+ScXjk0utr4fNoaazDWu5mSk8dR0kXSuRz8iYylOn94M7dYKszxk0WuB7EggNQsUVk/xhQpPYRCby3sesFP65f8TnfXqxWwVVUxGxEw54T6VinOsCGnb8Pfcs5nEwSFAhQBJXUxYijrWaK61ZnA38xw72DRD+vr7K8jkMbL5GR5+r9DKWgxbyjF0n7pNazbhkxGIwonuORwlsp/RCKJXYp3raaMuXdDby7LwSQTuki+IOo0HSNKkH5BKm6Os9RJoRPLoDXl6nvCphaaUMI+G4To9xRviVclDJ9GpcfRsyjAIn1ugFMynrUHHd1djHYo3V6hp8o6xGMYvFYSIyJtd1MbtP9wmZ83DeeKI16MYHkoKJHCRYoJDUw9Go94T5eJuNbVo0Lz5NM+Dsu70wMxJdwZkob5InmXwDJmHLrSiLqdSy9vzSa/Uxx8BLPNwQ/Hm0iy+jcK0ULBS9VwWbotMQfcK2+FcHGZ4CoW3i8nOTYQzhlVTGNg7fvZa7hjodmHg1G5tpEiP1DIPNkSN8jVS/du1LyjY/MOZCiiuNoIz8JLjbxhuAqF2uZEg6QO5WHPhaUbYwwUHg7ojYujIA5bDfpjSc97Fw65JArEcHn6wiSPNpofH/BF/e7/W89KVwYkbTJ5CaLSbQnEHGz5XmN0YWrRdc4e21XImN7MtAJxqgEtrm38KGTOXjZd0CmAF35GCHCkxJWCC/LNcX2trCmzz5MsJGrmXraiFTwpYyrNw2lQ40UUlMfViUp12b7JIW2u8ejKzcXa/UmFqlqSekLHwuzfX8OrBxcVXQ3ZGbOtV+wAab9tjlK11YVvv9KdzybBPh7HdDZJNzTAwlYzFEsLcovCwT5dL8zyPeZC9NVO0J7fzYafL0dWzQveyitXNc6CjbfYEHH0AGi42A9IX7DLzgdLVxUnlF1jqwLes9AJIJWsSB4e+92qUk1ZcNyTO+NTCMx08V9oCmxJ+maoiPO0yhQpWKuWXEd9DXSdXprgm3adRVDkK90MkWavuqOX1gPKCEYRO+QJyJJr4fuddsquYUIjlLVFjtcBKrziTlAI67r46IuYkzlf5iCA0WcdYzJR6rD6f9/BC9XHou1e9XlM6FAAUTO2NYjslWGHVr7D6Pp59cvgznQteu7BSdUEjRU4LHiLX6Bv1epEwJ/VFZDweeeNO+kDRAquzPku0beHfL684ebwS+fLD7cf5eBjqUispkth3GVjzSoMP+WvOvQ2FxjBOAs4f2od4Un9VwWePI3gbnY7tIoxRIM+J8pYgMD9pjHZybUbKiByVLOXpdsgpHFtc1w8FVx/nJX1PxiMoh6XLe1ltxJvgiHTC3U15cYQ9Uak6VrVBYH54wOU0ANOUKn9xO2H9doKRk3m3rgz8ztuGFxdc3qado6+X1Gm9MBzz1rn7u7KFlsltQSAP9WxqTBxzLpmidI0uOtwma4ID+7xoQPz/T/BbTC3lpFnYO74q3q4pdobhIT1s0nhamp8qSJFecEWE2ORD5Yvb8VDqLBUDZpStAzB5vNdkrh2ESIqUFIweFfMQfs35wl+pZCKkphEGQOc65/HOkdK5i7BhZMxFzl/dwztbKoB1EF3huaUlgZ/ydKlRuYIxwZhsoNnnsrzzPe9IY/m2PdJ2iRq1lni8R2iP+yBjBftEVAjhxdWODnrtzk4QeftAtFkbhZ5jTSW54YT3pcrSTdtNZdOEtL+Xlbmk3I8oMBYb+LY56Dtf7iIWzxJEbY/7kMdppLxWcqVGtjvoSQ7UOh9ftE1dqrM+6yobc7ftIZ/n6v+FRhjouM0AsMU2yFQOMti3daxqOdAxJaoO/eJ2jouftXn9DHswlNFFS5oJgDwN6HPmAczQbD/xmylt2iZ6bbgMXYi7ikdorVryKTVm6Xyqcs8A6q33BgXNgXHcuxo2HjtR85457Fx2kpxuSWFZUEFH+AjjblPcJ/hAMOXp5PduuAAylhI+r4I99j3LmVawyk4+SdszZae/U7YM9dfQuHs27Hbgx89IkfYcnvNp4e92oZ3xtkK9M/D1A6PhlvEAlODgPmNHQvEtA8KhLNUK7GZUpROh9HLUXwJRoccm6kN51IOJzDPqNUNzpF9Ts5Cvgcl9CWAICtc7osYM6An5I6WKmToqgs/hrTFsAvDyGwk1y3l+P/STGiIzSt3DNA9IgrKEcdIFIlELoSylRIHBRkcUfjJZk6eLplxh6ksFERCKAcXDB3zGAqtnLw8FVxqW2Pcp5jXjJISBy4nPtvf4FfFpaHGdx801TG5DdL5N4pyTDb1kr050fInRA2AcMbyqYY4YlHlk4gfSaxUQlK8mW6ax2WREesxZFmYRQQgZhsSBaN7WWoTJ1cLD9W7zBBPWij/XTLSNckHu72Fe0Q+DGa+e59GPZMxmm38dNGhKV8HQNk+fdc0VDIjgAkxIB/uCmU/bBHs/oFkb5TePhni07JoqAYOalOez5vt2gb9pv3taUGIiqTgDhkNz2kRMcUBvUOyzsLzBbfSNjYU4WW5RnphvCn9MPUA309/wARv6H/ZsCKN76XfYowE6vpjWhSJ3Sj3keQLQs5r715UazKQgYhGqBGB2imus1CCT+qJlelXLHj3e48chVSr3fN2dL0qotq0Qvm1QMZr0OAZoGz3CWCJFKcP49bYRId60sXqN18ERh32oHC6Vlg94CXiGsqgjw6S5Sf8uKhyLSwsvEx96PLS3j/f6MWJ5FZyoaU/k+5EDCR6vNAZLz/HQgyd+KCbcU/VF4/d8podG8zwInXp9gJcDjhdNIK8wMT2kff1BMAJrPgxch0n0dFdJMH0TqBae50AReeNcd0n0i9dWHjWefRYWBrmQiwy/eBWO7IsR2257MV2EoWWbWL4GNt1kpKa2zWxUbuUCoEB8E0GkY/zVqyTOmrCC9myBRRxyieJeOmyTRppWkoGbNt3ka0c0zpffySXSHdJ0ahzVsx4Qg16e2nX6d5GCuKPvFUQi5rfkkexFRmiMQdmAAP7pTi4rL7B6MIAET6yWIcr9v+doZ48D9JTx0bd5alpNZifZo8lZGcw9Qn8dN00CpoAPeXwGqxgp1Koo/JyI5tuSVZuCKmOENbcz/tylplgVVK46OP/rmosYbdOb4JAdgHUoki+kJaD8hKDDXSPPaT6VEiO79jX0PYtIOYZI4oN0bMmH92CzECJj045JAe/9gFvGvZ4hQezHK2yMHQiABvzHLkxJ+3t7/d9ebPoeRzrxeE/J7ljqC9i9oYv5ee7TtK2RtrdY4TYMBNwQj3i8VyYzmhStO0bdMo11CUzRQCtTWixOnWPXmA2AzFNNAmfHCVp6P9IJehTZJCE4S9HmQZVORpE+A0Ko/5l0vt1dMEc6qiww6YiMGM9QE7XsReLQb0dDVZC/sVDBypyYh0pyIhKG4bQTImJkJPuuMHQD1RnTquJS9fOjOj7KRByFgZEhywFc2MQII1UVZH8/RsIMQPM1EzORiDgxFvgOcdmn9Z8ZIAHSgaHuICTDzdkCaGF4jqgW1e9Un36YiYknqqGW4qqGF0CDJ2MFMK8vQSyX6lKE8WMRWyJ6MM8qYf5dfZqx6cSZJSbWGN6340S4cSFlfBUc5EzpzJNA2sy4yB4Rd/ukmOD9JYhlrAuVzSkLDE6kDgH1UhLs3J6F+4hA9McObvb5yO2+PmtJgUp3UKQKAL8FCQjx+WXJ/AhSmaCEiokeywGoeTWdcUKYSqCJULxzWa98KfNV/CzIjAK505LJdSncOoVqmMPykUQURl/BR17xmbla0tI9mJyehg50iNi+rsFIbAN5aocsNBycU9IkllMeXMhGvMW1+3RafJ7KPf0QGNsfGpXFItIqmw7ZLiAoOrluvPyAj4e3BruAB8NcQ261dfDRgg7OQMGwPV4UWXtqKcEhD9DIouRvbYEijEAYp5Qzsvb3K1D0TFFqR20ikkaaMa/P0QYpXcgDMW3EoXAIbGvWvHy68/0f4R1OYLy5JjKVh6tnpkhJnXyorFpPL1wDbeNKT+LEYlfm2l5T7ndAPZoTMeOq1ZxGuNZYfqBHGMis4vnU1Qz49f78xznHkSuXA4bSqyhXaN6oShnB+TjlxjLgUHaoficsD5llvxUSmGUKc9XU6Ng/AlEY4VlJdpBSDJM8lMN7VKNA60S3MOhOka7xjY7m7McSOJMnQKZEk6s5EUSPoOQo/WkWNKeZcXvCaAXoXgCqCtckgtd5mpgmK+swZbthCjVFjt8nkwp/eBlPQKIbfOBK9zzQiBDafm8OiAKWHoWHuJ1w6O22y1LG9qBYTq+4jm5D8e7CLPr01fTcC+rLCUJO3eueRgpLg3pQnrLlxqp2c6LXfoDnUGIovtmgk0CJfHzRVPKcn6PA5TSDTE0Yb7PQhSVThU8XPJrhD4GUFcHFv7IBUIQWEDJqeOXHz1hi7ez1O0LhdBF/Y/afDdhiViNZBE0jsVT/Yn6LOohYxxgHHHIe+GOglYXXJAQiy4zyOsk73ZG3zwUk4JuzidBYx2lnzxJrt7VtEt6JZEyUosKH0gyao1S21eBuM03ugqn8XZMRzHLcUIDlJgP+0os1LvAkCUNg6zLM5eoqaTWI48IzsDGrakRFYCkw3UfK6WuiN5YBphOqNwQP1idAyYyvKHAR89TQrjTt0wlMrgvgzFjGfy8IChtE0EPOOT3ICUgoVb8uTknnL+gJEVhkl4RCdYXmgr8PeEwWkTBMsLmXqHwix42fBqnLbTqcZAELsBpi5XQ6kqvaELB4Z5BKbWY0qCl0UIYNchmqBBjiato2JfJWnzai8d1tX4tCook1OEmBjsIHtnYADYHMFaDhoyHoCMpt8MWoo1tizAb490iQ/gQH2nlASKCnwDjNaw+SjoMPTV1sn484APt9NULHMYosoQNJx6oSWCAOVsl1Br7T8XC5/zL3EkqgzvZmRSKPcbSt3sCljBvrrx6d96HcpbiDNcX1JZ2lOwMCqOnc1E5dlN/hB5MOMoSPhthI/NSuAyRQRl/AqAL4yub9Hgf7issNK6wFrgiIBW2k3LTtAImg9SDRQEfBnu07QMJPTZAcVI/gi795a8PgUA/hVWsjGUSicZXzAGyZ7+KaqT7QfEYj9eVkwYX2sz4ASbhneyIxtgkD2zcJzgxnp12bbpEB2VZ3IP/gLo2qARuHYO9HroUiIPKX/R4Lv6ZB/wHfmgezbFimP0BWtQGPLY4eQLoQsj/dzrSgzfxVRxIKAIVIFk3o3G7vA72xI4ZVDqThRkMhAYL9EfxNpQgSt+toUM+WeRyc+zkODmz+Mi+ERpbnSETFbRMsEt9wAIUPVpnaMUaObM+kIsJcFL6Ip2BhZEYvPg2atQJiHLKLQgkrPaHgmkQgHXe6m+pd3mn5sPCMwiDpjHRh5H+4x0JSgOBxvDB5wZmmgLF2n7D7hx2h3zP6MBzahrkkheCQpi53TZ21JN3aHWPmJAUSMyqtP9sRtY7STxKqARVIgTIBUp2C5I53zdno0B3IYsJ7cBMvMpNuUzKtjMSeYzhVCm4OBS/Y8cQbgnOJD0jhRBqm2csWL/BFpltxu2tIxcnHzaKgji6+STObnREy8nWMbXrvunnmA1CemROH+5R8RrrEdgN03vsnhUoHMcj23xlNIJF5+44dwd+DdAHybO5s5cw0t7fgvjCAeRVUBGwUs8hFtBRm/c4N4j4wlL9sNSeuMMKFfwiE8s5Zw82Uu71yiqTbUsF3qtzuwwK9EReFGv1u8jzMVrRnIAUjpQwbRrpABjeJti0oisjC0znRY+7hLQ6l4pwlXXaCAtAVw6RY5E8C/GNd05LxcRoEJnv2dFE1gX6ka1omjrnH/SUG4fGsvwmpIzgI34Ok4dALXTv2u39IYlVcSLvJZ6SDkSzpviwRCDEOuaBvIDgBOP3cQvd/wGFcQjZJG8SuKUDx3Z2V0iZJaZAP3ixAjz4rANwSVq3bsFcQVVIMPfHeDjL+Yxefji5R7gup522qoDA/15kv3aRNnSsAZ8fOD3ZmBio/WEbnfWgiFm70bxlgMACajfN98Q5KsGgwWhoV58HQcj7vOkMf1INDlFK/TNtbZH0tvw9V81A0pWH7WpCXasLS9QQ8pa4/ZaktAJXroVIWDbCjCoRzC6AwnMIGkTEumbzlBpsqt9utL5TlihmHTUPskVKCzU07LB7QFwoWl6Ucopy2U9sp8zyaayOaKFovrtMNMp7ly/p22RIJ9nTH0xJyvgUWSA1bckjON+VZfWijmQ5G7AKFebaBTcowv7JYMNSBcQaGr+3N7cd8gQPg/sLYyrSFrZdtDdZyYmdGnKCCtKfbTcH6QIQOw7Ju2M4AKgUv85YG2lZOgdvTLf6/YUOeeiuM2lBqsU9A9XkWqubCye18xDsdsDC749P+MBSoPgihA7E4PwPntE5iIp9c1pfmomRcJZU1YcSbXOQZCSrSRYucWRkwRrMxfIVgcZSt1qyXmAn2pSGKCtksCmbStk48cwWXdwd0roxXu6flmzknjIV5ZO8istAdhHnRS5DbVerjWoXrk2OHE3nnsh4KFQVcOGKTCz/j6YO4TWQxrtfjrrjBBSmlFAUe8ZiR2Pk0rIcniD/T7rDcjjAWaB1ALFrj3aNC59k50urv24zEyXNJ/DQGgpQjDQxq8dpTFOUyDIqlDbQpnI4bDx9vp/HQr58a4d+cb8lGxhnXQ9Y4ttpwu4VWh5dNkUV+UXKqxYdtt0RO92aNNInCwM+oNhCXGkYEfBXJ1oq9SzM/vuzbUucWWtaMAn50juBSd5POLN4Rpnt3DMe3YVJOgyWqmRZ7V5fn5/jybvh4+FgVUsD1vdNHenVVkppd5EiCGjhmYHFI6iPi57iX12Z4w8hm6pAMy2tTU3t8GPpmGXu5fr99lwf7y3CBL9k53bF3PJb8xrNZC3qVSiVqaCRkSyMG4sSPCGBukRZOKnIKHBAxGqLve8jl60YLjdox+G7FqF/8P/eX6mVXH+KrLNXLwENONa80JQqs9eovJ6qTFL/J3/39xKWTl3ZvPlyPhxqrMWh55VTppvNMbNzfMftd1kGx5W2iz8cMibhPQKAfHkBo5Cdf51Y2BITYZbsDMLMtwcEB4oI699wqwQbnuTZouufcxb/8ffD7vodcvm60z6jfGB7XpETbSKZJBpkeaNF5E95PrXoDE2HvtD173Cb4KWclHmI3xDkLFF9Q7Qd/0pEXfumuq3kK/Ny/NnEvjYqmPeTydaMdo34wPFEtDSUy8NcM+HKeVC0dJia1vy/9LQXZejXMyHfotWvsNE4E1jLelRjy89qP5LLhhfRVscfHJ12RS27/Ys0qh3bexW8a9uk/qvja1a4iT+n35sR1FRo5TljrMuo5YIHt7/Ize8tQlBaiMu21H8ml+kJ6BS9qx2Z43tiP/OkjlIPcms3Bqc0xbT3m7cwTwiDThrjry+kmX5HvwU1JuxNzqCkhVPuRXBpN7xQN6TU82bZHf+5TuxJP8PY7Yjnr7YOskc1o29t1GZ1nNHzH6/gWuw4E2/sGA58g7THdv5wy3ABQs4jBrna14HZONjSqwBTvAKf4fSAQyh51Zll77vt1+s2tWOeibTLtNP2Xwl0+47xhQRMLLW24SZYO9MVrtj3Xmfm6Saytot2367Yn03oaGreRkK9x9WtaNZJX/VeMltchM928l2WXM9fD1X3dnLa30JF7LAfhMuEwx36PNhtpIefCWMsXEWV19aMpGKRjOh2utomBdmcSIjVCrYdmmSrazkyhELBt+hSDGdx117ielppaZgVzSPJbyGmun4T1NBsPzKBWfWCPnYE0qMPsz1/IF5KWeAscPxdAXFOIZ6dVp1qFdnVezNYWjicCAd74Zl1PAeLS5WC/b2Oyi7j7iZtJ0nIqHsb2in0/nT2n4AW9UrlMcaURWqK3SG1lpanhysW0BfGezYW27XmvBTv3gtDvhKaX8QRi81ByvL657ANrmg8YDUYP+xj8Wl49bO3tKYhlkfznFcZpeXn4Gj/c2syDinSNKmS8kPLOhg79V/F5JVa9A6b8InPya0OjERtSGgdGTHNW53x8X4yT1wBtSAOEV6Pj4sxWwLbfjWmkEXAl0ScSCZ+Puv9abPEKlADKh9HRDddSBICjIoLGMNpu0TQCMPIw5E9ZvbbcCmbUXbeQ55X/JGzMR2LlXTPrPg58zykYLVBH6V/yRb9Uf6KPKuig/SIehU9Kk5+okO/W3Z+fhxL8jGaVb6K2EUwTBJo4YEDdIuiYRpL7B3kt7TAXNw+R6I0T1J0KauixNq4NV6Ydth43OUGk39tc5h8FhjiO0+wE5aSl4gf04GmnfIjcq7xpQjjIhcxwmrB1wCUxC8NKF3cAfdOIbiD3yD5f9AYyRZTpZkkxyUAmDQgmqE0XX1oUG3sU8PMlYjmMVm+03leDiyv2ssTwlmVlRGatVyCoqqIuuIKvt0jp2rx4Hk6U6Zn+nE7ZVke+mZc/gC50oNGQY9loxUrcBToqQgeiEFS7cwT3ZjL1SRhcvuJWsoOYV2wuctwXOZrRbK6Sc0AL52EBQAnqhS6SW0i2lStIkOWM2r67rP/Dz/d4jiFi9HvltgJOgs+LJZMesSjpfBuBloElRJScwcy7EtaiAFICaedcRmRJpMv/nsvn0ybjQ6qyAKdC4FTWFSeJa8N1cFXeRdyxjNnC+gM3/XICJdOCJjclnlHLK4iYbzeIJhOJqbQshekO2la1jNEBKCE+4Dx44pEMMNUkcoJ7Ww632dNh1sh6mEyKLsfTvNV7W+zCKJ34g+4ctnxHUxWI5otiyPnJdYj02HSmXKG0w2LY4iq7Pv6YuRi6YFpqWcLE1V7L1oMNpJ6sNJoUnzMYWcq3645Z80GVLnB91hvoz1VXWQYGhsuMjc0Y8jvnINgIj3CNJVC4p1mRmXnF4fnceBc5se8GNUBQXc6hWdwadG98He5i6FeaCOMBgEvi++ZMa6OmaqF6m1+I9bRmXl7tG0b7m2H0po20eWbEmuubMr/22TzvpQvnzp4+uR2uP28/td+K1imyPP33AtUbr81TIvXJfjZoasqx45M1aT7mZ07jayeugbsqT5QlJrSPXVNFLtfZXK8c61zzJDDQ4a9ZfmXwPbz5miab9J+IOYL56eYGR5O8GQapZFRJ+ksOiPECzYooaJ0DPag6ZEl/DJuB4W4MxIuXfv/tn5O7v/d/ZwcFK4qykjYMKL1K62YMPZezRXPrWKvsd0vVEWSLqQ3D3VcW2560LW7YKEjnEIuNyixiUw8KVQM6xmKHtB7tsr/Eh4/DrSriaD/Sy1Si0FUl9pLG2RthfyU4AK/g4sS6LIHe/Wor4e9DouJHPIaOHJ4XNEVOd0ZiJN7txoHWjwb+Yu9TkHhOZoku9ALQEVOKjaLwEz6fc3ci8vj59OP8Y76Q6Tbe+yn/HZKJSX9VT2FzzakueCXXcqfVZg96pgO3QldxLS4//TX8xqfj+88fb9fTWP9b/X6S0wPy+K2HvEpNL5wMQ5GUQueemtX4rRs4pCip9w4OHL0fvp71yfx5OY6HoSqSiCtHOXXjHYEUiSsviZK94ISq04DWkieHP3o4jfqgm5buKDTzEhvdkniO1qpbKHQ/TiACN/+XkDsvgrgcTcBiZ9qdOGV0G984K37rQJcLGdCSpgMuWBzVmsMC8cikXlVTWteS7zgxknR0zfl4uBvf2UNojYO9g3fCTDHGKQuauicKo31+dlG883ZoBoKMdaDtFQnkxcjGQbOFstjbofr5qjmppZfkgyXUCjQbp7FEzqXpKBtzC0vpon37RfKHbR4JLTCdL+1yz90MQHdo8lot6zsCrGG3ny0ll/v9n3/Dh9VUnCRm3TGDwCAXpUZhnLC0gkVSHIG2TSBxuYj6sepYIjweJHD7Dm0WF0sd06DxHgeP1v70wwQ26YajdKkue+MuIpWyyXyquAjkCV8d72imemdjpkMAPlrFGleCDRnC/bcRzZ8pupKw/PY6dPpSXKQYZu30l/18UbO3wo/fo1WFfdLUQYb7BBM0LEATfocSQ/GsQtiIl5sXnlVxCPlMS2kDXfIP3LXgW5vaNotMZRJiX8HaqmqL2luX/tBPszLnt/Lt6LZdxU45wXdR4p6IaOTXcnpQZvX3uL85dO3kbU6DtTZ9fSErT7dnbwSShvzspqmmpi4C0dIzvKeFqcmph1QhzH815kMifg2kh+g43ltqiKcgX1DYKz0DlxdtreZnX9gb/dHIkWeFhh0PPHMyM9lq0gH19OOIbzS6/rz4ozbrtZ9zXBmd/fDdWxya8+HoEch4nnC6SQ1cE+fZZaHSPJVrE2shBD1hpesBtqOSnazmJJjqA6irzcBcNdWfcHA0g4DYjXQKVWHYbIHWgWbuHLGAdn0cCnvdqKXeX6k1NHMNxIU8z47nHMp1H1uvAwYgQeYbTy2NBnKrTvlNxI8NemdY9n6mRbFJR8ppNhJiwf42KXj36vvRNJywV3e4uZyB5ciACc50sGQVK9t/Klg/ejcs+WVLKKcbF4lMRNabYoub1VymBnFHfWIKNbUJrCGOitg8FBmDdanLAzjGcQJOzkrw1nnyIsMmM6NHRNdAiC8LaBuVitJHhjru3dVUuNi1a7JEWbhSiA6aXIGpETTgWrbx6lEe28EEQ9Nn4pOPNH6+b2wt00IxUSz0cepFBjjCHnmD2/HMFflcyUbrwrJ3un3pLpRkf8/lXF5FFLmHCp6fcWMBoik9LiNfdhtT8chSx724D2LQxHOPqjLSip3ZhnnCIjIuKmTnErnJzYHO2RQQ+iqHegrTcQuksmQ9V7iklP3hEa7J3aFD8VOLPj0imoyumQ4mWpz9+QlBcEM1Eps+OsaNAwNMARyLp+KC46e92a4z2v3kcGEBcpM8i8v+yAFY56BjvqnTX24Ie0xx9qjQfcEVwHjJtLukdSuxdP/5hMEEx1wcbYNN9VB25DINaGrNq2WbfXZ82/ztjmuDsOvPzRn2IOVWiuPduShBqGgeYxpWa9S7sMXV4HKD2NIbY/lr/gAES71XLHBNmrdVG5wU304Gy/GQVp3FcKI+NYtV0s18/0jphzkptN6WWPjM9+NQzftdFWKCLSLN/hNKD5qtKaIuL+YmMeT4ekr4/R1P4gXXLktjzAt5yldLxx7PXU6n6YXrOd4Q2TGgYyv3L62XAWN5aplSbD7yFqsvMUNXd3DWj6yAZDFJGiOlX8tqIaL0HQMOtXs1zsmLshAwgNTQdV6g+GQdXXuqCXmVbZPb82Hq/KQMjT7HPF78R5yX2sTyvWgKjx9JbincgkTsO04VUW6VMqKYej+KL5245IQvsrs7mRG5oND//j7RNSqNZdSbMe6RhJYxb0ZYrpxxAZwfLc/WwPHc2H91PCF9EVfA/oQ+aNeZot4fT2Arji7Se8jiILk2bm69vle+HafjYMYTKG/N3ijT29ODF/OQ6p2BfYVX+EWm2iX1p+vFkYjgkwx0z3ylnugChJRlJQ+RUHcEiZ4obH+un/vx9hiDovyIzlilqTymaoS4TfYsFzbsGNnVFEPX3OCcTrY3+sYT3rtcyvLH0uSk2YRYwdf2LAqq64Gi2pb7+HDyxtlQ5oRsAo1LILhnab6FqEcm6okXJt3aTjfpbEHL3TCBV2vaRJ4js0VXxrJQJqFQxoQb70+GV85d0xViz8jkgL9mM3+dCcC8gpDPCUVm+asGSmpJKGznCeVwabFao3YPYyT5J1cRAaQ08eACFO+BCDcAik8x7tibH/KI2cZE9ETYA4EfJt6/dBRQaPwOPXiiJYV44p5rewoQ92zGxgW2AeUO99kBLBR6C6Lwz54Gc8azIr9INGfDHH1TepljypYbt1IaX/jUoxAXIkJZgt1HGIK3CD+2+2fbprmHi4AzEgXBaltdM0D4RCKiWQ/lPOHDa1KR8lslH/EMVhzwaIHTvbl2V3Zwd+ieJdLQCrmdVHkyKlxEoqu2rMPQwosMcQsfXrRn+1gllVqmsp6Yp+jVaAmvEItnqaKIi7j58/b7G6zORDx6PB0PfVPnUiShs1f+7fWzxw/v3b154+rlixdOn8IH917+7vbtc9rcJ0NwYRGN6hCNOGOvgwzy4MVcQDoqru8+Tu//+2F2+Pxp9/byqQxsiaHq/UnLzqgOZbkCJ+jUT2sTUn6dQLkH3O9pohK76gFNYfyhcrmecKwC2qJSK05mmur0UGvlC4oyPRQLi40frZddV03lv386tgFc2YmT7W3iYHdP9B1yK6qYLU9g+xJKA27WDC/AMhOcUW9m3n0DIYTXizbPG+MTID6u3usVlsP/PPMUWg4Dl5OXmEehH2u7YZWroeYO35n9d0IVkcTogim65O0Yg0J19DTNZwUwFkuUJXHzYxIKMkSQg/IHHrsYbMmxoA10EdRJNQS1olPqUXKvoPUbwAVTZsTMqt+313/FW2kX/iNWqem+xwBW4O8pQ2kWoNxVf8TqWHr6YTyRxpYI06dv/8iCBPQTtRXWdt0FyTWm8UvMCLjTo0JecWGGCCHJNYC+y3HCRLmbLAfRtRfi+33++g8CFpJX51MDDZ2OtjGEC2f7cVubNG+lzYFdngHxwFzp8/GkZnEYLxap7bSxlB2ebqzBywkgoAUagCEEV+5Lc1dVajlmyZ33ImlpmLVb47BJylsW4cJAT5vHruGPErpXyb5pC9jISad6h+Z0T/w3poN4DYEuDiTTwl4YzbEtjVTbAULZESD4PTtWh8V4Dxa+DRF3SKahvFVuM/g3da0HuJ1xkcah73HpyKKgy8Jo2hrjmSuqEbLjL3EtU0kv1CTkEabHyQlKs4i01MaG/yRRkMsiipnQu2U0yuLa19OcSLLGM5QXz8BNuvtOG0Iu+x1C43XA/9CoalCGJVa72a7XkhycPI7+CKNsrt2ddg9MTTIDF8bQDjXelDMNZ0JGi08skk7Jr9A0JkRyOiytXp8T5YFgpeGQApPucS0/EodeF5P7f0JAEQM6oPSCMiYIfD9aWEu5gbQ2sLgS1HDeYbHIJzfdbSXj9TwWTpsyLLpvbFIj6dCmR15vWoqQy8IdHHsNRdLqaXGV9Q3fbE0ljPlEDjaGb6kq2LRutu3zojdBKDiR4Byv39aNFkQ0fD5Ww2gxUJDQchzGRt2A/YE+4iP5wpzBcl0e0DCoi02VZaiRtzuFITMHJOrNBiK6zrDdT7yisoIFujSpUEDIE8Nl47S9KAB+P9JLBYH8/M1t5wzT18mWf7ccog8BfvaqSgvAL/Z0O2rMBxT2IQBmBCDg/20ps+mGm/j/VqBD+fT/Wf0FA3BVI9JbuQltyfR7fqurgUCN4H17DwFN89UbQWBqCm95x4UD/do7ToAKPYHAvY5mwObz6aQrDVCRplIk4e93tsJIfQefQP9OJXWXs5xFfMqt432XnVyZLCJQKRH6pPcV/vILSfxNHyJQJIRPjeO0efeb2oDUwzh/m9dZxOp8vl/KAMsRLvGW0xrbNOAbnQ68X4DqU7IMefHNGNDBwM9DJO8UuqxemRXmUkb3jZ020ZCmpLNPSWM8b9kWsD2c7DIMBA13GwqlfByQ8dssN0iqMDz0fK872YTb6RwPBJeKXibe+KwTtscuRcs6U0WryaFtjf/Zf4bS+SNhBNn6MyiFIGnAr1bYLooKJph7w6HQY6u3QtCjx5M8BE39ppMKgeeWVLJzDR+txPpdLxeysQcewbbvQx9DW+G3eYURXRoYvhSBOE/DenGNnzIWhBOsbMPgpsAIUP9eGP72wrVZyjDTNGw2CC4ZUOOj0gmXmDhU+yEre8rOlV2s0lYra2628UmS6uyggvu+xpfruFJ3V7vXTlwrls4VSlQjcZ6n+/V9xCrEedfM/J/OxSVAlTlS7yU6DgTFLboz652BejjSW7ajgbNsfajv201KjxDoHz3WdSPJF2kUUVMcqZP7vVJ6iXe4zruzx1xh05qE0F/uxitJaeKcqYaoWkSMHZcg9QD33kagDxM4ldb1dfIlKdXtwe91vDNhLPWMyghd2iqQZaOzAsjO5NtTFJ6wYmLZ5Xk6h+iSw1kUCYr5n5VCUg2fBSjihFID3GW2pYGrYsXXZtDobBs3pMdSh85tTyCpr5lMY9fasSI8a3J7bvTTXnm7iA/UYyodU0mIjh0zwtAc2BWmiZap4M2KWp2zMZBlmAdnYKOJXBEyZlXujTHrY4f6iLc8WT4vX4KvbhGTUiKKySd1au5Uf2GpDBpsyZ+MJeOs0PGNb2M8HwAyi5x+B6EG4oT2pz7qoVYaSaNpnG2rt04JLo2gpuROQMz1gc8gXGHJMsglGlZ7QNyWHewc51ov2zgzzgq1zpa+qDGlmafP4622sWLLbwBtrmvusOmGpC2741PDjX7nuTG6BGAdVXfFIlHmeFC79THcqcWT9GsuqcaGrBEeCQ5b6dzhiSUBZCoFkEC8Fwki5s4eE35lT1VFPLLNC6pL/A4Gi3eUxMyB5m8fRiBxlel4EMuMxWoclDielU/5El7erIrFv5eMO8EMVlxFT1NtwPEykFRXCEwN60itRWRm1wDkvQ5vXbRosZ1EYps77LcX6UwCuYHHba4kvV0nR2BzHYtPuewamylnpEqJ9UG0fkyEtZ6dxkvY2bhKEomnyCKu1mGjUhQXA3qx+ADS16JoZx915jtpjTf5Z5jLMDUbqRIQyoil6jCUEp7WxDPd3HGZjgc7lBhvMeKNjlcqk1oqaxUm1DPJK9TfHCtKLnWu8k5thpRmGuj8Kr6It3s8LSvaheNF2NYxmJfVkb4rwKnhnhkLDnpXujd2itJud4KUJ1kDbfgWz9m4y0nvFghKnHNgQg5loMEGUMVxXd+9SoKPXLlsP2kfDEF/gXwa3bAIj27mAY23fT8wEABO2VY3fX/0kNp1ugtOO3Zf9pXC0a3K8iF6ONZQOCl6PR+EyGh9SIiOh1SUqxczesgKeB1yjHEO5RYmPFTom41QKaY8LhYQqmKXHYoSuyrU4PvGIC2hb4+CALt7LUTgJwBxeFBHAuNYwTqukANpIoYyMEyOkDvBoQKSJ8Y34yFqereKmt01Xsk6FrfX1rgv1guERWJnwnd27s/11gz7zrZS6Hq1PsgcO5Sa3qUjX6+upFI/LtFLZn+u9sIzVfX7Dnd7UZk2WX1dehJTT6R50+mhXrqVyf968DeXL9fXb5tlZ/wGRfS9oBsgKVWExYWnLEhXKkjHsk0qEgC5d7KeB72XN/8X22dP0Mf7k0ilNrglXlJomCIv25XEV9Pz1g0H8pzLmYb7/+/dtigSBivqXAiaermV/UQ9yCehdcsJRFH5hNp2aQ/hqTS/Ovxsf9mXT1fJK3UBZ7CFa3m2Vi9ayTwXtMeblg7JZsjALi30STn1btTpeis8Lma7PnXq4vEwPQ9SAvxG3QetFERKsDep9FehuupmlUMDVpZbi8tY6asvL64lh1r3WyEvzfThkANCi+p7OZXLjZSBlNWKxfFDh+5YduAOBLJs9zabSwkZKAddDsQuadY6lGWswCUNK1JBQBbkS0y7DIajUqdSw65vD52S+HdtTSCp8mApdH5GbHTuCJzf1Anwl60yyJ3k60CQIoMscihDOXyZPcijEgVUQf8chH0/C3PvjysG2G+hcE4fNMLryEWeiECjwCMugwLjqygGHkSQQfFNlKLMt0FHJUAwweLmURfV4KLmbLsIzaIRTbzRUjH+cjVEmx/jbOikm176dDKISDfDjOhlnEmm3olhoOT7M1BMNESTfs4yq6w7GtnJOF5kGy9+goSJEidJqshDDQytimeca/IAJrn54J3rkCo107zSpkuP5GV+XhkaSFJApsxZsmZTv1+7O4gZ86Ly5M3HgqXlYnUBe41KQVbR+UpbIc/bP8yOOuuqu55666u/SAMNNtRwIzb49jOavzCLsjhLslSjGUJX+R2wF+er9MTHcZUZCZdH618IdIkqOXD0xwHcoYUc4dSLQfRYluTOYGArPSl5TsXRjnXacrGN9U2RIT3ZrSPHPwoxnTYGrlAkh8xrnye3vA7NckdHnqTHjFJr6Oys86zHjPEGlZd6T3ANLduEpZG3NXl8e2B5ywi4oHveu5e9Mou/Vt5861V0l9YfKmVUayLtzX5PT+6sEfZeD+oh0GjuLPds1EuwldKnsW8Z9JksesCaM/cIaf5OhW8tLo8EJyP32y9HSshIOUUrlCq1RqvTGxyMgEykSqIHDs3zQIK7/SdEwVkCZRGxLNloSg6gUNCrQLiSkYm0qOAm7RycPt/eN52ek6qTZ66PX5OA5unJViV9uV0YjGw00a1HL2JRKCSf+bAR3Xr0ShL/dTrBy8cvACMoJsgAOJMgKVpIWERUNRhIlQz2DVaOHEvf/mRIy8jKySsAaAwWhycQSWQKFaTRGUwWm8PlQYqwkrIKCluFJc7s6gmENmwz8aD5bE5/eKXUU0siLFm2YtX+CAbKq7V1qDQ6g8kiZFsu6WdFZBK4KP9kK1W6emr9zt5fGVbtGYxNTM3MLSytrG1s7ewdHGFF1XTD9MLLyidec7P/idei1lrnvuctc0Dxcy57IfEMQhpLn/1LY5Wy4DRum3gJ7JyY7PaOzq7u0EZypfRBRjnrcvKc5x11XpbhlksNVzPXfy61K4kzbdIaq7fGWqu2dieH7z32//eNWxR7v2fvvv0jJsxK8pP2oHCDooIZW21xmMtBHJvt2jY7bHfINkhLeEt7ADz3hgwbMWrMuAlePn4B9CEw8KYHGQAnhQVP/7NDwl2421CZNMVAfLmUtIysnLyCIvMyPe3PZCrEyRNOOmXH09PTm0hJy7gvp87fI68AoDFYHJ7Qe5+4YJ3PQR6DRaOzuUUSmUIFaX/X80JzWtNuMh4cxdilsa0CWKBSbpzNrZMqB9AgQIICdhwtWj+PZmKy5e3973ocDDsPS4N/KK2mBh2elBm6KV7DnS4jjPdrglniZHpSv7CHhoY22bh1rwrBVynuV7q9c5ueoJo1nkZ9JlTLrSFiyKV/DHGNKiwiwNTgawP64NZwsOoHeNgQVeJ+aYFrNXhHB0cvtOgw+FrgAgR5M/xaHO5PkaYxRNtK2jFrgnhV07T2dA3LZc84LyWdY0hA4Lz6oK032rM6yeMco7QMCmjG6BrsjpmM33JIXkUhqcrujL9iZ8lQ7eWoaFoh7huuOIyYG/blGNfWlOSd9S4q5j8siZhoHFz8QLhOWK0ZUpxs0rOuGjw2xsRX0h6GDLWJ9zKFDmmVYqdsaq3y837JPfrYnSSJdzInda0POW8vlz52cqhC3Culz7LuDj41aF4RvR66MX/1edf2vSmPyScsPZ3l5Sdb27yRqNs7pTLoVra8TRP+PSgbTPZAjq/Y46OOPRaA/c4DZoaTujVZKYU5camive5ADFgISFkO0oR+9+oGdRTvTx97Eh/p1pr44NShT7kMsavdflUVHvm+1ehmR1cX9tRh2Ni91VaovMdknzPau6+SZ6AtirI88HZw36VCOrvYWlFBR8ku599PFkvL//YfNJOZmDI+v7nZxvl071bLb9vdU/Mrjr5w+rls/Xm6/gt3H3rk7VcHJg1MRCAYngGPjoiMClzgBQAhC5jnIzFeYCICwRv5tUBeqF2hwukHKJGkLTfSWpKncq0O6ru+6u0fv98vHupCXiiUU+9Abc9/TzaCeLW3xNySFj1vyYhZ6aUAIoPhEdHXzbZFBaNj9uHOYr0XP7cU7PAa1+LIIRHq1ZTg18XrCRmIit43x4lEcsknn8PcZZ/tpsenBnEup4N5oFmt032Y5Q3UfVJDgYut3X7dHqmiQPhiwxl+HN9wMKhsxHuii+jUxz3IZYC+gIwmZVSo1l+gDgEZbtcg+YqdlF+gCB5iiIKCgoKCJgoKCgoaKBiioGCAIU4x6RltdN23WcOEst7U1MMQksJtSmgTrNOHzWxoB/8/sEnxXCyk4v+DmHy9bMj7pIp3KvttqBzU5NSL7SCZd8eLoZQx2k7PXo5aj6NJeA+NHG08bxxGJ2trJ81ayhQub4YEDm6vxMYYDsFBbtNN8cPVH/uKs6QX/5RvPID2c4aKCzLQEMAGeE0ZRiyA94CqAa5hQdci0bTCw0MHzIwIBRnoRxarRYZAYerkR/LeaKh+RG/xEuIjTAcAAC3g5UfTCYMtWkyxhoZtqGgoWihWICBUoI1ruseBBK8eI/dXQ5VfwVz3bkhGBRnDKbx0yteNBAUZaAhiI4uMxDBiBbwHVA1wDQu6FommFR4eOmBmZCjIQD+yWJMPAQQKUy9+JO+NhupH9BYvIT7CdAgE0iJefjSd8H++DFmtSkUFahANJZZJyCCxomqzxB4E8jLOUSb8q0GQ6cBglWR4Ha1jGV+TxhD9Wy7tUyqRdOQ+BhpFPGf82kxhcAQKKhp6ZrziUawCMhAEhkBhqa/uziCJMBtLa+i2aXHc/etjR9HvNOZEU+8miNM63703ghwXVJ33Iqg73wNC2vINHaRtwajCrnz6pK4J3BtVR9A0iDhq6ke8ociRUMTAkXvnyGFRxOAi+nSvCdwbAYEARQyyISAg4I0ARQIEDmjD8urPQjG4S1Y2yaSpO6pF9mkxrFygaVSubJmmHxxiZCAIDIHC4CaabajohxoAlKpgJcYAhcGFVgtrEd37mnj++X/q0vgvkPuJyNP6JQ/pFy1PqdQ5DEB37qGh3m6dIs/DxjTld5jGPezM+qEgdPOhD4KIvMMNO6FDL50dnd48qoNFEgVu328lDZG/u+YuKjuFvPNuNoFOL/GwWfT/O3QoNNE09hlnOrH7cts9aiT03z0x+uZ7OUnkcxOhbTqmdyExZLAfoHQ6ENByrbNkiM4uKfkBIjq9og8pZ9aVhC02+2FOzT/99sKmM0qi1sVJwGP9GRk0jzdPUXSB2/v09mgPqvbloCzsDtafFUgpVuFmP9J9W6STaEqD7VjOlu5eY3PnFi4KItVr9wrbaXWsHCOjm6guJaFmhX7SjU9C5ntMMb9rwedJU6WV94atk6wMean2FZmabEyQFAWM0v1h1H5pLRZhc4/tYCO2hCm2AjLoHt7/Nx/1EYfeXEcpI9r2LGSSyUWaznDqwP6ejIy37gXZszERRNoDRoNw7jDwyMDP49Jm5/8iRaCndWOjE4ZL1lRN+JKngFICtVg7FPJ6LF4DevXuf/dd3S/Y6oJ476N41NS/rKU/gi7WTdzUWtftFT00aFpW18l7KFfxrrZJcFfgdyNiRn+2brktbw7krow+1AOEv7YISs0zbkmgsOibBhVi2Na8T4bkiFErkiZjMkbQ3dbNBjE86GOaaxMC8mfHuqOIOT30ccauSIBBm5vFuNP2uR72ueTlf5Er1BZHo9J8e9ckpaZDp1iLgzf1U+ZJQFMZst8JX13ZeAjB8585iZ/m5hXueAhkF/4B4AJnYB3kgZd5SKCM/RjdwF/wS4Y/voCHzlpunaWyvry4cOE/gsi97E7yTaJNhqUkoi1AxjcOV/xZKLjomxxg7lPGgxnT3ZNkYMS1/6QcFNbBRa8VcqqsDzstZ4MTZ3CALhVeX3OG4KajJpuwkEtG9PzkdqZ9xRR8TVL1b2GjNijzog==) format('woff2');font-weight:500 550}@font-face{font-family:'Geist';src:url(data:font/woff2;base64,d09GMgABAAAAALVUABIAAAAB84AAALToAAHmZgAAAAAAAAAAAAAAAAAAAAAAAAAAGoJiG4GmMhypKgZgAJEACIEkCZwMEQgKhN0EhJ5GATYCJAOePAuPIAAEID9tZXRhLwWMJgfIawyBVltny5ED/Tvu7qmPrRVg52jbEkkUV/8buYCO214BOm9WpeoIxvqAxe72ibhbpWhUM5nZ//////+iZBJjehfwks8jAFitqqjtam23QZa7RxE8CxwheFWJzreJjPR+8NQ4Ucwq227ZoWAohu9igZR4i/3hPQNTbSyZUmt1ezwdhTzXy4wxcFURTet75orbCftMKoGxlBrZYag1cTfcutND2GM6cdDwVq5+3F0oUXbOd9T7WOjjjrkvgtNBEfbnmFV/OmRflg4dKwy/HOuBQzd88VJoJCU/sat8mhRN1tzc0/cetWIXvJctyJIEsdDLSfLiQSGuH8XYf88PvveOXAP5st9tN7cbcp43yOnH/mz66hOCKDbnhc7o9PZFF5S5fbVRF/55TkfMQpftqbV1xiynX/jVO9IPicUSPZEI40RzSwfMPZd1oODZvLSQtrdYMyGK5qW5Gr94sTtraTJZU9sv/svCXdbDvZfhkig4Psm9tcMD/wzhBvHil3Qup0I3+kVGGGo02E9zgYvGssa10rnxWaZkf7RYaWj2X2q6tvYUEMetC1AiRolOmcsWEcf1tC9Pz78X8b+q9umkZy5IPfsLAPLz/Nz+3Hvf28aqGBvggMlGDRgjREUYiAU4ETGSSCmREBQ+FtofC6uwAjuwsbFRsLBRaAP//0vnf3vvc869t0oEC7ANSEV6MaOF/L/D/52M1QY6sdRJkkOXq6PtDkOWOojZ+A09mvQAP7dvZIqjR41WpFoYmE22c/ZsNmqMGjXCKJwoy4b2gQXm6MlXDkfPRLiJA/w2+5qI0+lmMHU2iglISguPqkeGRCqCYkwMxNzUtctwXRc1t124i9517aL/P4hirO19QkwP0ek0NQ2FTCYR8g/NK9MhmSWzo8IWtOrZ128QhoSgDEGod4dFYCDBWiTBYEDbtYf9+W6qGSF9WLNaGwiwzeGSuGhIj15SJKUzv35tjS3lh/KHUK4VbMNDWsDjlUBk+iVMt2G2qFO4jb+4gYKpdB0wJzyUifvN6zbH/uU+4CEI8y9NWBZ3M5JYMdPBJg+1yj/k7ZNMdDoc8igQjsJE6t58c/pKTslPwnwh//uSUAGBYuo6pAIGaBdYer1AgS7ZFsAeABDI/L9O+094HMEGhEQUSUiQDU4Tou8PMVRpN5fbdi955pytt6z2f+dS+RkzXUiJ/wGHyq8p5YD1rNpfbr2QOMzVca/Mqkz/lR9Tv/MV7i3sAufGftF0fSbw+DaN9GVLsjAwkEzvbL/cw1sI1dR7iUXUS3ZKJ5BtymYEO4cpxY9s6r+Z3dlDEJ0ALccywRnPVhi7fCjqNIXd/arKL7pYNaaRcbF8s7sPAQCFnlunWPmyQula22LB7mEXCCRgYRbaUi4qhxUYZVMZLkAG1FPCNu8GJf/5i/qLWl01khkEdg6YAgwlLgm0w/YhvWpS710HqwOLyi90f135dLDEYOVhkgfMbBqz5Aq8llvSmbpV+gLZDjpPyHdWGIe9y0SwlqeuzJcGmrqONQHlijQzys1+3u811WaAXYf5gEPsz73rK5qr3N0DMMuFZIoiRTqEwG2XrUPMl0OVJAvZhk6h48sfqn6DiQDpWSIWKa3/9cblunhqDn0BCASwmTKVkgJPRLpz5YB+mfoFAjtweztPSEW7n8MC0gRWMDcFBiDiq61JN/NQ92Es4qO/6c6FEsRScP//l9Xsv3Wr6K7fM+f0myZUg2pHSEW0G6ID56qrJ/15U5ztqk1/iryxyTNNmh2i20W4dDwSIXeGkBx5WEXIOguFRFiD4iCsR0j+/zLn/0/P6eqSShLYksFG2DfxIrxo7h1MWgIcJ++9H0Kcxep9zu5TVaeq1V3VLbpbwbglbEmAjVoipOuuJFotwRcyfkvmJ9/MzWD7BV//gAU4gCO2f4hxmEIa5lmWZx7eN3uz8c9hNv88n576H57Yhodza1JqRjQaF3uvqu8K8HAulDuZ3paNlBb+DS/eFgvA5WyT+KWXKaVCSgGlFD17+aWPmdo0ZJ/SIEgCCk55/t/JtOTfg1hjyKYQyqYz9IGK2uL/v86y/Vr0zG6YOp9UVDQEZU664koex08ySbZn5suhP8SSl0KA3ZQBrr4Gf1gO7rJC7LNlUu1JB1htl/Dpw31LXNeBeH+XL7ztBaKgu2hjetZIUQlms78RlCBlGUE6WXz/Mr+0mTAo0X+h1lkLGALCoBwSKG2x+O8oqHCehO+g9lwlQmEM8LUVvfuqQC8jfJFBlomRjjRDjjnHd77fv98lQfI1cIZhMBtjUmOEEEYY15jUDel7+vjqvb4TfTunY6WQjnSFkvMFY4wRxhgh3gnxMWl3DFEny7Cu4pJlP6vfQAKWcRRZBx1BQIjevdJ/Sx1k0/4bCu3ETjtjFEiQQogQJQmyvW862Fx10aBT9NxfaSIklJGqlBBSIYEwg7ohQ2guG3owSPvgn/6/w500b6x0SAmClFirvevjr9a/JoHxgR8EuSzMBuIN8XUAUukNpE497G2qgMJAy6CsyAyUj5mD8y2LUH7kG5SmsgCVjfmAKqwFVOtaQ7WrP1S/7oQ6sAqoQ6uDOrImqGPrgZraENRJHYZaUjQ0gcOCJnjY0PQbPjSDRgzN3MFCs3SECCEGNR0PfgL1hzDUqe9rZJnNHISC2i+EpslMjSKiOMwYEeCy4Lrf1W1hWBHLmIGdGx2KYYu0jKyc0XC0paV3YtijFd8xMvn5b/9AWbEYBFwbmx/yihdlZ0DYD04CL3+M/owhCvXAB4dFQf+vBdlpEPYtO2EihH2PycmAN/hKlfERIFSEaOMkypCn2BoVQCGA4uJ5A/wqsIB4x1FD9DVq7DSjo/bwz2Qgou5hAeZjCdnxj3FljTEIdQXCW3XCwEUYuUreEYsFtrZCD3/CvL3cirKUy1JvgVJKWcapcpYglkukQsKRGrlU60RSpxTP/sQ0IFiNIHAyoxQhOdbeL9E+vt0Zn3XH1YFqP6o2dqfscKYdNRB2xw/coXZr2etOQuUjhfwnSj61z3FVd7yU5/wqbt/S1RInmCr4W5bT1J/ihsizWWsJ4LfsFl+aFXsFf9arEwIAZxKoCwpVmCI1QuMUr1QtVxbCoJt/uDT2ko+d2n7F2twkW8plpOa263dKeZdB+jvWrIwtd7wLSUJOr/MEiMLw5vSfttwEErfAGf7UASNOPvw1o/MNtX5Om5LiUp7nDOd3gu/2Yihwt1+/bseSNcAj7eVkv/woYFqiOfuIzVl+EFVOhTtbOpHSQIksp36ALVqaFVqJTzTtKUnd9YF4IqMaJ8KVFFvUhidGYrMD+nNt+3pY2x2sjze9VOF9bPdHNIVoEJN5oe7Fx8kpJqNXdYGUq3CxOh1Iasv7JKLYpNCzXnjPYT8bdnoZ3/EQ5pqKGvFnHh4W4SHEpcgIEuDWx8UTRiLyNQxjTgYoh1pfM4EGfMHjnF+y9luj5vIaVgQzWvM6ao55tGXsqlQGBWaoW3qUKvQqtgeeGmWyhIoBHFAe5Rjo87Ny9VREWXEqifQFHQtWRdMd0dR1VwrnY8Tx3j7dxZtnMJy5Jo/sLKuLKt3N+QXIPheSZwrDThZVU9oOgE7W8fhEiWPf/HOT3ToLYJC2h0sPTF3S46fj6zjMnUcbXpjKcu60bIdhXa3PNwA1qjAGELrNFYZFrC0+Ymxg0EIhTGhBknaFggMAHoHHAbpcoQ5CG6ofkklURgqsjoMC/Zy+YaEYTrOwUoxtRGbZPjlBtVs/B18HeUKCYMBnw+vdYeKFm41CBphmMoO6tMCQlnlUXsWTmz98qEMSoNntctUdPfJU1geLjfegoCGHXeHENpcqV8n60xMSrz3DufkuObvCAOq6RJrIq3Dijq2gVfiEjfrqFkMXIViWDsoV3nmAJde1pFFamJmYA61E8CA9P2ftjmUeAKMx1iIH3030DaHiYIGAiJPYiA3+5rnIpGoppG0nGoZpjpNOx1QjBPTKnND5ixa5xLOoduxBKHK4u1gLRVAmeWoLJRcqrTMZW9hnchAWlZjslJWpOAxcy0QVUc9A9rE0zdMDqOkOaUBGkdKzgBIJC99NG8IiCtdq1bzHiNj5ODoJVGQNqUDLQmBFlsI4FCPEXlG5jm+HWFkhaOEBVQga7Ri5LPWh8ziLcrLDwCmRrjRTbGw0C6Gk1OfHftrVBhrZGs14NxYWwHbnAl0U6DHb3bZsFxbetRPR3emqa6dtJWV4XS4DmMf4oNAChM+4U1TO2i9iilqJ+UjYd48036SDoVwtr2m5JvfB6AF15c0VLZTlQKFl+vUILAxLOLuDPVP662DfrGXOQiOFxs6dOdoSmgUfcahg1hlaoUS7zW2zLYIYJUNP1ClfRLxDtLBSTS3F5kmZX+Z56whaNnte0pJcTy/hQKwE9SezUa/XvaJ6gDZfxwqaH08Pp30ZyYm6O0dCHj3ea/16Fbu68V1v9Y/VgyN4RQHO9EEzONpwSlrzScxG/EmgYgBinkkfsIbNO/KUQy6aFXKzzMAHE5+zfFP54++kd2MLzfgylu46lQ/KYl9MyiyCVJFoOqURQ9O2gcOcxeHT4ztqhvNHPIoD6lBFQHZKm4e7tEIsegxHXtgHiwXZP3IWwsNgEYtFBWsYK0OOuGkP24aZMBSKZ6KRRgnsLiRBbJGKAXJJu2FL+oLCQ9EVQj9CryJevyKbm/PwFHZaABjMh0/+fZL2nnDrL2bOI0Ad54wPAcd3Ai2UYHZMhFLFB1uZOx0Aaura3LZ1rS0pebzwCP7EnsKlvvLdyrF8fkMHOs0OLO3xxiGcHU77rNePuHyiNiSjH37JX+845bCux/nwaFWsBuGEm3knMP/Wn75DExYdQSvXhfcSZcuc4xbvTzTzBzQrePq8vPFH3ho41lZh9qDuMnmZ80coeupvF69MkeKuJb7ll03fYX2aJ4ad0b5df0GDA6wl1hSZ0THJGCYDHx9ezqareN5/j6IrDPZLZraD4I+d0d4G6vXbijqKj4MVNcXvad5lxIAEd299vY6fHMX61pq+BYgq4zcbWbBeYcV+/mgdqX5sO9289tfP35kpvLNClRXk4vf67jJWjAnHgla+NMUu10ly8H/8+tTPB8T3xi/XLBA02yEQ+WUEBH/IU0tu/HxN1ozH+lk1D50XyiT54EfKvmQ9mfjVwU8HbvxcqBs/swAKMKSTNE+n6Yzlpd6uJYrRSq3TZhDqox4p+OCna8cQP+G3DAf1QVHYB0AlPBu7Bz79mYxY3PiBOpANZo3WMayu8MJf5MX5G33ZXP6VoIk9NNRL1FvbMe46dLS62g5ZswA/Ie04KpM1Jrjx9UVvSm9N70jvTu9bfjD4/Ol6Vo7Sx0mdZHj5MZCVVuVnEKdzW1FBO9vTpdElfKIeu4mkBDf6begf0j+n/+z8bZD/CXCji/6/uaAX6WXplZ3rc/aajgXCnf8bjaUoI4DnykWbbx2VSpX0HnrKPcqIAu8EJpRfomPUO7mJi2o+DdJ6Mr3SeyNjspeCMUxZJuZAwSprp3Coepg6ccWmTV21ornrVrxAA/5btFElu9Q+0w92sGbArKk5APcRhHJFOJlX5JptHntoR4/p/O7q4m3cNXZx4O6QBvh2OkRwKKJ6w0Yu+fCYQZTAuOVXxvs8PGE1VGLcMtbHzSXGS+K6mcQUpPbUEEt/Q8Z5v0k4Xe/+Po2Ou6Cfa24Y4pZqUe55YIQaT432ymvjvNUpJgiyVFB1PC0oLkarQiRudU3psLe+9HvU87zytMG897KRjKnvU2a8bzGLvvUrbb7PqEZ+TlFzv+ZSd83zqL+WBTTCn42qUVe760gSflN7koILOpRU//DOP0Ckt+7/9DCotQGVwVUpM/XRYTN1Z82/vCsIFzWWcoyaPhgbtZeL+aijwhpHUWkt8u9jxLjq67tWE7vUv0YN7I7d7elpZPdVUVSPrMT1WHXFf55o2xKXMtVRTlnBh4m2Wlu9rcHWmH/QmIwN565R99nufxSfNgIQm/iBxbxrQ7qrAs7jz2lqpYMaHNhw3XXRDces3WbGDO7zcwhwMLzzra96YHwIwXy2MeDhgesYgM+3m66urzfSt6A5zkk5NPLdJsQCk5XHws6jMLbHMEYUxy0fjQbzqdnk5uhSWGbjK8UczDXz4jKgMrZ5sXkrfZo2x9zMK+osA5mglFLqK/01zGnShCO9f4gDwuaNe4IXLX9ZwUlT2wd1HQb6Kc3loeVUo6xU0o1Znfu7o6iN4qy/l13+4fi6FIRvXo+qn4T3qQ7uXVhzu72CFk4g17BEKnvcVzWuS3WT0jVNraeI5qWbCm9HkT37buieb0+be6nDxRX90ZD5JI0MtpIp/WCkme8luK06t/3l7BqhVY/rI9vbTHy9umGbv787srXjJi6PqHTGNPtJb2Ww224oqN8VwDebVOlljrmZ1+LFNt584tuqDtJaglzpbJv/IDb7epWaY6559/pbaoONNtlsi2ee50Wj3nWFJciyv5biBSGEEELIK6fkSznOSbWJ0pJ+nBzYuXxeJ9X+EAemMdriJP3rDkmiYEWjO0daOk6cuXDlRs+dB08GXox8DJSn0CyzlZpjrnmWWma5FcqtdMttd1R7mgpSxC/BSYot9rQlmNEUpijFKQkm2JSlPBWpTFVwqU53xjORyXzNUpYjz680pSWtaUtHGeu5rRv+QkJqU58GNbghDe2BglU02M6GW7z+m4jhUj86Qde+/2lm1BPDYWvw2563pVtKod/aLzx5D+jb7Yx1fNuRB33f7ki7flswbwv+EPgAOwI/bhtkxv1CrOvUJu6LLaC1JiusXa+5OeB/Dec/bLEQJbFBegImVJRAKytMX6dyA0MjE1MzcwtLK2tSObh4+ASERMQkpGTkQApKKmoaWjp6BkYWDk4ubh5eNpKQUVDR0DEwsbBxcPHwCQiJiLXrMEDbN9x0y213PFbjibfeeZ8PxVeAPgKZDBIh0jjjTZAqV2GmziHCAGGKJgyLzeHy+AKhSCyRyuQKpZaOrp5K38DQyGNPPB0AAAAAAAAAAABIlQmyghXmo2cR6JdIgmG6cZan8rnrz1X4XKcasSi9IuLGUP7Y+4OXESnjFmJisz9rIogyyly1vWbkGVUHJxSJ0+b2F6ZHJiZUbUJBGt2Unf1XsJpC8VO822oW75pLSeBdfmD6HQVbc4uUB0eOLyyjkTs3tZTRz072d6F8xA+jss6pHmmcYq1XLgC0cRXeMYKU6afLHHIdaS2U+iyKv0Tig+DvaXvXe9muZn06D0J8HPU9iHIhdcRP+bxQfQw2J0ObJmuUSkdTXW1XlSciiEqRH5ju662app8ygIajW/78Su7WbPS6Me5uzmWBdz0za/E7VId6UTQtOD34ohwzuud6ASIKCE5KXK9CsIDgREdedDUw5Mujc8J7sBetbMyu6x/kXqMEidLlPmPVTcX2OOBAb7xh0MEk4x8cc6oPzbhwvsZ1yl+F0RWavmytbOeZIhMq/0UVrGJTMlTJo3Sx7Fm/0wdTl7KMc5s+moF7KbSwijNqjlj1eyi1rDGMt4Zsb4dJgocs7FiZGdYDuPD+p8rid6sHQr2YzKWroz75okvORPnKS/2s88FLT/cZ459TT/fu7SNHOGJi0bHzuCcuyJ6HOaCzBu8D0m3Vja0iy703uP9mbuHg/Pp6dO0O8xqj1e2S4totoC/qP2sn2qdaXzKn/PuRbp42c+4M950KucI6Jfa+L9yPdrFqnF5hVPg/72i17qZz/roTVYsughDrhFC/xjtn8tte7Rh8Bf5Yvb13I77Dkjo45Ug7RRKxWeYcK0qqeTZGyReJu4zXyFKXlVhI7Ny0zSgQLD6/pwu6Kivah1ul2B2e7t+tPTg4reETkP2DD+M6atKDwpg8CszruAtAp+yDAXqwOl4717cX6eAbQp85RY2E06Mn3KQsdMPnTXdQmt+1+snuZPM7tiQit2bVZ4cRmOg7soSdC9eZTACnyoNwUd89dCM17jK2UvgowXWBkGelIerW5Wbl4aPWOlUzS+i2h3/vRP+g5X5CvXI//lrAd+YIdXp8FBNo7bsSuQBcIeU5vix3mdvk00gtxSNTNKO8o0rSV6SFsWx8J1TYtUtIV+IVC7QUCginnHMw5MVN6qsMnDlq8uaFJjfc0KuygmvSG/zjaDEGas8qw5UhymGNKTFdxitNMzlVRpjzAlxXpXXZewguKHYIXXa6FKc5IBCfFrekmJYW27KWt6KVrWpLZZ3tXOe7UHmb2tq2drSzfwbIibCJcizHemzGduwHOo7jPX6zZyQjHdnIBxzFKEc16tGMdnSjH8MYxzQxmH2LO6SzYbQUeUuRFYug8+B3PpJWIG4lvC6CdEtIIV9B++B+FaiNMNsEp61IuwLVDlA7wf0DGgD70EA42oGojUFjAxbTDYtRQ4996MaGNQZgjzfcGZRT2YfhfnVU3dKZcippRQnFJFRQtGOy+W9OUP1RYbZFFvnkbkewr39JUO2qILfI81Wlo0M4YDlvTYXd6GHO2FJhtxtx5u04gNH0vAMVRuu0II9Cqgrub23iwGa/KRU4kBpKSgpKydZkZj7ylOV7fudr/mpzrenCbqhtsIADVhxx54SrsrlYLb7d13fbP0xffPvPdy9X971Fq4Z5MxxWQVwhYSpdemn1G2Ey+lnpNG6Oq5+x0NJXmX2zorEe93fa/et2bEmn+KWMp6PTBMSj25KVwm6cRckq5gizOpUqm7aqYrgpk42x5PEgntQKjB+P3w1R6oZQs4c4KE1oGCHeQvhkj/gKkD7C149gZmWIaFzDEWTEyMlI40lPkIfIN0UKFEihIik2081C0TEZUgEvq1nW24Jnq85VrMIefHsdYKnSMchxF3BcVIU44xluoiQaj9xFCTWKYFJyzWqWZ17geWm17MZzvEGIOmGoV5Y5SiH1f/3InyzhKGJGEvPYwrGLJxTP+JLFLwFQ/BJKnrBEoRMSI5zRMaEzJmYoY2OBMy5t6MTGCyc5Pigp6SAMInHMTA+GReaklDTYVLNIWeop0pAG8jSmEZ2VIaKyJx1wzqcXypX0o3I9r+FU5wOUxxmG8zRjmHmRSRapjZQin/IZlbeZgfMxsySZyxxh5rPALotZxMj3fIPyK024aU4zRlrSBqU97cRZTQfnrOU3lL/5BxVwAI1tY2YUijUgLCgMG5yx2Ma9BTsoXHZxoLEHBJxAlrhBU6Oiq2j3oNM36mXOVEMYjJ0ZToxGUwc8V0xmJtPCgZzDYmm2XDlotrDaKXb2isMHOHmhOn1Jnb1nrgN2W5F7vYqtG8Tzlr73OsSrLva6T7wdYO+GYp+OOT5OsE9TuS9nxJfA8vWS+HFD6E9napHA3INElozFnnI5Mj5nFzK4QsidSfg6yuXvXJ5AKhcsFdo7d0oo1MKlVqRz53QVetGw0pNa681s9Zd21lbtxVJHQ+FsuAsoI7mb0ZKn8R4rMRHDmMyVmspgTZelFstaxqPlLadqRSv4tLKV3FvVKl5taQtVZZ0l6lznKbvQBaIudpFtl7tM0x9t4trfbaXrStu49U/b2Xe1HURdaydlFf1D1L/9y7b/sMHHo0wwOIwKIWA/qoQCh1EjNBhGh3DAeyzGkmisxorjWI817UAGwnFsxoZ2bMdWt7EbO+qxH3vdxmEcqAc6jrqPy7iQjPd4cxm/8aOfPSPWY/aOCXumTowO9hRiiUFBgcmKFT6lbkTU1Ag7duzYs0c4cGBHw4gJpJFuYI9MsGCnLYQYABs4zjRIOCwTFusNJRBlGIVoxvWGG0GBExi5Lg9hyr/L3hSfW0rJh/jPLmFhqZXkVlnHQikFFMIqkygcGscOO0Zqldwt2RSRSXYDj56w8JTT5VxpRS7YmcA92YEOVgI4pAKb2A2o54CKhhiyk0Ho+LOGTUISiharFFSiJ0uSmwBlTqp/dnBRSUQWZWRRZeg5pUCui/mLfQ2b9KQXtip07hBNHxFZW6oMypToFlkC51OF5kplQ3tyGT+NVMRitxSTSQH5wL2/BOmKcJ8EcKkK7NFSRPGWvMOCcknAunoJ4AoSwBUm+BX1I29ck2depgSp/ARRTQETD61LgtRmyJraBl/vtgQ1lIAuhSKoS4QfdutmuJEPZo0mTtPt0VCShinKyTziQg0Fsoxx1LBKUGgpUZZYyGod9IRQ5JOI+DDVxJ5ATapQqQznYVYzVMEylcXSoEwJqjkzETVYMgC99DBskpMz4oIXPOcRD3nGUx5wxBEN+mqsMGuOvGgCkiUN+mpMsNYaucklN/V4/3mirXRFUVenM4ecc8Y5tzjkLvdZUIM4SVA4/yU8SuNp5yXIfRDnMdX5ZwH/+kLNNEJsC76plZgLyb107cTL8El3lmROzhPwvvNnWifrQJ4xqKbxNFenD0cUkby8E1K4v5BzJ7k+f05F5NeXTxiwV64chMQA5nJPkNiNOPt8TpGbHAkrimiJPvvlQWXtsXFW7rShN4mpjOEeXuV8VvMECxnfOTf9nHhZr4CbeJspXLtQXfNINNnvy1zvWpdO9g558izr9v9VlLEqJ0kqvUyxoqxc1LJTy0j1Ol+Ri/iswixd+ESDoi5+B+Vl/8tVeVUINLbRiQ8zrpJxWHiGlpft/SDJXTgZJ7blmN/d8gGCQ3aMtj7WA5sNrXoH5+4xrz8iCrRlqiysqjJxE7QrXBmPsu3pewXlliWFlOgVjCuXchh5Hv9e3MQLO13PdY7BuYNs5uy1yGHkKQzW4OJdwZt99XJl3NI+798N3+c5D877b+/eAWRUfHJWl397k9J42z/fZ813Jc5DpuCffZ+diqaRVcgJfv/BidGzvGyK2YMsq5CNnQvYXUax9hJnUUpjLenRX3o8owN00R1y+r1tgR2eSBxnDHhIs1Kwy/IofK6w1SbITDR8NFySgWLkyFdUQd2SetdjbQIhPzbZU1NxVJE8veG5XvzLrSt72MHLtW4NSzDsQemX0nfWFBTcc1+jGGYki5iXitJ0T3fcygFEofp8n3+5lf3HzsnzcXRxUs8YfRMoFSiwAo92Lkt0iYI8RYoUKSrnld6sUHTGqmNAhiL54GTKsJ/k7TDImHwIs7cQX10dPgX/6CfE7gYfbl257ApLqeh+Tpi9EBPpxvlefgT0zfIkRsscXjZMo0bcikl+yxc2EZccFy5c4oaoWQXbmFuNB6RZKVCwVJcVU+Tz8DRZISRZ0KDRIHE+GivJQDFypCsSVqHdkvZu9r6BeYYDfUwg5Mem9qwWRylyIwOt7jYbSeM5I/8yPM0dM2Ve6DjTs6b4uORuJofSbt+8wCZyxnsTZdEhXpSKd2mYzno6rOt/yCnkYtlgJNFg25loY2cnNukwUK1MhRa0ih+5iEAwYJ2t6seUmYi8ggUlUNgu2gK2i3bgAVG25FAi7OpzbABcNI0C/pcxS1T3r2H+wVATzyTF06eKC6I7g+zhIDOcyeDSmHtpDTXcdAQIkMHMRBJpZkrOUrn5nX9lYD6WF1KnetS/4d1eWbW11tNQe/ti8/t2MWyf152WQ0j/kuom8OEX+OlZxPjCtJQkfOKFVWY6PvfiLiaOgL+tjcFXXlnHpeFbzKe4yBef/Oqr59Oz8duvmXnjCfO1v7wL/uANwxmJ+LM3zHp44jmJAcvFC/8WI1aIN1EWH6IpvkRf/IhJuwex6Hp6ENsXe5Kd/9GrJkGYrJVNb5zITSfYG8j+fv2/smnpAUtNWXogUw5LW1gaZ+mjlsZZeiBjAwjIhTHIfvE5BHXJiKFOL3iRm+5vMSbHo56AkQtvTzR+srFRbfSmMCOKiMKigVH/KLRTgypyEBkLA9yVE1jFfCxewoGTB8IRk2WFjInVONGDE2lu7hUzl7VSknD3ZN6g1giP5Cto7sG2pHVfF6wp+YIjBaS6U0Z4bFhEKR+fvuzC2O7/3V5x/VwfTqq09BR4SjnNnsQn+aY7OZ32nnpPR0+STZcRurm28a0YCDUQdkDIgbAHgg0EDwguEBwghEDIgLAFQrJ5Qhw2D4hm2wTpvrlBHDcXiHZzgug2KMRps4c4b7YQlw0CcQVCDIQUiG5AgQClYnNag7lxB4YlBSvgBKPQmCzAcdgD8i/GfjwuHj4BIRExCSkZuXJ9JRVrNtDeiL7lDWb7OVH3PMoAiTLUR3CO5MxRERPjkuG4KZrHsHv2oPbfzZH80kNayWQ/2846ubB1JQUV2IJi87TP8k74bHt2+Zr27n5vl6DVl+7lLP8KGxxux2dX+Obz4rMQmcPDHg58VqDMNK/sdMBnOeq3UvJXfzHSA4NFbXQWp/abO3N/t09/NQa0SodqSOMQ4HMIhosuueyKq6oQaN9NArKwHeJz1parHBQt9Z+TnhVoiHKmge0Rg1c31XttzcPtK9FivSbwfMtZI7zHX6KkIVIZIKpngi7BlQFwnT6hxThDfx7kaE7Uqze+vPW09LZ/wqw9XHX7WNw+nNuHve3M/3CjrQx389/CN9jG20SbbFNu2s24WTfH5oG35XinJXxJKWkZEIIRWXD9BkZOt9eSAGOxcYLD5UlJy8jKySsoKvW12nXPUlFVU9fQ1NLW0dXjk0aNGTdh0lTf0IcAWSZoMwADb8D6T2gZwTyUbOGxfTNJS3wgpIvdvFETpEl1Vq8Y2+OxQz5PBtscaNlpSz8spl5KSpemRpazoskmte1UXHs7VCrfzIJlpbDscpAy0MHW26xS4rzVk0wQD4QUo4wP0nqLLBmgNT/JkmIoSX+Uk8haL9Y7dOeiBZFsVN2ThY9za6i3gesfRknU0b0xqLJT6pVHV/oeyqZTrbUCNf+vR0BjMNWwRROGxeaQId2m/fbzjXdCXQod9goDdISUrgtrLZsiTBdWmCbNp6V0lgYd6RrdoUf0gv4/EP91L2LceiKSMrtfdLs72PES1lT4FuCakrLKZxGWJ1FoDBaH7+CnS1kkFb2Ut6jllzQsJ6+gqKSsoqqmjkCi0BgsDk+wCRBJn1W4uqoBakI0OoO5+10hiO09pQu848II698CxRJpblUEEkIIRY4PfwQjnIF5Du97LW2erAC4UyVJFKNnMOqdhSJqDzviqGO6EaEgfyHiFPYA0mV3bxqzUBCoTryilnjW+yz8XSd/KlJLK72MMssqu5xyyys/j3+4/JwKx2icxnkyxzODMzTDMzLxKZjCKZriKamOTVA8rNIuBLV1Jj+79w1QezTtTG2dRbDWkpH935nvJaPy+7mLXqc5lTyYtdNKAbqbzZ9hZ4m79ZM04YsHjiZecBSBzjIwbu2JdsN7FXhIdVbP7Uf49C+4W0SE+S0bmQ/tLKB2NlO4g3cr1K7YITt0d0N20y7YZchesp/bJRAyO6ZtiKh97n55j+85EMp0c8tMO4SCTPC2aAjV9sD0s1kUyZ00MpQbW4Iwt3z7KCeES0To2WnDjY2ayDkCmQ9Wypr95f2xi8GXH3899dIb2qm75oxfRPhFhxFIPcjf1U/9UI3HHcIdNuEQLuERPhEQ9di932jAPR6SdPovPh6TEH2F6qe/AQYJE77CmtcdhqDOBAo3ge02/KyxYbS3GoC/9gPDT824WnUQ7sV8nBRGgnNt6HmcYAsU22H4fx9c2FV3Yafcg512H3bGAzirQoazOhQ4a0KFsy50OOvDgLMhTDgbw4KzKWw4W8KFszU8ONsjhLMjIjg7I4azK+1wdqcDjlMG4XjlA5wV6YHrWV+4BR2ABxMCeMQDhkcypvBIxwwe2Zgj+ZKmkJCsDS19SDaHk2dIKsIPgGRbBOlH2j6YIKB7t6MVlt5WdO91rKIy+gTd+x2vuMw+RfdBJ9peVtvQfdjJdpRdIrqPKm1nOSWh+7if2lVuyejWdKrd5ZWC0TsdLr/UEtqC0eqOVFBaH/cRxE2v5v4dx1vvvPfBRw0+++Krb7774adfmjRr1aZdR5p4JaTmfd/b8Le2M2oKIMPQlmiwG6fPsYlMbyZesgyL/W+5zXbY6YDtmbjqo+/5njGEOEiAhDEKpP6icIlr3OIRz3hlZyRRpivd6c9EKlKZ+tzOQxMUw5oWjrlZuVKrejViz65fiq/eize+2KUuV04xF0kaPy3DHdGI0deQVS5gI4RdaOJxBiktJnmv4kHahkE/tgakjQaJ5S1ZwqWmI2RbbLCydJpVdki3692K7HFasbOq/O/6R1a7qWv0ZvVad9233iNkkxrdrCTYkhVTccR7O1ri9/llOaB5/iD3ZgGVNfqCXc04xq5lElfXc4+72jZnu9ftjURHEZHpLDpdfpejdGGuZybmqRp3TXVuxs1Ser8QGA9IaygJNI0+IjdIw3IrvYnKouzLPd2vaziQFRwafcixvCmJydsaq2OIE2kSMiQxn79jUr7sjdg60o/yu++7PDlm6uZe4+cgp/TdPBpi33+3Q9lxFRqrdEQz2JswS+UGskmA0umNKoSUKwKyRRNYVltoqmmKUB6BcT6m1Z9eKjBBCU5oIsMZQAnisW6pou5nf6s+2sdt7ZM+bVuJJZVcSvkVVFhRxW1vRzvb1W5+VloHA1qA+c14xzf+CUxw2qdjQtM5Yfbaj5SIs/iKE4EkpF+pg5nUz1rfYJwkZc53p3zosmIYsnGY9foh+UgmJaCugYRAYHzV5aA4vqryVZFVptGYHfr1jh3dM5HQUKBfAi59QRT0YcFl+gEZmkROAzw0fo8aOl0g8+pG5F5d7/PjSAiNyEIMCaSQwRFaJGjim8H9jMPDelTHVo8G/bg7HzzitfNshkR4uvGXw4e5z97BT/Tkt+AwuED9Pw7y7f9FsO4biBp8LqBXLgBcFxsoMMAVEQgIdU77p/mPSjBkcddDsb1tiHsCEp6dkWY4G1OXh6FnMLO1bEBje7PiDnRyVAmXiMdyHMZlAuf2tI14upbFcljBK2rZlnMFV8/auprW7fVosRZviVbXGlqj68uaXcuXbvP32NLubYN1gCILgxBRRgtdTLBEFgowD7uxF5U4gpM4S0uKkQeO42qu525W8ijf86OwGBJIrKxMVQ201QQl+GT/2XeF83A8nA0Xw+1wNyLrry3OJp7X3LH1n97t6gLX5cHfJvsDxyNBiYwoILE3fxBaXme6ZlcFOjIgsnWcxg+icwMx3HuUp6bUUpo859RodEsLKi7h7rIA0jYU2FV6EyRIIw+g1OlgfOsclFDe23E0y665iwd5mO+2FnXi/YR0DcfCmXAhVNuLTpA2Dw/2JJz5XNFj/13lqQN/kmXi6F//ZYzhxd4uANn/0//uf/m/AH/fwT8eRF/8d+L/WFfzZ7583QzU/wAvUA+0fp+3SfQaeem3AWkHaq6h2qorh+rBdZdQh4C6D16P2yneZHXKoW679Lp2XaMuBT+gNujV21cN+DX1ivd+/Q998Ceegb3P+EmFQxpBLomWh1xkD5ZZcV/0DWBuOm6zaTwm0O59584TPNEjsW4eD7Jt8+5r/8qRztR8HtksjXx+TfP8WwA4/ZmeKkUBrEUxANalAdb3r54FiLz1tXfOV7+El4hU8it2rC9ZD9RjF2G15ie/7Ir9oy4OtL8meByDHUc7vCxumrB+PWq4ob8t9UZzZMBR/jfKeEGsKKlp+PDVh0mEIaKMNMoE+QoUKjbbfOttsFWFvUcft42AjBooOeut3/6EEQMpYh67QOMVvwQmLOGJjimWWOOIP6GMpjClwaZmdEmv0SMj+kmXJnJEA4x46OM7ovHL/NhO7BDn2QTN8b7Tselo4fj021R1JAtjV6C97a+cGMZmSUhOwYaH7rTcDAj9/1+eg3FSxYiVK/nI5CizwCKLbTMln2bvfNXhl3aduuIXDWSBBMglTnGOS9SQKbJww4shkpFHn2g6E0lX1iUhM6RaEe/JtFH5yzYguE6UwNo/dlEB+6iCISb0MeSVjRyjCf6x4hcLvQLRM9aCggusSnhog0IKC6VfNYJrZg5vaC2GRTY8qugoRkQzulZjYxkT0/jYJqeTnVZeRlOzKarNtOz+y2lGWaaXqaQMc4Ob00ml5VkX2upuWNgZa0NZ1XVryrepYtsrt8O+ah2o3v7qpAVaGpKFLwJiq0csRUY0s2zzUuC+f2tq1i36qyhnBUEBTrBgiMNmYtKycpcbTn8o6ycYGQUrShJSqv71L6jb/1s5mL8q408Ff6qfrqbIMPYvIjj0eESELPVrs+HDl58eegsQBMDGgalKKmqav9EJNb0ZAzs3j1aBvCjGs4Y4/2VvZuHCx6WgVy5ZhRSVUlWZ2M+oNaFxkKZauhoZEDLVylJnknrZGkzWJBdSHpR8aPF5We/Y2BLGxopsroRIE4kWHN/w/MDXSOAnru8oHzA0YPqE5TPaR+4x4pkNjAHTRRucowsu0QPX6INTdGBgTfrXICWpicnFxZeQUGIiSYnFJ5CeQmYqWalNSiMjpf87b0kXLeuSFV1R3lUru2Z5l+2qys4q7Q5nTypErZUIhCLMg+P+D/zuf8uv5LhCpQnk/h5ap1RrHflA5k9EUFRITFjcbz/96mC4pzOIuSKWbIQtCnp6ZXC8fG8eh9ofl61EESFCIXlIvRynTmpvLg7pqiMPGm5i+h2tisON85FP1+AWMxGSPUWgEisjvmjPgK83CK++0tz8Uh6tcfkUR8hfHsmebm2x5Z+hnDrviR/EWroVJOsYlkjgqIycYIgXAKUC2nM1f3firsOMiOXtFp7vhDJvrv08HIN+6qWd1FJfjis3Gux6OR4+9jn+Gi5M3j3GwyehZprlwTwi3uuZ1VL5Ykz7VLCgIvisTBYuqkML/mGo86+61IC9YY9mTz2V2/5vreQuf++d95dHs2EWePbSf/ZkKKAltVzKZAqlKXvWHhL748EI+b6+mWvGyBrlW+7LlBN2wqNZ3d2QnT6HxEclXh1NH5KTUwaVg5N0E8s/peJG5G/uUdpkpDDDnlkIlpRgSxSgB2pP7SIs7iqKFGij67yvp3KaNrQGsugtVi+gwBhqxvXd+HVYSukNKV0vOZFN2N8aZW90Tp33NO66tG8q5m1wmxttLMeSZD/GWqIFOlyoYB4z+66dFATEdCeReyNS/8FpdduyA2DqDzm80fL3uT6Um2KgGLv7yVxUZ07WvTDvhYZ5xxWijN+CSyE5Qe0xGMjTipbSBfS4gR2vfEMtTuXFTLf5MxNUdTi7oeEEYxYag1GdBzOi9nbVO/E27+lQEQo39vgvp2WJMVoClCN+qayvqCbLGCntoxZDOAm2BEVkuNHyT55WJrxBuYXDKRNliq+HWvSgay8YDGUcsax9T78eXDvOt1Oz+BwFKY8oXQ5HqoFJ2HB62UOJbrT4UKRFAZU/rEI7m/pYzvd2yZa46+XK/m8ZV8ZYt4m7bmPEQQOhZ9AFcCoK/65aACV1SSSuf0n19vkLTPwP7x0q0xTQY7hcG4NEKQHxur08iUQyuQuBeJK/alIt+cQWH2LtuS2xREERS2y5BJF2gkknoUg3oUkvIaRKGNJPWGSQsMkw4QxvQVi/LE35eqiChvSmKXrTuCpoLZOfqduti+TXkzbCxO8uSBwl1ctrADIP0oyNTJgpM2PmzILZYJbMJvOIMdrIDrAurGR3cmS7oCO+7PDToMHakdfcHgpGtEZ3M/YrfmwwwEhWJS2LUY9eajnCyQG/qpZwbE/aLsb9bhFd6OkrI1Ae0iZG+cgR8B7roWNMgDn2uquQAo/wvCui/AcA/DdluRxpQeaTcgKsY4B7iVhrvRk7RXN//XVCZ3C607Pp2oNrFJbS0agKMdWUsc/5/iCZiQQ9dRb34BTqmdLCnXk5+RxE+d165rXPDKZUfPEv6HHhLO8kYD2fQS8XBTRt5WiiDKLuWT/tycHNlZ5rmx25ZSLPdi1Y2V0ukafIJelH3ZSqakVLxx3SBTRjKxSmVqe9fHJoRSsXiF5OAuZeWfpp2bUVl31n5bns4GEjYlvsqWGewImyeLKBEBXq3IOEm2pBK1rXjWHP7CUbTGSKkkFJ1pfTrVce3TKjD3BBGMHsdT4bCGeyHt3qszZYF+/EtQWcHF2YNx7M+hy2cA6GSjqOlJXEPXvzyBiPd1b0bgKHm+FvqYFwgIG6ff4Wddftm2LdmrKn+UKh5+3X3ne7c9/Vi4z8Ka/B87iY8fh0x0XkUQTydZr5DG4SDRvusckTD6Vs2pnppUS/48OGe0Pqd6KR5bZ3PEVxeTJEMyzOb4uBBAM5YMPOXpdl52Wl6A1H8mwY58EQ83mg90UvCRIihk9f2IXKuxXabczltJPu1rwce4UC8vI8ReN12axf5M2zodwTNOjnaWWU+xbCrJ8Epv9e9g71NkzYUGACGtYCuCDDC2ETQkAjWoAUtFzGOQFWCQpp1BZAY0afIggYpDFbAIst2N1hPXDyyLgW4AUZXwhbCAKa0AKiII1xwhqTfG/SFiBjmoMcoCBN2QJU7OEahe7c0yY15LwJWywWOooPIizn+2SBcjNE4CqCWR+iR4vYhA9sw4fuwOAB+5kHc4hgjhHM6RA9H3AOn7iET1zDJ24zwNwjmEcE94TGC6/whXf4wid84TsDzC+CgXofkVAjD/j1gtrnpVmrutHcU/HOm4XH/vaQant3PFH/failqAOCji6bgPkFwP4loG8F1/tU4DafCVzrlcDl7wnwwU9Ew8cT/3rbt9oUw4lSpSCxI0fDovjm5I8nD/vGp8861DD6Fi4O3PsxROxQ+HHmaSbH920wGHsS1R6pJ1Yk9hW/i30eCGi0InH8R3H8xx69N/Dm5qIbgnFk4uEL7Uw8bWzEtzoJHPCdJbKMRgjmtsUR7gYri6TuEJNxD4NvW5zgN6wPFE8lMAoGJTz1aZEhw+k4zER8lehcmEP85muU774OscjyISXRhzhPn1jMlbDmSdqt9Boa3Uc+4M1SZ1Z0u5EqZqmWxLOPJFhV5BrR3kVjRvcceIgmOqMQblVIAaFqkQ1WIfk8xFxzwuiEuHhPkaaC6ZdWGqOiOlfGROLhDuoQ2lgNM0vasrvrcynOLTSGrNhs451TxbxigRE/eMR1hV2pBKStzw0V1Sry9eRz8sot+jFMYjXaKtBykFy4e0SKqS/9oSochqStjrXT9Wo8RNZtlWVj1pVhsWJjN+ElikpFOqtjWAuRjhlUjLTqZhOvs6tcX4qpYI+YqhPeT9wNcXVJzXoBTIGZUDJ79JVfPDW+8HFyrT6SmOhWv0K5nrKEJmoZEjVpAWYqA0mnuyQGERZEC3REc/IMgMDI6k1PjNutyG1CYA47YafXA+90QD0KCjy78632Z4BZ869dIdrLr1i6ZXUutIqBmo55rJrmYW875r/ReBkkVJ3nfJyAsnqF6cIh3oLHgWdADQ2g43xZID8t9CWrT7jkLIlZnM1Sx8KsN0Z363Ujy8GU7dzUPM0C3QNzBiZU2YiH/pGyaa15nBttrTzhyGAJybQ2BX8KUq/Q/+fJoJNnioxOuc3X6GJakgsZNXauJEf+B7G8m51SAaWf2EDJhXvC8tEmrmgcFPO4ca91/nO3QaOtwuDDVgG7i+M4r6lMVGEJCDwEpW+cDqZAuKcTL5XHK6t4Q6mBibpkt1BZQDaa5tOUuAMJJL8DDVtUbyS9UhCB8aReUXFVG6fSeAhAgtOhxlsUYp3ZraKe5yjkbmFhxqXvNcJgTupAlv/lTnfhjSqGe3N7OyQ7ihe9fjIKY6LxsQ4L5jiwy9VOjFSpz186zwFGW9/CQCKwzjD9PhRjKa3HQyAcq5SFaPpBbo0/sbOncxRnJ7OOHr9pC5KnWFtQUdIN3KiP+Fzjfzf/yOxpwFdfXyAmRzY/RJ7koV84uTirtCCUwitJWMBoWc9S98wOBpa3YesLrpefkrpCrhEVVedIrNbJr2zAI8eeBp5yYlCQwTTDR40Kw47qhykGNPqETX/PVW1ZibVJF5peSTsINn5JoHvRSLuFK3yaxuEdBGi5xib1iaRwMc1cOeH0roaF9wtXXqkI+rN/VMyhFD3ZA0ErQS8lALHMCn1pk631+Y+vn/VC0rNqEOt45Vr7mz1p6NdnI7/Vp3U4/HuBsDgQWzuMZ3hJza0lGnr0gRnjk1mFi3of0UR6TYxuVdBQY3VMePMcvZCwF8bAQr9yoFwebAGd3eHo5RaOSMHPqohBgSCY4Ye6GBkO2rEIdh/ZKiruXGeJsROQ2CZrhp1F4IIltBEUeBNF6EjSR5ZT9oBIxlqnDr+tCyfpJFCK+aFZlPd+IqLI2u6ojgTbHjVAWvSdLAU9pT0WTYyfZDWTM/2oCT2Wql7Vhl55dyXNCwyu6PW9MqIxv06g+Rag6e7mIPJjEKTWPeON5ArM9Kn52iOMgdcIsoiXgq8sMszVAwmkDP7IfrBzptQ9Id6pCFPohdgaAiUHQl2Zp616bk/9XqyT9ztSiMwb/e2xNZilrxQaBFrPWSmz0SWfDoerkp+11h+RsXIrmtzsNLGlabQK5jl6T9ovks0E0UG5y5mmJ4zC3p3HNmvnXFXYZGcWS5lhNLDDtBG7PyhaPHXtHEgRk3O0XsVKdS1IoyE6FiZPPFUjtsL+sS3q2ZwhlDqDgZSWN+GaX1Gfk3KblCh24mRCPJ4SrqwyNNCOg+xEoJBSKrb7HYMBfRhwBWh9w6h2JrftVbK/x5QbZpB0ujS0pznbvrOpyaqym1dMj2kLU6rxqMz43EVjTntPB+V+pxFGrQeFhLsT25DLNFSYSBo8Q5H8DP4CFYdRPCh10LlLc7urw1lnzhM6h/BWKnKdN3/osTDt4alBx76wIek1OjausIMw0RG3y3R2Cha1+OOcDTKvr6QyX/RZyBdipcpgs7c7bggSw5k1M1trXrqcUDQfE9J4gfxWEhKvpKD/lOTDHS1dMVGMWGl1S55VZ5aMsMt9+SLtXZKWvZgIBV3eeC6Kbf0+F21jwPRs5moXVL8xKoxW5BYXSC5LmOkfGm+KvZ9mnVGGC3dBXM0oNFaesxIQOF/omuH2xdBFtbL3hTyNB/S66BZcoT5dgL+wPGQH9dr8hwxMCoGTIQYPw2zstyCWEAXDieupYgCYDCp3UWTCawzosFvKwnyBkJSu5bYqneaW10GtSbbA+lppk5bwsI671n7741JJTVlQUVS1PhPogiciGu4tNnUt7ORgs0xgKrEQsfKs8XtARwuiOTCyBijZ4aI8VXrsBNO0doQ836M7ZdpqMzlTMtu+sYFiulBIJGQvwzjoPiTH9tg7QkxwGRKSyYMBZfv5ft1suyE2CRBIblelHd0EjGEb58VWDgZOZV71XBykhj2VDv2bsVIGAD6bT8lmv3Tz1GLxw8LqIYvX6U26tuWLa0n4bqJCnOhdhgXo4kWQ2oxjHdPIHGLxLQWzgnKm95RkGg3/B6SpNHe6cGhy/TGSQBdFneZBILB+jGAvmBR7HR8mQhPZunGsYFH58VunwBElL3Vc8IXLiZr6OCFvppTF4z3QuWwM+PHU346kU7H0F/TUyAzAmka9d1C4cfpWgq8CWW9GFyaKo/wNfW5ZZEBcWGzItuL1iub6J1nYc98fkdDB7jrDjkf0uZ9mYavg5d7PkrOeXPgfDzRPKMy0fRryaS/3bv6z45WUKWoYDJNRxNDZojFzYOn+saAVqsn6YL7GhcyBIsIHLAkELrw1fw9yfAX07NOeln9mGADEpw8rY4hCKDnWszRW5+x4wUMpRceCn3gG0Nu2ZFZf+r78xBcEWbUs1C+SMpKZT8F0S49jUmGwBn/KhKREWHmO9ZoSLlr9T3wfgNiOSI8W+eTlxPAwi3nkXtxiz23ySF+MgIUePsnMjjBPoPpwFKD2BnUBd+a5MwjNA7HbidvySsbUOFtc0iAxZXXlQ6wXpTsGwzcAWDJcj0z0ueRXXjdyhZMonJYyf3r4wYnnNtbq7vF6ZEwqUTt7I1j0sD7Nn/TOjxT3sieYKP5IcSe2teIP0UvrlapLAhdBrRkwhrJ31dlbCSaf17yb3ZK3RNAv9QSQr5ad+jSjw6XcihYFYxKXaXOASC1WBY69WEhBa7ZOCaUEvgLOiTkz01+Zv4zpQQlPe8J7BUnJF0Rh6NzM9BBgdZwGraso8nm7YmBeAdhzlcOi6Yq2wQ3EnBiJHVdcpn3zEfVkwtxA9Dm5GtzZJaIKg4LecKaBzZT2BhXUtaaxrdjgGwWGvqu732TuGyA2FSDXa4K/p74MAvSunSQ8LRAbR/7NfhMRGNn6MnknzIPgeqFmvuwVSSocPzeOGoOSTEpZEQTzUM1AB0JHEE3UzMlniydxrCcnEFusNrMh3vV5MvFLYsaWQ7BkONHJ8FVOrTRVpDTiQHcoe7J0ZXk1iHvN3rb8deZrVRiYS9MbSO5oytOfOIz/aMXXZ9TnwcWwLIrmUu/BUcBycpQnBbGWUv7YhK4yRu83qg5rMUXhhV/5lUnuoVnt7Q6IjJxob7MXSbmlnqRA5LnT8yzppVJjMDEmtWkrF1qe1ZpR4Rh2X50Hh13rD547LcGCpWyfKEYICKy3RW0JpN7ll4p2Hw6FCQX1vzF1VF8SK0IPIKhVTYgUNvNGK9R4MagCwhqvM/gFizprUgaX3eQ2VCRpx7y68lh2UOYX0MJqxQ5JwuxDWGJzqSxer7R3qT/cjAxHCKtp1e5rnKQTEKPUf72sicayFG7NCJ1RI73ZyenclY/BwXFtyJIe7Q3w7BzcSj3/UyGEbST5CYfGDGd9vXtK9/m1A23/hpUhjB/SvUkfuvQFeCI4B5C7Kx6wTkEVD0YW8PcaeEUZX14N31J9Udusq/A3xNKBzXh2XyhYMZPMgtYZa+PZukFfsclESK7tYKV1kYtEgCOb60zgMWmjOe6zePhj3klpMaqBpxUwlFm8SbqD2tGmuTItNDvZQL/BsTjG26a0JJRs90mRaoQvZHjljqwPfYwRDpLILb2a58kvSwyyhQzZwXEplmQLU1nf0mEOs4aWDsSXCvPZu8WkSS5E7WyCFWGB1SP5jspfO15ehnp8cfZXzZ/rk/Da7c+kMxifNmhS69b+8DgEgl2qLz2qYlvv0SBtEsYJ7gd+pPgTgIJitowygxo2Jhxq21/ErWO0rb5juQbvKF9QZlzRml6hMRY/KQAbPX4O6AdpvZY9YSJ3O5n909A12xdQT7y5TMqAUPe9GdQPunNv1gTMwQucVfADhGo6SM4DXV/g/IlDoZLwpI6RhXBRa871ScMjI/ylCVI0m/35vB9q92rZlo7EGcTQ45CvnfE5X8L8RsZtY7miPqz9Xs2PUoAXRfPOQBU3WC4EnDCsXdnyNJaQ1M2zsOtG5TFzDba6unSzMIwmGDOZ9004ZiT0ZrjRARV2f5QSNHkL92e5R5+7+zTT09TQgH1G34nzdUlnlum36Z5Hv7AFR6h2pLof/gRwzPkMV1ZNzthwrde3U5Z/mUFbK+pZHXzhjImgh86I4+ETH1Tfc1uJzvKtxIYRCbmxKPcSxF1M06yv40oWMxd/YsGa2JOLwVOs0el6kinf0e7+BCrEh/SFcXuCO7GtDnxmPdcPzMZGazzz5qTLnM6TvHBB1x7rjKrjbeDRHCWjI6feBDvorwiC8/jZ0f5Q52ys3E4YpcGQ497gajWjOHA1l/TkNFkf3VwYZuyVTmd0RY5lk1ZRqbbf1l/aPf8GkYtOsoM3X/ct13psaEyvFFsYTUqe3F6xGIxSiWNfgSBw3c1/xTjDo3ukrzO/NN9rq1pdS0iIYdTGwUasg1iv4ZXYjWJIzsJ4n2DH/16Mgoc2RwfJaE7MLOy9awlQKxrF5FHqV2mQPR8P7etQ57TTD1gD05/JceC8p9Vc98KgIcUgAYE3EGr4w7LBn4b+el1JDxNE7Q9FfxmcjbUnjYuZToV/pEozXJxPGk8Xj7Geou8MJoaratwcVcnbzwPMwbuh6bi/Zlx8byr7BfUbDPOpgYuWqQqPSgunxLiSypPfz4iTMhfv4Oy0Uif+a85Eqc7oVHXUhJ3bY7m/u3rb6wMH9/IeX0N5V382Kl/o5HavKTvTbR0OfIq2W5/XCV7dgpPRzeRiF8dDzqjEWJQUugo8XIacu54iN2Mnu1shGulusitLjMOBUfkT77j2a2GSwB2x9oeegl5N3L3ZU1eeBljk3ciUMBMWY8CbUI2Elz+ZsCa+uYl8NYQNMbjfJ7bH3wCWysRn3dkEg53ZdMc5pzM6HHC5sVXTdObrP7A+uqU5Nc4kQjDTR0ITNcYgVf6I90cpT+4IKByZuv4abDBKodUjpmsCEOBTJNtOq1xQS5lXaFfH7RX5CWioTn5u1kaj1EK6BstgGGwI9/RlRnlTb2gbM998eY5mdu6MP6kc4CWGrhGEOX5ww7JK3eKKqsebH1QuVV5Zw3u5qn4WvCttB4Juat5/7sPGWMrxoptmh73kbpRCD6/JvNgdbIR+ExPG3OZG7p5YoT3u1KKOtb7eBS4un1FqdrYK5ax0MF1vFDom7YOn94wz+WhUMxcJjH+zQOdhMBgejr7g7M5p26pXHY12KRa2Gl3T85Ow/ilIFlcjFxn9M339gWm9XKvNFE9B8gf3b5zv8iGBi9/tvnbj9KnL1493hgMPH/14ERCcW+UPJplvgmHwtiuih0av19ux/YZjO9TW1m6kwYCbMhIyoO5QJ0jQUNdOQ8vd+/pCru069bHpa6lDK9qsdpE80DYLLj6cZHiGH+bDpaEc92ar5FhHUHZ8q91nHKALO7L5U5Bz4SIJR8ttiApE9d16gEMQNzaKy8+7USF1WuB4L/BJt2F6cjq2tIkW/H7p8XlHcGTbWEHnNTqDPTKujlsPkTR0awAAx6+0zglOcYvPq1GNSF8qVSCr0M4ZnwIXE3WNdYmFkBlLMDy8c80DWjJ0jjQEUHuTxAlI0k6XtpDoMun9xH0lvT/EkqPdHaeAvTujpXhu/iFebnyX9dGjUUSo0IyVn3+2xtD5UHxz6avB3v7GNIy0E1MASyzuRULSGZRs2Ae+yFeAkrV2B4kILc9KtYM5/h0G8Gh3N7jgHH9g1xa0o9JwW3ByYCA43WZrn4ZLt08GaU8rDVsJIYvl+LYbFcciXYoFF5lP0NlsBZ+JMG/iw/jbgsjzcnMnhh/mGYHGbpGoMWpk87gGdmN0/5Pd1G0A/vPNi3mDs32B4Gz/4OakyAzAI5NJPBIwIwcXE/H+2HTY652OxPrne17vXeqNe71mdGsLDybxzdvA4wG/9Pg2R3vHvENy3O9k7/7I1FV3EL7aEeuiylprnAJeQ9TA53L1/IYoj9sY1fOWwMV6aSeObmMxefpWdzY0uOrF8eybzr/77c4aPkABiHg8u6V1lxUKNeXoR+iCUJpwLB3KUQhFrRwUcs0uIVywUpfnx6IlFAbdGsGDml4a4E/nJNL8Yj6bxMTVlx7jrvnemt9JQysILMDai52HQqHgh52xvm5y763jnZlhr8471zM8FBlq5ZOxeCkJcNmun97f0fuh81PN2xFM5C0NA2rO0Y2wOP2qe4l7EjkoEoGgBG9Qxe0fZrEobwBFfpKyRfwd/LrkO/6fPi67R1clVq2deXzV+p5vin1uLAAhxIof4r5r23n0/5v+rfxi+8G941gKyFiPFG37lh5HLiC3uJKC1mjwmrD9M2Xkp6y4z8IRZehtkWf9WDo4+Wnw6cul4fVRP4/rZcMOVc1tydrCG55hCgh4gqCFOWOAQhsj/Z91RbyRrs/6IxIoVEfeJhqDNVVw3o1qXDh0Zjf0aaX7iBPlFvO4Gqlu5YWqLi/KODWalqOKmZxd0a7gMwU/5ogsqWWNl8PJZDsOYWaKhPSydWtOACWs/xjrY06kTyggNLFk8MILJQwyHi2N1qzdAZNjhMJdZYKTJBE2Y8RYGkvhcngU3WphIr1AGjdYBCFyyrPppE8EvxMmk4HDA6wVDQ4ewCxeV/BmQUnFpWuuTJIKbUyRDSzG/w2OxLVwXRzioEZj4RamzdvCMitVTFMLg2NSKTnmM8hMsIfDHFKrASAHPZP+TOsYpOszFINdIpUIyUB/7htLW26bDFNTMzkONmFQqyEOicjYJDXS8G9J1UCKzKhDr/RSmUa1ptVAo3DMSpBjPZOBzBxaNxGNQqRDlS+fsx0fwhQBotKPf7UbfdVeFZggFLFdtaHm8+6JdetjbjpbJmaxJXQG2FwuFBhN+GitgEtFOTIabMTlkdveE/xBDf06LBYj4+kkVVwdL7/D0b5lHwkE/2YWlxRznw+VYYcbKrr4fS9vaG4eXUZlJRhtYoNujrwwmMqHKdpyvnS0+3jCZDGweOA7CCOXJU5JgUCuVPucIK01eyJu4rKu/pC/T7WKPQbdD3jqr34hCBUKD3iY5KhUSo66AICswlFUQ1961/m7y8kctThJyNFQqEytUAho91bsex1QAk9XHqf5nxVrlHvXMlm45HG+wVuM/zFycB3WYAobdXFSwkSgsVkEMAPKg8VhzSnzcYTSt6uy42KVkGcsr1zEQ+/+dO/e+098N+35VqXfKoQu9uRQAUGcWldX66RDbzxx0RR9qwSPpcrIqQWyFpLK6nXq4sRxEwrHY2H7sKxaHgaF5zOxQ3eVRq0aTdBbLruqKE4dH4+n8jmo9txJTUydQmw1s0uTSxqKJdPITHkvhzmo0Vi4g+TynjfAgTIvXSKzdMmMGgnlzp+JJcvbVSiCxCXCDEul2CGXWIJTNuk+HHrkbzIrlYCZQmHrdDpA114ZZE58LuNV4qQeEQ6rxA15xNJmfmXH89E/XP8rkjShiqTDTRuXIpuCp2sEQMzHP9Qpm3ASlxg7JJVihl0iCUGFak+Wx/53sieg0+nYOsoFfp/6ebD+FO9v97GYEJa+SMdzyzIH+txp0kSaX0pBfleem578lXmFqU6KEnVZOqWOZiyIGU0reOTt9mlZxdJNRaatfkOTdEAZ4L3XPRHv6Vzr1rfQ5Z3CHJ2NY531jQIhJoePxeGELUJ0sB5/uLEOgycBfMZ70yWgSAAWq53qofjQnHMuG5FZKXZa0L8OGdJxpq9jVDEKnrW6EN9Ic5jcWPJxO+HjcGPFRR78jaO0+O36OInzEgpH5gC4OKwnWVvvGH77GdnU1DYDJ6VcO1gw5h0PjIeD40hj3lfNcb/b5wZQT+bcoGcKrvZdnbsOeYI/U/zkyJOs4LyTU7zR8VnNE0kTs6dHpidelq5iNlJUUGwAL6h3PhVoEbQ6ZUpnVqq115qVWvRuZpTLpq6frRq8A05omZZqIdbY0h/7A6mZwjYhZlgmbR5uE4koCqRfEocNpIAmVXO+F9m5Wo7GFMotyMYNxfJmVLE8fgJcjC82QzOgGRkZ0EP5LQCqEXUwECgoe1DUPOdNnYps4e6b7crebZHBZrGyi64rk26WwViVV+G5vJxb3SovvdunsllBuc2mUtpsctBmVYjg7GY0B17NQTezG8DF1yYpdmweXN/n863vGdwUnpnqCE3N6MHFFyeJNGQouCjak8gSaTiz5S6fqzXx3Cw9lfxUuQI+n64jFLOkuKVnh6nTE+WvbtdBEJ+96uQxS31Q6IoSR65j12+DwhKS3watznWUyB/C/yTShPS/D4WtObpBIseOHl/G4pElHAGRQASw1E5PJ+PtFiRAFUvZLayxdBPLurbFqB8gtprJLK6Mlc1ayZdxaAz7AGlybyIdCdlblYA1F+wiQvNTkw2zcdpsjjP50VaDrsZkMOk+vIPh2Fchk7dCW6JFRd+ScFmvVE3XfFK/H8KtkL2M54OL6MUxTYOGFo24Vp+bcDd98xf2+I5TO6YzvMz3iCpoLMfQt1XIHQFBCxjWZ4gZ+t9X1W/gduFqxLp6qVKqr68Wcx/KdJ2Lw1XHT5jMr5rfvmxxhqZBM6bRp+t/sn7bVs6LDns6oYnWPh84gA6xgEosKrzPwluaH/CmcxJgLl16otwOVl64xYfl/dsl8juJ7zYPzsa6IrMDg3mjvj8XmHjUVhYsCEjf1lyIYAv0X8LUXfOMnuimr6vKTlU0/IEbvi1/LoXMusLqCJbvLhnpDr6fZJCNSKZo27vbOE/QyVeifTnueZPiWDiiWHARuqcOrF8dm4RkidtAodzjzzKnVbdXZ9q8AVDiUGSqptIKRhY2jfhyphQGBHaWKmNLwMILt9wGb4dn2jztoMgOZomnIKtjB9ZPu+ZNioVIWHFs3jQCfTDsuQgm8u2Nzxzl7N5hb+jfGZ9b3+RSq1BlwU7lWrFp68J695xBvNDdLT7qQrrXHzm2Ygt2Nh2w622TAwO2ab3BOu1eQuvkfuKBlcI8pU/TvaUzlruYSB3ZmjI2eePHG1l8ApXCJ1j+EeQpDkUurloJiKgAgwHwyMaG6ZJE57V2+3NrZWvP+EhneDLx+FNVOz07ZQnZ657XdfOD09GuyHTX4LbwHJvdQu2dmtu6wltTfQi9/Oy1iCNy5i7U/WK1t2ZU/vVMX0lN2VBZ7Zrevd7N9nP1zudUHYuFr4hfP98dyPvzsE19Tro30KWXe2zZml/lSw2gx5KtSf6MkpT/HGQF5FbmCdLTvf6udflJsHdxu28Wi6V0Ni5SWfTu+fv1fsWb9+lH15hj5UTly9u0Yry3HxUxE+WkCplcM+aOxnAwDc+5rcKXfNu/2Ojbwt3wvG9haWxJ6QNXHvk1gzlW3uIHnwmdXN8pjSU9Ue595U5BiaUX+jMHpYEKc2bZFo7dF9CovL5bu7Vrebl9a7rQBn36O9aYOTK6fZ+zYowDdiAlmdzRvBj6Lq/sTxNLVl3NqUup16KJnqF4X3hios9LZrJFAiaf1MIRcUUstpUHW+40itlI2v1ddA5OZOU595KijcrSEmb1oHaDjFmxrWHayYNNuNIu9eTBlgVGl9IOJQ68YHabv5hwpSU2uPe/oCryL3GrKvgQdklu5yXB0nBAH+hxaIt5v9+UTZgzMp5d8QP0A3dF9T+Kkj93/mn4kPWdteLxH39K2k2CzECfOUM5msp9p8UnqNjWpNcZ6qXl5XcIxCdFo8sy+N2K9mjEwEGrxeYnCPxB3RQPFlc+rxj6RQwvotH/P/vfzUbOnxm76v5a6yPxFOYByPrEPCx+6UwlobOVLeTBtm0cNd5tsBFWlGmnQ7MAHiz+/NLNEim+WmroL80lnmTpEuP9S9dc37murYdSz2+fPTQ2PWm3O3uh98LcwbHJafnc9p7/XlNqxCq1RnrPcalatc+h7PrQH9hdE3KRJEuSY088EOdhbG5l2734DTwC2cAp/u9omIJ3rh0DwJvJSaC3xwNKXmUOOx4QWsj7WLTdZZXJ7NPV3u0MoaPV8B50SH74ctj505kRQb9NKvNbgzqnBj1eXT2O1hivkJgjEn2ox6JBt1UmczPW6XZ2DMAn0B324R4rf+jXhqWG8LLTnZtFrO3J1C1s7GMUgQnMpjwx6sk5FpuA/rRzLG0ty+DHCCoyuQHMRmvDvs5f3I2s8nWemGPaH8fuXE+WbtLjkbcVRpDBg8XfkazwrY8F5VEOa1CjsXATyQPr+rO9qZJ35KagcFrr03mQ13s7QdYwNB2W0C/ykrMu3xnTysihCPI+ova+jQcwFUxcHDermI0avWPcGEfEM2CcxSVfVTUHyVHGfJfVTnUsHtvn3OcPtvtMQpHP2B5wuHUAoHMHUcY3/jB3XHZskV1m/xSpiOLfD6ESwPEdCdiK1wpey5Z37QCOw68emjVnbtCffYrOWWv+flGV8yzVHwDJzW88gx+m/e569z0SA624zSyuXwWDsFlCjc/1Jnvxdb2YJldWzkrnxlmuMsy5rGJoKR5oUYh8pEQXdm/LGSB9/Nfa4NFzLoEHGfjVUsOIL1+RTcyOGJpwR9oeL21xTZ+8mO4+dXGd60J73u3aQM7tO9V7y6IEc2dCIaTOJcUp3JPaNm+KRpl/in9RnPq/PX1YePx/K8X9fw35395AJjkj7z83/7tTsgjcBSqRkbkkZpVs1uZS7J7XebzbdeBul006y6yaS4pURi7y2PWd3G7/hN3mm+jm1nXy2BcjyLzXfvOo3l9KcMqZPHYJ//DOpeE11c7WhsHZSsULczoUd/5M0Pvzs69IvdE6f8nnkrmcmRWp5VXOWoNCC2YeOdSozjGNGfjHurr4C+NGo2l81xa6jWPxhUxhmSoxPKwal0lt2v1vrETwiS93OulMNd+7CFC16HgkYMf+tXJNGXIHmc7jjEykZ4Tmhgd6E1EbsVqqZHKrdSidtiISGaDmjKzrWdY2niYQ4ihUBY5MlpJYDC8Dx2nAIbdQaU/yxiEZ2gl/V3/CbwrHENxciZnNYdti2NvDG1wB2Us77moimg26/9eUabg5g9ORdPM4JMLDkFkCHoshFLGQAOLH8eZdlyMA7Eq/UxCgU9o5EnbnWvokOWds7sndhsod3EgnQ+bqbstTxDKu6LBcdTAjNKJqoPCDFIqfLwc6eymydppIBND5IjJdLmQwhLJtJ48NYwJDIxFIQG7wXcMtDQKsHG0czTNzuWI7Kz+XLG7Rjrf39Y23a1vIIjgrX2LjcXnmOFpzk/QBuvEihXKxEf1BC5+rJJEIEqZYLGESSErS9jU5th79atlIeqdWIHNAQstIYITnp1GDQhmrK0qXzk1ePjRAuTzkMBoZYiHA4oOtdK4MYHHFJ3ZkSiZIbjdpQiohjbvdEySJdDxtjINGmtD3C4mOyAxBq83gl0ltzmaFP4ulTS1AJMDVy2v/kvM6rwdrxxT1f69rO60f5zX8gCwGXAzIvzt77XSR+PYKyxNXr/7u7sVmslkiwCxPZf5rY3UTtpo0B71amcNm3f9dH/+ISM4kwON/6/pXo9hkIZdLVWiX5b1VXLKrALZYVMoqrS4pLCquqPxTOiyF8Pfoxv5sxjmtV+D4uG8t5x8FHrXxbIND69H/rlB8RCgTtFLoPCamH6pa4P9Q+onywDNFpZ+XlqVW4Ke1qSwBqdO/y+Md4an5LLYEYFQc3Q9xSnATsvQDQRg6TUSCO1rNSpOQW6HJyVaW89jlXENTf/ROn9a6KDvIfGa2+BIOoBykspFjUClFVHzNnbm/+mnQAF4otNWjq/l/DVNJ8SKq4hcf9wYisQFNOMvFF1VNV7EIbyRnn4hcJp9pGkFlEnDLNRXZjrJdkz4DyA/J5NMUr5eyTi6jTLvYNMVcF8ZRp2Vy6jrsaqmCEUQqQGQ7g4EMKBTBJhELNgF0Se055D/n8X4QKE3mVrhDRKLRAMwBWfqElwTi3H+0giEB2Cw1n82t1JSzeeXK7BxNwJAd5t9JCU+8thGCUoWDwzZtnLb9r8z+kseJ7Oy1ZwGajRGwJUcbM7Cubp+1EDNqdQMGFkI4oQ0LuHzvMHdcwOeNwyi8RNAU2d+738muxXaniG17dr5AhesmYhKVPpI8vQcvTneeO1reultPwwfq+WVXF/DsS4jd7ffevzpiPpdHxiHV4R7leHmcBxTz8GM7P5MauvG3pTkBl9vAsZpAaufNLEI/8LUbKEb+0MAbh9cD2Bz2xavQOb/VsJtFZd8x5almEcBis5k49O9Hjz5hWXF7EOoMRfO397CU/D/t1MVFhSXVpazSojdhBbtKi9/K0y5TcKlcIZuMqiaR/i5xIMiZjz0JKK4xLzwa8wXHxymu72gbwt6icAUkliZ12liZWlb6eWnRqxuVJZ/82G8hQ9WPYTJ4lFa5YOJZyo8zKQ0J0AD2cm5bXRVXlDmyK+DBaFkaykEccEmczSTzKTtcNbcoirEvUs2a/bLoas3Zx+WQlENH9I3+BGGwwJs4tcz8/dvjsE/m8Kk7DxLt7JbZZvQ+3D76Wv0g6yyQkQE+xGTY0l11DxMP6yCuDBum72FZyNDwLcpeTo6npJs6oUEi9HzwdniTWsK2PV1c34vtyVo7kZbGYrojZLk4QGgxU5tm7Le0z2DWvT17090Vxi0+4hsSP4GUXXAP+Lz2EiZedQsPridTFSbToWf304UiEkUopNOsTSHtsvI9EU4d1diuDyYNcZx6kp1kj6Mbg0n6dmQVJGvTzULa3bDh7he973bCg2tArTknznZLC+fl2R5FyeVo6eVQ6Y4kPskSBKaFsuRc98xCwcj80Or50GBlR+6YeZhaVz/XMfQ6yipo7/Lq21VVt6vv5yzOyJA9xCwn2Rply3CojYX8ovDSTb2o1LDUL6JZUEjcORv8bDo349MGLt1ezUhdCNenjDqtnJ4WY1POh/i+Xd1etkxdpjGfg0DwkyBC+QS8Y4CN5cPgSHnj81T1u6Jmfl6dwIlT/ZZs1cCDWynqiQiBcrlj+tWHL5QsMvDWm48L3y4b7ugC+42awOmayqkV/LVGp0ehav2yOdD8ZatK0b0ERlqYnXzDXSbggG8u+xisEEgxN9nJIbpgLS3ETr7vKRUAii+X1QSDAhn6Hjs5TDNVXh8dQI9M93cUm4s9BzcdrMrq+E0eP0Rd5ea/6+B/1lJZbz/97PkVRuzmEYKejQAkAuEQxDdyjPH136DDv3TsDVUAo7C/MPHm5+8UocRbn73X8D+AMsRXCvTBjRejDaKLG0XvoDXf7ypMPEZFfwXyeK4LtufuXhv/zHZYfT0ku+8374DtOOIhd8698gZuH21myyDrTPY6lX5q/d2hOBkc8ZaZw6J5aMupu/vuvp667hyvQIg/s6fyFYjWS/lPKTsguVpIbodStjSSL2WHpJRKdSwycu61c6+OnH11/LXhs69pGvZ+SBBYP4OgXfNfTqs2HVAK2UnhJL+hRYvZ7TxWlp8OKITcpHXmxefHS9s606NtBppI+oeZodMKLJP+WLJJauLvETwm+H1cRNuK6zErfqf3vyfId7aNpNy9F4Q1/tcsIBIJxJl/OjPzOxqS6x+TldRnBpMysemNsdGXG6MN8bnNaqtC/9pz2NvZVpabYT/AYN99x7r2BdgHmffe/lel310l8GlFQr92pQAs1WjrX/h64qUU/b/4jm6mqd3iQ9JWHM7yQ5KeANH1Bv0NnobJ6L/rztjpN7qadvBCyMGBMxrj4W4vcHJg4ATg7buoc+xvV+MGTGwa6sbh5KgK2aSzutRcXIeFwWhkly3nulbdh2FzG9EYol2/ft/GXZ0LFsuJyLq985spnrz8p/bUCYpYNc3vYVpoGhr69G5YTs+Qw8xh2uS41QgBGvRZ29pcJgGdr5Oh4wevJ8njmUV1wV9Hp+149YukNcQXHmaWl+WUV+LKiiTFA7Wt32+6fFpfU/fk86lGZlszwUBjkI0+DLd0MWrn2uXNzEjCmQ6OQvxP4vGvlKxZlOZ48wzi0mS5EqGu5YtjmoAjZs5UjaR5H0fVpawp+eHxLlhAJJDJK7cZGvkxlR5oqCkvSTwoQxBLyw7s2xPO7YNEOlsq6ZboyK6GhGh0U6jClkh2i5xmkjoqhUllNDFVj8OaaXSsyampWLAWw6O3LWP/Y+/WApBIUiCrV/DF4VuxAkW9n7VAqVjR4KZQGlwNwXF3g1hqLnIDdu8+hp3a4qBab5udwqC3UYQuyPH8KIXnNEbIALap7Nt3+vbJqB01oaRjTkXP5OU+XdSiVnP9tJ9dXR/1cm5r4fUHPDafc7lrudcGfqb6FFS9936PPK8ELvHmsV8ZQUmbZru5mXTXiJa86fA4WCqer4K/W17+sKrqXXLte3Vf9eG/KpJ3mAfNZfL1zkFn7M/mCOivL+zy7LrQn6wtkZ/MHkw3vFznVP8p1582cqGv7/ryJcrwr2OczU98lsm0GfMCGzsUtLXtPFFqulGUbpVled0ZirE0FfNkqTrKdYiFXG4eDTuTIYZEeERYXSIvxBuOOMVTJlMRo6qKUaz0NnbotfrXDqXNOVOK1jZu/vSf+aebBwhVo3VweN1oFXy0EA4vHA0iDGB75lAc4ohDcjrtsAfKPCemSUjS9XcG0rQygyO7PZahi0NES+1Pa/JdlAYZ1jDY7oPIz5vgU/FrrzfnBypDrz/+66DB+G9kkryCldkpYplulVTVs5YpYndSpYFs/iTk4QABrhUEVwGvZIa/kiPKW7XsLjv8HEouohHF4HLmNGSFWBzuYvAFfQx1OFf0EB+XbXJX1k8S0U/RJ7IKDWNeZ+9YyJK7wUCTYWbD4z79KiOZJjPItvp7sxEXMChew7INzALNFsfWUBjkgUiQB+77JXa6fLXEwlNkZC2HLlPwLKslo3JH5DUz7uOMnc7rhyG/I1vYWRm/7ZxYf/3vN69pA6AvM29opi8QnOkf2sw9AB4IJoKjaX+g5heAS2LPeD0Fyf53QgWiZCtoy5dG3gkTwSnOVSUIKrI16ywhWmnqJB/efu9F6+QSZGczVw5yVyxGcEGQO9e+vuSR9e3gMaInSotk5BZ2ydreXMkqpZCNXhw70h9codgEmU6tRvYji6iHD8t2JAvQ9sBc92ucuO4MM/nM8IE7mnV4OE9MdzaZebYJHh0bDX6OfOKJ4BOPBx4n2RO1td8G7wXLame3Ti3bRKJtPYkFhA7YADuGFGyt2lVRsavKm3Ms8T3P968OmfLMYpbvotbaA68HXvtg4utBdO1ocKGy+17gy1Kvp9Q7FbhlQebxeLqKuqzbjb/r/nNzIY+KFjSJDx4IZqjTHZIjhu7vmLlfYH9gr/u96LWwI5RD34dBD6oejp274r1yNnB2if5c6Zj9VbtjleH7iuN7z0mzkUaHUuhkVL0zaOxciTS2qYSOjj7WcdByZll17XBfZaLhLvU9jLz2LR1O3tSkbCE2KeQoHOCk8PotJA5B1tyoxOHqlLLmFpYdN8ePhOy1oqb+fl2DdsTL1XXvb0M8A4c/BdpFTbumRY1Sxbwww4cqvt7KQEEApYAjyvDXt3gYqHRAIWjMa380csZPI9P+mLjwzo+ea+d/7Ozo6Wj/cfDHQz82rIkcfgRxkz5G3Ecf1WLCpJYd84nv15q9m9/ABJb2PDJwl/M9lJagUEAMOqlADbvwcrFqnWm0YLU7nLM9TNdTvctsoMXamXwLiSU2U2islhaalMMlSmj3OngmnV4PLo9vdIDi5o75n497NNTn40Hj54+fLfF5p0Yu//ZsfrPe6RGgc0+3k3361PmnqCLiDZXL34h4SGwYTeia6v+3ty/wIRCJM3+0/VE5n/R67Y626zesz+rxlKMaE1ZRqeGjdDdjL1uTMiqdzuezt7UlXTteAb8z9K8wF+RtwszIZX0vp/iNpGuC7EUwwHJrv2uUdQQi/etc54WGka7j1javV6ffSUW2b+uHmvm9LdC9gfLH0tjW2mJjWwhuNQHpOg1Lbe/tqy/Mzd4bO4ThcBDwxvtbmT5YFUWG+tCb/8cQ949kJHHD3kn15E+yu2eWzg6mOFMo4b2aSQ2nczDZmTJ4fHqxiujI8eMLx0d6e09UH6ypqkKcr6511jK9FJqDwaA5vGTmcV9rtLf3ONNL3jkUZpFXn0dUipqD1SfSPH7s+KTqXJb+zpG3ryQ8PyXMT27a/GpNhNEnH0RS06bHAW8naTRWzk9qevLMg8GtTsed366rlz1OHK1P0DTjNPqmH9gPd26f3/4Oe7XjaovzscefeNxFPLHq2eHbH936eOgZYkMBg6HXw4uK4Todgw5pODJu/NHtj29xxMrSyKbTrVHWXQSHHGrigr/28LODQlYCL44wIGuUcEjWGS74dUPPzsM9XAyHF+176JDM3W96dwgYuuW5NcSpP/y4q7j98TAwfLsZFQd+JBOcJnocpAlQQZoE7BkwzScVYGyAs1ZYKpN7pANsfp9Uxu93pnSP4/XLpLy+GsME5nLkubg8ZfbTyzOfO/bJCjOcBGkIIdnfJPlM9Oass0odauC8evPPSSFI+qldu/P/MYz5cgBoPoe2DzjBbM1H4rKTgLAsAK6MVn+ttUGKpHL/oFBUJomVFoIOhvZXjIgrTkD+NV97ggY5SPqPyldvxk4q7iItZeI39h5vYn+dNHSAkyCl4p1vYEBlzsUHfRGDr59gGWv7deszrL5PgLKyeOedXXcK5En3n8VBiu7gdl+Opz35TrxO5M6RCL7+zfrqIu6+v8EU70EhxFcjv9qXy8LhXBtyay+9GcnT8NM5LoiATLbk2hD4JQhz11CXRJhYsTATXYg4aJgdpc0iEArazKhhBoG5WJLXTcgrCrllc3zmFqYeD6hFfHoyLceFqnxcyQZFKSwpJlReYcVIU1igCLOO0TDd0DAl2Y5t7dyzSrNqJa1cV3YyxFRQgnq+KCtHW8HOJvGaC+mosdyVxFxOOYm/EeFqq2xDHJSA8O5VK34qUOp4o9VFhHcQVd8pEUoH1SXDG+HtGuTb7YTiuyWF2zBua3cxjU/kNSF2ebu9CMSfZbXV30Z1a458in3/mRtM19VHcnO3N2IL5e/mvYrAcnGtm9/ETteVLq/PUBf89aVgxT+Za5qKuLc24IJwhUSByPsr4YIbUVuuX92nh4xMYXRijPLNn+P6u0T9qN1DjGE7ZlmwZEsz0a7jPuQfv9I/GczJ+kGymtga+UXusQ1edgOzBWV178lxJuev+d8NKDsHV8bKwLOaGjISgpzUciCDALiuotZXyeS/6w7gZ/tks1avZXJo5laGBAXOcF4Woz31RvB+aWtPp2BXFpdnd0eYXSkw7Lbq8lvfCZyFD7L930YpZ8V9FicbV8ZaTmA2rW7Kcqy86KGW41nLTo6fHJy5hSnBEKeCRd5xb1ltmlV93AIZSfk8ESr1CHOXt6s6OYxXXYopL8WWwqXLMaffurl+dRlLbwyUlQJhWUT3vtYWUiuD1FJsUhNYTAKeyRLhnYaf9+P/jEt8sjTNR0xDtDyZXeB2pHqsP3AlYyX5DzZbMP6XF3aiBCjzqWDl4GZg3YJQKP8rOi2Cy+0KZHWa367l72bcQxnuU+d+lWFlbDi0m9xuiU4hbhqpMHQC724HGb8oIAk+kZM6xOaHj2wkvcs4eG/Rv1hCLzJogltZXkakA7QMC9vbanah6c88v73zWwOt0+ETQuNrVIa8zg3Xz+34rzzdcCAmwHWExkicwgzbqhhQd6EBoQAgFMoQKhIMqJ9wDgKOW/BBiJkogOC9tNAKOADPB9SCznorjhZeLJJetAgJ7DUikuth/QVPgN0N9irRkfXnGOc+wlE268RmdAfTu4WNKio5ybj1wv67qczhDMQBDuWMatd+h8XoqHdHgg+SEokRYZ/pxnLn4vm4SmDr46xBqOJSAeKMQ/cpmtg60QF+XkdIZ3qcTXm64UBMAAGmAAtTwAZT4J1KmRSCFz05NkfJ85AMG4Zg4xBcIYTOoZ1o5F0lzHEzKQHHa5zsxoKyrKyvJjrlV86opSGC3OeL4AvmNyii9QMkzKc8GcB/dYmLfe33SHqRzNlOdpnkQPPlVYWCE93ivg4054h6WhjwF8uBieXxF7zoydM5SjWHZNgwBBuH4AohdE71Gp45OojC8rg1+SjHOuFdNu/zbOTvnZOAdRAXHUn3jEgIEOwEMXQAkSNyqaPwDglQioSGD3IFGYo8yQDaLL+M6Rq4PHwcwbpnGcB3ZDU4kAikyBNFDB2w0REWOeYatQZFyIuDSBds1nO8zjhg3z2hIMBuz+LgKsFu4GN33HVHeZCAv7ehUz5NZRW+7O+WwrmOVxMwoftcaMlL1on5YvPSVwPTpPZsHgxcJEw4SltnDxKIYgE/rA9jEfryMtT6ch/yz/CzxxOc+6IhLWQjQbzm+ULpeaLGLKE8XrNtJJu+u3kh8Pr8Msd3VeDLE3FanOTLW0Ppfspj9W1Ydjek0aLSVGVdyqt9LoK4Vp5g7SjC1vVO27AkGkzFZqXVsYCamug5WyGLusPTihh9KSfxZjHFzZKU14HC01HUCq6wYT1LURG+iemL2CjfMlJHd7q5X8nDyHaR6tb4gB8MfhCL0KmPUK9Gvy6JBlOxGbfKC6jPetvJTIXzS4RCJt2BVRELKe9szGdCTlCssKFp+IuMy/P2HNPrRiLn98euNzPWyLQbLCOvgeMpHAmKFZpYgf0H9W6Qbi7MPTTSwgQ5o4rjsaU4VVRyb89wZ0B0vfG20k5H/MF7AudxhZalcNf4XQJnrdu5ByHpmk/gWUd4sPOTMmCx7tTOnG3tWS6ejw+fU/nKPWgIlNXT8FPeEUfPtmGaYGIzcZLp6IGl6UYfjgaMPgSaMX4YMCx+iJc86Qd1Lsd0ZtiQ4cY6Zk60msPjRV5tLl5XZVE0ZuIlEH2iFKT8MNN/AG5f0yL1T5M06mg1Vlhwmvb1aY0Au0kTRFVUyU41kKPxQWuTy3U1UxZKPcIU+gExYQ1TBXonULu4nOqQNeqXoHi4z87MJKVUa2RvhuxCONsxS6LVHNpe5/X0/E7j2kDAViHqqUhrvOmdJey8m/Bom0K6S4KRDnzSEWMZYRWwOaXddTBqjvOobkO8IsMshU1mEBs/0qa8sl1jCjWCcfYeDOe0j0k7x77pATxomrCaI5bd2R3NLcUVKtYqrLYIW9frrELChj3/lLPYWYEmGn50yJgbZdKFTeCBTVClmpJiRerwoiG1FY1HLDufo3tKcYWKtQobKMLW9SGrkESDUWkNLqDuJhpOcgLaNZ7MIQmGIQkeKlLSLjoTXdiCDkaqOsz6qM4kfKqTjdZOAQdkX7AeZL4W/IYmW2xrliTP2Ih8uoCBBb/HBv7AZDjH+p9J+sAxlrq+rb/n29zFmNxW7Iq0OcIFeqxL6QkyiiYdqplxP1JbGsRm3bZQIb+qB3mMkNxnxEVGNaDAUSd0lL6JlmcIdcg6ENuCX1Zni/nZX3w734esA84u+J0+W0c3Zq/e0vLsvNE4ptrexHu3lw/lLinQK7qd/pgVNNdWo5ezVAz197amFzrmVg+1k7WVBA8O5G8kKOTIY1b6zDAB8oVSsDnbnh2oRqxEHWUoW6/31pDYa5jqgOLE1AHLevatjvDWFTOY+mY6SwIOJ88E+Pp4CsWbIHrNB6xwFWBLY/abQ7MxdiVvDzQIZpL4YKuLzDhb+H2NGk4l2llSsum3J4D39ck5ObtP+TPEv5i4N1G5qn/WJ4l9VVuycn/1CvvMtjq0tmzX5S2pbiLFNBOaEDO5UtFfm6MsB6gYCoCtxhLvb0W7dwYzfQ4/8fgG2mKiP42R/sw3/bk2/YUG/aWP+it1H9VGu2vc4dc+tTswWvof3emc/07nJp33T+l86YLrpQv//eyiM4h4PAL//2/iU3yGz/EFvsRXslb+33yd7qVu0b/hKTyD5/ACXsIrqK1fD1OOXL9Je7KpJ8/Pu/9fyuBzHFXw7Wosy16EgGM+E+MmMf5lJXzNased6uAEngVTlHoziA7qKj744IMPPvjgg19KUPPgWNnNDKc3cMpZ2lATCP50M8h74Gg+Edm1UOhsAP4q7dikE3JVTTvMC8udZm8rV7Fm1aM1HdkJGftvTdzcQThy9Psapr7iU3X8SaFf1Wv3myQK/u3dXHA0TqN4jHYctJyMxKEgMFlDu8sazOBF/5vDsomxNHVpRsNRvPsYFo3LItiyn2y9sQzeXM4VKH++zOBqrmFXtGgrBwWzzNGntEZy5FfGz9KxC+9bY564pNH4ZU3910VYkaYjafE2WFTy+XikzacxfXdd+F438e01G1u8e9BhD8ltTqdatvkPeONPb/q9CLADd72vcwrBne4PXBYECwiXv87RCFwB9JsHF5I12jI45UCKUB2THnc1eGdRIwjJUZAKsVGSxQrUTra1DbJsKzlRwT1fP/waZZfjsDq4ACDmukoQZRRzln6xxcX1Baj5xjsPrie+8/Hz/fYLpnfmSCpWLch1g+IcbKm2mcjTOts47m1o+9SEVDyhYiWkospITDk/oaXvIebC+KcXyJUGd5xBbsOLHLsgdxyUCOBXPLV5QHhtfpkEtPlzAm25HtFpWrVj3Za7Ul8zLQPBKW1dfmatteRYpvUGnCD1LiHLRpq1XzQ41NB1jLBF496JB8F0sQcQSUVxQWCjJItVYqG2ObFQcMghCPagIIUltuy8vQX17bTQ9LaRFGGg24hZ2DdThaZzQO9ZAGlXOIc1paUwjaAsWCOpm9RtdIQgWEJP8hbVIIA/RVKDArS0t9FvqV6ZvE13MN8NCyJVUQfijifoK6FuIyPagcW6WMqelLRRGTeOOIs0i5oZ/2w4H4T6QTqLuOTzJREPKj4FpR0IlsAo77HpYXHW4p2xJZKDV11hMKkuXCW6qLluJagYzKGEbJ84NAh2DwZ+tdThQSPPHsXUja6rcCYdHg3LYe+TGAjpE23nPbQxrflYO7jOA7RQWC8YdX6NZF/tcal3pSE51TbJs5Ai1IvJ/LvodHHCNIIQ6l4V4QxJmtnXTq4yT8O2saVTR7WGo5VKLUwzs/YpQhlyPrbmpOBGbSd6fu7qMyF9YKrlUHcn4Xfsa4pm9pbqSkOfNdyRi53iXqZXjcXqDm0MwKBXaD/W3YMWkvdTp9cWCnIR1x7LIDfsNB5wRAzAHRebY+DHJ+X1M/47Wz1uIFcpwPqwPm/oGAS5VaeF3ERfrMaXVRpvCVOpITbUOKgPnn6hl6R1kV0p8hysj6fapTQmReKag2M9eymJ6dlLjT3RSLxxZNLoeg5hn7E0uoB7FYJmBfCBhVo90DaS0hZSAkkGe5DAxkktqKf9U+l5T16fuRIA8vboiN9Baw0jj7Uezx4qA66J73Q7THCtn0AboTrBx7XAN/hO3pUYJZdAx4mknkT9AcLUENOoz7Sy6qStt+U8odb0jgzM7W3gNBrKXToSqyGcxqFR4NKuVckVA+jJljndeXdWeCau2B+XIlxQb2bJ+BZSgireEb9bd7KTEkuOA2b4u6WBtWTVSVvH3DyhBq6WZirQKgxSRyrfaRi+90xzzsCyQtAsYy3XopWHu1ErteZOJ654gPnsCVOVe2vyvKpjXslekgKAVoi61df4IVB27FeQI1kp+0uOUZBbpMDtl3GVSMkKWftlJWgtzjKk/CzizJk1k3JWPsNIjmR2gCkcMEo17LM4Cw08epGz7T1jy2qtqqW1U71Af6VAWPPUPoCr23Rjz5+3niQFct5H9jV7HHZ3V1ADXzQ1ZH9aLjsS8z3COyMj55Up3U+B3g5qbfjw1OAlP9I/d7xDck2bXx5XgFyU6aus7i6lT15CS3qGe3GQsJFXfhr/nUi00IlhsyDrbsBnBFcd/RlAyJVmvS7BysKg1Dr3l1KjrlJiPAmtf0Wk31D9mgcXtub7CqYYry68ysRVVMC4AtuFYsvOL6b00tzSAWZB1BSzzLlLQjL7v2fzs7sepFMBkFjcZ6Q7Dh3AahXok7vIeXX9gN4FR/DGPaB00XKuaIhm5SP5mSFtKamYU5kHcN/oZ9hH8vCMSYqhYXGcNM71na0w4p11CcmlLpEmyr31c1IVdppF2GHYRyLqIhdHWJNKHpYqw3YhJl0B5krtrz0cqwmnxZHc7N8PSp2bdLDoLimc2cXhdNSZXUxFXqCXz6XUPtJ1L1tOVIlCFmGHYR/J7pRLiiO8mCSNY+9shZhxM/DH/b0r53xZLeiLLbzsJye7SIyKy5rvVeNo8qW1x7WZllxKnWvdGMbHvvP4rdiw2i7uLtZPi5y0cONQcfO45E6KCnDs7AonYaPkDGyUrNv40WUyua19KCV9qQWzePVLpe3hTJ2FEVF5a+t9ienog9Cyt3fI+0l5eCCdwS2d/ax3JJp+1Nvq+1Gtj6UnV2dGsOJ7JtbY/iPuslrIS0YECJq94E1z/Z90389HwaOxV5Uc2cQJEMqgFpN2jY0zgcYLqUC47skTDNZ3v7+dBjo4uT0b/v8WbDhE1xuAk31SRI7YM0fGFyzQBU5BRu7/3Gqae9tz5a+NwkllC7Wq8TvT+Jro3CsFlG9VyBt8vRUEq2QtD8mr1A5IzNr6YwQaj9kMRYxszycAODK+UAEFMhmbaNPY/fj9tWy2U2OItr9DMYRwRYutgVHODBZHLURqE+vqIz/wXBsbsoH148j72z+p2euHHLIwxVLcwm+wcQFZW8NiGnCF54NeNBWQ5ydMtO4QE4E0PwvT74CQ7JkONfWxV2UMeBd5b3sOs6OdOA6NDoma5AgVQs8KafudjtZ7FQryseX9XeOVTnXUJkbsDiQNHNvIhWTMuhqBh95Y/tjOckCSkEKRjnHaZgrObmSijBciIjFaJKe2cW1TEwCEBIUllu0q+ODiISBnL6e+vmVWZotZNuzcgv8TaYL7qO6ZT8YXKVgJ4KDqm4na/e30Sg2loCYp/xBZMqWlRXiKVnKHc1NC4/m2sIPNI/TZRdqz9Y0QYKwWAh0dTR2j5KeJuP3H4f9NvT9W+i42prUq42O+Z97j7602kBVT+d16yKnkNkg1KTG7NyinryNASF1/jRmDxvF/6Yjki7LMM54mUcgCz1Hz7q+4jUKNDyfc6G2D51OnJrNRASFnyTiCWqVcFtt0l1LDGRkF8R5NAVGZE9NKRlNHlfjm6KI+aDJqyXatYYF0C81HBlXBAJx/YuHoc7XjQ2AxVMlcE62nQ42nHhdJI93zAxkPFiyZ87i2DniSezi6GGj7IlLzTmV/Fh+p9hSC6K/j3MWn/OE401lPvZgdkoYxEar5MnxPVyUfa0JaOvzRe2wmctAE+EEIpS6nrUUdGzTXkbjCzjzDCdk0R3rw9X25qWPE8wtTbEUCtazB1SVvwvj5b7O2TgQUhOah63uGxFTkvmYyzD66N7mZVmowg9E2lplPI+A2eVm107iLJE3ynVZJi2JX0XICjkgebUBPt5FUtCbncWoezHV2DzfEqygPo0RnzH15eWaEz69RChY1N+j2wcpYddXjVYqN3joWZvzZkoop8nHMmrD5X2PjGbM5797n7SjMQ9lAAhspHBzKeng+ij0xLp9Jq44a9ccv09xtqhqB2Q0a3k8NZKH2ujDFeEYsQxv6C4GGE5AI0/Z8lDWsffyC57m3wfLmclR8C4Wpj62O1UuEmb83BN1KjML5ZpjhBYAl4T6ScFsmdOgtOz8RzugO8SCQ/j/3dkERxoHn0tIu0Ta282yeuxuoSfkGKVPgBPORnS0JKmenS5UoBeguiFmtbIc2/KESn8/mLHz4NCfs5NK9Qd0QMbT6IcF0EKS0xzy7u4uJIILpHUd+yFrmSn6sv+Gf0f5P1+Fmbn3HE5hLfcDSePBcNKNMjFIy5k75vfpoYslLwVudajEAzSTAGQtm8BkyZvYdZ4Q+gC18MAU5qeKZEGf6O7G50atSYJvH3fGZ5OeteTOfFmCu4rDkVOgUkyvhpjHtd9G3GKStczz1ZGZT8qBSScaj8mfIWOx15CAyezAQ+Q6QnQnLfLp6Em1oG2yUrcPMcu+hoDpB0jR/uwOJexBJNpPF0LNkLEIOY4uig+0Oz+4L3P0ma8uz/CZ+apTT7sAi+UmRdaz3LwEd9ngKcrJ6zBhgvhpyfsZmqidLi5ETKmZkfuM3Lzlj8qPFhEHzR2z/MqP7iM8tOtbhvtVqGIv4eaqN6HXnqbxwplJy+eVnqOvgZiSuyWQrzazcC7MO+CTns7xpsUJ9V/eiHKJTvkRORxOPTnMX9QYilGCDc3RQDeigX3g0KcV02HK9TyxIjA6FTBwZrXUs3Pry/jRT5KQRbRh4zjJ5k7rgmC+MxfT8esHKFayw0girvsCzT27PfO/x2sWKqpYaKXJaeohcRTvp1hUSb9XDTq2MvHcn/FCjAR3O+tMVvV7ln9kpiKO9Ij89DvfbYd2Vuch4EoWeQ7Axr9WLX2Wm5D1qYxgbz8w7SuSYHQWexcSDOyO+nk6HZhxiJyJHSIVEHFreMha6c21uThTZN0lM4+WQUzi2eDieDlytEqY8Ik3odh4OkfTVvIPv5iqAN4hgayzT6aI2EFoeHWCQDoAJU5UfcpDU3joYOfHmdZXGD92reT6Pcw/6nv9yURVXM8OQ986ozW7hMrlNQB5aG8vcaraWvPfQ9lxKrNaccPgeL3ugHb/wZ1UNJRMXbBtfEb5sSewIwzE9bNJ7WpqfKkiRXnOFhJbqIT+O/ToXSUTGd/w1/xgYPSzbLOxaEpGgAlMj1uJpPD7oIeY7Yi42OgHY2j3k7DQjpZGLqGVkrINtLOlNST+A8TyHYrnZDeE9WmLvkoEgW63dvJELTDAm62j2heL+KOykxboVvDk6uJHE2Qm1KfHPzBTYKFHk0zRp0oYFrm1MJbnhgI9ME3gluloSvbW07MjFP5kVc0m53RQYi3V8exi2rM3zogLieqdvr2WtU8zEMt80dVUWYiu3G5f1OHef8HUG3/U6o+sirrMT/ZMaIobnNo43XoZjIvzRoQ85SGZ/0epeL/VW1BUIIQGDCNjaIg8OAfBQb780YnWtha6FmKELn9Z3JvIqW+pntZFdErqBUwTeuOcg1ANztXfWrF39LDnh63sKHVXCE0QaQ1YRInZ0HmFRJryEHCimXEo+iqMVkLEsD/MqGOM4IRmRAi+y4WMClEiiq5QNNQ/rRnjr6i3WPIFlNAfQTau/K4Q7C17Fhk/fgwsm09XjISjhxT3Gsjzf90EPg4znYgE0mPptfKS1Oqcj9KWBPnVnhAjsmeOZogXS440X8gCmqK8B1GHlekeoikAZCrnYnNl9VAS7AYGM3gBc/UArm2Q0Q6uy2YJJpLN3SUMwKUSEFlTUI2khTH38jYAL0FUzY+VzEoOlLZwfe26QpmDO+EskNKwoAbEmEHxGgC8MsH78xtcPG+VmyBLxbUADt+qLOQbbMOEobNNEx5HAd6gRu/kL/gQZ6rdGyg4j2Y2piG5cuOs127Sl42dpIgDiiO7aX2bXBGUsjJZytxFAuL0R2eo0g9slSGehZ3Ge7UrEMrQxxHa3RB/Gq0pI17XNIzaslL+zG9GrlQty24ZxVT8ZzHnVKPdM3HFKLleqnOkgPg0t87Cra64RIIJLcEgHW8fMZxLEboc1n+sB8dHQGFdCqYtk2Hrlwxzx+3Y1CZDOZf6QE0bESTpaUdJdooIELhGnunmcjnt+cHxUVgji+lx1LLzLCibpvlCX4Jl6iE9PpdNbfZvVvddbV0dR2fRab1UN/aCdst3aaJPayG5Az9e7P6hHBqAgYhnqC8D8lGJsqn7C1Ux0Pd5HpwRqZ7bqbKvPImph9n96uJyV0OhipvDYoEL8dGf01yYubswhcSpo/HLHiAhvyth/0br+PntxkNlUiv0wd3ndBKSekj6ZJy2ycLStZ9t8hlTDD47bzOqSD8eHqQkXXhSKVrHkg2e9xiN5Xf8n585pZEe6BOu9JgNehh2vn4G8JMu0z8YKh3AM9vwwcBmT6OlmkFB6JqGL6KxF0+7aHb2K9GeDUpATwmsOonTZ9+ILEdvS8mq6CkOPvcQKtOrpIBNdauvNBuVWIQASiG8iiDSMXXuFTDImrKF3vOJZ7DGeIi0d1ksDzRrJwFWTZn63Neqn5PdwRUohO86MTX1rATbozaFZo7YXGdCYPiCIREyhyX05jAzQ3oOyDgNuZxsZrRJgfZ+GRNBhJEfO3b9z/zQtAXpfOz44TM2Gyewgf1SclcHcYvTWcHsomKQbkw1s9KdPTPEiBjq4KmjLNGhen6xqMqqN0am5HfHfdjXDuqB6NUFf/nbOWQy20ycfke/Bui+SL2UwYAMIQe17jryg+VBGlCORMhh5/yJSji6S2CUmljsHpLGgapnGJFiAIK5lHPAYEjT+uIVPYyMFoAf+dztmpH/U9NFaLXMcRDrxjVpPqW4bWgzEva6NBflu16ypEcsN1liPNAJp0CI+0VMmM5qU7LYOOnimNt1wUUMj8zVYnJ3HtjEdAbzQmgROwBM0tLdII+hRok+inistzpCJ9eSAI00ATKj9lzSB7V2MjnTwj4Ep+2TAWIYRUatOJPa9NjT8OvXXlypYMSfmbpCciISuP22iEjEwkn84DF0jtcXs50pxUeAAG3mahCzw0V3c1TF2sBYDglRVkN39CAlzAL1fuZiL7ogDY4HrxFWPfvBkAgkQLQ5UkpCsRacL0MI/3kfUi/9W0WcnISiCV/eQNKrhBfDgzlgDzO9rEKu5mgxhfJUzyefePB+k+R+1ac6mAx8tMbH68J4NH4TrzTe1RXDgedyadyHS5vZL1mBwtw7KCf5fg1ipTaR87vLBoD2UJD1mroKt2/WRjgjE29jCjT7tu90Pr5KbwE93kKcKAT8UCTBxd4VyOIcqJijhYqLHzgDUYpiONCFOHfFEKKZcdToeUgI+d+qn6D7uSZITrlbCrSWsZg7L+xJRGG0N73vF5+FqSHO3KJ6ehfY1mNi8rsHNLIRStQISoD76kuB2uILygO0b8QafDqDT4FNbzuFJEOxgZNQci0iLbNrnGxeHbGqpziuHfNq9NcaLkV2dElYmW6sgYSfo4GXUYNg9aghmmQnCfQ3gKWcqHhpqpwgCRLG9mnFsL7dw/699BKCmxZtEIo02Y/E4dy5I6UyOxDwTR8I+sL5Zi8rhad79Ed3mAPah50SmcndxZYaV0sgT5ddyTstB6DsOdzlJLMVFpi2Vcq+DOhOzmKQlXUEjHF+y72sx+mysuBSNZiAV9cuzS87GKJqMLuMPjXGD5jtVKSNok7wiZheSleriCSudYWw8QIKwfDNYWBMwkllCcdjAs5BsIeUMcXpfDm9x0xVKI9pFmvawNI5n13SIPpbA8eEFcFSi4mpOBNEiKDlKe5iGmtM8mD1h6wJ0LwTXjxYTw208S0wzlreJsvr9FB4UGe6TSYXPauBQBsULfEnHWHG74UozHV5EMG9zZCjTiQKW9uA0vOLP3ShADZoIC5JZQo1mg+XD1ajou7eR5y5RWzkIObW2/Y0Uljrlozwcpetr3imGwOYdOkcSPfONJuMUm4p801RFuuVb5jvUTHCihCz0ssI9oUZTreZj2gXDlo6HkJQXwdK/vAuQCC0RMqp75d4Xhtg4fv9goJ2v3LAaVOeRrO9ZSDODFA4DVskstUGK2V3grgw8MoBTnyZeMOm5UxtQuMzvwOAz/w49S21g5OS5hRTrdyQ9CsmY2kZOmwv6gyG/TQTDx/gHTkbwpLkKhrhdAX/T2BoHcSTdLsPGVZjDxTGymiY+EFZgMWtqjm8VYDahYiNwYD0SlMv4IgYHNs8f2p5mPRoxjOsC+DKW829GhcIdwugh35ztpAQklP5b7ZyRJpjREyywyC8J35grFBf8vS+isoiFYYLOvUjHU2ToeLEfO9QyO5AsYAYWYDz2dE5l812BxtudTMpsEmV8DOrC+rkK9Qfo4s8y9jBW5JMkrpPad5cdDR8i7i37SanoIHqg04A7DT0aAQqC1sp/HX7Wr9ElcacD9BYJMZjEQDMPCQn1FQNMfOVByjB8H+tsxVzEMOzPtQitQ2RZIgeShtUl0ECfyiB4ah7OD13nXkIJVNl+mSKRQxS2/VdwrsDi8M01p2OY86otoHZyPa/3MOU4MWnt4yLjudA4Zhve1GP9uj7jV6iNfrJSB+KfZg0ggaL9DEYVIFCk73UYflOcb4qwEbpWQa2Uge+qaQNIhK1USVZ0EO7bvAEkgtQLqZXfJ/wcbE1b1638++gqudEcEk9d5aKDWpl3MdvUh3u7KuHPJw8u9nc9AhJ/N0jJy5gf+JZnuilBfUvtFHSJtMsyOgf5F6nUqxQs7MP9SX9mFQi9DsWt2KD3Ct/ig2kBEtNfYPu1CD92sWcAaSKoDOhyqg8383ctSSgOfOS15MFLW7wN9ceWGFWpkAVMVkUFhN8G4F+VUKqO12GrdnsZhgfGPx+WwpHlORJRmm18isQOe1D0YB89XMZ30T3cjQgX5DsN1NIitU9hZEYnXoKatQlCftnMUMJKSyS0mBik4buOnvXOLUnyRwRvKRpSjskkWG3QdcRnSGPmxgCXcgIDRXMdiuFHYX6DM1QhMnqPassnrVWvx/QkGt6KOadU4SGxzg+cOksk3djIpp6keGLWq7XHJ5WqGmSfJFQf+hAFzgSSqhlIbXjbnMAEJ6k5isQKKPVQ5kJxRhSWMthzAucXnuPh4BngXXaMMVg+ITBrIkT3nhcnXuowJg5e9nYGMcIgNEKYvoEQrevzsHS/AkYTolOPySR/NPyDcU6+xN99WbJO14FnEzPGMeg5tFbBPqQJEXq9iwM31+rHOHCEx0sWrjhzpi7MF8czRxNzH2vO48ATI9kDJnt5cA8Igm8hiCDhtkQupgHKSxB0cUyLGkaaUGq0CwJTkEd+998lSDrQ/SHFZ7En+Ho+N69pZwB6rgV0TkJk2G2liSH8zny9xBd7W8LMY1oKKViEB+F7mMAb2bK1dbzlExiim14ItKnHZALSKmm+rsRPhKxx0VggOAHY3Jvc4Ffs9iOkT1o/NLP9pc9PUyltHpQG+er1AkzxkZZj7BR40ZoN2paiSoqPzeSLsmS/txbIr7GN3Sjnctr2N1BnGreoJqB1W8jlRzuqBO6D2ZHKryzvCl+bRHwAPOgdigiAx8YYNC3GZTxrsLMSVRYYnueLpjP0Vd1ZOck1yLS9Rdbo8nQoLUAR/7qFbWF+fiOVtheMGXXiSUllCbhc1ZRxi4ANVWCcXwAJ3SFqEBmjleWXH+DAyqwmI1XON55TaOnUU18FxptYmN3hzxQqWp5wUzzQV3jzmiR67+f8TnluUCeK1odrHEHGo3zzuJ1phYT7kjHrt9JfSAukhpkkvuuSkqet4UazFkzYRQrzbB2b9F1BVREX118ugHrD1wfjbs0hny6njT2ZtjDTc2lM1nhia8YBwQ+ykb42gxqAEDkMq7pu+QII/27mJQy0LTzFwJ7FhKBuqZ7/WpitoXhhHUH18RiqycLp64LFO+2wNFuaZ+N+KHADMCIHYnkm2EbBAm15Z7Etl02CnOX6iD3eZJnuS1pkKFs2yKlnBozx3Bi5QjA756sx7yRGggWpi+JDjIuDuXy9fsUUOQlZERY2WfUcbtjnbXu44sfNZnFmzgljYR75u4wsdANhXvYyePqSOv2sCVefb9hUkc+6ap0L5tPETrTENo/pa1Iwkdmg2wIXXAPZGjrLn+7hMRNxqwdEshTG+fRSx/Z3VlLzOb4ocpmlx0Sb/G1AkTiBbgvaRJBy8HQvhqp41VIU5dKdJVJOpYbDGxhfLs+3Q99VhRQ8oXf2XbKJsaQ+MzpDG3lq3t84oXXje0yyt159TttflA/yZ4OmRfzwwnTjHTwFNkwUOYzMOeKIBb5XQGUgITWMC8NbIpsrti1N/bbrmkJm28Kck/l0Y2+A8XXu/UbFG8KUdmt3dGsm5dRFokooxf1mddzrp6m7WF/ofBqLta3dJnr1qq3U/CIDE9Yk1ACDkcwp4ef5puiOwh+orGcTSTe/XmaqPx927fFP4Nlpf3e42/TtrtvxhDZ2U9L3/Sqikk9eRvUqFZWobpKQLQkExInvE0CmyAInFAUFhokYDejrVnL+ulKCSTsCfr+kqH76bwIw0yuvvvB1lspLx0NOVV6uShT60KtPoF5m+Br+6A/g/dfev60vDpu+OtbHJNrKgGebzlNh8fhArLEkg4zO9dLdmCHZDwgIvYV74DL5IXB3qwACIbbb7gdkvrI4PECcUQ/vHThY4TzaCs12zXPxh/9HD/40hT/mrysFJ/364Bhh0asl08RApgcaNAxAYtTPPz5+/w8c0ZfxMj8jeAL3edUODVpsNM7+ZmIIFF9TecZSMpWDPLPrEWkHIzEzmND7zLzlr6OlD/3Ru1q4jUZFudlKzl9Xyh1qeAipr2Wqpq5O+p7PmM/n6WOgw8Su6+mlZ2YQGy+7JPkA/fscO47NsGEFvBBSUUF5Ti7qXkhfFFoRIeWSXNTz9rSrbzRq7GaNzii+PymXiRfKh3nGM03hEfwgNnJU5p72lMHPvCvPyYX/hXb1gqap3RnFt7DxeR7iAj8uAm9Xh7bBpAGTzLI89TVtkGmTcQ/k2FMvyYfwhkO7nXHayE538Dm5SDddLmrSR+B1LF4wF61cijtc89HQcxX5JEmqtAoDN/bi5YB7vMxpnGbe+l69CgUb1oKBT+a+KdMtKMM1ADUXDHbptoNv5LKiccWgtA40wz9DgVBa+WfBldOeD7Ln12JFjtJnCnH6znsuP4QFclETC7cRcVQnEHoTL3nL1zl/03RvrKPn3fWVSlLqFxE9WVORD5TrtM5Se37/7QWN73efma7fK7KLWfYd1X3TLLm3mioItQDGt9thjkMMbmlJnYyEXVkgJuoc/KdYKEhfddqb9iOEfmi6kxgNBxJcL3G0bvoQATgboOg3SORVxvXCkZ60XSuElCmmUY/s+cmSBo8j/+tfITdgLdMUOHohQFxRyG6bVXa9Eu7qPL+PDRxPBQG6bs9oOQPERb/E1nj5lFXGHSSu51grWjyMucX9ajp7ToEmYFcIU1yrhR7RJiTJitH0FCpuWjc52Qy01xt1OQNoZKwPlRhYcT2MBhA6thP8rbJ42lrDUxBWJflfy5+zuqX5OX7141HuVo7jVgvjoHzvrGnT/xA/FkLddmESMLEgj4f2iLUt9Q1XLfi4Z9+8z2ZX0AClywKEX/3OYTfdANvyaswijZALiR7RnfDFqPtjaY9+JAF8p3RHB1wb4gO1txZBo/A7btHUjwIUuS/5C26SJ3utkVj73Ex7DH3PtXNJC1R39m9JBf3J/w89HQCG1oUDFvzve37HK+Qjeu6vvkIJ3uRlWynaA+vVAm2CCZvyxrRrw2LEcEVXRG5L7j008wjp3uyg2hkAG13KAlqAcqcB1sJNW0Gklutd5h8HhijNKalKOQqUZdBRx3HMl+j0i7c4hINwyCyqCRu7zq4kLq7q4n5snmlEJxF+9m0xoK4Np3YoXPQnaXb1vlwkEGOOMpt9sUHZ2MsC/rgkzAO+qqPxth4coHCjieENq9pIzBsvQVhdJfvhNbzWIGU7u+PDcKJML9XudMYWQfJFv/wD6EwHyoaYYQkWq3AH+Kg/7eMhqK3nGM71bOkTEFxMASfbD0XNeoK3XfCMPBnrZO9SnsOgBKAEJUMbids1WyoUJMgKRg36h3d8ByL8sd/jGCJk4CtbCjgJvnJLJp3Sb8l+j0KrGbQTJucoh10W2FYAGYGsc5qemBNp79jhx5KT8UOqugCHYudQcRQHCVqANtDPKIgUK5AHria4UZjdaY3SFd2ynRLTjCoSFtgOktsTQiotT1Hag7JVrWy0B1qFH3ABnHBXA6Qy3TnB3S1HWxXpKGtnXRAzn/PxLK/ZSi3eomRmycFkaTldGp7UKmDNzF7IKOPAIZ0tJPYxge/HiRNMxui2otLBrlOXtIXdcvDNhIShM7I0Ye8YE9ll2TIwgdSSinPjh3STLOXpa+OsxVml2iuwyKTQwMEIuxHawY4U6h1nAph4R3iOFSjcjlGJuXHJgYpYiWe520wOHhHBRVdbyNxu0b197O9zhn6psUjfAPCs8IfpaVWrrrRU0R3uxGbaMC+v1vW0wbrbb8pW1kYfw/mRXir3eGL+JLz/7jtvv/n6bX04nh+HdbWv99qpxPq5/6FRee1VfZdE9UQ/d2iqi9f65PfwybP33nnrTfjktU/+e6BOFWWFCS1l+8zIxTJ9ceHY5IYnFoGu/6D1dwa/h6bf0GST/IeYXSg/u4XgqJPX3ZlKRpWkf+QAG6/RrLCCZtnXItUgS/pr1BwMt2DAULz49f1bb9y/eHiRz3KS50XJnSFQ8/J4t/cdm1jT5jZc+x1wTdUuxAZPa4bbwMw2h7kNYdhOJI0QZodqLRFQDwv1B6SMhaPVP5GrVpGv1u5QSBasOg74GHq2TaFk0BKnhYQrmPAAvADECXtZAL17rwPhX0Ci8U/1Fh45PC81RU43QWIk3jj2kNIr9/2Ds1UQQE7kEl/I6dASAxT82t4webQNt5vbRHueo6N4z7f8a0jGTF3wZ7S5yqlaemVdUG603+yDnm7HrdFVXNvLD38Qv3tyvLq+PD9sh+qt+slBTh9QwB98yCt05IWTFYqkFLr5zKTJD1vHIUVJrffx7Pinwvmwk1u53Qz9uswjRoUt9jWPv9JIkbjvpbtkLzhTa0+gzNQKpmRKspfPhtYTGnwJdrckJmar3DQX7u0GK4Hr7xJi4GUQF3sCgp3JdXLG7lbTnJW/sdf5Qg4UVTzkjOXxO4KYIT6adItqCs+KBsp6Lel4E/2QGt8SRGiXw/3D3W5iOtMyA+pqaxVG64IcrHxko7YnAhlzM7IFGeRDqoGDQS2H9E5F5SVrn9Sjl+TdoSjuaGaJnE+znbW5s6ds2byDIgWjxsdCZ1AXkpPMdbQBmGSmIIVp3z7YGO72C3NyqTun3vzpMFIcKKMqPsHkPTDIUMkAqx/4rm77UwBKHYSIhij+06JNhfEJwYHp+xLEhfuoL5Rdit2f/TTDWrphX52ryz56YEqlbPLgKs6HxFMWaZBoVO9MqroPwI2DrnElWFcg9KZiuapB46pZXv94X7dyn+95sp40018tH5adUeE3n8G8wr4NdZDhPnkg+AwTNCxBE36DEkPxslaYmMutDM+yKfbprEz5Bl7zYq6lLyr0quVGZe7rd3SAjXVVNap2S+v3/9RrC35rvx1h06vYmV14Kr64xyMaeezVd9VWe4ifxr5t5oc9iR3I6a9dRh5uj/JsH+nIz12dqlRXyyF69AxvaWGqc2oh9QaHvyoWi4jHIDvgZ4ThsHg+7EsVRG0XYdXU5VTuc7u916N7uKflEq8Y5Td+CEO80xSbRIs/qnqzah9oXJPbBk4rVwMlz/0wDfVoqGNrdwMCPwKa2jRErJmNQMbQM190ECPsj31XlUUeizhbCDniBljOjOm6j7h2urRAhpDVdlCtdAOT10x/xO4VD4OMA4yjLXwsqzn8P743sCq0cgeMKGV7P2O3utUBEJNtU0HhvcMul7AXHMpVNhvsrxctPU5Ex3sYxLg1uKlkmheUFn3F1lSFTaSXnA4Ctd39oyPK1nykqppI0GiexRS8iRCIGxtNbNu3txfOQDgw7q23qdCErGNtu5oSe+0lU5OUnU7fV2EisiIVG/q05jILRhbeQ+wK9ZFy6dGhpcisdquL48eMjwRjF2yi9fwA5vhEwXZmFdhR8+CDDC3Wx0VD741vSDa1VCitQJTQYVmccOGqbFcbu4YjMemg8AUgjbZhXGBLzM5wZjvNjsxLEN/1Mo0/bp6by9S3krWk0He/NgAPXAv2L8cjnwXgakNazSwzQleFBgYvR1/O5Z2gKDyxZXLGdQKwZrxDBfminYFLtzTvEZRbGMZOEPdeVg2YUn5X58bcRGSc18imHrnO9a7OaUkIA3Vdna2R42JPn429V2hYyz6JwwntQNRQfFsAztyKeGZUZSqlZDb/66sR2Eze7ieYYPDcjtq9+JRxvJALjj9zSHeD0R4ihwtLiC1yE5A5FgQVvVx9yR7MnTnBmjI94Bmh25L7AON7s6Fh7xrCyvmvAwYTHPH+ZuBr1UN342VaBY1Mryzf7Ift2wNYbh2mhWzat225q3ZGZ7B9q1vlk9adMz6E9YrU9pmTC1hcUuvCFg+GNrW3EThhUM75DDBWajy1e1ZSIbVVt0p1RQKiwEOuOor+RH33wVZJ1fSpkdKzCS3cpK57pRMfhEFNGv5sgU2w5aLZ/6HEa0jNEHVxNPrEsLVrj/BTvc7iuYSh7bU3OvQ84Qt4hJo7bpV+UR+viezoUEHQ+cdN2mAUe2qdUmyxvUcF5jjg+zet1re8hmQxSRojpcemZiJKzzFQh93tXPre8FL6opCB3ZbiPDYxXewONXSTl0jbxcmNp6rI6+zVuXfci/rHMtT6PA/26mdxnOsmVuBZMXj8RHJK6WYkYi9jLONZt/XVdlPOPwP99nZ1vD6e7zeX28u2lkM+lNm5Oz2TeCGF/v8nhVBUCtjklpHhVkkoTQueReQqGefA/tXwLPUcN7RvL46nQ18iKcLaGgAmC9i8QzCZwEacXGX0IbNjyLWA3kucVsGys3FvxlMo9w51RimvlwbPJz79KcP4FV07mZgpF9Q/18iORASf5qDjPh3oHDVfyGwg5SIS6ogg0RmFlR5rpz7cXo5BUd7sux5h91EOqNpH3CfvVM7d9THSq0hF+yJwlirfa31zwweXl6qHK9DkpNkEMFa/mrM4OAEBY6pl5dcG5wqsKXNCNoFWD5S7LRlfgu6ass52xZOu46daNre/eRASeLcKT5Q6MZ91aTUMtRIJZ6xg8flieAU9cLpB7B6jBVyf1fQ7GYC8g5DPciXmhcsBUlVuS++04hZw4bbaxb70YYws/8zVhACiNGngHBRvgYVrAOWnGE/Ime/xiKxnIjoFdoIRNBQPPiUmoFD4QRt4qtWFeCLNc0cKELe0xgIC7YBqh3Q2AguFLkcUwflT8J/AvVfk54rDVyEMq6fpGl7GcR13yarNfPxlIc7//IauXNcJqwbt72b/dfJeOiM4RSgI1tziTjfhk6OIZ75U9lNyPLIqUoGr5Cn3YCUCnwbsOvqHjspW2hI67jNpeMXCTBQ9ERXOs+iiPNVAauB5jlxx7/ZlAS5YpZ2rfIkFiiaQlugqPFAj+lSHCTf+czgcG52JON1ET7euvkbjF2tg68p//fnlx++/+frzzz7+8P333nwDHpJx+be/334dm/tkgfOEaFTgKESjAh1kDBBuLNikg+Lq/y/7w7/822z0t7/eXeyvKpzMB6kDY6dlZ/BdbgmRrFNfYhEE/QaGvJdwwEuWygFWTygKQoif03WFVwW0RaVWOplpqqWp1toXo8rkXiws7nzTel1XNeG6Zeql2Y1v1diKcyfF2Iv8N5ktBXPGKA04Wak9A2YuaDEQx65gBWFEV+nGZ5TxDhAf1zN2Casd/3WfmtCwF9i0qDBsoUWKc7Sd61wPLj6edjrY/Wt9JJyFZ/o5OZU4KPyyhn5Os2kJwmKFMyew0IhQECjCdiiMME+7p63Xx7rq2uX1jD4hS3XxU60IQrqUThTvHRSWfUCw1sYh2n/rA+skPyrbOh1g/KK6dBNqeDtG5OcdcrqkhNN85Rs08IksNvAhPzGVL8Qt+89cg3h3X/DiF1pk8WtMCEjpjOB3LFlaRBDr6kDPdeQQr3S5P9DT82GIJjMW1X8nNzfWejlwlxfNzquSDJ3zzg7jeZQWyXXiS3JF9UNO1AAvzOwMEbB1S88pLLXDmUy5Xqv2hW3Wm94skufGZbgnvRMBYu1VgSMVpT+wLtn7tlr6reSkM81ccaq/7hiUg+8RIEKLZFrYa7s9tmKTMpJ8oVz0UJT+pg5NR2dBjhssw1BOtesMvfaqvgMrJ6uBjnYdktJU5uaXOFDWmBGMK6oWsuMfcT2mkl6rP8gpDh7m2n/CKMhliW4kdKfIjCyeeXWBVnJLUESsEwX7m0siNJ6hvBwBptx8yJoQZJ+lCkK291H8OZaDuZ9vaEFqpjehYwE2X8t0Gasy2i3I82TmOIxG3Vd7XY407BM2blzFIumU+g4NeSIkp8Pc9DIAevKX9xp2KbFlaKF5U+bQeze5/x8CiujQEGUUlDNB2Du4BJuaEYTMIgvvQOU9lsl57oqbH4lEs6dI3aac8u0TJFUi6Th06vtjUyQizgvsb9onRdLiaXmR1Ru+wad6T+34iuwF/iGAitAeg2BwYgGsbPAikgaVeAScFgNuuxSu8KTxdMPkBrgskqdrhbilkjKVi6AScSXnJPQYs+QqozvA2ZiY8piNmpmsz4A2cbtJGDLzDGdIc9q09V7ZrLhoChIAMEOkOqYuAhGPD2uO5gli1PCrERCQP3/xVZltDnW0f3MRkAbAn/0CD8BfvBte1eUc5Gq/PIANBgj4/9mUu/Dcg/Z/6aDwffv/rPmFxtD1Gcmr8pwg5Ob//DCXx7zXudzYx6xwv8MmMY9/yaUx0DejQBvQ+g4xU2anuSr3xABoO85k1yaCmimPBlAguq92rOXyXfeAuXdRmT2lzOc7fKv7h8t32jq2SZuZN2D+9lCGD9/mvbx/8D8yT4DzHfi0IAWbiTN+0h0/3IvHa8Lx/FpBVPt4wKW7+9jkFr6bu8/l29xXfLMMcxo8Y+TNHbE/1G0G+8foaxXa8nkPrDtp4UhWUe5bJYf2lR8G33anhNJTzotA498GB+iHWyi8CqelpV2xQgne5FifHoQkQ7WuhjbgqSEUm14RbSXW67tec3sU/viiuzlC3WPJxerRF4oD1EyrFU7Q9opDcUZ6b3rQZ6c2NxE04PvsV1faL39FaKe5UQbGD7/HhGIrLOGyTyIgmx344d4L9A0m+1oBDIUo99ibwfJtY0/QsxWDW2LLTENdFUxzUOcibKYpnM3iwq66ucxaz6Fv5L5RLHL4PYvX2vgvXr0zCHCZUQG3tNKFc1XDNUOvN9bS+Zx040Kznh5ylvA6k+aqmfq18O1jpoGP+V5L9AEQBGfnNV0bD/r5JK/8XGADHm/oY5/hMx+YXzI044eZz7iOraBbOXzXgWulPMUFp/vVaSmuyE0mEmdejp/kM+HPVDFd1/Hqjs2QzCywsu8/+cyr0jy+T/zl0x4LvNbxygRf/jUqs8vSJgKZx3RWqtBefz3FEGyLpRzlBYZFXzuaHpUgNVwdYKjGNq4FCGKF0mAcZX5sgbOiZztD164dbfH0akzsQ5dt3sswDxgGDefa3v/C2ZG8uRkfiTHBJjaIR9RM2nn6uuO7yIaCmW06bMoEL/PaTmuIAWaZtSSPemXexFz1HaijSIzzc6P+4NIcNp9/t7+LW0n0IXFsoZ69Qd8iytbo0Wz6WpC2mKZ5NONJ+7oNtrGak7twmkUDHU0NVEdV1JnqqTdVvpBr7tNFF6SBc0rmHE/CzqTdxMr0X8tIts9JcZJsZPt1Jjw/AR6/xGmURUPMKOhOWmBU5bXxXVl1K18BrepTN7rwXAG7prboN6ujvTnezO+1DbSaeHR3Gy2WzFjo0zSvoS7HP7/s8z9qx4h9/1QimPEVtp3Wd6FNi9U4dP39qWeXlogctsYGxifja1OXMi9LJq3dkM9cnzEb9lLRapZ6QznN/dEnFRoXrNKQa7I3ag6nwBnMyxG9TA8BKtpgWHOFlwv9yPRFzMzmMVhzkEsfm+i5YQ/vCbSLX3sNlrmjnqSRLrV0WTGLu3nuZRZ2jk1kdryGd+WivWMjbDuKVnHbAQZivFeR6bObZqaGdFMrVBoCdaWupj1JnbYoSI822zYLiUUXkLwZTm2o2kdWN9rxpl2UERsxAaXjkksvo42V1issVa6wXHG5Hwm22Dus1qU22E28yRwjyWuaYq+FQGiToGXwejxmJ2fD28mivGWmN8BNsN4ep4NXcsW46S5/eX3psWzmDD49rKMLNcq5zkbucJptWC/N8k8f+EYJdM5xWmm/ITC/IJtQNBrmbLhFQJNXXaAgAG669YWvzEiK1XoDtxzOI5+XkxFckA3jqyccgZZF8yVAxNoGMb5TEgbXS6osLVqnDNY5KEtZcC1M6F85PJpQciEv9q2Uz2eoCrHnXScinKUeArj8rIuAvYTgUEJCAxV66PCTAdIFkwnydRxWwLUAv1UYh82xQb+EgmXKUiBbiiTJcqgZeHhkpBa1IcH3k3DSyZsz53ymVGvc5oPkTpe8+2yTpToDnyNr8f7ce50kpfjBc8XSi5Mpnbs8CbLFSZC2z5l7N4lyGd8znWq6oXLp1ZtkpiVepE+S+/z1MbJ50uvBg4eeokUKFqandttuiM7dakqlM9VqVbuvE8W05TKrprjJoXki5zdgVM//obg+Qex85UZO1bxJTMmPmmCkekmdK74+XE+P7keeuiC7+KafulqYBqQxyjqF61CQK/EyNRTIziFbqTFbVwwXI0dCPUqMr5ckU6FbiU4lfu7oqYM5MP/YXNKdaTIliwxtB294OVPiV+anBR7yTTNtyrgUkKwcTw3QhOKlmmkyIfLIAcKoDZYV5ks6OyyauoaxAe5QAmE5BZFyjDzLFB4OxErzOvmMhw3IWQkyZEnv1D+wLk4mOeR9UA6pF9aPjqQIwcfgUxnRMieHNhAzg+bsnLPWtNbI1gGt/aA1G7JlyjciJVpB44GbfTlBZkY8mC620uiBRWZURqZAQaoLKMdJK3Ky8GiSzkCymHJvnCy4nGDKtSZXjIxlH2SFwC/MUSDNw6bv0/FFDH6xzS8AN3QjZUQQhWjEQEzEgmtpITbiIC7iQWzZsO/3sPf9Fi3OfmW6c/RXl1flZgNtTLLRJzoJwVzPNGYxj0Us3cwq1m4FiU1sYxd7Tpy15xBoHOMU57hwiWvcuMad6viLqzNXd9scj2yJJ7d4xZs+PvHlHr/4J0A9D550v98OJUZlcM/9QhOW8GxNhKRYHgYLO5xwwws/gggjssQBB3n5xsg7eyKJlE/2e+d3gwNGwTeHo4o6Gn4eddxjyenUFBNDjDHFHAtL/todcerBPxlxxxOvnnr5Uo7TAuB05Xa9ox92dSaciAPwT340PelNX/qzNgOJZTBDGc5I4nj55qUdXpPa1KU+eCJnBPLlBxEiBX3pmhgXX+akXUFqf0PIkG6TvkL9C+A1XQpLv65ECT7rL6ursgWYrsm5JsUlkTUGGKhDE5xxTLoGtYwwT+TIkw8fXCCXM1kQniuigsFN85bZEGdkzhTnEKnAVGtkzjT9CsvcO7iGzNusSKWhvosyrO+AcTnRLuq9PzXmp3mGc+qNZq9ghOJ+V2J6K/7zxll/bMxt6YK9h8BIo9IdysBMGG2Mr2VPCeRyMFYePjK/eP852Fy/x+ZwnXKSYeR+ccQSKS4jSLlCqVJrtDprvUG1iX5KRMohyh6ccvccgVTORComi76cbrfHFzDt/Wq58sqa3FLldh0cnQDBXTNynZxoww8tlCq1ZnqyY9xXBqNoOd3E2cVV1iholE//4+uzL77yFv92GhEVE5eAYARlSgKMxcYJDpcnJU0tDPVThqMLB9Zt8ON+WygoKimrqKqpI5AoNAaLwxNsAkQSmWKLqgFqQjQ6g6ml1vZpF6eenl9e8drGw8OyLJ/BGkypnjpbHgiDMAmLWIAkAWZ5NQtB2Rwuj2/cNkMyzuSk6LfGQqlSa7Q668Sa9YZ+5djY2tk7OHfh0pVrN27duffgCChUGh1iMFmpGMDxcP8VLyMG2YAgodrKXovLSvEMTj2xrTzuXzS7DDEdZrJPJ27jSilchIOjE4ygmANTFrpSbs3ccdwuqz3nPDo2H3GxWvtnpSEHWs1VaoH550mVZp6n5pKTKXTpnK/YWUx5Lq5u7h6VKMfvB3mz1KrZsdFguWV2iIkgqDrrzrtuWW2bVVhViTKtHwq71+W3P4JCwiKiYuISEkWw6U02JQFG2kA9/c92eZ38AzGQV7ApvlRZRVVNXUNTy56Z7aE4GVVxYtKUadCenl66ibyCIkbzNx8VVTV1BBKFthhMHlMcsEgD0CTbIpKo4GHHjZ+wzYGJP/ZdsXNUI0KmAT2KQR90dRVUSmUS3E4qty7qcFA1VVAlVVGpncxCSVa3ou5y2FMfiKK+tt4cMuv6aqynObgswKKC3Qv0C2SkX7o0YKAgjB/VU5va1HZ/49ZIBvp3JDqkEOjSSYQ8W0vTiM9kxrKgbyrEnT8Y4tqUWEDA2OAry76xoG89Dd3ZrwlxFDokLexYk/ZhwC6D2EH9h88VuABB3jgvheH6GGnyYDZXoo6phpy1NQWpwTSWS5R6P2hnVJVURuUyxadq+xqPoY/z1COpZEcIVUsapUHtmPpwKQ/mVRLDqiTC9BVAolBqMiKaUs5i/TSFRcwJ++ZjXGU2zEG2Kyp6Ly0JmmhxcHSJcA2qrhpScVJsRnVHw6ONIegOlEcS3EdYRjIPQKkUwDKpKcuP7y6dAK1cFP2k28thnbLGyw5wab1DqyPQASltojq1t6lBexTR66EarZs7gzv4oTyz17FUQHK+B7j2JkfHyZ1coVr4bd5ac2+y/5+SjS12lxxfq2fPDu7tDFj90MFWxrJ+22QpEpsS50i1lywuv0jAGA57k/n/mG7MirKn+NiS7JnfdiZriQ5tyrlQt/qhnlbhHt8riW6c3ylUdOg3fmj6FmgaWbGeaH+VtC7mgILq5gVny/4uBSqHftuJHL8nxJy+f1K+ysvt9uswchqlumxG3C5jaxd32JvN+JR88vPi86um36VivZynuvfZgf0fwFcNJhGNxRt4OpFMRQ92geGZTjTYDx8vmEQ09pJfc/JQCZ55028okYq6uKR1Ie9yVU7lvVu19s//75tGHfKiUrXqfVeFl3+QjSChdS26pTa1vaUudYdecjQZiyfSz+ajoGLpzJXeCSLGNHZLUz294moeOdKMlpok/ixeSzKaSl/NoSTJJkPGZb5sl7jUt4VPN2KX0728a6R2a9Oa4CxvMJ1MMTjQ8Bmb5g5VLNHIuy5sMXF8k4JAWovXSnpJBPXgHudLwPe0oqYwCNT5HagPsNi7xjlPvk3hO7iMF7GIJSxhCUtYwq5YwhKWsIRdsIRFLGEJC1jEFUxtRpuWTnzToOgANccPihgWPhcCX2FBD5PJfKC3P9CrYiMGKvPtD/zqq+Quxf5UBZ+urM59ZRATqH7bS9rd+uLhomjV12cl9xSK7SlLvKK7XHreFN/l3jp1NrZxZ3HX8NKbUADowVK6Yy8MAbS7xp/JLfeMH/8HO7NV7t896JczUDJYBHSAXmGUNIAy0BjwhAg9haWlQogM1FwESgZVeUQbGUGxuKZKyqZRVVERWcQ4qgMAcECWqmWi8Cit0obFHTpelBRtK2ggOkjTn913oIY/xuC+NYxYsDv0P6aJDi7j9HnTOdEuASWDRUhHHnaJUdICykBjwBMi9BSWlgohMlBzGSgZVOURfU0DBMXiVJWUTaOqoiKyiHFURxDkiCxVy4T1q6i1hmgEMYwXZcvUyNCIUrfNelbbVUMlNZKznWBWtiSxXbLqPbSHKT4teTCxnSHtbCqRWsI/BxpheE56o5mqproaalGr2tSujLU8ymoFNauoksqqqKqa66v5LYQs7IqlSJEpF+flXx+Bgv/u3DCys4jk8GwRs0vIqBfUXjdMQctm0RBMtiCGYHpdEJhHD/c0G8D3IA8ge4QR2SXMAMJFgDAwwo+McF9AGDiB+6AN4HsAAAGEAQ0AAMAMBBAEgAMMll9DWYiqXJKVOGWirj+IBU9u0ZeOkINo0WRhhsCBqllFlVRWRVXVVE+GbX3FENSAiihLNWoMqqqmOoZ1impFdO1ziZef/199lFoPOCOL7Lo+z53zXHM7RLqbBaB7s5DoXJaekd2GjWrKf9+JtbBZ63VVyG+HHjOhJLDut+NxHFxvjho3q52wAJMHfhpycCOUmZ90TlpOwqvZ7SSAfR6PkwXbnygSH8Js7QvmyrM9mNtutZbA5qgYefO9HDFW3kTAdIdkHheFC9MFEuPhCJXPzoQVZPY8JFuDRY2L8MJh1lKKMNVVkM+x6affQdxsTzDpm9mEP1Z/qoPmcfEZsS6w8m5cn/l4qacwN3UTXn9qGKVYTYslCTPfCLaiKfW2ozlbmv9HGyyBI3JcvZptbV6ri5WpmtWejI5SdLIVQ6QbHTJpdZRi6Z2O8xw31VX6QNiaZYWBPzp8BU0NjWRALiKSCjPs6HQjyzqCdqerBydldYlkWV1BzSotwvvNkDQIPbQ4kRhF0bYXgSape5h0hoaD+j4Xxfv2GfEZyRBZ8iGpInPcKtLIwL7vlDbBtlJBVBoxJ1pncHZVVZ2PXg7wHIJj1Onw8nosngZ68+4/cXRc92z1jti/mpFk930tHJBfqBsqW+nyk4Oa2lR1y+pjsi/kFN6VGEfzKl/PKWbUd9Utw+XiSta5DKIeIL5sQZ5jWtJXk6iqWtE3CUrbxnxKhdRQiWJqToXUKNI2btaLoaWHKa6MCMifFesMCBv0UMcbdl8OMDS5HYwP2gEfhwPe8/Iv5Iq10WQMNN/OO6XU6tApzszyhv7KHEcolmHQX7j+1lSJlBY/7Y/ue+cVflYC8/7fDnCf29jRIGe8xH25ksVZ+LPTbrarsc8vAlZQ2rb5ZHP69sLc+3+/JMI30JN54aktAo1DRFSEwF8cV/wuCHjgb40S9nHKwcDvCJbEJ3SDJ1igxxp44KOqTHre6xQLDS1Of5zgCD9fdSBXVl6Jm8vJ4qTGd/5O+Tf7G1fVN/Ws9g+dsSWFfAYAAA==) format('woff2');font-weight:600}@font-face{font-family:'Geist Mono';src:url(data:font/woff2;base64,d09GMgABAAAAAMUsABIAAAACRCQAAMTCAAHmZgAAAAAAAAAAAAAAAAAAAAAAAAAAGoJ8G7FMHN9gBmAAk1wIgSQJnAwRCAqGnWyFuEABNgIkA6N0C5IQAAQgP21ldGEvBYwKB9xaDIFWWzIHkgnlxu5ft4qZFkFEerPq73Yj0H96AT22vaB03sylLiT0V8hNZ+V2zDzp/6zT2f///////29LFrJmuxOY3SQQvgJan9rHUj29TwjM3aNQaCmbk0KnRJJisXFldLZsqaIwsymmnN6ZREqkThTL0XtkKgGqAqii53ZISXLWRY9weuEsSbks4tOyNmlnppv9q0qqePIDyAFH2YNJLTq2fWfdcvIVk7qXlRElM2RmKip3D/DhrMbdTr+I4bcTSgZNemyQhgZ1QfN7QpQP+fxS128hYq2OIF5RX8NJ1t2mjqaypJApoIGsNur0+ubdz4sqsOxhZ+EefGzltFknWcynnzfpbpBEw8VQMYPxjqZ3mdSspsKZpBh/zYYo2ThbjkZlPzJ7vpdHuzGTjdjcduJqbZ+NvgeN3dTqLZpTPx6QBZKVUS5gadsSyzhLC0nIDbICC4kLOJYSRx2DG1bfwM99cxCWWc7VN8G/416o+ceE2jQ1Nalu4jTcV9Pp11C/BUR0rTyi66G2a8B4kgeiDMjsWZP7X9VflQXMlL+aQoJZ25cyintFbTrJKn7w0Etr6OPbUMNKBsIv8P0YavEOxrvysFFt4C58DvIRfqvBKitlks9/226RyzU/YYMNO7YAr+Ak58D/JDrXyHHvyEavyTIwdhmUaCNWxDrjhf/n+dNv7X1PX76sAdw/NjukU6bJ/Xl+m3/ufU+01y6KRduJLoWHhIAxMUAeISJWzqVLV6092eYwelE6t/9bV9FjOdVF8lK2blcHpDoO6EqEr3HyLVxH5E72NP37reT2v3kE9ntktb7vEF2n6Kv+zPpTASMXKFMUuUDuIWY9H9CbM3cZ/gDvth43ai4cOBEHiIILZEwZ8wGPBzwebBU3btw4c1Vmbf2tfY377bvq7jevzKvrrtvt31g36+rqVnUU8Xtxs/d/ElpRAiOIohYZT5NI2VRpwiERFiNReVTw+/2/3zVr3xcCjToRhhVKkCfGoDJRNlHETsbmf77+wzj7b2BjX1oJYEj0Qfon1DD45N3OSDdxqRjCAGD15xhZQ7hXqj1/8zDBkCaIhPpX4157UTPIpYdvP/eXr/jmYo21xpplrbXWWGOWfaw8Zok8IuIPxDxy+Fd/YMUfWBF7tWbUijXLilnyNcsfiDXLLLNFjH3kEH9kixnLLCvb1vhP/lkzV77J7+IFWdGDJH+VlctD0S2p80IENDd4Uvt2x9m2R531M9KTTBiWA7aXwcmCu49HRfmhqK8pzv/eVOvPOffe9153A6BAyYOgkTTWkZ8Yp/leHBSNdqtQiIzma5utyKwJWfgGyOINJ/1ZsvA9fx86Z+Yu7//s6gFMuhNVa1LyghceUVefnmxLlgM7yRLOB8oB0uSAK6waoKKsLgj+cuoHKAACiX0bCHkDQcpItv/P92aua6+rruo8GmRfXHvqNUnTJO3M/7wwu3cK2ALyHLNQCPrU6gMgySAkScKhOf+9lnOBNnQhuGBT5HcP4ROA0JszYz2hJtz8T1u65yRFBaTAU3545zZABtQeGEE/KPnWV9QuanXV05p1TKkIVhJU+vV70zYXlOny7VCEdK3zzvW29s5+HgAJtwlbeBPqS8NcANw4SSnQAP8DAaHSC3QFjlewgk9DA06XT6XWq3vLi8cL0kjeb+sjHGJF9bVUNEnZ3dKlj8+lYDAYbHcwGOxYNHbwsHPhRJyE9e1PQbSCxYL837GCweCzjpXuYIF6JasTb4wzPPCJhjgMh2EYFgewbUNmLx4T5j1bm3PknPhNL3rw87EDD37wLojeolAOdibVrgYI/temWu/pWe/5QtcUtqBM6lkKmC98TmFs/d3IVYE0FnDYnI5Aw2oVQWvWjIWbAnq3rNl0a55finmwrVeCBjxYl4SQiDRtWPa90vVPcGSP68JOeBSCYpZNJRNVDrAMOoO26Xa+CtOdE0+f+P/ltP69Kime/64q6ubdxx2vgHdE6S6QpSSOLNvKP27gMWysrbwdRHAGMbDNy5cVMo3ASIxhci5VkwdWYhegSh6hMOmaIv5VqVbfKrRINTgOkMZg13PPiWeps1/NnHW/T3V2NbsMmmxDUt1oSmqA1BxAiHsNkKcFRK2CIDkboDSG1DpqrWbPOAdRY8CxkDRGGmt+5419/O6+v72Xta97/B53r8f9valW6fvdANkkZ3SkdAbaWWeoNTZIQEo67yu/y4xrvv9/f6Ab3SAbACUBpAwozUnEGIqkOBpqloP/fzemAXD35PaK67zOc2Znz1gdKWmNN9nZ2Bib5JdtpJm9KLgwuzC9IAgs/3x/Md4uvYOfEs4x/LhrETWzYCHk/2vmrx2tRh7HD3lrqKDpRkMSeQld4a95zxd7VlpirmIX25Hk9ZHkfz7rznSUHJqmAv7/naV0vm42y9meg+YEwABAJlK66dnZ1F2ohBXRlsGyAlxCaeF5mlZJVaP/NrY2zlykd4RL7cxujyFtVf3SalpfE2vTbDvEOGqn7nYIgZnZKMOIgDk2wabc8EXL9rbetNkhN7mMxLtjib1DWk6B/DIkISRCfuP/VA0Gg3hZFrRwOsGLxb7qH9esKVDTAuJh4T9bKt0neewO+blUyNpq7SQ/pTG+viQauxMKT+Hh28kfvmWB9jDwVOsu8O4m08HAbKCD/82Xx50r6GDtRwhFSglBgryv+c7v63OPHLrzmAm3KQrTFKYwRhhhFEcxwnGKYnbfX3kf+9lbZmg21ocssooI3SRX+tcNsmbfbxC0z9Zx9+47K5AgKCDIlUBOkkCwu/8c9lP7h5qkI+2NXLqsUQRUVMZUXGlv/j9Ux+ATtdc6/rOmtQ+m6pTOzioqMWiIfrGmtCl7uImZjsDY8Pv/xtCsME4QbhAe/CECZUJkK4FYpgHCSOD/qLIy1dTqIWsShdQrISf2JvmYTb6UJV9j8oM++c2c/OVMyspJljWgsjKoRg2ogXaFuquHQt3XC6EO9Eaox3pLqKd6T6gP9QmhvtKnhfpGnxPqWF8U6lRfFupnfVOoX+htoH+l94D+gz4DuqQvgf5AXwPN6HugOf0K9A99AJvzj8AW/BOw3/g3YP9vTxwVKMKiDSLSoh0UmdEFAkEA9ACMAEyDwcEOCIgNw4oJCJOIDkc4wxVtYMgIKzxUjJBFAzaREq3YQgCdGGU6vPKqbCHYvdouXQsl8N++CJJeq8ejBJOZMs5Udtz4CUUpA4AxgQEJINbHrk1d27p29e7DYPCOSui5dzUMUPd3/haQ+DBfYfO5TIKbGwo9fXuFqE13V1iQXI+dvrd2aPrRepxNT1YQJjcMGwc5Cwn5I3kQkK48W5teMWRwawxK+22eNOsISBkOmRlh601PwSlL2msvSC8QkEviUddDl3QyjUKahp4fKnHwwgZeeIDDc3oEnj3toaxkuw8+YHwvib5vn7yum1HdLh96NumKZQLLtvHYQs42a/UzNPAmhgojSqImOmIk+qMoz7Nthe3jHlotjW+Tg9q069Kj1wAbAQzTwU9pIF4/QDwvl4PkwSkdJIfIGDkJZWiqdGZ0BsaWgBiwjXQmlCoz1na7TWEcW8/U50+zvJPeOX5gfeUg5xSNEvcsqiKsBrUgacyyFrdfU7F9onMk9jMZ6AnPgHISvVRT6KsHIoNmnB7Jc3PjWpixmKYAlhOM1KOYTrdimVUmK8EzNl8wU3F/wvhixGYP7AAo4ZjX24Oon/zIng+vCfJjJgoPFqtSYn3pAHjEafPjx4pHgkIlcUpGfoUHZdtu8XtU9y3duwZqnKdXR2ncCL9DebvBueiyifJmZKpP76zJasSxesBMhRgJEruVWdhmmi1dHaAsfHh4jjpO5KQzIvX402L9npL7JATyi5PeesuDXS3moTS2wuHO1Kyt53Xo7nXHnOK9T9THF1c0wC/f67IYqz4vU/RibGWBMSaQJc4gazzCFTmQfUThMUsVvcZdscN5cxKmsFLYN6ek2WxX8j5KXZkrlDaivcQs5dJ3r/eg7ox3m82N5ktFfo/uV+9B3a3OtXnybuoOz7D5q9sH6+8aIL2xkZaHhplz7V5WcLjd2fyEy7To8i21/Fb78nhOAsJGmZ+rOodTFy7c0V/rjavj65XQAHT1ia550OXmePp/d7v3/dAzR/LEdvCUn/iZX0/PL9nRb3dAL6axRq8Huf+4aunP0V+vdv09p916ywEcyEHbC/eXowFH5rv30itK7nuvEkXtnNsHXaB/6F/qpyvc5C50F3oMPeEHfuUZr/hj/Lny/dPM3/p+pkYdVRSooQ2a0T46uATM6Lqbtpu9d6Dbf0d32PYqnPAl9tykz7z5+ZI8O1gKwyZz/v2T03PrfDuqZXi+NEP0HmueuR8r8Tzwoh1GdbOKmOAhClt9yQM2o8VCwtTkNVteBRO8EbEFIPYKht8iEVCELzZ54hzIcR7JPexzJe+RK9iFlK7FRIpt24bQ52Qmsp3N7OhKhZSnePlKEiLiLX9MpG546t3XkRb6VqgznCtfZ4ZR2rV81icvUBusRHkGnzTsyUHOFDY3f5TTFkWiz1F2QvWiaWDBeaT9KE1EuUzRexPMiXRpmydzeW/8cAYG4wXp8w9Nzf1yLE9+wVRWveSeT+OlkEjnVe4smEMlb70LJIxDuVocfiEwiCheKXoYJYigPmflgb6jvJfl4czNEaryudFDz3uVlg864nI1a5OgrwQuJC2EB+ycBaMDzhmYpDmzZs6XECI5JVL6znbmwC10oHCGJ/UD9K3lkMZ26SglDDB6jawln57DsyaX04pY5+bZU6xRjIYztRA3KIpsTAtKLhsxEDLuCDc8tsfucxATok2x8Odjf4RTRDJqHIeXdh7EYMdEmFXC/LnCKC3y7ouEiXOPckILLufvTKZZtaDKAkgrxc2O+Whgah48jUf23KfC4rUKs2DClAiZ5cPGgDDILDSSyaZR74ND4WvYPInTkp4xrRtWLDS09oy2NzNbBHEqZmJ5ZFwTpBZCTOO2wWRJTkFlAOp3ibPYZ6mGh0tdGgXVMyJyTY88jURTDGZU2vTwuuRYl7kFs9NF9K90rKmSbPNMYqpXyNtDr6bel8mxgAhSpCgPAYhx7BJbFQNwECVOTnCKyVMVU1JJAtvSQZnmM8jxlj07pwcs0Me5FzdyqT0HAO8qliTnPXJYxszSBub+bIHnLwE8z2aNEMlTReu8bxZ9KgQOioQkkYQPTNc/DK2SFfjKICZ5JIUHluhkemEHpjjOn03qm8jcYARbckYkVVqxnGozG5lCSBO5QZ2TThX11VGyaNhB5vsCTDtTPu0d95COhKboZIKTZuiMLuqaH2jTGZ5XXbhrdBVSfFgPRswh5LtTWE/i7ElyeY8gqMHoIx/8EFWF1v60/2BeymBKIMOdGerSv/dBbmV3PxlZqOQVHNllrjzubJwQluCISgl9A/x99l7TdOKH/VEcTYH5lO+a9/w8VFsF2R7xmHNsbeLiIPE1OTCFgiyFhq7Lw1RgyxzPDtgnu1dadO3pKF8No8WU6SDtyxyh01jNhjpd5dUuN6k1JXTd697uoYejgsvgXTs7qW6prFlavXCxVgf+Av5MD2ZbOeBEGUM9HcnsBzV9O6ScvZpLt8PNP5h4cvWo7B6eGZg5XLcv/lHBK7XPOugVhYoPrJVqE8rgyTTal6JRLbsc9p3WJFTYCx8Dx+xssIaowo+FKLfnWNP19lEzCMJZqsHUNSreIFFButnDFXAO6CSZajIpw0sWQPkreGwEFQ7Uim/nO/cA/l57opcDj+o+7mlr+pRR1dIp1syV/ZLb0r3wQklfkYsPN3xmJIej7CEbUAPcHOb+RO1Tk1FhFnZL2yHqfTIzW8rpRDBlB1GfxmdGmC6DS+ds+PITtTH63evF0f3rI9Kdz3J7hdur041OXW7sLEVr88zVlvDw5rmGYMADLHuP5sydUaGy12AnmYc9p+GrZScISuOVDAtAIHCD0tCmuYmuu1nVx83lGNVJKCdcdhFeu2EfeEkTsSST5WqbzDTYevYwtrn2sWHPyVm0lRlR4LY6L8O9cBYS+EhJit5I7FI7hXZ+YJHXQm5rdFDY7PanxT+NcWTIuOAPmNqok+006fjqT0z9A3btkJiswz/uqE1JxlU76+MT8d09UxI12ANa6fq5f++MZD0e+WT/3l/wtQOU2iS88IsDnIq9FFG9WjSvU4m3iOFdYvp9sXz4mu3je+cin/q12K//2djO8Pmd7v/UJXrnzbaC5v9rIvsd/2o8cReBYCgcTjIWica+leJ7munEEzJJEgpHgrTRWDbIhVGcUDAEAEIwSQTFKNKkgxOYGLCB3sMIoEUxFnAYIkxavfUxKRRL5SYr1VqLbbZT99qokyalckUu2lZrTp/C6VdWdWOJSQiiJFs0qVhUNYs27TgxNDgxkWRFDLbqoLnCk2rt36wXqWkMhqPxkpPpbMU199ubL2yyZDSMJ8Pa6Ww77MZpXr7MLB4en54/+bLE2frTTvl1oOBAQc7mZx7kZ34duHPE3YYRJ5MgMw36X9uLdiftDzrsdNzotNJ5oQv+RjQFYBOD7Xd5aKTRev3/lBhmuBGAAENigmmJItRU0800mz0nLtx48OIrQBCWUPMsEIYSTiCCWKRoi8VJIKOgpJEiVZoMWXLkK1JiuVXWWG+jzbbaYbe99qtQrVa9gw4zataqQ9cP7rf+nzjtLASg7sYIAHVriwRQ6W8QgGK+6UmqGna2H1qSxKwks+4EHtxguMSZm7yFgLOqm3X4aQ+gUq1ocuPCtnLQDjKp51sWJtRc6VphGDOFJewOAuRcz4mtyq95qVRplXd8oGb1VgAQhFPlMYnMwppjmOOKHpSYZd7u1aAxXUq3GUjSWa+BG3ar9TfE4yiRIUuOPNMUHB57eJVt5ud+BH5RaiaFLAYia1pw8X/gcq8zsX1XrkNL6O1etPkcKiukKCyD1BqP7QRJsO1uzo6+xXYjRfOVsJsjxflNcEmhlXrx4SdgezV+HTTOjJGRZkLqF8yshI3hraM9qARnJFOVHKYBRUX7MW5FOArM1h8YDHZlW7ThaegAnlMqzvC/LwjGyQvicS2djXk83VGOGv/UamMYz1AeYpwbbCs7aaf3l1Kgmr8o4/Y4AhUNHXpMMAUKoLxswikwY267K1Of75D2DlneXlnw94tUmhCMkFEK9rUDKZgwSDWEAyP34ugjH7a/9NyXuGLY5cj6VR05/JfTePkIx6F9Cts1psT3dploR6avZznemqbvoyJtXOfaGoU/49j/NVb4fy79sRe3nN8njbao+hvju7/Rj/5lcrHke0+DWWx07Vc3gC4BG6XEVjaVaIUkYe+h4ibS5zZI2ts90XpMidxrWaSp4VOA19f3MKjO5v4jQiBf6Vyo8INwIvaOL+nOlNu8QVxgSWqiaNTislsMJ6Gpsfo7sV5WWzXNhRIUDTpMfDCQOq7qnOsgp8cUyNUNMj0RUog2L/GxQkAbbMdTVEKL1Wp1CEKCOHji2fmVBzu+Fs1mmWxIwdVWR3NT85A155IkrhepGnxwQcvdnrI16FwUeGmCGpm8vuUvpQTbWG1vQQQfYCF3t3qV9n33Su6fVubjW7ndTFEZdvm6jSyuOtrCREbepa2GDQ3r/rk6XaUlEe0sQpHiMhZSFktk55W9weUzcRzM4g4mVMGujQtsAQFL4PJSoFa+80q9q9U4Umd5ay85MAE/5CoQ9WcOLkSRKSG65hqN5XEOuqbskfBHFIbCLoBviwBs7bQ+l0/OLS/XUQ5yVm6ssQw0s2nAEEvRZkqmoQQs9dj1IxY6xGp1CDXcxN0ui2dbrh8GG1wRy87XSqN2/wJ406HUoH2XnNNVPVl6LTV9ykU29RuGf9DWy6MPUZmlSnts5F4uL0XwWEchYaWNDNVNyCc6wLjBdaVcEte7sJW4Vp6gp5EE7T91M3ANolKVjTZN34yIy9d6kbdXvcLilUJpU77CaC9T2S5X9Mp3WNxLaqSYUuEqqxCnT64PAihVGMo3aHmfIs5PRVdoigBR+2Sc1FxCkM1rTAcGCzfY+ImDRI2rBW85n9wgCre7N03rhL0flf5r05u2PDwhZDzruVzt194FewGGl73iVa953RsYyc4gDVCkU9LxbaMcDqtbGkmWMlZ3YRSIeE4WKffwuoux1Uw/xx4oDzC4bbEMkPvXOGCDJS3VJYK2a99W5lO+ZJUfWF+9hSaoiZQfYem2Qw4JCf4KJWGmmHnRcmZi0oUwg0mqX0RsgI73FIlei0D4AFah+Dk0b/1S5jfm0uwpnoDQOd66tttlkeojyBRlAuMWA6b+wduv1DA4AolCY7A4PIFIIlOoNDqD2cT0hc9ic7g8vkAoEkukMrlCqVJrtBGAB7AjaBcIuuihV2QLMMhDHONJ0WyKSbGcYymmf9ooLLD0k0GdeCTwdS6XUloZhMoqx034P1XWdAgDWhZH5pjjTjgJIBhBMZwgKZphOV4QpWaL1SZLFmq12R1Ol5ux2Bwujy8QisQSqUyuUKrUGu0AIwtx4iW4v2Pnrt179u7bf8Gv+9Qv+uKwygpcVGddeN3vVulR0+C/auc3adaidXqUyiXF4nEpU6PVc17CmWuV+n8IK5csXbZ8xcpVq0cdfQxm7JeYR/5pA6nB7r/4Xx7wPb7X9/l+P+BB/9tDPRe6FhjtvZGQaG7vqpFLs7zbLHUeObgDAp765wR7G9xboJJMrxgXXNOKXLuyThx48BNijAnOkCYrfI2n1CwqT/Gy+3N96EGEBE3sqSl7zLMcPg94qXqvEFTY8J/W1UxV1oMJ51mYIpkjW6XpVfqjE0b6ZbALPucfCLqF2eG/f01QghMLquKz/By9XkQ3UjMzOU2SstWenQtN68LSu8IZXcl/L688aCWnrOo6AVP1tYOAChs+62ijnW5Mi1WF6U/bn4HwTiM2cMMe/gxv8x4FIGnv6vBUnIAFP5AKGKeC4SmWveHEcGJb+xR67dtex5m7t0Z59RxPlrY6wybvvZHZg4aMwT1ao08yl9gWdeu6W7deky44MrU/I1tSskyRIx3MV3rwHNAG5ClUcdMUo/OVOrV6QaPs1VpuhJQbCoppDwFa2YFcozfxX4s34tUkNNfxnZJnW1r4z3r7tmyle6DvW84W0fZtTe6Zs1F3Gnz4WD1/FjZmiqzDwzGwsROi7rF7+Md+SEts5dYVA8IKIsavSmGvrNbnzKFvpORrotorNdXzJLy2941ucsfpkUq0hp/L5qm0P/h76CnT1/lHaXke9MXKfxop6757K3IYFF519O4+QopMlHh+nauTbDlxpM2Wo6zr43W5ckd96Gte/hWu6c9/+E2knBw96Us3e24kE9FEdsykL1b5WEn//IYoNzOL74K9bf+P7rsS0P7Ralvtq/tg8ZMX+1P834P/WheQy0pkqe6eE/D+NyxwR6+nxLr5g/MMv/0/rpGXDd6yeHYvf4jbFeVfFiz4tr7zhRtvKYLlW99dRfzVFun/UNEc6Wh33q0+RqTO1LUTIffXKl+zVTljJDDNeW12LW9YovbdOG8qWOUtzB+ciIS/w6LCgfcIb2NPv27Rju5MGEQK8Bjx/kDd+M8LFn039O3Yav0FG36c0/TqirDzfRfno4j65F5jLUzffVTprOMxvIPM/JwOzvwopvp1YKub6og2xliW3I3h+PLh2jtxwnH89QxlV9fM9gM19vFW11YACG51T+rWASBIuLB/rQaR6AASCAlfAoQLrQaREgvB8tQdaffZ+isvs9jR/oqAjDP7wE0C6QS3UVgE6d/M+0qwS23J2Tvove8kKPYCXoE9cHCX8eP/m2oE+gqp63xo/gf62GP7fxJdJexqXaukEBZ+uxd7tdcnhDCzGS4d4NOl9O8OvnLlWbhyNQ2ycR0NgyHpdwXwmdsY3PWAFY88NRimy1lYK+0Oa5U9YZXaG9Ya+8NaqzysdSrCWq8yrA2qwtqoJqxNasPaqj6sbQxhbXcwrB0OhbXT4bBGOxnWZOfAWqYx7K97W7i/7V3h/r5/KfzjoCDpolbYFaHV9mmOUJlqLRHarE5rhLY4oC3SdWvcpq2K9IE1bfNKI12/5m3Z6kgb1rKtWxPpg2vdtq2N9KG1bfvWRfrw2rdj6yPdsI7t3IZIH1nndq0sE9fOuI1buRVhLPDjB0xTkGKqWPtDihuZRoTPZFue10jrv/KNmpd7HQvBYcJgQ0w0iz0HjvzMNc98iRSSrbPeZuVq1WnQ5bJb7rnvbTsdCCRkg4ZLlCQZDh4Tl0gVcqtWHfKpTyNWK7t3hvtU3yh/Yb1rAk+fwkqr/LUv+pIv+4qv+pqv+0awQxv28EY7iAJIm3LhSt9fo8txfIVU6/wcufLkT5NSt6RXPC6VgyQXWREa4Qy2Svs/hBXbtM3bsq3btu3bsZ3b1U/ou5MgpuBtqfVhIAgMgcLgCGTHBcfywc5fJX0NSowr/iM0vrhR/wxR4RmSRENNFFU5s9qsMWrpXNZQbeAgbmtDgWPx7fwF1mGbyDXpGW00BnYtmMXSwXcOPgtSqKzqrqU7dE89ROfqIl2iR+kxeqJO6+l6pl6u1+iH9E79WHnCSn+KUvRgD3j+HAocEg7p19lCaLMpJakeWlvbUNttkarazlJtD9X2cYcqh7rdGQ/ZfeL8zt7x+QU6nNzehw8OBz+jvYcKIEtWPbe0NKg72At8QUGbvJ+mF2Vu+cBRTSo6J/7n4FnTdbFhdy05Q5waz5Qhfi12SDVpaUg+lLRXcLQXQ4W1ba2HtncNUj10pNaIoaauTepq7Vr9GbORRrQMTXPTuP5uKYahubW5GJo/NL8Xn06HNmWG2jSyFjBy9CiXrku3DPJD68qece6QKhcySnZgmHfpY2DXgvVm6tQwHUuoFF08vucrfXMwQeFkETac8hruyvaF5EINas/j56zVRU8W7XSl7ug8jm6maOQskaHc77lo/HC332g1iwsprKMZLKn9pgAwjGfgg90pnt/Jsw7cneS0lv3Lfup3/aDB8uri4K6FwGzvObKDo4Z5oUV+utEVbMZH4BjPFWCDGDaNNVaZ9NWZYQ/7JAYbZUmqdLpQOYBbIT/vplPhqzsB68HXtELjmtoV4sSSuIDrfLvl0dtZAoIAQsZhMYW+DS1ohKPpe0IO9w9RHMF0oFdQp4IbgY4WZ2z0NPwPaF/Ov8/mx8GxFjaisCmKX1Zq4cwxbtFnM5wCf1FFVEL5zZZJ7i8qVWoT+Sa5SvfmHO3OV3YAE8dpjDbeXNmvfHw/xdCtkNfUSn8NsavSBxoeIVhQY19lPoaLEGmdrx24xbSubfF2jeMQqm2rbXfCutqu1n4PIY30ovZ5FWLSvlIbY1MFuA6HUN64sMOrnms33SWkobSbT4pTi+cOGVxLF7jY5rrLutnPDrAswkXXSA53BSsq50yujbjS7Ad+yJHJHpj4xAzCIhguyx273KE3lufOPmpkvrfwcThgBzdaQVMXNVp6dfGk8Yw/9fRZYYp4XFHr5vAz4oZasXvaJaeONDLsjTCAoEeoFgsnNz5ylYkLqzOUrundUtO7X2V7Tsru5fHFe/umFEDewq3m8kjjEBs4P2IqC/xDjBjSdCX8DKfVzeViDARK7DP0s1JJulTny1x/lXmsTVQHddd8mdhdXnfxSJWXHeCELgU61TvEFRGLL/1O5zknXCcAWoU2IhHyfuXQOiZcJ9CCmRigocmJ+gnulkjsAEmELY76oJbsO6X1dBrzrd8SQFQV+UpZrzMTY2BE9Bd0r6w5sdyURMtNmwng0ycBWCtuoa1xSVC2wJxvb/U6OPfQyf/wKG36KIQNJzH/5/Rn7ToQy2vyJeCSvzrgXpsFGIHxS6pxKvdBgChNduz7+2xb5zDI5chboUMNQ1aMSUAprQa1zCYVjP7WU48dc1af2NH1uVavic7j51ljTTGTl91KN+fJawww5tguq2zoXKXb8bxfX/9cvf90nL/uAydk4MZBCLxnwfhkPA6fiSfic/FFeBqeg5fiW/G9+EUwCo/DcTgF/4XC3jt4S8/3rslYuTO3qrG1/x4P++IP/ujrvu1n/tg/UHFKrmfgDP93q+AavDTPbOGb7e7e/uTrXxwHZwQUPXfLVkvOGWIEJz7KNWSrQAk2kQBBfb/Nckf8pQce9SZ7fSUBUWwmHjruvntADr6yL+4lDXd4whvLr23Xrqvyarjarq7v+l6Je/EkXqUHFx43vHUYLsIn4lPxeEzaTMWz36cO/DC27TVm2DOWv9l/8mJ5k3n3Lj5kc1UWEVui8nWm/qY6J5xx5xlnatqFP0rmhuWXh1+FcPSvWgXJ3s/2G5xPPc8Sel+l6Jcq9Mqva/vdzHzw8++J3i/0INWFEW/P6Pnwn3r34fC9a2Gde42ypWI/SLr3733zfaHWI95rF6Mclnqpk0rGHfmMNp8/O29yf7JmwZwpl/mVLawFcGuaqDrceebQHADlpKIUFNPz8dkmkA/Bn083+wev5r4I6lwekPpQgL/gOoVa3BwWtZhlPmUZ07UDtjvzWcBC3gAq2L4s/c0qRmKdGa3TN3z3yT/rD/yRl/25V/2df/BabySCAADEiBCxGQB9iCQAvv5keaff6Bn8fsSfx6FezDeeJ/zxfjwa6XU/DMQnV/bKXflrmkEuCDeq163gCwmz3uEj/qM3M7Q5a5W8x/JWsTs2p+DWRU/mZvKAruz9n1ujjcE0lQdPgVg4wglIRJLKlC1HgWVK7bFXpSoH5+Pu+9Px+lmk0++5F95lQiNzNEQcvGw5KPLRANJIK70scqpVbepSt4b88mj9+2n1x7uaIpM72VJlApMsvEmub5MpkZoU0Z+A1OzDa74yUm+S+lYU+JBLyQzv356V7zpDYSwYaTBbo4znZJoZ7C0QItRcUyymFCdeOsVWQ5oNVltrnWpZmXlgwA1P3fPEM6/D8LlQBxosAVZiHxXjK0GnFPfUSqFKuVSuCvVILR/DPUJw0QiPjfXSBG867G2MVyZ5H+tDqEBwCAWzC4LpvlTePPAqDPyKBN8iILjYgsLELr1FpRUWrnnFxy0rfsSEkRKVV0S5iSMXVUExFRVdYbFR0ycnNRkZqcgNJD+IvHQUZmBJERQnpCgjK4tmRVEsL5LdpbAjDWuSsist21Ozs2T2l0ZNOdQ6VHENlXS4JakrbWNyzLkuoOi8CwdehEoSsaopAHX3jIK0+wb7ukCdATHDWo3FBBkdrrKGnvzkuIPz9Pmge5wcqqqtTr9onVp9TNGMXEFUao3OpaxRk2Yt2lW0TcuCqjlYbA4sEEukGpqmZuYWllY2CZXao6ZBEDmFt0uqB/p/LyYmAciXmVijnMJcwt3meeItMv5PYb0ifaL8ol0T4zqMG2LdFOeWBHdg3ZXoniR26sK/KKgog33pKS+dIe4b5iFLbrLmNhvuGMRdVtxCcgmDK0y5yoxrTLjMMT9wLgDcCoaZvsX5kdvPeL/K9722UptfcnS8VAlKiJEsVvLYJcUpMWaahGgTk5IEXVKSE7G+BMqSsakktkSzNSXbUrE5BQfKp6486ivAUGFpCjoPjnPOdXY+AO1tLsrduN6GMAAIgkDCgWCoH9WaNELALIzrvTivTu/7HB/m+jjT21nePeSehu9TuaPu6/Ibn5vubyc7zZ9BxbLbpZIc73D5OTdLuCxv+ajo/67PHcA/xfWTnTIXzxvIv/v9ZeeyM+4UT8vu/uVhRvIg/ofj70fxDz73lSeuueKx731WsNCX+QtcDVz1r+qKvx75zuW8+b6ovOzraCniEtJJkyqrqZNGQ+W1f399Od2N90bIKl8gFIklUplep9WoVUqDm7uHwldZQUVRVUlNTka2I4P7M69nSAUsYRs/G2R99wb+tf6P4dEiEpCCsTdfG+qYMZ+VlnrgMoU2HBDzg47vz34enN5x7udjvMciQRME13xfgbVrcDtrtPe/PB+PmLyGMdK1FyqPN75UiycjOTbWEtwitqXXIldsB9dlDnTz2EZ5iEUCbQtAc6bH9wtXsyJCuX9W49rlo/p2JfdPQWY2t6xjQ7k5bVWtxmmSu+1TC6ls053O1lMsFeLaSsU0aZwNLvyJtlPNt4aKFYWgTE9JO0JG6ZkaNOC/Rkm/2lNl2R/1aStvWXDd/e0rfZNuzs7FzZ2TRpfT1z3TV0UG+djwlBgZUkp0RZcI/RvDGOmXeCLIQyBcuICviTEa+0G17gaYdzIcEZc9cXzg1meGJNbV9nm8zmWEvJlrI49Vm6hkqDKPtANOKU67LAF9sOixMVGF255GM0efBsbaepazsixrQlFMZm/jUAK8Zk3f4VxPk/sjmrUlPpFUp791InebIYtpx4dtE3fVi1qVAbn3gzAqMfpxTV1WQIplC/I6RtX1qZkTEGAXqTZj8mfx6a3TOQpgtJLj6FrkcV6TuTEr8EIvvj6IlhrJdt99sFaD6EYryjIUglxIKqJ48KZSV9BI2gWGNogj+xCRlk/txWyv+cvDVnXYP8BYMEEccNPuLBlIob/trRGrHyyrqSHnaxX/b8l3WcfIALkaVytrH1LNNAEZfBnXCTo8Dl0irXBdlCepKyz4gKWRWJJF0lbA2r7P8tvTV2S3chogcWLHr+3dOsamFHFLCRkI9QErzT5kcSxC+ZlU7nJ2h/MaclfAgi8iy86m3HPpF9rM52srPQNp1qCQ0rR+LCozDgeCWmIeTS1GfzeaAX6kR5JYtznV+/Yyiox8f9+znDn0mZoikxlL6RtAuJrvdwBf3C2cc8JzCTpiyXUn46/l0UvtEiEDubRISeSQmsgjLVFAeqKIjEQJmYkyshIVZCeqyElQOzOI6mO0eW3fX9WtV8x9DhR7SDZLeqepv+xW73Hq/25zUTALEQ+T5eIWgSQa8YhLfGIEEyMBMRISIxExEhMjCTGSEiMNYjNtYNZaoXN84DyjlqtX6zNH6V6763gXhVyMufWR61U8KxjCkHWJkzKqR0e6RnDos5t6TluVs23G3jqXdKfvP6mA/kA2kdEzQ+A709MjFKBL1V2NDDa0sDJA11PL5rxM5qHKYt4tY2AWQ9bx6RPbggzFCaqHs/sVmuLZZFKrrZ0h5wW9RsVzBB4oxZX0azhTkxH+2ATc2plrXzW3c+8DqZyDAFF5OeKbjuPnWK4tI5Yn6XoGzKYpXMJiGBUtm+VggJBcxMNwUktu/ZnYHdeYyXRHVxdky5BImNiWwXRYS18VIdDRGekYRYZGWGJsJiY7N06EIDcveRAFjbEkgzhpxhzkYLbyIDt4oQGJEMAlKYImgpJHPS9GjpJ6kHBeMEYQndMN09fgUg0ciZFSAr7MTsY3rjxCFBsAtAgGHFzDdU6okknQ76qvMCvWmLcCLFnFUse6t2Rl3UI1uKCjG4YSM3sf3PiiK944irC4mZffAf3aBIeoFEh0+xn9ttlVj1mtclelsnDxzfe+a7YPvVVv0cQf5W1wHq2xnWy0iOQG4F4vYnrFI6U8K3ab5S6/orgioEr3I+M+yjdYJ5P63ahkknb1HjJsuAMvaHv+CzF0YBAHQtiHnZVJY11lxCqLaH8nmJcK4QcemUes7AxBTP7xYVb2ebfF4GZ3U+p4/XY5Kh4jg9zF4YSykzKf7ej0ugDqCyoMUlcU5Z7BmklGOyvO0QKw+apz0aRNrh2Eu5EnqZN4G/l2EP7m38DKpVIRIxgU2kWEgyLHFCIaFNtFxMOS6I71lpwjpXYQ6UZNSZ2iuVHLDqK1GW0s0Yr2OVbHLqIzjC4wA7qDenYRveFP38qmN7U3+jOjfUTbIAPOvj8o8RA5x72hqAFdDINyBBSjD+gtim5M3nLj8tZiAoRHN6mPxRQopkEx84CsFvDoZiXAzUmAYwlw81pMFAugWAT9EhcD3bIEuhUJdKsS6NYUxTooNsBbNqfcp7zV/ltjMfZrESbm1k/JGDxy6VLW9fEyeUOa+uGh/6D+L9RUFALlTBuAOCWAjt0AYlIw6zPByrcABt8Ceh4Dd5yAwfnbH+CBc0g1fqNXJco3nm/zuOl2ZMLj/k01vwLplCCQTtPs9BMx0exKcZXjeZPsQ6f37aFP4uf//6l6Fljof4LtDb5yzmVNu/rx2+e4iYMFfAicTTR+XxEvP3sDO8ac2+4P76wGjCJHbaOCw+y0JfEzheBxAwRi4LptVrq5WMYtve5YKz6RST+uyCVpLfwtVZimQZxwKPOjYJXFpQrbvdrBSjYVWkhA3H06F2Nwi1W6kTzC9eXlZHmHykilbUbgCnFNy7lju+thX2oEd8kGg+ckZkF5OD/MnQe2hS3x01/rlS9OL8Me+dOy6C0Wp6vz7YTTqh+6XEHt1rh6mau34Z5Xmg9IH7IohK+gHE5Smr53QlLw+VsdAOsCg/suO1eaLq/IoJQ0kWtmLzqL5m/PNh610JNUv9zyc80TdxNn4JErXWk78hpTqhyu833wxH7iFIGUda+fjxuM06nzCZ+lbR6jzK+JLCpWBx1fpxw2W6iyMZg9w4svvaXTad2i+mXyQ8eIWAxBrmHVaLbn4H6PX/Jyn/NwFrI6ub0gTVyfErNh4A7+SoOV9PmqvbUt6/FV7i6HUnYk7yCoGimO8SJyF4fYEPKxSmTki2gchDuAV2Oaji9yd2A8l7QIfEUu5LDj9hTAbrukqjwp7oF9HYEdACYy7ZmvA+bj+PSpYa+IqjjaMwpSfS/Rag4FUZpztJsRtTNfq9RMqnl1R6/DHHdUOgY8ce2hJMWxQtxW/Xx4TP+rzY5+fn0M/a2cmOJDjdi3qKarsxULgjneRB6W0un2/ffTcFc76C1uah9W60NvMvm21udrFjUYB5p2dcPEWnRHjtKRPl8WFMS5RrJHv+ZqPXLkbbeZIY2gtQUBFyHk+S8vIxRlMzXRlMbAYMvRxT0QyqjxApH+fjZTMkmSeKaKhVgYzjIDMCAEGepSVpO2OXXgIogWSfzOTeDHHkuSZFc0pNRAWLk22o0TreOrVjd7jaYBnU+X1RW11XXVT9WkawXMe3chQf7bJ3l4WupdBD1siRfby4CeISGcvITjtTRiLAk6FsfsPdiQe3sz3FCQ6EumbOmrw95qbGalDy2eOeHjwq1WFWFHurr9DMSGEjrpX0I2TRWX+gZ0Qs75rmRBkmbVwny7z5QwlPhHMBJ2GgPgXM+/p9HiLiFh6JSU0YhEJwqMWNiQRGDE5QG/zGuoBUldjcFQcksuHhmqtiMZgm4Bzjfvzla8nrMdkeYAhDs5E7dsGaHWxwskVtNfi8GO/uuGoeYV9/zBGFD3USBKy2wUBImoECUIbWjhG4M68XdIy7mHayQfeP2fXWnFbYiayStkmXMe6gv5Mh2ye9qziU5PEUP2S1OOCu9cDnizbGLhlERokB3QpCo8CMutvVRxc6YnV54iBoEyZtsY9rD5pN9WSZ6hyGMn67qzjb5lBR4nbGjXUO0ZZAXjtKFBpMU5gWQOAL3Rka4IKhrpLV2OwPE2CeiKWYus1Q9oLGL7xgsUQ5MQW4RmxS8iGyyWNux5FS1Lt2AZLUlDLfyEmpsP8KYQgx5mXtBg4ka/2eY27DAX/on3wojEP+BC5v1HQQ6wA7rrur0GUP/w4MObe2HCz/7/LSwqKbwgFkcJ5pmMKINV/ks9VU+wZdZINEm0MNiwQWtVhmiS+GqBhxuhsj1+oJLJB1gDMy3niC8XjQd0JOGOO2iEFWs4tKceV37Bops8+DDWRQVyHHVL/A6GIvXfjO2KB7TXFFab5wSguO9u7tyl4uHbJzrMYc3VC5TrrdCd3nZjAR3s0JVR0ihHMi+srxciPuw4V6PeS4DMEfiEYgxgyv4IbxRovZwOqAx2pr0frkbUeYQgWYiRrLmsSxIYej9mL8ZHhJTyEIcvIElb0REEOKRd5wPBWiZ8MZOBl+wYFNyWb4OaskIt5qDgmTlqYL39TzjP4wC7STpfOHklIuGdK7xTuwV9glsj6nEh763j9jGLAMGpugEAuA4saLCIseFIiw8Ic/TcJA7NRsUzqWhYYeUcVPjAbrf6p7Oc3h6KuWgRbqb40BTQ3mj5ZAiChF0ASnqvAf6NnXrHzdL16QS1qEFVtp4hKQymWEKNhEfGZRxULVITtCJRjnG/ayNLMUR+QgGqJLvBIjLejmmo2yOVaDsw9YnpLls+ad+SOh5MjVZvRjQmzNxIQb6BTb405SRbeSK8uUkEW3VtIeQ+WrIadzLIlWOULwjRU9bYoT75ejF67Bv9TMk4mk0PHm4E1CdO6tQrSJpQahLzalohTqIPs1t1e86TU8gFa68oeboOQx3UosIA0zmdh6XSNCUz4hJBQyHLPB8nbFZFXMk4xa5J6P6QREbDtaIwFFEx8zmLqpbtHVoJOqMtvaJll6x7bpKsgA6/NwdqfKVv2inXL7IgqtDdtGxs8lW1Ki5S3N4ReE7Jir8TaGeE/CYFRImW9sbSIIdkibLXtPz7ZZ/+C6HnPP19ycQdkPtH5kHrOb5cXAHML25vfxKQP7Tn2CSakdoltzB2MTlSizk84oIOAlsulED6xupNN90z2+F2ETw/p3ApSGyXS0kXntEsNjC4/XVl8bRqQW7Q7gKfB+jDy1fdWm5/FXi9foYSCk+9+MhX02pIgdNskMVESj1qcQvWEi1j8QKNZWPAJlEYvK45n+lOt0DrONh63/bAFHcoEj04Qgqeus3Tn4kM2rql4mvcWZ1JrkgmwN5eFuIUXVNG28cqlOeWvRaaA+4PFAzwPQ9i0AJaFlig2nXqq4jCOMgimGAEc65oHewpOL9fdPdQOMyjKKaCur3n0tHUFyFF2RQLDdtOY5K6aRtIehxStzpLlaQloHTFezo8B48INVvJZHhraA6yWGDow8HcYx8vc5Lih3wF9OMueoD2TugI2hpuLg0zPLdi4K+7GiThu3ihpbILKxbuof5yoJ9Q3j1f69DFoplu8XCaPN2G0uCGngPoitytnAsuVVcd8bFgAv8zIYGnJlwjna2t8PpxVqRqflTDll7x3oXtTTCew3JDG+7w9CS+QRBC4a9TQFjvU91rb+fuKveZzN10gZLPmSGBrP+KoskpN7pyd2L9Qv5Kf/nCK+7ymwebw8+9vO9CLF66ATdS9uL6DO0PR6g8mg6K9z/ejKuulnN0XGMp0cQRXE7X3v9XVAsnKwhdNCROuJbjM6C+mecR3M4TCkOJvZ8lPtJxyzdG7xBQ7HBHe4jrqPzqykU7I/k5Acuh92I2233SmHpV4qBZ+Xi2homja9iABRXcEeCiF9s2v44S+hl+Zmh4LYY5JvoMQ8siAyHbvxZuWBrTJeL56eDHjpbpz3yM+MYxYa8aa2+iibu7XOtGlrGD6Tp5izgCP0T5ZyKDNtHHDA+d60vgTyqxBB9IiLynFKQsQJE29EG6HzNOCKNIO9mGU7e6+BFkiEi0hc1vndZboHPR+IJNOBchUDp41qQfA4ROW1VTId+oojGBkJM2esmRbhjzajZKLcYqt5+ijxmGoi1qvEKWQ9kHJFnZ9HAV7sf336aTqdw69EVA5ma2W2rYMr3Io4Xer3hZ7SteRSDKrqo1/QKg17hC9w+HGX5cjsUl36zR+XW2M3IbqKI5v4xInlVxk8CzMcu4SexSHxp6h0b2rtvROr4/XiIgRqlQNOvEjTahIZc5Xm+/ppWxcEDse3DPBLWPH04Ak0N8QuzVYU9orzRWhFYxA8rgVrbOBFCZRQy98IdyOe8J8VuJsKM2ZMZYaIspzXEbjKT3RNyIlE0rvQoQx2osyWxon4ZnPMOwQxAfdu4xHCSb9/F+px6ZwR3YZOXXOV2rBNWoxsnEH+CD79v02SzV1dVDsoyXl+dhTRdjgdf+hDZZWWGyvLS0B3aOmN5QynuXsRRc0FYWPtZ06c0rrpuAAuQ6WMvZ0ISXALx0etYAQkIa0cCAsKGxIqV1m4TfEDCrnyTJh/tpH9hTMEeWpiKjJdwHkXvIVjfR2YyAY0kt72Ha4UaXZIsJfVTy8+VogDevtHLPWAibj1uyW67vpT/P61EJz2RDH7oWn4vafxuTnExWsO7k/3RZ5f/rwr9tO+6/vEVjcRCMvj8L9iwrqgReRGe7OSalzFD6LA0gg0U9X04tRFadJeRGGPi4DMniqs7PSxOIORHY0CmWkmNDS5X0hbTCsXUQF6undz6Za9j8RUI6MWD6nmBOvpzQV3HszWb69diH4eX/TfTpFfRMEOv6hJ51q2jgQ7DIhjdCmWrf59o/a9ihOel8fpx1HyWfzFrp47BhlXPHgvbHXRTiOKijhAFZzerKB/vy20/Odeh05aHBEu+tnSghEOz+ppA1PDIVOvK1WntjHOTJyOxXBQ9HNgH7VeI5wAZQqnOQDYaRfWLqlfk2SD/DNnbdJzIwvhdHOJL2oS1IBB5xchntfeZ/o5SEc7CUzRhHb0/Fbz7lNM0SYaYkhvJOkFTP3j+b4vmtDQh2k0TQF3g/47lAOti3Yl8r2n+JTGnC21vnc0MmU7fTgUppnfR2lUCmZjynCdADxYrjx8YL4s0XMviBIvKJgzRciNnetd2gITpeO8djlX1OofQVXUrrQbiWpjo4Xp9Pn+KTdIZPU6EInVq+RM5wGMVkQZvuTJ7c+YGyojoAECoKfFSj6fD8d/fG5hOZFAHATmezBwphLGuejQzDXAHzTClwCWSEWYTJ2d6xK8ZuBif8/3pokruPwufP8VmanOPzdOas62GzOsWn6cRJOsUnT/fiNdHsfxuMuLMNzkg40J85QNSYqra5ng7/LupzxdispB2Sfln1Z17FDmXpPRwctxvhwAHf9svxOt7YLdLqkWNtzbbD+FEj+8t1YX2f1Ec6JRoR05ojq+3rM7jzdp5Sqx/0sU2Xy6FzuOrvSjDGz79TjmFPUpXg3DnauISxsFs52bh2fHWYZE/+gnc2sCt8hs6X3HIH7cxa0C6RcpQu/XdzMmEI2H/6bgeVvdISfs3gY0NFb45DG/P+1ET/UAh3FZRj9VJO3V+PYzj8VPYbtvlPtT2nLORsMJGLFraKzdCOWDcTMctBhH6+vslLZTme7ITb1pcN3J+NdaofobpzumszRR42DJeyl7bR/bDNoFekv6Shu4XX2d2CPRn8yWDTx6/TTtW2cck8+K8MRiV9Z1ClDkuk0lEIOeCyJWd1MKaM94RnZfLSxPPT0EPqXEKjWGuJOEO+jxAth+hmJVARjYGAXnu456zA4ToNzGiZgRdSUhB6JchVhjfnh1trOUBBCVv1AdfiNZOoOv9QOvrQMOeVLztY63JUppuN1mABDcMKYdp8qH721q+X7iqc9uawLVVyDhk9WuirhtzPp4w4jfomTrrHgj/uwoZ1//PIC3NheeaCr6tJYtPNijyJQkihHNWkyrqOxLN1bLQoZYdR1rNdKIsAu8dpDwcbpEsnD+3M5gsSJl+txLFwn4Mb14Nnu/v/65Jbikx7r43YcmUZnpK6wj930di6RFNLoCMY+23m2V4vlndSjO8w6zgSR8/nBiltL3LGb/xb0hh/kujt+MJ1fHOnChvl1fWHYOUajleRNeXWGFiBw1cf84uDvsqG8oGS0KD5vGON5Jpf0QcJsA+VWsHfIO06kFzJ8QKyoF8+JYoJj80cC+FqvhGw/KIRSHN2XH8e5ryvb0Z8uvJRlbm0kMqMvPgoEz6s12WtVEcvk8SeZTYwH4E/nj7OPTUwbuoJhja2eGpFSNq9BDNnBRCmqso61KHg4hB+1armPOvltqZweUG62f4ey94OpxoGYdYbU4JuJnDV55JO97minfJ3YkDt0i8flhI2VdeWO2xwIfFeUMRNoWjhbuyF54C4OkXcWKCiwGz63P5ue60a92lYjYDbXP+lYTXus4Kc+TVXulsknO08AzyXCZOg8SC1pwIr7cOc5xXhHraob7Zdp5rv7Zp0ZA1c5Gwo6WaGXI5uz5BMXAy10NrR2UgX6WUdhp9165ALSQ2a5Z76YQ1j7BYar+aS8OassPnR5/ZrywhGP21qSPZ8Xvu6NOMoLjd/lWzWgVLKJ1PFlush+SjUSTDK5oMgAupM5j2pRseH2qnkPA1G7GJEp22ig6o3BhXTFqMkeG3W0vB/o+BR63mynJWQuNKz05aDI68CVfc5+oEz5xlgCTe3f9/c9m1d/6HTdOfDhfOrldBQvfuSoeS0aAyQmpKAWwm1QQxxLRz4RHSXVGEG09qNwe8StCwKGkzxfALRtGA5qX9A4MwbD01KEQoyfjKhMamHm5NKb1FpCXR2Uftg/aDgqsUqjI4PY25lMXxV2WFHvTHoqV34iQrtEsgmpPSoPxuKU1I6Vac3GqeR6qRrdd9JL1PzdKpD0UGvmmMabTQA+NCKs7B8bKIhwVoj2ehVRpkgjZK0ncSNvJZwwheQIvD6H9N5q3yUtbyBFKWItlvBdrBZZAM6zDTcoGkGqEAylrGC1XklVIwlIqH0N1Q1KjFvcrYbGtBm4IED9vlueHMKqEYL3fwx8TYhRYkXyULDHfEmZ1kxAQtQgYQHMqpRodFVtH0YU3RF9EP+D6++FhabMbnDNLMrIWvnzniY6uMrKN5RQVvQpvfElwP7yPzd9NnrEnTTazuWr1+PVa1eUzE/WbEW1bjLL3w4qQJYnyK788a8rV6LvmBfyjJrd/nevNI9BBOdcPUOeFfcGS8iC7z0kR18HNdJN8td8KiH28NBLx1cHo2Ci/om741BoaogyLvFOKvaKXNOafcTRf3PNGB2G2Ozlnrdzh/+6Agg4Se0rP8MRlnnO/4b9WxirPXt0MHQUB9ZGs4xFWgglZsUDVp6TmwR6BD6wHd9iuJdIlOGaGqZvcGkgTLg9AFqA9AhQHnQoIwUxApTSp6pkEAAMGn2QmobKAuprpqGOoKBGCpF0NGpuIFu7xy1qXn3SSNbBjNZryY4QZ0E4XULAPe2zUjJMmgDwKbUOE0VMSLPHH2mbIcShXyhO8e0W4okYKR8mjKz0sDhoAuki2F5JfUkZKS0pmD2RwPTMykbdY0UDkLb/rDwVj30UF+3e6BjwTnjPtRQv5KV56/sIUMWrSzUih+uh24XZV2SPDs7Y0xJ8Rw0qVVcBqoWw6gpnTHVlKvtbni3IVmrLR4a1+pyPoaoj7rxR1FuBcWpPqy/A5OYTvdibhq7kApr9gvz4xY/aAgYa02wEetdMjuUzB6b4hzxbwROHnA71RQ0J+wDnB0es6maqnhmyfqEt6mrL9eqjoeoFippbuHFBtYmym3j18tazKailNEZHHCF/WrcUnty4xziP8ktOH/g8cDUjz1cL8AWGvV8J34kVLtkBR3FiZR4g6M27NI+aqnOYLLbVD5xnrlyriVYAbuxk2xQq67t89nQWO43m9DengslvjocbbI/ZlxWFN+1OF2Fwen2YmWLrJOXc5B94ccR+cNMreynsZpvv3CR9+wgTheuNX73iP7H7nFKBVfkxtgdk0ax1PYYOJsn18iMcn0wDbmqfd0jSnSp6r5kif15cKCl7I6qoIOBN6CsbBnJoCO0scltfYoCToCLxC8XsyZ7vjIPV0vAz6Hmm4EX9acA7fy6g7Yd/XhxFlMMlLzk7y90bBkH+9M/P3EfdFda5+To/VfEsHsXIPj9R1sMW54chcMu/Ufw6ScdHmTA3GObnevsqrVxZNBeINRokTmG6tsmV3YBEjadIWEDXbgprZLLYKtLganK/ChTp5W309vO29lpM7lGffFN9qBojUHLMlmmJxdZVpsEJlMkbAvEdIyPTbd5t2yzux0LDcAmrxfYuFDv0Bu1dd6JBQu8C+u0yjJ2sLHfI9AAPnHDlob4KxstytRjK93qKfxYk9eqE7D4WkO01BmS5hnssY4sO33EK97VZdUadY7BFmeLa3Bp1exxg/s5ZICo2twodYdBssPXLtjZaTOKqtiSmkixNShaBBpLjbbpyUWO1SaNpcPfvtfwdy3kVzFq4B+OW+VFwf022c42r2yXLcKKao6oC4naRIk0RgXPKKfMNyOUYXh4ebVkaEq+HUjfbXhXXGzFy4tTDT36M7xZhFnCRGYRbglXGYqG4EO4Q/Dx/aBGoDPBRMlruZxmP8AY4m9SGYHpvdeQa10DC2RodG+rqtxKTxgzbonnASA7/FWErppFvG6Yiw4N0g0EmpDZke7fFRuJMJM3C5LP+v6pqkbOuwVoNPphzSsiSCurhWuFHHR2tgU5anDB6cNHFpwZtP6ZI4fd9+GA0WhZuXjKssposK6aWmxd2SBxFq1QNMEH4uuoirqTR4/Wna7I3uzIfwfvfrTBsOHJQTiY4tiUZRQWr1y8RKpCobpkcf/vbbPXWsa8NTWn0zISV9cD66RCkU4C9+hss8jwWPdYa3XtWPv4DTA9+ttY6Ni2BSOOHn1fjwL75dnF8xFSfWasMTCQPY0U9psFs/37CrhNPnutdX5rZanS8msuVxlzGYk+U2yTrcZ5RwCtmC/QioARKxrNiFK382WNQQprUBjoMKkBkFWSeRfOMySo4mxUkpLOY9nqqSpVLYdXHSK0BqGFGoNSrBXQMi6p8GIMgq3hUvRcFh9pKrTczzfZryoaWhxZjpundX49NLFDIOJXtjK1E/CEBlHwRQ65AwEvnTvK5In4Lyv9vNdhNHzdK0CTo1qHlvg+Rz63gHa1GrRbTuYLsiLlTryNahpE9GrtSqW2LQO7IwU7IgI0I4mFBWObfUzCetB07PdvLzgOVXHmsC04jdoLNn6dItExk4nZLv4I/xslIKIa6idVp8urVqZCP/fpik8qq2bw/UT+mde3u7eq97i/357J67aSiixO8cE3TLAaBv14RG/EJwstC6dficDLZ++3DrVVA1qnCruvoGxj2iqcdwqSifgChRicsqLRJYOiYLR7agbE7u0Lt61zJvO77lR/h3kUTtVl5QvJUghAog9lSXkiNvPqSUtwJNDqsJXXe6tvYd5GZwK/peZljAfKXYVFKj2kFxdsTbeuySCQ/kCvCGcqlVCpGhGhTeEQXpaVedRiDEp6b1CfLSaLdVrTyHjOXwF6ioWQht4MB2PMcpWkMrf6ubhkUrrVX5cjzSDkSI8ChQRIEy0Nm0jOICXMaMKZpkKPP6iZhd/hjSUsebWE0WcyMfqqJYBOoqm3OzR1IpWhzmHX10+zw4EmCbcfhrl9TVLA2uGKspiDjspZtFLm0N9GFQ3gfmwOijL31HPDwpsh+UfRWIJ/B89q/EGPqbBYp9TX2x36OkCkqXPYNfXT98MrmqaHhptWV9CkWOvpPLKiC1+nvYXpbwtHearWXlWdgCFpJ63/NTQ/XNXI57brIK7X/jmhIkmSLsTL9nXnDqmTlcqgWNW3FQTNZNFQIwGXt792aHRxk04FOVxayKpSQXaTCbILisPVjRJOPwxz+jxSlaxeyO2zJo0EwpBJViIuumgNjpN32H6VEoM0WgWXDwKc0K9xdCghTd0offY8MMzp90jqZgJMevi9iAqv/ckONajkCEA155u5pcDSTIUSUO8F9qYHZ2TeBe7OmUlbTd3GaJk56OglvlLD5iC5xuISSZ2I067WsL01IjHLQkuBoV+dvrqWCKnehdIjvdElk2tcBgPoOpaUv6PKqV99uXauRv7fwNXymWAJpBXcfj69VzULhwiN+QzE1mI1wfz/tAg1WoAHhaIh4NvBy0D63DFA1TQN7M6pKDr3MyDEqBQaiGCbhb/0S229evdGUc1//6htmlShecC3v+Jp+AFg/urVT9tPF40mYbR+2us6oi7WHXTmvTwh21xTDsOKa/j0JVLDZ5P0cobTC9f8gHPJHCVMPkTPtbFMMB9ga3h8WAPwG+HX6xDptHI9YMTFpcuOkwvJ4apGq0QmYoUq9ftMsE8grtSpoDqHQ1uq5x+4+Rj0/nCNZXpo2LJaoyODJiGJDBkWzCd6zTHIojw5coOoI+Y+IcQhEshp2XPrP/t9a+hqhVSvm94NouBCuJihq9IWDqhUQKC1rgQmy25NX5eBtU4n1MpkkNtdoausq3x+B/IG0VPY2oqEkHZati6v8+ay60wxM81GpZPvLzGLyZCwcbaSYpxNwioNmYZvyWBySdNtGHDxIAqmfrgi11VWuLkla+WvwwobMDk4CVwNqkmsqWnSNHL4UtHr3QBCD5dVFrKgYnNQq5xZyhVmZGOdR9dqIhASnyyrtVWILQU0zYA5aJGQzuAMZJIOKcL186wkLqWQIXZlcaHXEnpFeYnI3VRtYLJBlHSwvlzmGm3oEUJCHcwXCswyhKKjCGSl9MKPBDyFUvR6oW/tSsYB4EA/3P818DVDKVsKOBv+Xfnnsfzk2Gbp5mYYW9o03tzq4w3uw/N4VX4i9weH65welwkWaBlKtkABKXgwBkLIFa03CudOIYUiwaoHBDUjmD/Oxzg2fqyYw/qcgTpXlJ7Qthg2sscctTEemVZ1AjHORR33c09eXHCx6ljAmQj3ym/VmYoWTAP81C3ujLTzIY4tJ2ZOOL6DfzxGbzfAunY5sM28chYAHMU/XTkYgNidjMLRe2pBfLjWrUliO9R25OvlMEbjr7YYC8g6ppiFsxWX6FDMZqZJOvXEmStWyFRy0e+HgWCBgLsZUKEvFaaLTTn3bnZQ75Iz5zwtEpsxvsye1YRiQl91l7wj53vZzfGZfmmpfylMAWMgq1SpkksGEjHhPLxfeEqt0P/Eiks5yQSsIWa6O4YoJ3eDdhcE2V2g1lGmgxwujTD30xLapdy8j6m0j/Kg2XWw9Myy7tH22urRtu6lxmVbRxdsXWapmj0HN3rZaBs1rkeekUppFQWCICDyBLx+Dj2n6GOnf9R45KXFzxhezY/IzNiM/ofHuOXk7TxPHRpdV77DvcFdvhw2IablcPnMdgi2hn5hQhBxYRTYQuNZSdYguUZkUMCCUoGKL+iH+0vlhRKGRq6FlcJ6axDCtjUy9EATg+vgiHmgOHo+cT6L7mxkTshnkep/qnxnKVhWPkjmXMTDdyvcHprZUorGwYkpN5ns/JZZxHuZegetZwvFCt7s3esDVeLlueDq2KYFSZLUyyHO947tPOb8yfvPTJER7RdlBZtk7EGTiT1oXwZohUH7Z94KTZVuClJXPsuB1FUV7nk2VJ89i3jzvAjvZ2L5Xx66LJvraqn1oBF/tYjF4TkpNwTIrJ7UgEeJJpekFIN7AXBlj1fO61MNMjs3A81oILIvatk12tXcNNquhWNBkEQFQHJomQ6X7OaxErx09oKRhziQV93nrYVPopoPO5uMzcf1mi1hcGTKx1hcvh+q1hY4gZZ2q8frxN4J0HOEYrUxLl/U9Es3kTw/zoWbRZgbmUgyjmvLo7q0DS311g7uRu4LI67wLwX9Wlw6rrlog9QKNA8EdwTQYXpw59EMbpOiIWJUlYliO2yBgY+Y+C0X9Ae3dzYEMo3aaI09KKFpxOcyddp4O9u9+onptA6hZ7wzMBpO/fJbKLOQbqQUGfmpSALvE3I+SPpO7oybRZjmwD1lGxzuskPnzpYddDvc+oF7A8xcrCTrm4T+xqaEgW+yuD/Q1Ci/5H7TwTucboywVTpaxuq67s0iyX0HkjY3LQ5cDBp4MpmB52yLijQchA9SozkKwIQo1KwcaXoxjHhXw5/B988OiRMJ1R19PT2dA/39eK/BW4VUnTOcs/Wp+kKfsa9N3yq0mvythjzv/fswFn5HYRTtefwBbub4VezCEblmbg5u2svxu7J0x3112dal00enU3ZuJMSnX/EfsUxCSqQt1BOIm2j4oJZfGI8nJY7/dzwpKjkkYL5lYtH18xdcm5HR52dGinFEGJv0/cB2NVjucdMHIpk/IjPJXjdqwXlJ8FdkV2IGj2a2OHBbOtfLu7gGbgnXZf4V2HRlamH99bg8tQnY+wx5ZsAtwIPpKKRSMBbhL4J5k7s7XnlxvFY+i9y8C2XNh9ejuf6ribQpEAnuNg9qNOb+7WfUZl9IRwgS1GMeqEBHR1PC23rXrKhMHhHo6wu1UcEGggE41fW4ItJmD6xItzLY1Z3DfUp6S02pWifR6ixmLSwRQnbIotW5bJgXsF0rJd3oS2GLqSq73Lq/eCX9x6zMC+RNgwcKvyYRU+g7K0cwEwB1jjuCoTbDx6lzNXufjgAjd8OvzDMrgZVPjWlNx4XlRGWIOj2DMgcch5s7mgdMzTjV7/cHVzpCQ1sdO9Fr0Y7x13/Af4y/dqxF70Q7VvzxJ/ynmBxe0WQLA8wBtnKZ9AaZmMIoB9zUo1lEp1Rc22IOChM1a8vFjtwiRX7Bg1u3movkbVYQwsCrQlfazlxweWDe/PKPxy84Iszz15u3pUeAxDikiLyqGQPPfUUw1v8iVOEwjVtPqHgjBu5f3OdgTr/4WXTtzTWYVj5/81xpw+xoa/FmTuA/dwb4BjjzaeE3PSNp4Ao6zWZN7NUkR+Gj72tnjD94hEa4vByD1SIDEghFXmp1AncNOg43a7ZcOQIk00zlUMU5+BxroIgGZb94DmP0GKgfQIiR4t5RwEkPhg226inM7ma7GSLx2XXuWqtGQ9Z3r1WtE6HIZNTqLt0tDIxBp7ubz29SNR+gdcVeBL6bXX6z5+GccWD5Yb0y2wMgMa4rOm3Vn7Mko7tE9H0z9s85sEZ2mpCvJVEPkskHqaTaOAx8beYaPEuqP7P/+czzH1SkAyG7S8KBxo0Pany2o9sxDzrtKRWDIQINaFXAHeBOiBo0ihkq9qg5aB7UXaPMDLcbHtHARsP5gcqYQhH7OexAo5TbB69UOwrFYeBHqpDm6vl6jklS2GeCC/ttWw5UPRjS6K96ECKh0uscDh1QaSVA4FHaYpl//pnAVApVmStvYeCTAz3/awiZPDPJFhUUiMoc0wAu+WmGbjFfhOVCqVDO4q2RrllYBBcs9TttkF9X9C2fcwGuHrhnPbB+qsdda5bLyQPs7lb1CLikXI6gpyHOcfcVnBq+dj3wHFizPixN+spxt1z+0cLC+ISH8ENsfPrCS0S4uGLdcvn6F+FrHDNlnl+0On3eIb+F+C+0PLXsVCBhfhALEFwvD8HBvQ9z4s0BRl2Z6ffLMY4d/1vaFbaXFAeERfxStnOPrGbwTO8+JT4ON6cOoCGD+wfnzrQnpgn+evO2m2rf1BpbQc/fPLf4fxFj27xLMZvdbwZOqwLmH76YJeDPBzatR8wgpIVgsPgT/SORtxh8ofoRV6bNXrkVV4CLU03hLi+gyCnqRCLQsIwh0v5LgYsJrZGN+YDTt5zwqU4ywuExD8+S0chsUG0btZuQEbu1G5h+R1yLbwz+Cz6jVOUNggZqv03O5WqCtgFEEr72OAPncz95kQj53k8pBVilcl68cuHJ3o0pWUAmX8hJAICXy3sL+uYaAAZQw8gkZOCBdL1CJ2acnCNTozTt9FKXQKauUMUPZPcwOYbaAhnFnKjO62NKH7oLCyQaVlHBh2JsBqSD1H52dSnfrtFkAlhJXh9dvlFfUJ6sIEdpW63cnd52Emu1acEWG7HbvbBui/WXtqpE2YNNHgZgWrd5G3NGq/1/bdjo6eLBdz/6CChn+/Hk3r0wRFUX9HQ11TNDPz6UzZRLFWpEG6awBoXXLuhrb+5tczCyQFiiIpZR3bWkSdhHiGrvaw40W4KChDBTSFYnPi1S2EUyFswifCskMWUssURKb7YGheq63bV1vTVWr48gxYDlUqmorL3447F1DtB023ENgZF11l8Cy025UbKaYp4VsAb1gTy+zACr1SCiyNOQghwFS30wOenbjeo0orRGwGpSKPjNjfyJ/Kie0e1rLKlrhR0esa6s1hEHWENObOVCFX1hfcEzNhpfXstlN6pAQWszT2GUmyw6ADJJitREsqJYhbhWn2nm3Wi7AtpG4LugpbpttuSrHjE5St5WKHLKZKqyR/eZSjaLaS6nlpZWUBlmFpupvP9IVSaTiZythfKDbCmLTRNzuRwJl+a+X1gOuVUoEegASAcBAolVOJP7be/OdtW9a4c46Rae/PXMkApCOgBMztXkKMuQVbbL65XtHLJZIG2T7WS7whbIewq4weWCPQqLPD+kmRpCBk5TltiS+fnzkov6L28pWKqv902v+oB4rJj0GSWRWoYSEPxS9NYBNOdU3O7/j3/IKKJK+ByhXGp5IaFmJ3KTU51f8I6tuqJg7JdyPEjAzKCl/EXILPy7lCPi2l/GzkvH38YmJaUmsZPIhrTUcgIpH/ui4KSdwg9lrANiG4PDeCY49op2tIndtHSZkeyXhPb3RBpZKYurFiQuOTmvcgvnBvYu/1B2alY4njCexT31Qigv6eSXeOb3Sg0KkUwr5qR/v5XwTw7uIfLtgc08lpSHq+JbdHYhm7AvMOBYFqk7m7De2sR37ZUHhHWSHWyAEsg5wVBwd3F194CpOPSsXQV7XmcXvhLwhfTC7Nd7+P/JogMc2UseI+FpWtrTBAb3BGHDJ5ohECfMizZlozRS8R6TO0G7iItN+O9XJB+ZPNnHvT4gh7g+MOCYNfRrK3LU+Lozh4+sOz0+ru0jh118TFLdtWHlSrCqn39pV/NaBNotfFyVlMfibT7wrekRLucfworv8RytWCYyKK7nrCdkd5OyjgUErveEHldrDDdsnHCAqOOjQw3tv4Qok42/isSUK5gxEXJh8l9wY/07erfqnSX0aHb7DkT8sFIyR24aav/Lghtm5sf2XeIn25bkWqtsSwtP910uoqPF78pQ1ETKZ6Tisayd4rwrq47xvnCmJnMTs6mSFxa5VMiR8KlFjA/H/7877hSngMwBTxa8wOaTCOWpaQZyEjspNSkJexufPi/2pV3E5ZT+XZhJ+CuFlsGEBCBdbDtKO/ZK8IzBYdgOrGpeRs3hsOUlwhenuFnjBHx4Vmr2IT727g3OlnmVJ5ckCrhqVqlGps3jCHUC9iAP35et36ffpX3SZyI7dxdDcYITSGEDkh11BDJHDnDoWf/hu+hzhHS+4JVasIupkg1AJU5lJoiEmZfYBpmJWkpzh/1Y8DB4HDwE5oUd9bNgWTmK6gFN+qQYe4uKN8d9gFouRH150xMQSBBOl4BcKT0JVm0LdoBxIibIlM+VtgFV+XQ+E3Vr68CG4uKNn8Gfb0UBJOlw5Q1WT2OhX97ygKpqUX9/hgGrv1LqoQhm5RX20pqVVGts8h13AW7eWmXl3MyJW9HPT7Fd1JVH0gsHre4QmaKl6lULg7jIuB6sEaiCXCkaaA79BnVCOUeLlIRGLUL1K8aERrl81Ip69GwCFRMesyBXTXWA4B0afNPmbZuface/6OqqYwtU+lXj4TSEMesLFx4AL5GHXoMxlGEjZfgq+BNlKBGkyVNe9EGy5hr4MgWKAvNSILnOnaQ2Jquv6e4R+UlWgO5kzYGfmmIDHFAt4VcwNH+ICRoqk0p+9fX7ip5tpW9l+HpaufscoaHRVzNDygIrSY+Rx6TAyuCyTOvVcgT+ktW/f5hMhJkZXPLkhJQ5384pKXBpbcc1XIlEwgc06hCFNShIJKj2sFUiN41h55VyQWFu76f0ujlfv29tY7qxyWeX4+YzjGwxT//Xoo9KkOpbdN7EF0voF2nVwaexBU2+lJZ6Ni3/HYXyLj/t7Lz0CynHKhZsADa8q49Vr6hZccz9DrkJb0lMTeRfdFovnhJcdJj2eVXZ583hMkv6+45wmTP7onKQAyBCwmXmCLKnHNnn0fnofHHYwC0c2NMgGU3nsD813R4HiiGH4DApKRhc0iY5NDT6swBp+ALZE+SJDI4OkCZ/U7aaQiZnVvt/w8C7kuoltJx0lcLqRgo3XgFcvTNlZIJJB7eUB8qynRfd/Y+uToerfAMuB3GxBhXdRp0WPA4Sd15jSPJU+UUcpn7tWQebmukgbd2utYecbGZlk1YKL8UvV6k0sZqrAeTGZRlLlUqsMS4FFNiXTbAgh5FjywpLYNIHL2ZFtxko09SRaV0MA6OLRq7TAGVmC2gu0BY41ExEFRKsCmaa1Q7/uWaQf6G7+K2yzMrgYGUICzmEpYm1+ZebhA6h/PnV55mLm546kwsdpL0r/r6X9ecd1q0LD+7MBb+/gkXZA8dYwTVmBe/5UVcI3vHL/u+T57aXBJgejHUpl8Ilx0wJrMsoWcmVhN8P2D1P9YVblh3qztEfWgbdLfzvD2CG/awgtCe0yvXE1l5dfXXlelLudFWSts/l3Nj6xM68yzd9Z3Dq5VILpulGGpOGYtV7LqqoduE2gDUVvo3Rt6v3rDZYjj+CbkG0lAdUuZqxr+9sLZtdAVXkkPKIvz1VHlGTFNb24dcffgUBkUPm28eVDAEOFpIlbwDatZETEygEVLFMs34rsCdLHDmxAOUOmd1RJi+vDKmuNv7BxUNl66tv8LPL7dqV4P/BgJYiy/TtaUvAIPgTmNHDVJTK/H5S+Mk4trH0OhwHUSnQLOR0XA2wuYZBso0czVqgHuvrpKwYJQJoMSTSdW4BiBvBL6WhQalAHaofUi2/kOdC0R5rmgqPCQ+pnw2fVegT6kW9SBX9xjcV3XMASIWhJ5Ilq8cuOcNfNKqpp+RGAAnz8WWHl6vv6/zmZ+zpqTuJAnVzgFH0eZ0gA93aFRkE68YyUb8bIioyHAKddaGB+37gZGpX8vj5IeY0cSrB4Tv8FAi9oXtbEq6Ddbu83ujhDLub0YAIhioFk4h+Vg4OdHWoes7ZZZlZA+BvL7wAPyh0f6fQ5KISUBecU1+ooDQV1JJH7XoDAwlC9cXtn8GfSRfcb9oZt255UHGXz96S6sm4CcaMpmWmUfjgNtNBsdG4tR3dz9vX3NmpghfO6q+icjsNqJ6znu7MJpYLAd6tjF1R+eXtevDt3ZLS04tn+AW1ejYE9nZL3jvSZxfOefyB1AHO1Hzab17RIhNqsiOPrm9HsC1vSWzZFtSNm/lWZWdQkwzFxRvIMOptNdwPIbOs4+7SS6L8Z6TEhgCfdoBD4PKXkxmX6+aP1RdVB3BO40DSSUUMRlGJ8cN9/bl1O5SoGXcdVEW/8ZX6G3z76Uh43jUGmoUQbL0AS7JDnNcX5pfNWzmLKAovw2sjVSX8ON/DWVFgyKBfFFlG1AUQcmrjmETj22DTqGnspa0zHNyKTnrfKvzvYDBFpmVWyFZi2sDo7GyxZLAaEKMt5a6zT3cF98h/H/gdiQztNO9pwNqHofK+VeNjIZ7M4OfyjJpLvYN64WjUQRnN2GpTd8wLhf5837Pt9EPopZCX8W3fdqOdnBhku1PgbXmr/eq2AY+i+EBhexFrd851+3mwv74LhHSwUkg39BzqFCeBXo+KQ5LKFEhYW2K7xCNd6auW76esXSupNZjkO3QYFyH+Cc7FT2wTT8SudmbG9SsCvlO9WRzFAgOLJJia2duVVWJglfA1I+Ia15RZ4bbBzr8/OHioPjAwMMATGNBNwu7ZtienVeiBWoM/dyTTgB3YKZpv/vLDo41DzD7vwUMXfnRWxWLgzCu3hnnoFR5JdY2IKax1zp5te7Ck7srDeGRujzoOthyxfuJ30pN16X1vJGjWH7oacfInNY9fDxL8zzwxzki/k9znn0/q3IFwUkeCq7Epz/k7gU7JUsY8QrdlJKeaAhz+9rwpM1jKtpQUO/jnpsRdAsrti15aKMcoH+iT601d5by9AS3+FnLTl3evKB4PbUojG4JEweIUIw6XbwwWB4lwhrNfWzkis7dYzUOw8kxJpg7LoOvTHmUa2RJLVzHIM2NByiDH1JQHu1kXgx+C3PLPzddz2E0/oUwT848cLvPv6In6bRMsTtVPEaxhMP3OGN0aSgu3RJC6zFFHPZfyu1JFmqOBhbXzQXXvDAx0gsven8vubB8nvdvsmryJ09+k1+B93+op+5rAGWpAvyBoz8B6XgygK1O1FkOzkbWyopcw9pKEOz3zxJNJZTp04pxWsSwvWTkWAMnD6iIniYSSSMy+yGqzD5mqEHtMgv3jM5WLEK6YMLQigZ5gplbSE4riwXzGAfWzqJpOt70gSc4TSVMJ6kKtA9FDJkjBlth0JVs/L64xhoRnt5yDa6o1l6vw2rMjPxOzO7NJJ4jpCwrW0SRYvwO34XxZIVXMXRZJZZiKim0CAc1mKWLcm4V8cp+OXlrTXR2iQYKGZCyRVJGZLswHo2riERnb7CTZSQpFm8Fha7WG6UxBA4piduFFXLpYFauNtZBt+TojflVfAZkudhDSmYWerIxEAEPMPYlPuCRP2ZgXbp7vVOxqbFLstC3M5hGncmdTo3LXt1qEL6/UMBY5nJCpVMtlGfoip4OET5DMSdXQ88oEgjyXhkHNU2QXiEFpoI1MKqZpRUIaWJxb2iwNRCtdJiflMNudBwC5bjYbCFHduTsqclVZAi0q8saFLi69kscjM1wcobCck/7sppxLkeVVcoSF5PSUJ5q+UmlHQed2Wtqf8Xl8Wj29ruT3LxCSOWRaD6AlrKZMaIm2RZeWcc8IT3OFZ84+zjGw7rKMORLyWrIiN0+en5+nUJDImCblKbg8fBBUWZEEYnpmZjqRgGP/eC//gYnxICmgyQE5sIGTlWCl9s93fWHg7BbNlqPQUZaZ1VTusz7P0tdW70PvV33RXSpwQZAm442UlumgUldA92xPJZsDJQ9i5/FkdgmNk5xCptLyDI+BW8BFwslTutbmVt0pFUgGPiteW7a8ePmiTx+eHa8rW1G8YpEpcpY3+1p6mHd44GCNzWa3db9SVmsNAdYNN83ZtLZ8bdXh2RGpgCfox61fUa5p14aAYq3dzvsoxw7P0VxKf+pApF+3qHb2rVYEoTKzraxm/BLJzQ/JpefSznCzn87LEqx1jywcWVAZ16rJlqwhV6nowDvgHb1Kde5hUlnxb8VlSbJ74ehKMME2Vasr6SqXi4JDXPKQcnmoyxGhNQetYyjw41TVH7KdljXAP8S6tFmW79ye3rNeULXG0tzlcCSSMzJ4aEvGlH34sH14GLSEiuYlyYmb7PYVbVZ04YmvWnJyWl4Rc16VwZ8DZa/UwVbQEdE5HFJmDUILRXr7q8ZUh0thaKh1ou2AwxZe2xlmtgZ1MpWcX3QJ5fRcDZvO0LuLhQHqE2V5vwrjrtE/5IyksdzQowciJhD6I0APwsagkAHcGJ9vsedX7m1FGmsEHHAnTHUd5bCBflfnj/NkJKQ2CX/5/vmrutY3hum8GTsG7Bj4Or7wDSRT8UKc6ARLV01zS0cDnHC0jwXglisbCngwK0pvpQBFwPsNDRHFRp6YZWYKKkKw+kXlE81dkByi6l8bKzdDDUCc3CHXh80LDwvSy51xcg8AqR56BR/fhueP+1+mXp4XGX55j0r/o/9HM80+CID8/4D2w0L7gf2+P6J9kmqh4lj40zGs3b9GXRtbNvkpnAosUm22qe3h8LDTgzBjVYfJhuuHUv3S6IYiGQTJ1s2+ke5fVKYN69L8Ug92dBUY2nju0tDYpDagfDZKks5iWMpoPHVZEU3XXBl8VlpEYUvlLOytY4eBXVZK47N15u3apeBRGeqIt/gg/JPumv3wYvAIStYSO3AZsqyB9y94be67naPzKhIgzjK5fjlIzY/VweSNV80fd8BG8DPw0eWcy9V9ruIc+5zEC3UbwF2E4Wz0MLNLvmSXvoseZHXLIeZV4JH+PbQSuXjJExyFNwT1i1iwsgUeGiNrwhe2ey7EArMA6ZeWN7kdws77e89mBtafOgV+v5vh9cAlwB0z8VPW3q9ZNUHhjAadQVHNIV5ZsWJbLP2xTdMR0UEbsOPv7KaOhZAH7iFSG1gbmDPjzRXmZsvJ5Gy5MDc3T09fsklPIw//cNn5D7kkE3V4mYFGUuPeZGb+cxWnycrSAGd47kS5Z66+MUiEFO2G6cJgVXHKd0VCY+T4QteukGUWGYPFSjE5DPqps5F0Dv27zpnbtPzh6cgmsAisjwQjT0XmCeAPIukW8C2492jkl7lemDk03flIb0CGP0sHbqJfYqiO6d0wb02TUKmX82AMZMkH6IWErZ996soMq2wablKV1JdxhGRZ+nuJ7smO+Ymx6jrMIghqx69EHJzharFIRhFlEUwaqVImEivNkE5g4a1t4hltJsRo5VnfiphIcUfTngsaMit1X0YDg9GQcT6c9AhG88mS0nfjTTwVwyqsIq54tmnrBfkWle7LuFzyLmec8w+P5HMq4hxrPu2332hOqyI+RF/3JZh+maAdg2kXyPp3pB/gX3zVBm21lyVWbL8fLVxgTNyTJ57IiMhIz5PHmBTshu5uJQAMDQMASpHZlX7Pefv2AfDAdV2xyHhQgUpYNWgfz5l8lIqMjIg/iQMx8QEHqTo8xJQ5ViN35nQ6t0pQ+4i85asRrfA7Tm/bvnVrfa+PurH6D7lE9b5+KvZfQMl7f59nfOxv5sHY3r2e0dG/4Yn1BGccf9HG1lQuWSK5Yaw9/VgcctUE8BL32ZfEIlDht+74nxFqjqSZlhDbNQFO3Mw4u+XMFl8IGMyRdIG3eG6lLxgM8YlHlprR6dm1a8fOhqHBS6T79myC/T4pB8wRuJkcF5fLcbkZgrk6eufg0By/kvFfUMnkF2tzXtgJ2fYXOZe6WENvedeulq9Tmm9V+xCcSaQ0gg9rfR4JmM8tH91T2Hr/5rO9H/SCc4G9+K/3ZLIzJCdOWTo1lccisSannmm39TIXrFi4gsUIjHng67qtZ333GQR/E2xC/kpI+NtkMsHB0Rywn3KekoU1xXnNGDMl/BX82dcRUp/yPQAjGvbvhCCLlITBl890f6x+sI8IXkr4+68EU5LVYBg8d5SGd973JZrNJYddQ986XxPtN/iS4O2W7ThYZpFh4aeWp+/UpGUylW/JT31h+SLltXjzqKBfC3WxjJJJ3DbLNtwlVut3gzMv3fe6Kd3d3ecSEaNkI8b2eUYqwSRlMgpnwUh0GtpHpGX4JMg8FiCnEwAz5MB0iT175kVoDQUFuhfmkw1R0qjvz6L5fYrzn15z2O0w0PoKhKG/3H8JPR/4sYWKGbVSQXNdzeZpWGWN/NlZ+pvjIQtYa2VEuHnYCcF8KFZNQEJFQlTeUe6TyYR/E5J32/ev2IRn/0+x95BP31oYXXIviT4feNBJxYxbcaC5uWbzOKyCI392lmH6eNCwBIwI3xt2SDAfipUXSKhIiMor6tAnLZm/Zn5v/phi86FxZWs37LObEhy4NUjFTFuhoHqvplUrlSbyZ2cZr4wH9UrAiPDwsF2C+VCsfEBCRUJUWLAD1AqE5suBAcgA9M9XQNCwwtoGyM8NyxOh2qJCegOoA3rWb1vpAI6DxrBxeQy7zXA4TlqGx2XYXmsUvwJ233/xPCxi29i8o9NnF/lde/QP+PzayVf0OhxxIbjry+9XfbTJEJlS3Zu5game7fXr/6fsnXINftBZpa67VpJiWdyYpRY1ZHOSrW+5pglgYeFQhGrjTy2mvV/+RzlZfD6y39ZHPdjVU2x/rpCdb5h5PnflUMJvTx/Ktk+fHeBGbj303v2XfX/uFilRe1s6IZp4Nw7HyEBn/pn1Zzx94Z8kCg65oLgUopYsVCSiAjr9okq1IzWbXMZUpJS6Ax3SUI6279+emkJZWpN2auKeoFVRvIBrkP6tCXzzD/wGRK93pFXwaXA3u/5BDn4CZQEp67jO1f67JDqXNUh+LUYyIn2Zi/AvonDwY/+e9MV+DYJVkNaxKusdmSoAbR08L52q7rV/t0ZbwV1aMECul1gnj4Mfiyjh+MkPUjeBNBGSZdxPdo8KI/YTTC3EfKch3NG517Bn6V4QctuWnGN7aU6JZAwQYpVQ9OF4AsmQmGuGhLnXUCV0H98JTcLCwDmJSmNaYokJd8AKUPRBCsnlz//2iSgRv4HkAd98NcjdWYOqnvj8kTOvzZasY/E2TNDfYOQsSmvssXlWuGOumZ0wd+f3EsqdpOcHFLsUHzMbVJwRIKzwF4M7Zk535fy1+PF6pOsfv/fOoCroc7BpjhK8dkA1XsmYTP9JlFuMvdZHsOMlm38F/h3NkmWmx2PHs0tjE2ND+wqkcLZEBqCSoelRYT4J4ahiO7CjaxKjvU9pjrWk0JxIfjQyni7rxd1hnIc8drWAVpbDspruYFn6OtnJs7CK5N3W6s2bq61RGG09mut25x617lII+ZALuQHMj26t5rXFwd7Mbrr3uxXdBdQuetqrQxIsypBKFrUXc1OXDp5yL4lzs0i3KBQmp16ehTs2VqGhEFHl2CMPXsMWrWNoO4CgvQHHYUhasMeQ1Nbh6dxroCxNceVDbwjyMYOUh5xxbWVEyYM7MKe7cvYaghS4dsM9Ab0K+2yCTTjK8ZpdRSQFmTa9J4AQAsP6p5gdx57lZ/OvjqVFyBIrwxnGtK8Ip+dAZNC8BmKwMeDK98AUY0jNid5S4Hy4GhrwutTIhbKFo1nRCYQJPQ7jGZtUkHQa5mO1Kva8HQ9rvkGQqdriB8YZzC12guTUu/MCWOrnYejMWA9fmXszoloQe5FPHZaJMi2wSxN5Ry4nJQj1UEfoegm55PW2FF8G4oNPAul0Df/y/XkwyNGvwUL85vEwJnjhx6AOQenyk1cZWxnaeQgqnkDPgcgI72OwgHkVPQciI/THYMAmfcKeeE0uQpA4VRZHhCdepp5kG18jsSuzcjKzsFlKu1oi2V3ltrgR7VL/fW1JpJusQy7REPGmScSRNcS8vPgXgLGkzSbHmGvz5TIrDXM234i5/H6HM8g2vlqWyxEdyMw6UMzJBWTF5NIcaU78zApMN+b3SnZtRWz0vAhuFMYXW5JkIyVmRHwfF8vLLiEJlu1sVc5TEmVaHu0DTNSLOMz5Ec5IYELRB8TMFAPWGE8vy7RVIaWVq6/dK/tnwutnCPNplH+nYbERHz1Df97Iv1m0YUtWaCGDFHu86KRdmOZ3NyfvQWf+l3l/E4pH/pCGUkgn5+Fw4TMT3Wtp01wpRUqMxUBFEHE6R0zuFgfrolrylfgNlD7vRmEDImrIXiScXxZ+I8GQ9MGzbn6giecYMSuiI+9iold5S7yfxFEqMtO/zxnF+Ym1vvJN9tzb3MgYaUxJPJOIffPmJyAc8zqzJC6lbB9Z65/0h2hDLvVQVrW117X5crGaRrSlh9QhGZv14PsKqd4bPRYz71lM9Oq2koQcijsz/bvwSFfpjTdWPc2ee8uOii6JKcESCInzWkSPY0HJP260+moUXwd7F5eAQhC3IkFD26wJHjryCN5+y1ZArojfi03YFx+/LwG7N5m8PvF4EvajxMSPsEnHk3NfVjwYVD0g5r+sUT0YxGNCI/ZGfK6xaCI+J1YzftHpFUz85aO3Vuw5amIIUInkMltL8l6FwIWynD8wxu32Yt3MUg6R1D1VKvKlAKv8nP9G49giVbythInbKmzDqhqUsfE+hQw+blP5E85tCTjJxI0abku5UbMaATgRyTGrXOweFYDHtt/EJlT2Nh/EcZwgmUsB8F8FqTm19HBTmzzkp1VNzYfSKp8hj9IEk5FlryIjdwlLFTMt3DAQghZ7HLJ10UtNzX/jPCphOAEVhMaITyeSlp5OOABKdMGj/Fwb234Tk8kqDpESi8CfCzKen4/ATSXL89ex8qtsoMcB6SydpbMUq6kFnAiOo0L+03KOqHbh/btfk7HjxT9S8Ag3nzUJsie8vS1jr+/p91DymX9nkd3i0/IYli/grBJ56ScCLCJgZp9Jqkt1qS7VpX2pLu1Jgcej2HfM+FFvfXKG5cIPK6veCcJbSXLbqii3/KzL39HU5hGtJgwcHSht8KFy3LiEBiz/a3MW0RbsM4tA08CwnOPYcjAZbcGCadmhNMG4/bJaIrCz0mEjWQoBGiyAcfVL9VK91G10rWunsWLxntrY3A4sJfkDa7x875lLu1JoWYZ0Ata3Xqr2utmBuyMAADoqq2r0qq6KCaboVV0VAE29g8BSAGAdBdMeTrFrgmS2TUe5qW1aNMk2JSzbuli3cVrQECjFN4OhNjugL1rzPVNzWwf3OpapYozNNhjX1EAb1z/yLK0+PjMmaugotujVemLlJpuvWeUTgLVgfQ20pevDhcKV15SyOMNFdrpMvX4v856qAurLg8rLtmTq53zDHYQ6DOE/J7K/7Yqu/l7wcmr0TdI/FrlGAfQFBv/vG/Rw0WhhR9mDDFVhqP/N2GSrgR3qlWBI/nNiabpSm7P4zCNEJtEhXxjc+YagqxErg99FcqZ31j4RR0kWzSehT6a+gyFIBt8n9CxrRrUo7ChHk6EaaKjDYKePORZaFMidUJ832pHUkSH2UrrBqAuR3IdCXSFqTH2Bwa/mkbk+ZxJjHWPLfj7bfvLELLb/UDxfDOXD4K6e83Mn7GEh92Ic0cJEYYdqIkMyohRXkBvyvz8PRcNkxsecbYJdijurZSXfZS/IxdJj2aLjkZyHuNiOScOTPIyA4LodjR5K6INu8huW3EkoQ0A/Roo8jQsY/HxCT7d+ihd2lCPIUPUz1DLY9KMN6pM7EttbldvNIKx3a7tm2PllonkZ6o2XkTTtiMo9fa77rjZdYm/GiTg3WiaCyaxWm21wGILxhzHfSr3BnWIIbMQ2GXwdxlhajNgZhzFLpNPgjjaErQa/JWfn8mgY1LuHkoqsNrjNRvSbBnWTIXl7EpXXTuPk54tdWieroIlotuGzHzGJjrzNeapthhM28Irs3uFOhsHnDlv/LkU0W7I71KcwJOlQJD8kCBgC7XP4ewFHJi46TesJZFODIUwnMtsJqqqQy6mv6AsMvm/Qs4SitKMcDUMdfbYRrR3q83AsNg1NlrQT88pJRH7dTAKGsHwi+9/qq/5ayOXUV/QFBv//G/RooSjtKPvAUDf22LaCweuBDyeWoG6loV13VolF4fYvYjlb7Zdd7f6M+4hru+lETwb/78PWaz7RLQdbxk3gG11X1FWutVHdQ/fV5DY82UMlKyGKY6EXNbTxapitnt483ctehWmYRAEFV9w6g51tu0IxuxYUpnvKtfVWLyRb53QrI1t9LchUWX2c+mZUat19kg3Z+jOvUuXQjk5zItt2hYmCyWFDD4FZkKnrdVy4GKfAiVQtb9isFGz5J1wAYn9/NHI3XCRCH2TA1PQPZeEHwI48nMJu25Tgq9xHnsjIqULyRQGBu5TKTDlGLLs9zm+fXzCgMjsVkGDhh6G4JDmqypJwJwX8NYzlkKS/PKW/FN010f/FuKWbdMhdR3xK3jQP2Gl/uQ1fhAl1YK1/OEq16Pc5cm1fLDqEFx+irGsAdV8UKDMneMlbY5V9dwtvnYLBVkCBE4vzkZzRy89fOE3vXxON/oSNobxVstqYedmUL5uht6y2BmUbztvptr7owEVq+RnUfswp0UgTzbTQSltj0R4/tY70dQyJ+4dGmmimhVbaaN91PDO+2+8rLd3W9/j7zNNjmZvmUq4P3zcGNsp/v9Y63u2WZLtH7nuHJ2GFwBptsmwadLTz9+2OCp7+4L7Nw1ZKSufGf7B/LDgu/qWmcuPGjRs3btz4OMP2vTFjvq78BMRkdTcqjeSedGxZDpjFyJSg864KMjceBcauVGeTxIfpa9UraPxwZRElqwdQId7B+N3qnpDMBlTyKs/7Vr6Gj7HjN4MmMPBAYyfLweN0PSpHZeI5/P+T8gB2fgZ6BCS8+UFu63mgzffpwved5p31vPrNldqHdkTjK3LQbIVcWVlU8wdy7tlC1WSuWc/gZmphQ9X4TVv5l9Bj+7tad09VKdHVr3hu7qse78n7zVU/Tz1hy2Rax68EeWRzz10y8dONV3kMrQoXfsMlBBhk3xkbWAgs/lcxQI8QJUKKIMW7EntwqRzS6T2iN8wLymi53Po9/JDc0l5UWpb87d+y+Mnz6f/f/utLO//9r+blV3N9OW5u2wg1Jzw1uJKX1Kpv/uv8/9en36q1bvDS47fKq5Xvz56zxfLmd1H/A7q33h/zdq5DcdmfWJvBwR6DLg7g2DMACJJv9rE7m2bf30GDdmd5VSfELgntrMiUDEdUD0q2Cx22faiRD1UmyQPmVFQEkY8K2NM1y/oHi2I7vqvRScXcp6eKRxisR9pnuk512KNbbt684ezjg4SjI2Rr9inXWorc1ZKs9cHT01UYtX1tLhbJdAIvAppdo7vpmU5vPImNEGKXrmFcyra7ioPcB05PF/fBImnXQYhnk5da7Ptxqdy1RW45COTTtgpknhapJxOokC6VLhdHBXIokvuwYaoQM38yBsz5bnQJZOtHKXRhNRDtGiTQSS5ErZbRAxkuw1ZeY8XqXFrmTJBVIV5KajsxqIW3bloN8ySHC1eHmzLXN1sr59iPiK5kIteukQusV4r1hTiyvpwYkMAmaE9AKnDO3iYl5EciVe9SBNKIvTL1hPGAd3zvCVq6WCTTU8PwK2Gd1TIshkylFodzszviGHPKcVzw/iTcPZWx63jSFlPrt67F3fheepfL5veHYdECT23lLdJgi5pb+9iz7lz0KORyLRumCk5sCXI7zjZUA6KecdOwDbQ2MzrlDdVawrppSD3TjeSImxGkipsa8aupv2cv25s5m5fzbxgU1MroNS+Uuw1I8s/dXj+lv8WGmz40EnLpQHuPIqBRrxcrtPcrRnRITfteycHsFT1d/Q8Nx+6lu+PDkWg8PjIT6cXK30G32geBfBpnpkP/xTIyXI8FucsyMhyEdxquup7pQcjl0IakoF7GM42zDUiU5hJaoYVOkzSSUqeBN04p/gyGhTGL3lMxFiT0+IieqY+tYnDEzTpIyyyUelFl7uH0NhYd84jTnNtozg1z08JV28o5rqQRXckMrr0hp7yhcqSwzLiiTSfIgZb7wElyAIK2jS5hvsfwgTwTCfL7tVFhixv1iHrBz+6Rd4pRSFwxk1RpS5Cj4SczQtw9K8S4aaVVrXSVHETnsFrcmUuMUUjUNEkjRepyHUWapEoyHumKxEkrxYE3h9VidpWFeImqV3VrA6u1C3fpcroCw8pzsDk+jxoMrBpTpb9YaFHcrH6/Kvr79FdVN7Mx9TOnXmtVIHi631SOi8FUz/joMBpBs45Sg0eX2wHR0i64ayrpnV/vsMbfCZ3L4YvcfW0JSHGljf67wTnEoKvAXOkXu0t1NbYqOevuuOFu8tTaTzmVcpVRgwUwBu4EkdNdzWdgZY3pI1x59dgLSSMRXVdlWFXremMbmO32F3d2wK667eBq0auiu5osx6aZIjUqXlvpqc5Df7wNapX/scbfRRgnVrb+1JzWVA+0lsaqBbpv5fsrfAKXlO62tCr4h4Z385NSDEPLaP2yfM35b+oLkdoXqRU/DN9v+AQuKe1fL1XwDw3v5ie1yRDLJMvKqtAqtwQ8tFke5CivkjWLS8Q1GCdVhsOMGCBmjUjXL1ur1acZ1a8NChO+WvEm+P4Kd+KSUoOJVcHbDO/mx6QYBpl0Bv/9FOAtuacFONTqvP8/EOhtX6pFCf2erFxGPyXbM3tPXS+vUrvrTc/qph53yjX8vr6JF+udGvWvlG6ma8bE0pNeBw28Ea/r8rWW+EzN8BT38gwnfG0Jxx40uoFonW2ScP/vB9mnEfu1pmJv7br+90p+Z9Y+p6F7OrheMhVO8VJ7RZbH5Wwboc55gEeLLFd+jUOToPfXS/3IdWDnBHgnWXyR83GXj0jHdx1KdP2/E6SF+5K43p9LvkbtpOrwOutc2dqUBQOLr7EspPkPYUfvwwwW/yGzrw+W78ryM1BAMhC7gIWwGGwkDT+EERcoFSYkEBA974JHvrJWw/T164NGoEiwSEwDzOt/7b+UksgT1iGHJt/3I+EEYYWMPJxgHQ+XT+XvL/I7NtjfY5DQ6+Tbafya6GFUtCV+ZQV8i1MoWJG1OEheUltDJBac/TUCymMRroiTsg5kMDl5JGpOLOSVylCwssIwuVQY42WuhDhtm9iZcMVpsUYOc6EoOmoplzkIr267ztNEQCQD9I88tEeatziEsjDFGu0WfoMYV4C1LawWAe/4OupFR4x558BE6/YxCWB8D+a3iEh5OI852fVNlTHiuce95ROVR3tmLCSQiNw6uRR0hcLlfs9Vse1Qozoqcf+/ZHlukjYY2BeDJLiGI5fChHY1gwiNKWtujFgnL2meUy5qNg7YfWbmEboOaYYckHC4ZSvEzlHBsCstaIimDleBoUfJxswp/CK27K3SOqspWY9Pgfs8rozR7qJJLF+SL9JJXgc4TDYZCStAgGo4Xix9tMzX5ODrT59BWTKlNQbhKVrXndp8YsEjS5DiC5fk1TTY0cnSkybeM5T9JswzH/v5hl6VccRtWHScZ8YP6UKBsulBTiW3TqrZocozRzZ+u45gU1NXrtEibCEcWLf58KTvlGwbLnmS+ZiPeuGZywk3ekvocG65yOwkgb4QJnpPeca//18d8HNUDSlmWc9bBBiK+mL9INRJ3vfz7nPzq5Q4Lnt8e0sAxMpUqsqHI9y3BMa4b2uHO74SqVYlc4FmiUM9c4tJ0om+5AuY2K8CI9ItdmdYxcO9w9AAYGnJK8t5/oXQKwxiOC3jQcIUT/5e+tUNzdmfDZHBCTrWxv5QLHjpPiqEPfPaXKys4YzgJfeqkXB8yMtAI7fL0VNSx4DmOoAiRpaZHYhZRf77Hy9BsyeczR1LlDtNgfthQvG2gyUkNtID2WsUJRqYmO5eedITt4vweDj2goZN+na1LmNSrD5F8bPp57s9T+NyCIOV7uFFI/IlBxBE8mhxVbITah47BidlHGcP0pTC2mt5kt5NlbHqqsesFJu8ZyL0MOgssyserjOTG8EZBfJ/3LF+DjzgST9fDdOgjFvKncGkh3O3LdbWGkvrp9t1PFim19fITA96i4Ys1FaxgY+P0VA8SL7fUjoARTbcHvclRu/pFrx4uCA8oliPCOXXA2hfeJ26hqEtynWAU/63EoGX7T4ZD88dumMMDCHRQaWAYcMttGW+0W7IgVvc1Li3lN0i9/XrAhuu7QjKmwZ9ibhygPofiFvG3KpQdZl0D2JBO0yC4XwgCmqww/piX4alwvSyZm3vjjEJxIL24OG6LMYVvofjMz4O9NOIdWY94TsKFULzAVMpFhyjI4XNHcUW23Y4oafaiz2wUFAAXOjfL7qZugAmNNzyKzMJcApHNKT80q4q4DMd1H4/Bv26hGPIqRziT7xL5nOUHMsvhNA3XfjRshbKOwd+6m4dHb79+7yyNCK0sWcVe4ItSD0osJOJmGF5Vp5d72ORdnEy/WpmlgFheaM0bPh5kaQr5EBMpmyCiqhIsaL4JshOg+a/ep+KxumDfJTdubVrrHVehgS1CLe8CVi2cFhdId93ZMcZhdwuiw6uYAkiOCW4jDJXBug/ym6K+1gKhdq7VfroD49AMuJdtMz9yLyqQBCR0WLBCDJVkEUVmzb5u17jsAgJwgQfqv19Z1DjZy28L3yaMRnhj88+2KtmPDw/aJoOEZKk6ydRbISEpRQfJJfHW4nfMg2kVrB+3lWKzLByU7XylBJBZALs2fgr0Ph7uwdO8BXKT/blhK+NH2Xizsdf68gcfXrdXWp265RB2PCEt4HSiiTeE0SljQZ9ZWZ6/uZu2yyL+/S43/qRMO+J2eytcaeQCWp06A6Vpnx0bSMkwN5uXkNV+e/unDi3V1u+GG4/zsf9aFRVZKlgEHUVPuB9RgvFgn4PwgsW5cYnbP9nRUUn1pcKogog+GLu2uMoEzxaNTvl0ZzVvA6berO6yxmcD04lY1k/w6hWYeGjfJmbjl3JwegmQzxDEAPaY3QQRuOgFuCS9MgUnDrBXwsVxl6z1rUQUqW/4afbQVLCymrxSN81gxUF5ehnFMp0JIGXvT0U12lRo8KNMnHn1PubMRUAtuwtRRu3wIEz+ifGbnpda6/xewqqi4gJd96meRIzSuU/85pn/NllDze2vN83h/bgO81gP7QmExDiemJyxTc3P3bnHJ3zAw7d5zG9ufV/Tf+ZdiJ9iQt2m9P/vvFIi96nNszwkDsFLn52oXM+S57gV4Qg5ZWoRZBb83RXIaUTw6hxMGH06BNXqAomNcCS12mnKfeL9yoBTUatnQRjsg6bfZVx/5mdI8U7tCVy6NJEnek43SXoDP8cYwp7V1wI4dXZ9V6TMJp+gyJPRDSU5NYFjHYZeIo1DUtWvnv6EH+XFXNJue0oMBbr8NCUYGRvteOrWJEwaWf45z0OElXcK5WU2O3AIO71FT6/POzHXt/N/f/RHVG6zGPeGilL22OhAr+J1E2WMr2oD01O5Cf7W6YZ07W/pztwMuVKuqHTXWFSFupffaj+4zT0kcaQUYDw/a0hJOgN9+Ug5Gk9DATpV+KU+pUvxJeriRyu7jjvOz2+yykGu1tNsxPDaW+LeQlZXH4pIWD4UvUwptehRzEEownXkj/70SJg4o3s6DhaZXVsHaPBj3FjE+6JWIEwMTR0U0vYtWGnAwtytYIOAd5nS/j9TYhT9a2khuM3TLnXlOtQ9NEjJu4o+31SwMEdyV6fho2CymTfGuaL7k9IAYWMtj0R72TCrYTeDzyrkjk+jhfZNMWBebHWybnaq7SphH6wP2/e0daWL6/Pp6Frj/JYZJySqJ+oage8/jHKVDFROXRspyxf7dkJ5S5OWYCvBgy6eHsCKW1hnywfazWRv7wJa/VRr8a379AtmeJq7WujeSQmp/14mwPY6ANCNeNC2xGkj7YnqLF9jg0hcbvIAQf9taSJTB9T904nlkm7mHK04dJ0g8W1J1DUOx+cKoNSP4sJPDxosCKV3Gz9hMsFc4e5euaRBSa3LrXKWFxxntCu2a0JJjhhLgWMI7qzFGcjC3InyupleDBATMQzsk0utylLwCQssxo+ahzsqbiHVGq1rgqVe4FhyGl2zosT/l4VNLVyQW6zyJ2qXwFLXNVJrEMQTqIDvgIACyxmQsHctn9wr/cohQERXEMB6WBbMPOF4h7s1zLUDPHRGNnZTkyTKZPHyjnjd8uh0YLb8fcwFUnwUHKUOq16USA8fvnpy08kS8nRccQEdzWeQl0WigBB7HleV+fOzYqqvCp9qhAA2sy4Ssdt00l5TE8k1ePk2Cm9kKxwT2IQ9eqr0YYv7GGXhl0boqinRh12bSjNTcstmqtP6oMZQV7OuH+fh6QcNXKC4+ZCCiLWZzmCT2M75sh2JyYjyal26XTXT39OpK5PourePk4niaUNX4oVWQrgn0D44amieiYCbCa7wpbRUdklsWqg9ohnwuoX37s9bVIAiiyo7u7p7p1aFT1utKCSSZpvQCZHCcRQUbsO34mc/qK/lzxvb6qcvkaPvSoyB5hgjZifXI+cOvbhq8PYcd4/8h6wJfvWKfUn3Zd3CbdjT10Hp464pjCd8rWNPDJr4BXgCFS9TCt1vuzJpTlVRRoLYGFT0eRWdIswNsiZes60PONLXmcRoVEaCg1AY0lsu9kouWa5QEELJaJgTGnE11MV0YAemqMJXH+oTxZZuV+AMQpq6eDHKOMsF404BG54BkExNwXp4nxBGXS97zSehxA5sAy5RRCJmOHzHvGZMOIGJIRNCBgejOmBfQn6BEHgU6kbyhvI4tKPdmUVIAuUj35dphdWZLZfPIIvyGBuEUYbMxMr1CIipf8LHk7AwfeRlc8xpKexq08kGqdeS9Ld+0rZXbVs9mUAC7fp0CE1/3l9sva9Zb7HjKxsw4ZH8rVQiNQEEFUUkNdsPhCGjW3nJvTSRaQcXSLxAS01aBk/XFPskDY4LJEVrtPkp5a9owG1GG28E/8p/YoxS+u6EPWuWjyraHuiS4GgVjmn4csTUqINgzE75rO/McTu4JxbFN0UwXZyBKk3FKH2jzBWtlJ5KpLHFPORsYSRN3zUqE3HF6EwVkw14ArboLfM1bBiTsydkZyIhK4X7ACJGBUIXxSGZlB9sXi/FBcjQUDX1lWRZ6k1wWQKEEPgIyJSVgz0WTKWmi39da4vUb6fCY38asRmxFhpdwN+DOEGnQ9AIr3LFSBCZzwrUS9y2Jm++Dhaoaq0anpKliRSIXkN4CVV0bqUHPHr0x41Uz2Ul0ac/WZ+WmLSvk1lPLXm+JFjhjubzTgt3xkoqBUJYLgttcjMqcKU2nQ5PY5UzKKmA6bp3RTTMuNj0DAbHinCO4wNEh5eHU1rB3MxUjB1nL8n69DScrbM2oKoslqEJsYwPOVZJeoAq7fxbqDK/d4N0r40JvFRVQM8DqqI4MuaVHm39kEZyh3P8snLAHplRQdigxNncCKSZwvCG9g0WWJNMSmMZNKv5RxuAZSsmDuSzBvwxM2+dFNL7dpAKMkisjiG5J0XxJlmFXN16GAnwdp4k/UeOPi8jRQ5kfE1kV0jOAZfYpIamiu0RaKzTNpNjB2dEpxqKpA7wN09YxwpPZzdtzb0aqUjPSN1lvJloDPsPjm0DwwTiz1EmylW6ny+BoqwHxzGL1XMpvrvdI55x7WbdgMj8SakTHLtYFfFbTMUKTFjE4cJ3LirEDajh2aBlDV2H7eeKprwBq1zLfSh2hrlP+9omdEkPyPDI0gtjZGvSQOKLQLdGeM5UjYCJakd7R39lJl6z18n1k7RfCsrZYTZLdyge+9jltjrHmh1eADXnA6bbZ8Pk70+h7eoYxXpsdRaJlfp//zvNgtL0g8zjzRvIdbQiSBaNEqO0sKq0um0dIbM6UU4zmlQZbiYCDD2xv6zd7UQfKhEwcGJc4wKf5WRXF6BRDd4h1NazRHKw/ABMS4oYGlRaIwgBe/fdmM1aHagmaJ64+MFmdN9J+mja8dyx5yfBAg5dY4FQQpLGIj1UpyGm9/9iPx07uAZlKjuqtOUbP1r/eBIteWxOiaCkvB8OGfwS02W0W8xEQTLAcs/YKfZ8c9IEVoDyKju/JAMO0d3Z5A+nBnRXk9r/RWrfAEdyN0fT1n4ABYjmoMjoWeg7OkSz/eXr4GVYxNfilst73PnTHXJIaa8RouITY/ZCFhNMci4GRAXkp/wcaPqishw0hejqhw9YBbZY/1YfeFcAFUJLshJI+DXxJz4gLLIKAomN3E+zkEtrwCU6NSQGuUbyppglcBFS+6NUMVlUQVbM+ysglJSIxwuEslNp4jtT4vsMS/44AwzpK8ouD1MNO6ixq6JCQYfQKKseRiCURZhhazagZEVxYWQpjehHGDvRStNjsTjBIYKJ3xUOcQLUYhCP0hI4TfRGqHIxiHPO++T7H1OVHCTd3REwwyruA31rqe4iZUjbPwnRl5Xtjxtq7EeExF22OOF+71VPFmOjKJHdh8D4gruvNfJX/Unu4+EoCwG+AYWpCAhstCujtFc5BimNZx71p5+F+vk2hTcftgfBPgRe9j/I0fCmNYlTmwSv66co498ytoTX/SghsdBEIu9yjqC9jBl360lwYn3bnHDR3zIeWc78Qc94Jx2K5MKoOSwR9vTh+pPT/fVnSKkarkSS5v8BcZCcdy3O4HrVpukHBnpL3YeA3AVt5/t5Av6k9rAtmlwyLvoSi0vZJqQvalzxcDeUO2U89ykt6Ilgn2+/ny0QelpbKjo08N4XKo9aXJKh1wL4f2xVlRCc5TLMG4tPz/qngiLDUZz4hgfLNJhmf6ILIv0z5qvQwSMI3DwJFyoQcz8baUIPp41sqhPu7TTreay6IixefzRnRweH3Bmk/UE9EzyLh4pinf2KVUyb1/PA+/L1g/BYHPvfULgGcqkNa0FChs5EsaScL+t93SLdFg6a7j80feiR7f+NJqLeYaxxJ3cryyMfJpwl7fPOoI2CqeOWbRy+tAL3Nw2RxjDFj0BFwkJke8A1hyeugz8c68b9Yg8joqmPo2x/llcj2UicdWPQNuDLKePiXU6fT5ZZ+A2OOIpWqlJqqprlBVOqc6xdbkQrIKq2teAS5BNKOWO7ix5rNM10GLX9fAck1OBH3gcnztiriejBSOPsmAcA0WcovhHkblGoG0qIJNwefECXytehumbQFDO3ouJwnvWXLSuLay3qllsNoK9lxXSgc/uRBOXs4+gzTzeAVn26fnQy6u6Lvk5TFqo7XLUIrAntHZCadoVFyTABLPzOrrD+7poQE57/EbJVSpG2+kvQhON6+WTxSNpd3ubJN43kcEL1W7bOO1ljl0iicM9VohMNKnfpquusTNqHIy1U14DdZvwKKIIC/d1nZewIM2SnQ5RhT2zt8JSPefveE5deHoch1cW1MRhk/12d1E3mjC+i8kl95jO8/TweS+LGgVjDX8c0by2d7ezx+BnxTHvm30ELa6mh/HRJmtiLljHJ0Uz57w52gaCUwhnX7rn1CesVhswhDqJjZws+HBXzrJ5S+LwCTM0eu3THiAZwK/jBbOprUqLonsfSSKmVjn/YOWfu+ukWddH/EhiVCxu4eOVCbSBpz/JK2XnSRks1LcBd4TCScp0+/ihU9ymyikkBeDgJzRg5ljTUA1c2eOGbS0xL+365XRg40jdaowuBz9fpvs5Sl+GGb+DIkITJnZY62zP9rgT8gG8wmVz8aXmxeUqdH2EOHEBtjxLwPLt2zOS5tqxZmiyKuXdVSDcuQEK3T5qVHFivvLIa6wXih68WRDl9RZJ6t/TpY+l6oyn+G/v0FsFKzZSsA7XNq1QYqNc/ZiPvPURDhStL4fI9D08eddP3y9XiP6iP9EMePHCXCQ41OTw/sekvKgFMZqhoGGbLMyzdZgkJVNVRVxU+bHQtwcmUef6dDxhuRbTfSPTrvaDb9vBgejaUTwOHFiVp4+TgbWpX+d7XX1oDokgu8gY83LZ7hawyJvECFMx+aswF+MGXu4BuPl16Bq9dMr1wHdmR6/pVn2YwJb5CVQFQsRI8ThvvXE2VqUtX1yNj/1Dy3KohmjAiOf1/F3NFO81kq1rYAqrGBudOt/zIzuwY8XrA95BS+fIcfAscj2/r3gWHalFcU5RFuaxNkIWugEwf8x9UPPd08escPW0o5Lu5MmZ2cvGeNmq0iQuUmmHH7bwT5vBxwVM9kNcBM+AkXfcAePhCa+fbzeI3AJK0Sc7kM7rvNfJti4PRpl/E9ETp/eFwArJpBzptRaq4lWLRVEuXX0ss5o17t+K46fHdD4eRqPapirId/iertF7Ny5M5nhAck3d5WHhtlZMUUQubDYDs7gj67dco0p5ptcSBTVr0IjxhIibjJwf3L205JPz/aDl6ornJWc4g3nX3Y2TPOse9Xa33ZpJOXWequlmCT85P8z76ubwfnxfOTeGn7uHvdE0prWdrcOAzqV1A6cDNXnOh5Hu5IY/ddwbxqt1gtCtrslN/Zv7/Xj4Ozx9uf95/Lmcxmk/VQUZYHjQJ2FOH9xzik9b5gMSf3miEPIA36Iu0xjZHoixFdFIn6v3F3PrVE7BFym9enJLNHEG2WtueJ+l8tLhQk5VXkILUjU6r4v7Z+m2/z2cj0PX1umUTeZ51iBdjS5F9OsWHiz5/b9jINE+V+8v5vFUTsGNwk7R1NgyOn7bcFjacrTJu6ITbNqexUOe1n1yfXXTNReC4it8uzpJzJmgmsArxua8bf6N2w1uthkxypsof5ZKBiS7/MqyqHymsms/R3cPuxkiZuQusnp/MaNIsAGyNzVTVe/vq3l+Im22v0h3iW12IJOXFDP8QG3aOneWIofIspRqUpmhRc0656bhglsxb9/CquuYMbFZl3DRTH9CV8NjHMSiPLMuu/3QhtQ+5AMT2USHIRQMH2nNc7iQ3/DepSP5PQ7l1un81vbAXMUcGpocuG3My4ts0k2mIcWYkl7LviQ/tM+EdAV/3YvDSpnncFGCirx3f9m9ZnBLsIGahkpf8juET1rh5dV8dKLO+lyXqczktuM5rejitKDe77tyRbowVgWtYyYOv6ic3AheDCx0yzgQFZxm4b3KSrYUB9fq4eP0m9LU1RWJsFo1ARKvasFgW+yt2XzmGHHhagLmUJAtHjWx3ObyHTrCZZI756M0FWDYbCejuEUkmyGmJWy6VAPsIC2w0Z1KiFqWjdlq06wfJW3BxBpv9M5wUSZmSCJD4Qf3hapb1H3yTQ09SZup/dwxF4A4noFfYXaHtjfUGLkwyts1zFVvUjG4zFsYDFEIT8xKi8qLieDi/WPBztSscTBKMEruGb7Hu6tjz+QAyCcT2GIsp5mgOiqzLAuuKeVFJad80fpnbsc76vCD/pNP9JkVYIWns1ZZ+AzOtHjzyu2vXlSPlgMk0/37nj6ot5W//iNJ9ma5BksUTdcFFqIiMgtPdzJaOBHrDl+omG8gHZQ40TAZI76w7Nn583QQB7nINWoh8KEa147Vya22Qs/t58ea9Fgc/f7J8HJowEbaJHGQWwMZToY8Ej1cwQCYMsIiryQqYc+W1J3K9rfiI1zPuNuMqA+iTNJc9YTH4DCfNuUUv+XOUQDSJ0WSkCG2HSwYyIu0FjTPXw9A26gcosqvsC/OlyqZQ/r04bf9SQvXXFeEBHxxh6AdNKGCaZiM+xaLj1q6aw5USRHIdy8M8AUs0WQPE4gLJKTLp41qyGEzzd6RBBwcb/0j+B6ydEAXRCPqz6mYw/xGRoQ9wS9yJ+Z1DhC5Kkj+iAsTTkpFzpWaykKzVZmmttxsR/dezFcT40ZTHAA3xiCgjRvosrgDelmajhw6BYgVhfzJH+c5pjDXSz5/r7peaIvGylRDtiAa/bDcdCa/9n3yMzMoLnFu0QjakLiilIQ++4atCngN5JV4NssjHM+NFjr/VL4Op0AboBWjHBgb1m9mkobYq4WGaBPux7taVdNapeTstbSeaNOcdIEbXcJYxCGa6wRifChvsta/agPCp35AG2BKWMrk33rhJHLrEFb+HOZOPFhQqTW2MpYxgr4tJ+xPf3z5PAPTXpOJafVWSc9orQ0osna3O5QA1Z03Yghi9Ga3z/cpSQhGdkXtkuYdl31N7xZb8y8EmsEDMSIyHb467P5MBoQMJYD0MTaRNbPykgBr4yd5BI1h7IERTVhUM47IX2Kt4WpTmCPumkNeVP5iJErcE70PVXhdMb3cuI1UIOT3GhponRy/4g+pQe+omBfr034dHgt6n4YlOCgnwTSFQRM7BNBz8BSu9bvf351+U4XhDg+K3euA31qBYp56UJizJquEHyb2Z6FQJMTtzutCwjNy07BC0EOweQgIaX+5RcwZLBX4zngH7QAAGHOViyF+3oOhqh8jgpkriqeHXWyid/SZxK+NUUroLfpJbqvUhy8csfL4Lht6VAB1X1VW5nUW6U7QtCvfCEmU6TfAcXu7H7NSDMjS9NxNKkk1bVgW0tEq9oHOpeoJL6YCtqoUT8KF/0zmhE93EqO6LAnBHiFYnj03ubk3kaqK7oIeU6QlI6Xx6lucJyTJBoIGToL/RR8fko715Rm/HoY2TMIN85YwF7kciew54PUV5pRRDYYH0k/vPp9r5sJN6pwA+wqzryLNvqk5jWWnS1pEZLgc+3FXwpne9FOLkyebou/tclHHLJtkrONUCCrcbvpZbDItM+1gxQyMRBKEoHeZIIp0Azw3N15YRcVOOVxo64Jc5PHr6YptJ+dlbLLx/saN7G1SM1CfGHcwSlfyUH2YV3YTkMp1wVuYXMHJUzZABBO7rONnmBZUKj3uB7x2vFEiYeyckhqWsGmf+HREtoVgA6lFVyw5ShdkKc+DnLWqWcq6gs5Oh14r2Y6Tw6wadVFWQ3u07cMWGAREODI4bggWBzCG60mEU7nxYLgzeqYdERRzGQmJOt9CUKoKaFEVhMqIlXDaRH0TxNkTuO1rnr/w3Cku8Lz4Oif1tQ9Kf32EQ68pOctqTenjE+cf8heYOCq2r1Z7pRckdqf10HlD0u4cMuILoYL/VgJDFiF4SCLKPZr+Ykf4DHDMYohsXnMIMfM3SgDmLYKTsh9SN7GheQkJoiA06YGvmeg95j7H4YEQZT7KcKosIGZoCImOisHUr+ZecrcV2yBZqBmMtuFxESXnlIFSec2u6EneYhBM0XKQjrD1h1o87H3EE+JMunsHHj3EEBaxrKHnMQwvJsjz//5rCtroxUVQ0YAMASxcW5Knz7PTRc2/ujnWoa8XXOSuyuof3PCMKYxRnGNguTfMRb9+vAClBw8IXnWWtPxR+VAfDbjGaOphBrvwGAoGFZMt9VMvHBmih08sQwfnFJRdFLYfuYklotWBhk0QezA+I8uxRmNLgRtL/7JOxpq2C7BBmwYBBfNkLG3wS1Ds1x6iYXXpTsrWeyxLTORe5l0x9wsI53VmJUIRUMjbk3XsLfMGc7HsTrEq4F9zjZSqWLVGQzl0jWmYmXIbIsyNp1SL1pJan4y7wDnmLzIhxpxTmSIXaZjEMmTsS1SNQIYdkYri5jyfHj0/5Eg6xO9gPzX/i0/2F1JDr2T4KpsYVPIE4vfsNPkPZ1kvpKZN2J3qtWIKpouqQP6CpwlCMV6dIWrbdIQlxf9VrwlOIwtnWcTnGHrHcTAYjtM19gXDlry6Ujj2Gwyg5usNAOhnPMxlChNBu9+69BC4BAO7AfWXfk19sZTvUIuFYL8VHTI5WYYB2z/JsIWwbaYtCgrFJLi9pOioxL/n3XA4jiIVcVwhkqL1BIAJ1zOIk23ZXLMc6icFGN4z87RXCNPill9k4RjiEDeETGwnzoklqHdpYMc6w7BJVkMuCAp3xY9FPZKRspcSlD0U9o6q+okKMHWNqID/5mzLGlay6rVmqRTN/3VIZRVNy8rVvq9v98tJgj0mqpSEGPvdf9Vhr69R1poaEDa6e+zVXC9mJ5pqe/VrvjVqr1bvdSlmbBrOPz8ybFazbLCGzRWEf/B9+eDOrWtXzk8P97c3V4fvH28PYf5cnSi/z7CHJRpTMMzxxm+RNkP9HQqxvbKb2OnfNk1dZ+amutb8871T/XKa9larfnHxg7u3r1+9ODs62Nlav33/uE+Z1ztKaOBhVo6KT7MmYjBQHQwAh9KDev/6I4OBbuwUB2TuPPAkOK6e9orrI60bYznlprBxwH9PKTQdfpNSYYz6+PYRwdl4RxCDioMOF1KpUheUzLAS3TRRM7zs7bkCXjmD4oAarBM+VeC/O3OS/nmYk8vzw6tHV3e2V4ePt9vlsB8HLS0cuNH7A/+TH80CRwp+KuuQJVqHc6FUrlHas+CTWMeHFOS5au+konN816vTtFJ3uv1Wie52MH34jlcsIBma4vZ602jYbG3kIsLxunIFGfN/ebE259UEryB84OPt18/vpiGwad3tfsO+qFCYiNQhHQvOGTtsFZEtMNG+Jzy1shbuBm8fkWf3c1pWKaApXv3NPyJVCdV6zsT07/hYW0lZbqZuMjRWkdX8s1bxZRd/Lyq+gPAvfiwf3L559fLZycHeFlnuP954t6tqxfyb0tJWjvLCgqR/YXCxwTD3DTsceJrz+fj5bH4Xq7+nyqYZR5287mooGVWSXuMAPl5t7XvRY18PePt3c/n76vfwawHvTN/L3lvnb6/5pLjCrW5j1K2ykuaW6Hssd1eyyYShE9fFyhE6d1jW1ekKnz6d34euLHb9lmlOlvOhZdD6/uZCOL+MFpGYLHWDnULv5mwlnHH/GFKZ3uYeJHJ4XmNT5HTjJEbijYNC7qa2+KdXV6DS/imZoAu9cwmQIZbwMoWxedC4n+acvkx/738FuvOhuvMHfsmnWlAl3wu/PL90rLRe1q3pym6p03+0HT95EpfdD+1v+TtLSAMNoKmW9K8pv6H7TVrhtLkiKYWFkmMD9r3rcJCipLb+tBe82Aff7mZSi27Xy3notlqwgpjm/nCTec+u0aRIXXrLlOyFm5oWApiRXc09fpyu5mKGDseA2jF5ZJkixJsRtXILhbaKEIHZvzzoSy6DuOgGILkzfJuMs7MCo49fbJvvsAKY2XT1iT+OSgIj5K7RFPg/ZhMQ6pXCTKDRzIuFgCiZaFpPwrdkZTvtZX8CdFq/Rb4FdbUlJJXkqBxDvngndR0gYBJFKFsJD7C8Q68GUCOLSbVOZ8MOp8/KS9UyORak5vl2dJEhNUmpU6RoyQR0K9C4ifXF4lYlcdgTj49U2eiVTOPhIWBrqOwGKzCjIiF1+5Mh3sAzfv0UWwpGu3QugA2rDpWXjoL96fEyxFNOnteVqlRb125UW449GBzad6yUPMPmssDJ5SIaEN5u33vkbK7cF1pxcqlaV4142pJXgp6Os1cpPTsV+9flfdaAw3dB9vRByfumaNLiMIqiMn8HiC0nUAVvKErmb6mJ9BzAQW8hyzBEa6VhLN7nC49qGNMkAJhrowW3CphzmoBjs7xA41Qjpf9DmdG8tBeBU8VsZZCdizLXmJZvPxfSt2YHHNGiOMAzSrQCKrpZIeK9Fob4AOP6roqN581kl8EGTgzDDmEkV6Kp54vYoLxNg6aknGfKnveZj9TwqPbUZU8uHWTTRbkJx9neyk58/oSqnRA8wVyQuMLGVzv056N5dA/ZnFfea9xPFjTK4hf3cz9DhSKatnBGgcnAXSPjG3RzPnKd/IxX6O7W6pS14kVXt+3OH+9fP1xrPKBCU60VZRJia2DQV1Wjal/ftPKueys89n7s/Y7Tqx1Pn4l07R2RDJ5xm4nqLW63VN9w6LQyoBRVYACz4n8s8HMi1VMNzGoH4S0UqILWTSccL7+qWFUinjWxH2uUunXoEtIGIzEWqYWLMyO7vmiT3rKbNcNs0nUMglXNwn5UZP2kMx5se7duVbJzSbygqneqds6+pwv6lbvj2eqTtg4JYLJsJMG6tnA7eS7uO12rWrrQWehyMEDlosfAf7szDA/G7KhxGqds5ulTGzzHRICJYq0tBjaQmL+Xo/BXTNRT9i7IoldW7Im2YZdDfsEMAkEEzIewxLIVTXNS7VeBFfXUBLCREGuZ5k28waSXU1DCjGpSbj4SG47bkwyq6TiejtSrOUsFh0j66N3ewmZL2/tAyaR5rQm0043rDBORVaG83VB8HjqjqrAncFCdbUqarpER40PBBDc1ZuvD5lQgFOtHdyMnSLZvC2h4BqX6fPzrAppapaq1Qn/lvFiceOEs2p2bqGP14090d2UMFEghc1i7tPsZnOaV+oisyQarPiNzr4mpIdmlutDDXynA9rS4Bfxk2B+ooQ8fsUnVWrqKBF5jyrnUG5ycy1tBUXrQV58zZgnAW0QoI1+0G0ry7banoWx9HWUEVnrmOWYz/X6HtriJyDirkR2L5zrXD+yWHgeomje4aThz7MEmPc1bcpVcJErMos933V3kWP4jgcynRJORDepEK/+fvy0PuQEZZaZlLRqyDQ/+E6AcL2XyXrgE32q029nhwlqQPQoTPt0WG1fSu7vZiyUJD3jizHXg2ZDJDy7NxjPaPTCXV24jNv7f9jwa9JqOepssyB6cEsxc3jETVlmx6eesY2X13OVqaRJ+Hwd7gRBd0uEnzmyTnQlT2hf0m7q4Xq6HcAsafqYpZ6Camaw0Mx18uJs/3HgQKYxpp111EEOJ2LGhr9L6i2JISr9arOE9fUtU2504I3a4o7FiIDsB67rZ/2HvzzZsnqSMXWEGwwV9j0TcZiLZN0wFsJDU/YRg7vMVVsoqkU8ro250UOxgRAQyPux7J44DpsCt8Id2FmLktB/EM/7LejDb/KBJdKo9wz0e2XINUm3QjPGayA4u8uaq5Or15ti/1+MdRym26qz5no5uQ3Rub+QIJHla6ZWQjpLSM+WtSDJygtjZzdoSI1xye1ITMWNnI3iHLn9OqjV9uMxN0stTg5+vkPts6twc5ojxnFotfpRPtudBt1ki5cmsseQk+XpuyXUjJ7y0N03ef0+3w4b/8svyt9Vvk6fbr+mX8P4yaFleq2vJ/Ts2U8FllsHk/+1RNiqQU2Oa1K5vfFOgxGWLjylUPaJ5LOOMdLDO7KovhqYffnY8x6akaLFdu2fdpD2wuAu/tM6zmhR8PO8+L3h4jwPcC/LWCJ4RJyBVxoj7I+vzjIV5Qaxu+Z5OHZ8XoH9Weq/vTcSAbHyHr6Uj9jG3t4CR2W18iaJfDhNj0oax6ejb8miJwFHiiuPMNvouJVelp098s+IySxecTcGpD/OhN1HYhLRcls0wJf7SmQ/MbYyESDvRCRqsmjc5IZulAKXkKemsJtjgrDTp8n9XNInvIBN4uzVqKeJ+qEkBFQaUYUatoV3aHh0JdW+rrkTJ2vaW+RSxe6yIIDLzd0YDwAt0qp1LtSGITFT4OQoUAsoMu8XN6HjwGlMigJSmBM6wAAIECIXHJzhWsIU9bAOznYkYFIh1pZwCcsuJ7QgIaZYdn8ud8TrhzVoasJMOkMAhxH4AzGYYWCgMFUSgLp4Jmw+iJD/LOHyTlnU0N2aoBBXI4oGK+MS94ZnA2XxJiUXLJNZCJ+jfd/rbizNKT6M+S6nQEJj8RQn43FCLDDly/skLz4WAGTZJ5a7DY+5EHwsvJOANDOf+zAAmoTTkYRtWDppZypEldZWsmlw1rLmcQMSKZ+4vQ/wceKhTjk59y8rKe8tLrXqgzw6BqR8W4iAQbDRYCeOIsAjo7P2PmTH7m/AUL41AH9LdEKEvUstuGz1jTwYutfsyRVVvWYon3Zc0I26C/h3106gh6pmIf3q5T5fzaT9q1da5CGSoeHPty4f37ty6eeXyxdnJ8e7OFhEkvb3yUaG4TxXRKFsjTvMbGMWjft6Y71sV2Nyr696Onv77ooa9f7d+f/9ZBeYV37WN6gi1rA2xNQJharYqqPTUiXWKUY6p5JYdMUHeXhYfQxHUIbGkxPbOOYLohbmiwntzOVlY3KqD+9tK2NiCXpkcsSyf8y4pwWlKEEY71MKdWnJ8k1delYY0Om9kAFwwDu95hWjluS58S03YotGnTDx+DfG7LNBAU0U9aJ2SAPM2SYqvUTipimJKFMlMzglFZz/WzE2mtFfczQhqI4EdySQzTo92qguVINLDHdXA8YSURRdTMwW7xnbH6ldbotT1N+3lYWAllS3DfvRMmWp92JfybL9UTosg5XQxL0tXK2d0tYowEJRva5DSTmHSoV0iFVUlVNdAxHGxQKd4fbGU1qQqHXkanwuCJEJf0OZesh6ClJs1xq5lgnQYmottQqoYPte8kDU7KlYH0IdVej4WG5SDTZ4diqfYwOJ7DT6EUkDYRIgELALplnHWLojUthIEKxHrIkIR+ADSzmvemTGhMjiHU4VXTZmz0lhPJP4RUlMApcnEHXm0X3YTiBozE2umUE2hg+95Gm9qomdUP8sLt+pV1oVcIIZILMLKRBm0ZllcC6dc/ah9lTzx+E8xOrUXKwZCyRZXuRxIFLOxYbMsFfzEc1h9rXRYcmaxVkgTK55NhvvhyrQ9rGlxx8eOVi25jlOq1q/hJ+bP7f1Fo0P5w+W2QYVvjIi/JYzaEryAsAiSEql2O3pcH+0Yikb2zXRw51Z3VCbHmzdPhybHpDNb27tXHSuC5OIYMSIRKRWqMvCG2a1bSEhbi0xAssXt8rbqYAJfaAzf9cCpYXCENJy//Pis8F2yVyNVYKk/RuAw11WLwEjqbRP0wMs62CBCCknEcUHS1YpiGnENug9f9hKDKtUW/5zBUSZLxtxYBVfOSNXAmBsrJ57clTu0MTdXDGzr39kCJhIGYP0ro3MGR3LCwGpvTph2dZUgZPkpTARTFXE6jQw7d2ZZflQZKLHIMZ+Vjg9RXID8ewGITtKvlsnjXt7bqmUQ2IsL0SaJqTuSEAVS7e5l8PE9f7ySvc/XbpkS3FkkXioHO3NIMVdlsVnpgKupysynI0377XePlvdi9IrGsnvXolCjsbUdMX7/aZl4FbWvtR7E7pdX4wPH56bjv8cHLX8PhqVg7l+kRbHp4ux5qQzPy0iFaMm05a0OfpjB1y3z1ff66kioMWbeMrPN0WnM4nutmA5qixf7SaqPcjotXtSXAhNsA6EjkHpwT8fW9/zbe/MVtbcIKlTbdbWkxbShYEOtCr9Lb7nyyFZdghavGQdjlkOVmnxvNlZP5REv7lfQxaazl4azb8fI9NkPZu/TEhd3YpFDVLrvqkMILCfwaSKtFYhrviTuidc38QN58b2zkmDiYeRqoiqU30jFoaNrRdTfZC4SRbYAS63Gr0Z5ou5OB8ZiA5jyiI/I+Ou8MOH7cxuxfgbX5mhpk50CO1I1YcpEQg8lKb2FYXURPv2W+WdIbMOef/y7u1vZYuMREpYUXX8d32w0khtyZCu2IVEfV7tLGHH7kg63DqI4aiHUfEleZDIM7kLErzPpAb80sONbzCADNTnjIFrCSNdE9Dage8rdRD1JUhRcJ8v+O9wlmeaZcWA0etswR4oX/6YQT9TUOXCHB+KGpaSohZdp6pnxbAOzHQY97HK+uogJ0+4hmkZgERC1X387rxgSimivHLId/ypjdpwwj4916DRfx4vN28yVf+W/gmzQq0v2YZn+dDWn7fTNXgf7PZAg3sGgix0608JeKe7HS4bI2XUQXiRHrIP9Y2r/M/go/3Ra3CDNmMV8BQOFRyxTFya8+Xd0uk3CpZBdRzYQI4Xn4zoTU6plCLjxaZhKeuXkfOz5Ib0fEbyYiORstvgrshLrK15YTcg/c5yg/qKcXJDLzTmXaDiHLSJNPHk1/sfVbfC0k01VZn3e41N36y4gcK+G3cAi8zKaZbQtZJ4idafEXccU65kMy8OdkQVpoIlslv2WO2KKkJ4N3aXzr4lcI1jR8IDI0x40LZdx6F0pcv8/8bbSofN5VtS4CbTvm4xErpiFasHcy8+zSpR9t6XUkvkKTyQhe8Mq74y8bWioIC15jUnH9oTNgEOuCv7kmDUUpLOn9dmrjvyI/yGPCxeZLQ832V7xbEgXg0gwAsHskVTbPCQgwVA4+aTr2Qow6ZRdCUpOBkc5tIqodZTxOdsQTc8giU24oqXO5ZccxDL2iE/TYAfHbxqLAPiPPzXV/+c/1V77n21D+gkAP74wbAbAz9cty/01793BXnpNDijAACAg/Vm7Dri+1ePtE1tf0fztv6hxgH4PjYVkGG+kRrArMY00f1HjH4tIHjXC/iZey1CU4s2gjEdHSVWM20HNhrKW56yIMEzGuRnBlfPO8UDHkQH6PsriUlt/2iL5MlKpb9KYM+zr9cBriqGqZxvuXPgI8TyqKtwTaZwbMoFikjboGPDZi+VtkHO+qIpXGzUzdBBGtWE6DkbYlPPQUwzOxjkZ8PE1yl6+/rMzDLJTb+FU8vK5Nx5M4943hgO267e6VG4a4wiuhPJr7kTlmsjXpfRQjAKyoAbHh1XqXb/yLVU7WGm+ZdcaZKwafOXKFFFaf0l2Q2aWnmVGYtBT+lJuqT4fE2wf+yhZAvyVdC2lURmvyMx5blqZtMVBT1vmC4Wa5z9rI3RVf6o26yZ67VYFlUY4KkkzeZIJhUv0M23kuVwKee4akdvY82JgOXvYpc0jYjvrtTeuwp9wPElamEBi8L//t2Umqhbf9ghqa77Lfv/n+1vxMsPSBW8fv73rVChpvbkedK13Cgb80XKIav1zeZf5rTTzq57HFRWpiE3MGSBtKatxK/78TKVUtwE9vsqnBGvLZs02xUH1WsAQJ/ySlH2a0eunAq/50SA7yk7+BhaSD5LmP03Nd583/y5/e/MN4Xjr3W3sjyqbclvzdGXx0/so5zw1j+ftndJ20m932XZT6+P2UhxdHIVnHxTs/hUxMOmG8kTId9+NfL2dW2u1uNQvYUrdiGQpP4X9Lb9AH7TKCYMoHU+BIJASRGSIgoO4+2hMKYAkfmusXq5Fyk0qDgp1tcNmzb5ZXoIDpxmE8p92jZ40EokRIYWtkNb4M+wx9ihmA2M4RQb8WeyJcrYYjzcLvGR2vjGEpijfjjh+Vk54y78YX4TXegwGw5VZDjNtjWYXXBGXc4VCGiCl8ll/CHKvbAICofxzunPnML6aEzKMOHenk6LXR99Ok3+ULSVhnj9JPLWmLfIXh9Q2Xr2eZFtjW8ugbiEktKTk8v97Ge5tfzgC8MUGzsWUi9fyDmdzM19R1fs1+gk8qg9q1ScerC8RzxzICZzFJZzJ+UzgTtoVrmvzqQ/glVG3KT//Ws+t00Bj+vVeX+M/u2EFAuIUX+LQLMD8sLJ1wCt1mwcECEAAyL/ecU+t4ihxQEz5lNbeLl0bkqMHoH/JEaAw/8vdgBiuFsaGLgRe+pBMDcUEUdkYTM7HjLL2MCduKCxxmqnRirUm73/NBo/tTocAeu1xEFjE9MDpFET6BJmhTGD4DmKA7e5mCsy9hxl47WsyETevbu9VQqTQyaGnpEBLx+TyP3AtYBJuWB7MJz/JtAcP7wUpVCYTH0GwjOT0HuilSc4UIMF1S+DDcYQKyiLplBI4SAyeXJQyyemXnJymbIoH9pKca1/LoWrprNaSUyA35v9YKWTQiKfnzIE3J058ifCFYPOtMR8HscfCogdjPkMReV9SWVrKbCOZfYZJ4g3gKSGVugEyk8W9Jnard+bBnlxCvrJuZukKWOI9kEs2agUwwwwyFdiuWWQfpDy4w2W3fDoEizVQGV8ZKtkNEWdIWYdyHmE9jF7Glzgnw3RyhFHic70KKXIXr+Wyt1689PyeufwJraSjM8G8zUzzAFzgPOmVWQF8S4tckzJRAsQCGSbkwzKst9I9XhJYiJ0hl47XILqUXY3tFvIEbMbMLNTSVBLEyzSpHHGYQJO1siYECtAyDMY7yI595rXFSlFnzMl8LaTDJF4VigpJDcZKVwfteXAuTX9u1Gzkd8/Xbe/VS5HF+DJtxjLwXZiOas7tT1IzYIv+kLl2WikicEht/1K5KiRTJ0+8ZYrlaS0FVMr4rtJpQoZkWUvjPXCM1JckljCf+w/MV+LiSxO/LeOUgDHOhxGBSGSCGMgUmcG5zJEFskRWyBoSioTDDUKDxZSoQZlppvvZATmM2GYUJ76nZpKXUF8jBUIf25QuNE5afzRBOrwMmc0y2xdZshEQ5SA1p1x52UGrGt+Q+wcz8b4XKMy+IsU5REXLsRJ0jO5x4hwTi8jw3w25+Nd/+eLhEyhNkZD+giWWRFLJJJdCSqnY6AgjVy+5cQ+QWho80vLAd6B0gvBML4OMgvEyUAQX0SFcSiyLrLLJLoeccqlM5aqQG28+VapK1arBl5/nKeiOVr08asC/Rh6VrGa1qFVt8qpdHepUl7rVo1751Kd+DWhQQxq2RImllllO1noBhVKitcZTh3PjaaKcaq82rWTl5prnFxTsg9eaaH78bhA8s4CunekJW2FpjZcaHIb1czW20CJfHZZohYW1QWyXpcuUhcaaLAOkVY5TCFUZbou4LxxPjTVOdqwDX448OdY4+VEmN2oA41CJg1Qo4L0mIMVXbFyE65ysTd3qR9r7WtlpNnNXLvFxrL5CDzvWcX3oGI/1BqPJbLHa7P71X0uLwkz8OmiLYnqhr8eytGpTaSs/+lm/mmy2DCHJiqrpBqPJbLHa7Hiz3XYi22677Qd0hnei4fL45IkDoQg9kc9is5a2jq6evpPUHEkAivzaa4RoN0rJyPUTHiChOFULpAuukJiUGB4EM0HAglDVPo6ii7f1b8VKVarVqFWnnkeDRk2atWjVxqtdh05duvXo5dOn34BBQ4aBIDDkswWFEbj0mCT79hy6xGfSvkAoEkukMrlCqVJrtDq9wWgyW6w2u5Ozi6ubu4enF4BgBMVwgqRohuV4QZRkRaG0ftWC7U8P56U4jl9csRJNy9d16nZczxd07PtfWW6TtOv/RWjVpqJdVU1WnBAzMJktVltHfSB7HzNNh9Pl9uAJRBIZolBpdAaTxeZweXw44q9QJJZINWSaWto6unr6BoZGxiamZuYWDTHIeBMcRKoyWaUzVrL+F8NQgV9Z20CIiElIySJr0oxF3kJWYtMnFURBSQWgpqEF0oG6rEeLVm3a1TM47gQTFv8ZivwezARhZmFlY+fg5FKmvFJUwa1SlWo1atWp59GgUZNmLVq18WrXoVOXbj16+fTpN2DQkKvpM5SymLfKhMUmjzZl9Bi8Mo+UOPc1JAqNweLwjTkp5HxJJJEp1MbNiOy1NxTeBhkm2mq1Vd5T4QgRnw3XWmetnddbA10vKkxtsNgxVyhV72uj1ekNRpPZYrXZnZxdXEEW7tNhcZycvMJt6z/PZRVVNdt27Nqz78ChI8dOnDpz7sKluiuNOv/rxq079x48evLsxas37z58+vLtx68/v/3x1z//mbZYQrbt2LVn3ww4cI8OQA+BwuBIyCAKKgYEL4iSjBRV0w3Tsh3X83EQRnGSNrJmq93p9vqD4Wg8mc7mi+VqvUFEYolUJlcoVYBaowV1kN5ghE2I2WK1OXeHl5VXuF9nVXVNbV29p4FHxpRkp3rbOzq7sB+2H+/r6x9woPK34NAwKBg4BCQUNAwsHPxJJiDRqrMbzXqDxbYziEjIKKho6H9726LBLAZyk+PVAnFtF3PlQJAd9jbEY+oaAx4ChQN6Gzl86oni29r9djSOf7Lc/6ZuUJoii+/c/eJ2KngHHb8J/P91w929pfe0VwotXukxGIx3DHYWJnR+U2LpQLFsEaoavCq9JXfRC/m2vU4oJv824KwbPAXhnUu/jOjBt+2NKyVhjliqg7lMMT8NmFNexWZ/8ZeSNhLii3VzupK/U7w4Onk4mSmUTBW7vXh176PUPkWTProZBAoCS7WH97GB5Wft0KSIM64ceBaoDtGtsZV/L9XDXFd6nqBfvVMQEapHbzEvseK77eMKZnDJ3lnXVxI1fztIsmRH+o+3Aj00LyZ+THwD1dlSeSM5UTcPPxkcgRu0h8CxBSOyfAKgVU5BVtZa9rvbLM7NGcDVZp5JB73UCl3uGSvFnYZNiDNVykV9564cPO9zZPZHN+7/cRHlk3fnSb6m9ghED/JULzUag9ioAXat2+AfF/3jzC96M4Vg/TmEQ8SuPTmE1h6DOc7QPn2eX+ni9Xn/VDzcR/XVhtYea+x530amCyLqvUJxtatpWXy+OebXNosoHbsO8pip6dt1CEf1K4SS2bX3xLma2fe6F3nc9qTmlNt+mzQkfEeR21hCJBgKZ8Hxkdi44D16kMi6qimpNnDjSogEQ1+WnxF7z4XYxNJ/AVZLM795WTk38C37amvtybZbO5Z/P6/35oqlfeiWbt1mtuyidyqxuRWf31N3o1CDdkeZGtPT/olgbCgcif/S0JpxofiEd+LbzCxbY9uNss/fH9evgzUO5I5eGP5S+c3YYFz8O8Mjw3DJwnLVr4uXXPOfO3h5kLt2eee+jHnjou/I23yRGvhmiLDrSnvef50uGxgeV+CAb3v+rcDE2AZnDb8hS/f+XdbLRG2YqG8Mha76Ebr+BxyfZc3r3L7xI6LlddTRQAMNNNDAXDTQQAMNzEEDdTTQQA113EKh23IhDbpdrEiWkfjiWOkx6xqh2yOW/opyNvJn50PtxQaZqYnf+4F7S7HnNKely97sDu7byUlBpWvXLWTMutHvR8V+hbPQV8gNLnjO9Qof4XPejddapjGt4w6bP8081QCvMjIfrwhNdIiH5EtlEjAQgapKKc0UYhVRMoFbgLSqw7QmM6wjIcEWZGeQgEGirLoVFMMJS5YoJdMMeqKYdJKMpSJkQhA0kqlEzTYEowtpVUC0qq5pNGssd2IAV9jgs5l5gZFX10H7moYCNDULCRiIYFVlkztTiFVGyQRuAdKqDtOazLCOhARbkJ2VBAwSZdWtVDGcsGSJUjLNoCeKSSfJWCpCJoZho5lK1GwjDRKRyruJMIMFNI2W22Yworquh8HCpiJU2VgMNbwRZX5kcXQdxdr/gLRa6P4thCnEbd17L8IJkkqjM5jl2tXVKicYICiGE8d5Gul0b8NQ773jZN+6mRvjnR5rbLEbTfRwvb91Mrp+5nzR2d3ze3CpevTDGKlHf3fKm2jeO17WI/718FD4+wjvRXh4BE/h7xUeEd6LjZ5NBPrQTnM26B5nh0I0OB73xhWLw2LVD3mWlCRggKAYTpBSh1hvl9QrgJoiCIIgLPJao5aR/NequISXOVO4enhw8XHtSvnikRZdrcRbwXS83UPq16knfy0xPseY+tT96LSHh7p8TgF666MvT16dKAb/WIic2+4dyv7WB48ffbappiU3tpcPPkZUVOXopvfxos7Hivq5ezu/yKWpc/v1o3cP3No+Pip+Nk+h8LnKozyRzJmTlE5z4Xi7n56nMg0q6XicO4ft8F8GqDugbRr5BK2hw7p/7PjuVfhTFqnDfzzIW9PkyaPAjtc7aaFkFp6XkLYWi3JPHEc/xonGl71t66mIZTvp57bWfOWkcTzg7aVn23BkksOMRe3rN8++Xru6jPtSzDlOMLxcyo+EQjYCX6HYnD/wacart8Mn7z7cb4QY5rOWPaUbuIYjo/SaYFXzclg2qXF+DeZ0QkLQ55I6gguGaTStXh94iIRJmhqWIhHV9TBZStF1lRKig9KJmYJNTcWIR0icqWfZlZ6iDCOpApAlYeyiTjjQy5VIoFJqvIyF7MP+yVbQ+pMytGCxyfK8hFgnpxXh0mWNqwONaGs7C4kOh8UpVV+CXZJP2B+tRynFiEkpthmvmQnhgmvOjGhGqdBAC/JkSCcgVAhGaI3M5GiwLb8MlXvUy3G9nxxpTD6fAdwDgQ02oWdyCtUB4VuZo4xW/wActq+KhXM9BSzIYmBPEHTxPJbOcf+aUiThpnWmHGZKvdpay8yPQAaTl+KXCvit3v6mscPmr8X3Du06d+TOapzlsKnTx6t58rsI9aT6japC3I8nv20XNsaawxTVUrGqVWlVJxj5Lno/9/+e6NS44l8XkeO6FL+Pai9a9oC1B/3JjDIP7pZMPKmdTROId9bFcFfFgPBgdjSJOWtLwb3+AjE8x/fVeqdRVWXbEr8xD5QYotN+ox62yYQZwwmSSqMzmKy37gNN5xP2ibGuzmBVIqY8Hht89zhW4ccDHi3mB5WXZ91z3KQZqUxgwW1CeObuLAjUCFQmDbYBBBJrmUI5MmPMEJmWSnZWhsoXWGpFU1nWKBLFDNymkJ2jU0EUFW3hKtIWp9KlVWQWKtVBRtZNtiSbRUw5GKHCZJrIFwRY000idQXLJpLtRkBAakobsMUlMgZ1yAaSKTSpJCtqOIqbiWSTpmVOlnSTrTJG6CSq5ipbTOULAlvVTUJ05lnZSFzIJG0Gz9wYy1yXJBK3KgOzIgm6pcq6MCCtGyBRSdTYWOpyaxy+vM6fhYT8z7//8J+lOInT/yCm05Zwsf1Pgv9U9Wm/iMXYscXAwBj4cTvt2Cc5P0JvbduWE6jmvCIz+Hv6tWqn86jg3Iwn8Ae6X7hUZcEkKzGcsCxt73qdgzrVK7IO3Trq2IFdi/ZTvVBDjajnQN9+KcrYeFkcYltu/2dY8VtC/A9n7kNI/ciRn/GXdziDDIJJbx+xIr6FbtPvNLSlMTOE/abvkaRRaP2tQa6HuoF3jZiu+BCw3I2RdajZuJnlrTQhjZKHiQ8lPhRkET0OZKV5D/Lv0u/+rG+14lO9l+8p7CrseKYIwgRLhoaMEPRMcYPfEgGs/GWMFn5Ub1z+1HoZyRITxjo6wGUVrPxy7CHDdayrQ3EoWkZ32DgRnjoOsgItN+MB6S75Lshm9jf4fVJDrPvKuepvdbICFXoMAA==) format('woff2');font-weight:400}@font-face{font-family:'Geist Mono';src:url(data:font/woff2;base64,d09GMgABAAAAAMk4ABIAAAACR1AAAMjPAAHmZgAAAAAAAAAAAAAAAAAAAAAAAAAAGoJ8G7JKHN9gBmAAk1wIgSQJnAwRCAqGonyFvjEBNgIkA6N0C5IQAAQgP21ldGEvBYwoB9xaDIFWW78KkgmmMdYeexgAhKiaqDrHti1Q6B4Eq6BOsI2hlf3bGdvHXXz8REuoGNvygt3OwK3dVJn9////////yuRH7LfezMKb2WVRQUwUtMxK8XN2fe5AGIW7OYiYqlwnkWcppeRpDkuLpo0yVlhSuNedJ5Gisopo1Ke1FmGl6zex74lIdUt1TpXUB4aPu+gubElRc+/PFSLYRVQx8iUKdxIHhzu5hcMkCRIk8dp6TRJHS/uem+6t0kl5xMqjZmZaMtNGM73P7x8yo+uiOFVi6wcszuprVjmppLpKwX1P9mJt2GI6YH6OXpus8Y5pK+YxpUpUHxaUlSwW8jKixluL2q7s9uJ2Enfx6v7nWca2xk3LYi+fTXvBpIziLDsx2hIPfAoPuWtUVyzwel1TGRqbInL58s0wgnjKqIiEYaP/Va1SSb3WTZ+pn3nWzjeW8KXP9G/dwmch+Uf7WJvSqUuq/FX/FbhWDxfsMG7GkFg81R1umCQHA6VJSkpSXOAw/VjMVa70Hy3+BNy1oSz775CHdrOuJA/ZSOp5BvvPIJNmwqQVZOjRiy8vR11Uo/RtwZ2k6KgMoUx44ILm/C03AzyY4ceAWs9Xkr+I52l3+RQpYKEyfFFoOgVGtSnBSR7EdBc2dPMCcl0cw68v6o1qy/IRX4H/SK0qfBUYu2xGrKqKE3FeqPg4/7+6Z5LcPFnfwkrSinBwfp6f259739sGPaycRVQMbTAB96gR9Wn5o6RyWIBRwKeMBvVjFBZRBrFBb2YhURuAzRUrxqIYW7tRK2DAqFEVg40NFixYlTqrZ+QZdaGeeXrqeXK+d21c/Z3e6ZV6Xnup8kS/3++e3e+IxkTpkF5p+HQvlRi1UpkOf4LaTFyfXYlHkGw8jhCyIZxHyIbzKEfwowylljqGoYZazqEMPmO2hDLW8SjDMJRhGI5SX0oZj9KUfMQxn/nJTz6/vx7HWSQ/PrXmI74EHmnt/z2TZJKZ2X2w93+eT6xAArW1KFNgVdYSQdcZFKaPnu/v2Z77n9dM1ExASRImFCVQpKEkEGkY/48/BHfP+79z+TpV3VTVDkDhBSEeSZAGtfxPm7kOlkQKPOWHPd4AHaBMh6AflM57LmoXZUZd9bTHEQAF7feb/QK0J2oJsRBvcN6EutSXI3FaVamVu8eRWVUAKFC6SUh9n6QRfWlmT1GwJqkdMxhfIKTRFkuvluZ40rAHsb99vfs5vuZP7WB5IrJk+QJ+y/b0pzLdpY32dvBmGHAgEgDv9u65Niw7V/p8jP7ZUiUsYHwmRgWmWjgNTPM81Mn2BuM9Q3VWlbgRtVQtZTpEDeQF8P3uga/33XcH57TRbpQSp4ArQ0Z0oeT9J13a+3/+jIBHsKSVZcDQ2qw1TQCoy0FRuylyXZMrurTtVTdNZ1Og4tPwh+gYfdNhIQ8Ro0n1aprGe+c6PM2l3Zd2N3qXUlDSZU1usy4VGRlAB4p5wh65MWP/6VKoR0iZEf7hgukamOepWdUhqlT7utKZkh4s8+2BgA8EZP7nJDuTMl2Ruv7xyAZlun4eEyFd6ry6b72kh9oyim34yI+8nzTyzdMESTGfGc1XxjObYeU9vFNvQ7ohOuVWQnvEREqz6TNA4q02fYrqXTA5Q5c7/n3x3dtonZSBAk72u7u5Dm0qVZSmPvj0T5ATaPzEvvjk5KWgNMBmK2/w9Nks6zdUTTVo1aPVAuuAxsARouZdGBooDO3M1rf6VtbRFZGRVfnpmh4USvEwAslDSG6h9rjUaNTqlXqd68Fz4D6jfmSLZgycTjgNRNK9e7sXuDThFwm+r/PfAaHmayHAvNZT69TWDEvOnnw2Bw6vAuG7/W5YkGZ+/Z4nlshEu1pTFRcu2Z2owtmAMEUbGP9z/l4FWIc3QpdVfeds6OYt4PpEF7D/AcAF3ptq/gxAWskMYG3px+T2ezu16jWAIQnbKpTE7U66JF/EK3lNrUXeff+/OocDDMMwDMMwDAbRLgwfwwEOYTSj0fx9J+sJTnA4oL0w/BiGYRiGYXgY1vgA4HqDoAYICFuusJNTkbcpHHbKkgWURxL+4/J3EDZhAtNHJsAAwf7bVGmVfJvNQYAPB6FLUoK5GZa+Tp2Q2Pz3plql/wM0ILVTC462ZnDndVZaK51NudbGFwWv3+9m//7dDbYhqG6AnGmA1ByMpAIgnQYEtXMEQKoAmS1KM7fF0Tp31kcNktKCYylpnZFZH53xLvImvliT3abpeRtdkCVzQXzpwf//783Zs98J8N9M2qXfhYqMRDi61Jmhvv+SrjKB7ko3HumbMFUo/L5lKe2v7VLIoxDRMRGoE5OwGOit6VJfXW3NKK30Wik4Jqawsw6z65AIMbSRsY1MjYERNc/D3zv+XXoH2+BZoAt50tiW6JhgIURE+aVqb0sehONPDrlo7aaT4Nz+cVdoFli900EAHVIseu7iqAHgEKd3U5X/70vVur7XDZAg6UBKrhnImiRvoiaFO0hRG0I+7tx2M/D+//hANxoguwFKBEBaAimvRNheihQtm3LA798NN4OnOBzNOm3QpMyJiaQ1KeX7hhAv57nNSePZ02GPtz2cLxHicW/N/peh5UJ7u2pBKJdQM/tpdz0OIVEoi5QnNFDxqq+t+HGjiOdIOrZ20+PBudNXV1EA7kGBC/3A50TRIWaqIr9DCJ2L1rWLvnBd+F7n6woccsHo2x2vyTTpUi+lb0ssTu/eMyi1vt3LEpF28FPw5gxreP7/117t7LXywlZ8YOmCEzoF8lVyksItsLFmhJWFf9vxh1kSBNbD7sqxbIRB4lNMJKCONau6AmBCh6aVNiCSdC89458/tfYJXFqSW59DHIxBIAECFQSIauzUuc+bSYF/z4/PubHJsq8fVaPGqBER72v9tq+ieCFU7dENUySFNK4kIoEEEkjgBiK5Sc/cX3sPY1rfL4km0zJz12fbi1EwzVYAqQqKk2v/E9Vu6uE0CyiUdu5ABEaB5X9jaFYYXQhDCGNWEDZiJBFnGiLTVYgqvyGGDUOMJClJm5lLEsd0SJk6QhLoDalff0iDRCG99TGkz76G9N3vkIa9C0kiLoFCugAQaQIop6mw2PCUQHpMZmxufAtpaqatk55+hoaZm2fRYlasZN1ODhzm2HHOnefSo/z0M1iDOraSgns8JYXvCZQUj8/jUG65PaXkv7e3pIy5AyWBIAB6AEYApsHgdLjaALnhtZUGgpZu13ld1317SobMLRGXC5h+t6PcjLjdFUMAnVhAGV75k4MTYJ6RFw7TcPkFEHqFmHcSwDFYYjVNhiytpbYaAIYGHRJAHHT6C/uP9Z/aVoIOc7ocWhxaCQNUOv4QSMyVCOPZRVAejC/QG11AKHj2syqetGqUoVYKQ69RnTXyjFWveKUnIPmFRuSPWrGOa+pn41STxx/7omJJtMeKNfn6LVXWZYHVN5MZssaCxMbqWC92xbhtQmQlFMpGoHQTQKWzmHbwoV218jcAiJ7XZKLAk3rYffQe47c5mxko7p2dkMMuVzrz0E+OJUwkng/dPEoeP31qhGGrH2qjEio15TmtzNdlcv5MwC18iqHeEC0NGDBjw0lbxnULfvPor/RXpDmXz8V6dz4JkQc+HPdOyjV83zhOMsyziwWA7fRJgy/fYsedtkrV3FVVgxZqfuvaa3xxdaqDTjciaeSsWlLUoStrszLz6CXX8+yK+nx7RKKgyUrAP1OaKHiaEoWMNlFkXG7RtbnzcMksxrIKsBw7qXqi6QdmkynXSiVUZWsT1ajGF0+zAoVpgToR0e10x7bnufTQo/p5urmR5z55uOChKurpcUeOm1eb5xsbbn6F0cA+P8G9LqI7A8ZPqxtbBo6MtdivLYmGwY2Pq4BB9gL0bxVO3WANvXYFmV7oFloksxpiPtjUsMSmVG+2TnRAdNOV2eG8h1xc8hTlqhYebvjE35NASAyiuoOW+1vy4HK+sij7Rt3TiOa+JPD2I1VnMxLs0DT7CPsDAfquz2Kgr3MXGYwxgWRxAsnjuY7cidTJw4tWKX+POwqn83EUTzKpko+jbPY5lNepnGc+C2Z0CFYRO+DraaUw/BgNqBKYaS812Pe4mhicnieG+97qeynefKRZYd55QRevcGA0rt1AZfjpgGm7AfLLN3uSmHP5XHsImy1FzLlbPY6aLtyitf7TWDFZV9QBdXdRzxRPPp9P7uRuvnq+P9XV+26a8D0PecTjo58v2eKXT7lfVzalJ5Nc/nnV8lfxd7/DP/v9/J5aiqVa2nIb95uOAVXMbPTwkpKL+ZbH4WXrMv72QRMveEk7Qn4iBomgD9BHfuAxP/EHfxZ/1Rv9m1mypVoLVTAyESeFbMlMduT0xJkZuc9DDkt17yCPf06ecJjba+a+RuMMFowLHQ5KrhjZZcn/4/j04mSvRTwrXqpSF2EbnggvBeUlQNQBVd2sQhOErSf0QZ9kMSRM6bH0dRQTBH9RVhCyv7LuCxmghFcEjHMW4L+IlubnzVItahTS9hiO3LlTDBXlWBGkaaW6L5XckD3uIE9Q1pZUTj5GxNO2PPGItAjUi3R6EpHJpKQLhiEaS8aAJbehX64bS+xIqfKk2buG8jUhdVSz1iU2XFvpi+XJRtwG1SU7sEaHkT4D0o6mcrQGGYbZ2zKPjE0hEs7PIz0ZwSFXbRNSppSSj64/rud651u7gn4eQESUNbGTjt7WzYiZfwYrJH/dQ0gAXhvgTfwQEPTzwUGcG2hC4WmHMjKlihoNI2mcMRqnoPhc81rWZykxLG1MO2ShQXAAKUsSFmnBqrF3iRJI5H4J1C4GwkemhKGcqAQXT6VFlI6NzmcZ9tcrWHp1LjBCNpuqbQlqRK6fK+gn1zBMAaxwbCnEGOUwjZks54skBZm28ylPogUfu+EueXR4JYXwI4sAzm5+Cd9fIscHNBe0L2eelH7y1Enu4aeBd5d49AhIwwAIlak2tVSZJQ9PlxfHUjQwJffX8M6OsibQVIX66RcRZ14GlBUKqRy5riSVPZY7JOvMkkXGOgZrXNeTZiApYE+d924vOvtMilZEElBK+ZZCVNIM1azL0lo2BKSdDtbBkoIGfLg0514LbZJCOJFlGz1b873iQh5nr4+yKngwsuzscWVoMiGvkpfnQ4KoZniFN79A22rlZ0j0UOAVHAJRxomDxjAKPJbzGWY0x+ecVzLHBVz2bibwNhwIrC58eecdMiCQQ0JkPNAJ/jXnIKMSdorfdgQ/19FQi6yDziciWCASuNhL2fBguOxg9LhXHDR/4EqPVmsYELqO9MZEjfKH3+cWRe1aU4B0F+kdiR5lpDpiuktMPEihloc5GHLLq/uV6d1ayW0EVGqnBULlIz7lMY8sXB9A9teL+xtfcZAa1OSn4fHaSlROklpjrdVMscVVweTBnYM17YNUojKVuwZV4BfqUWasmR5dc/LqpR9ZBWX9Amt6yzCVfgV0VpeysLs93peMpc5wnfJP9hO4DL4v6F1AR5wHjCfoReW28h0Qf+O3UZPyOpspwH8fWPUDavt07W+H0jyE1g5v+pN9gG9GSFL71drXavtEn2kSynWZEiKtV+aWtpHMIEjs2/fXA55XFJ3stim76h8SKUgKiv3AKvhaCybhfWl36IyWajn89mrtuaw5cm9/V7+9LK3Jf775Hu/UslrBcrFaOJROg0kwURZa3abwRAuwTBT8bzu9KV2N315cw+OvmTSNYMucFRXygoDTAQAMPIGNio2QOVUBsJRrExL1tERAhC7uBJpcsXRoGRiYtc1XGKcBr8mJTmDPxR0uBz1JxNpTqW0Yn9dCI6zFwWKAlB5sBCwqUJBLGUzKoYKFQinViRrmmk0QY0SSRp25qEUWqkyI4wecU6o2F9PZm135rh0thq0Qz77LnRCPXOJoWhi37/JVOzxCnQYeq30q09GwTXX0SsOkGEx0/184Wn9BsE4jidF1hrb18I4qCcYSZrl6VHZQ4LLwBsWHVNi8kA9YPGrmOC9aY+H7qseRigYVEijKiktksSzVuIuXtpOY/mDAiGmIsv6ehHHCYH2btaVS+wIj4x2z/iVqdww6SyxsrNBoqZYveOuhWaRKofDRIKIOAgQIECDEjCRKbi9T576iCdN4gxBZtwGKGhAtpnOJQOqsq4DzXYJvFvbcPqOtsrQSu/odXziQwNqo0fIT5VKhfLaueKsiSmc1rlCo4oPER9rSL5A8ZgukQ8wpScPd0eNBJz7g+7JfRHly8QJjf2CC/tjBF8rDH/yy2H9g906+YZH4wc7hEWG4Zdcob198d+8I31DcTnQz8PfovtFhUXh6v1jvEfzJQf+EB+C5g3p19YCVpD6wPg2ALWkI7EpjYH+aAEfTFDj+1gw4c9LTBV7/Vw/YdvL/k7m9AM/mR/hPvb8e+3c7Y7tn9B00Ox8AQjCM4CiG30lckxTNYiAYICiGEyRFcxkWZvUTRElWVE03TMt2OT1e8v1CUTXdMC3b9Y6rtbrv6WA4Gk+ms/liuVp379uMxsMkTGfzRViuwnp3s52q9gVhFBdJWmR5UVZNb6uJ4pCkT7P8aVFWdbd5p695iRUIgQMJEkEGAibywIcQEsiggBpjwFAPAyxwoA2d6IAfnehGECH0YQxhxBDHMlaIgwgRSSZCJvPIpxAkw/IXvYBDE2aYMAOwCOgDaoE+4NCEHoNgFJSQyGQLeLLIzq1w5Q6wLalgS+4Em5IGOnMX6EgEtOdu0JZ00Jp7QgdQCKb+6o+cb6FC/18Hs80xF5BgSGgwalsTQlKmSp0WXfoMGTNlwZotPiExKQU1LQMTCxsHFy+/Fq3CIrr06NUvbsioCdOy5NrnoAKHHXXCacX+U6bSWRdcckWVG/532133PVTriWcQgLpXRQCoW00kgGptpTnU4zzCtC+8ZmoWLHEzjybgxIEdm1nzFPcwqIzKckXmiUMYCqvIkwWVcVDMRFI3zjFLy8lB0QpVtBzE6D0Ml49kyQzheMcbpzASrLDGhpK9wAEYMxydFiilzzJyRjMNiBLjqZ63UKHKHJWqyXry6AMDGur9qVCOEyOMMcEU04RHkW6E25yl3/0e/IFU2cO5VxNjUoAH/4FHo5bd8JUtCa+h1vOopyVkCudINILUG6eawE3sBzs4W2bOljzTVcMsC7B+BjYpRhhtuHDjUYfGT0DmlA0b6kpY8jClJwwYDzSN4BLctpGACTQzLUL1UncgxnGgU32g4bNu1DYiLiyG5/MBVri/Jj6cn1xDX71VjOEpxCfz2OD/WSGVKLU8zmssYhmVNLPtN3LIh78l5F96tEGLDiOMMcEOblBgL5uThhHz2n3NfN7JeifLbcVIf2pcCMMJkkL9dgO2D0WDHS101K4iOuzZustWLvvEvc+w2+66/k6kJuz/YtqO1iN2O/2KdRG8x7OXysl6u2fPlsx6rxEoF+NuORD+G554b9TQK65rOuwI672FqXRFfaEu3IWSju6REp8tagvMmvnVRSbnmyap8awZ1LgnBHFq4htrI9gpQRNUPBe56oqINeZFGGZkEDS7XvuNI1b6BR019lxnmeU2Nin9jSsoTpMjW1G3YQ9CJkmm7LY6hDGAzIxW33Gh9MmEdE2LSWpIafiyY2306m5GA6f7FTDRBoiewAjB3bq51j8XUFHyrLiNY/6ZhKk88eEZFZrODhS694mcbAw6BLNUlsrKzOqi7jwUP+MBZZ0N7ouRc4lCU3gg6DLzIjB48qjtlhKcRGZHw2M2uJE43IEnKF9XXwxv6HnqL+XIqcFiN8u3YdSYUUmDNYyobZy7YYtir22HlBkCBF3ONiTBQ6cFbBc3HUWHWXwqZooGh2nkCM7IAA3GAysv8cYh5R62XL0H3GBdrvkjvuFAAzoWexgnd5i4xNVI46C+jC4wfBeKrqQH4HYXVPkTuMx/7YGuphzL7pL1qDF0NAsRcwd670EbY6qm2rtQRMg1XQoQ1aarR7cr4UmY4gx/4dX6SGiSMdY6HTwWks4eiyWntp3AWx2iBb/S+BcpQz7UngNsaCF2oqkvTfu5tor4MRcxWvTtYp4HAzNEXEA44EHuI9QGYSq0A/IA/QolgseKr83SX/Qes67tf+w6o1eYDcEQjRJ9WWrWbS3fi6082+CgzSUu8V60G7RBd7HV/greBiGDRKlZ/kLMTUdyAJDAVO8XYxN4x5JTTHaecjYdEeYcUeGvtAPdBvRygBnpDho3uLNo2fXvNYS+VNLl5sJZcj2yVHXqOmbH/ymJRpXqMmVdj5LrwujUuOW2O+66hwB13EcAGqunWu+59mIDn+/uHkC9o47Tqex7ELlSMXQ/zK9bOVQWrXS89wCkru2zWQlQRO5xRF8MddT2G2Lf1TM7Pj/+/vj348TjtcfJ3ZuTlpFWKKfC+pheG0BIaO9QCDWny65ffaqownVzDmjIM9eThMxa3yM8/ATAE4FVpOYai80V6lrT6nx5Kr8d6YePWz6790ykujKaLz6+jZlVBUt/6ea0SI5cfHn22e+Agw7JV6DQYUccdcxxJ5xs0vz3xZYlllFjxk2YNGXajFlz5i1YJBBJZAp1yDNlmiHI9gtnid+hnrqbOeG0P/CLYXfxJ4ypofMuueqGX+Q67wd/wwpMLFVUa/WW+8//l7vuN8WxzZHxwEOP1DJZbA6XxxcIRWKJVCZXKFURdQ1NLW0Ol8cXCAERk8XmcHl8gVAklkhlcoVSpdbscpwKHkeR2L9WpzcYTWbL8U6N3JOSOh7a3alO9br5U6lfy2C+1Fa/vH18l6ep8gbF6mO9Tm8wh3oRrtyRUv/zISciMio6JjYuPmGgd0J2w2DUf0UOXAOvxkRsiGNxPE7EyTgVp6MoiqNkZMO1wdjoJYS8+NbNpYlf8hkzOopLya9tnBY/1aaO0V3FebGHbLHhxvqObGcX17nBbZ7ynDEWeMErpQd2t5ZoMTQ/6E31Za1VpUGALPowpVVPYcDmJW+UrIEnBzrs7YKWIURVNJg7nBw+ou2yb/s1BG+UJkv5TbgjX/OfCLqHbJb2129jQIELYo5IzF/r72ZaTkIWLZiTH6JZHsqpDf20R9v0R9e8SfDKR3PKOKNO50nCfkCbJO2Fh+ZQOmXTAlpCy6mKaoRexQfU9urFrxGs/umOk9zyL90yGQ3o5V0ePtAOIvgTqYiZGq6RnIoe3GSUfSk+oL5rBz/SqpZVEX37EU5FlzzRNO3InZwvHKU7KrVpOm+WIgeDVbCGBmsZCTdsn1eBxa+ZmqhhHcqO1tInSH3YB9TFptlHXa6U5+YRyFE/orWUgZcufIhq9gL43AVxldHEf3o8hCcEZCXpZEHnm2z2tdHb7LJE4giZ/QEMw7MrMWmniSZ8Vw5J9umnm1B8GIdl2EeTyXCMluEeXpMZXNJVmVRLlh/g2qeSk9IUnreLHQMpnpeyvLIia88gfe8duxZxMRPbXpvG8xFTu6T5jLzHz/kdra9I2ctlR3u6dwbp9Y4dGdhUElrd9VBtDkkkCp6dd/M8lZe2IKtxS+/Ka/koJ7a82FE33dOf0+caeaSR3lcdy+iDvutiD+5DtHVnYSbnt35f6uUHnvRL8un/2t+Sp/hdseEyMj5LZvlUbXvd0U/vSO7v5dOGKy49rcSm7FG7Pb7zt3mu6TpNm7Nf5lzk1n+5Svo14TfbY3vzQ/yhKHshcN6z618vPNGLC4t3/UdJ3SrEdv6ptic12dQlu4nl7ezbgefO+nIqY7m4O0OWWp94bb5f3xbUvIHzteG6+PH2y7iEyGUUixz8SrWD7AO/rEvTbockVsFHqtUH2Y1/8aV2da/uNVZC/+zTf6yhuSrFUvbb7VOVVP5MXHU2JlO1ZVVqOdVXQ3J/tGG6Iwn5ZYn//ENLFa1r425uYJGU6z/NXnr8OHs5p015/jTDj+tj/9DnvoVDBoIkVU5OHCVBguC6kUEI5NMhMIh2CAy38C4SK+k+X+5VGs/ryg+f+7b1reKcD30gaLhwhoK/zpJuo2wTjOQs/wVQ19pjqOef5K8fJ+iYMGXOgiWrP9Ij0HdIpvPyvAZ6Z4t7Pb5rUbLWtSoLIeNfe7P3SxyQkLIZLx3ky1vp3yl82UqTcfnOpOiq3W42DEk7IeB9g+iIvCXHe58wj0zZI/6AsweCM5DcgeYPjGBghQMnGnjxIEoHSTaoykFTDbp6MDSDqR0mp2F6HxDj6ENr+tKefhT6C3jCWBPFs5gEieUky60mRWG9yhuTIlZF8+TIVdkiJWpVtUyNXtWt0mJWTev02FXbJiNu1bXNjF/17bISdpY1JIaHDaIhgyVLwBuEkGlRRlTeUwoyE80NmmheKLf51n/7K53flmglhKM0mJQsp0aLNh2W1hGTCGgVtcJBh5U665yr7hIYIPbGL5MkAgkpoDlKlSlXBaoZA4+PX6s+w0ZMy5N/78yUqLxR/uYqGoGVJ5l0st1Y57ommHDd61nv+q7DVV3Hjd3ekkiSpE11pWmlUagcn+LRWj1k2IjRZWqqu0Gv+livTr0GaHhEwhU8Utp/PqxZ4Q7vyI5u7PWYj/uET/rUOI5Fi6AuwWszGWmRHhmRGVmRHTmRG/yBDef2wcGP9GjoILTLNzIInDTDV5JsT50dS2ZLiSCh0jrWciE4Nu3Pt7UEdL6vVFb+N348TLK0xaiMDDacPlJjfQ1RL8TDSAI2GBsBm2B7vA27YA52xe7YFwdhHo7BpfgMvozv4AdpY/vIyvyYSvToc4Dl02XjcnJFneKE0Gfmk3Gu/b1DrdMRY3sna70i6pVwXeWue+mph+gdcecr3/75EQpcuvy+Pz39hPwNVEEgIvXck8jpbzvHNxT0qV9TzOvc85Gw0dKR+M/i2YscYnYY2mCXY2+HKa6dPc8p9bg1l78r4DLprnNXcu9Yb9fx6apxrmu9ariuTzXG925pzU/NRq5o2VoTwNy8WNPgWtdbB9cG14Yt73LuKqwutpZR3QSjRo82Y1+mTJjvGwP2TDKCscl+luxAWU68ObBrwbqfi474IAs1dfPk59/ph8ACicVizLh+grsyvZBdO4T+PH8ukq7wZNHJtz5N7cl0swYlomAoj3tMYbDE3X5WaR4TOawLK9hC62dJgGG8AredXfnaBwZIWbbPzetnXrs9vUaYLO8uDikNwuxsMrPb4WCetChbN4aCzfgQjsnbBNggBuVaZxsTvjszKNEzMNgoImN3TWMdwL1QXg4zWXx3hw7j85le6NxzrhhDy3SB8Y7xoYzRDgEEAYQKs5ikb6UFrUyV01A4PD5EkcRyYFTQZOFGYDJj+E7Pwf+A/Pv4bw3/b8fqcc14dbimX1Z208IxafPnYJyEv0KDKrFlyetTW4kaawuDb4q79FLjrrOPNYGFQ67QbMY1r615fk0apmyT2pycQrsqs43hCsGCnsNVlt25CErvev/ECfFA3+bXHkcaUe9Y6+YkrOud6p2LCLkyii3JFpr0pvwh53OFNrgOaUR19caWVz23zvdqyKV02kAW97y5rovp5hC42Ja623OrX51nEeSmGzh3/AE7qsaLSxFXGn3gpxyZKGHhCysIi2D4RSnuR+nyF7bnX/xDI/OzNj5SAra40Y4mDNGTlq02PRva/S89fXA1cq50rfcQ/FTc0Et1zyZt78iVac9OAQQ9I+p5Ivkbr1xlY2J3SulelFt6Ue63cRnn7F7MTxvtMz5QJqQ8LmaqYTzEZY+YH/inGDGlmBk/5bKmdVzMISBk9JR+tsHGtCHldq+/2gTW7DpAX9d86ztc3XbxGJu7CRzpUmCyV8RHEdO3/hSZ8QnXCYBe0kZkY0q2rEvrmHCdQAtWwmGgKQG56TjibomMJhhE2GLVB719fGf3zUG55tt8XgCFJuU7Zb/NTMyBoehvdh+VNbuou+L4PRrgM8cJwFoBOdtp2whxShZI8/CJr4YL88I/3kmb3u0d4BLWX8Jf/0dALm/pR4ALvz7gPksEjED/TDWNUh8ECI2Q9Ya/z/4vFZ29cMwkO9psaE2asUmpjFulUJkqbdB98mI32+azvu8G9wcJV8ENURGIqA9qbI0LcT/OkWvKVc3b5ylQR/2tq167cRfd9NDr0T9+dm6B/ZTLqYJVLazaUfU3FAIth1ZB4dBaaAMUDyVC6VAhtBs6BF0CPQw9Cj0GfRV6FnoBlg4rgcFhJpgbthm2HXYYdgx2EvYN7Dt4MhwIz4OD4eXwKjgaToFL4V54EFGHQCPeQ2YjEcg25IOa9TU7a07UnK65UHO55p2a901AJRlP4IecXv5XkUggwEIXc0q5qnnCiiSaeJJLq/YnL9U1teqtFzxsnYUBUd1aG2R6782DHJzIZKQw/dmesVydx/JUlufVrMm7f9LCFP8XQglGEJpl113QQoSMUBGEMrdykPxnxYOm0n7bDsHcYPmPeAj2CuwE7P4j99zqh1CmskS9wWrJmvNrjtecqjlfc2lN0ysa07eMY93q4cVnzkryHPq5fVWjni8KaDVx9KQKTW43tO9RZoPpNkv+tJpD7Drn6X3Dw69ioq8mxO9bG4jvFh954/BmofileLfYFjdSFt8SV4mviC+Iz4nLRV5ZbXy1tprd/E+it6JB0YDonOiKKE4UIQoEEG0rchZtyrzuIhWRdKAB4NPz4Bngk8vA0P5zwMcnuLtEfPSLW/aHr78JdFqxJCaA+tmhZqm7uKrVrHZtgzNDTDnYgz+Ewwxyseiw/7OK4jE3dcyN9/RUoPN9fz6ez+fnSZyVs3Y2bgYpBQCojJQh5QBwB1IBIPt9mTx9m25by1TeA8e6D9/on81b7mVH8Z79hqDy8oOXD14/6HiArIsCPLTuFD9iYciCLNxiJASR/W7Oal+Gn2/6q9steoWb3XpyANqBvdr7P7cWWoRlNWMmbLCpaBlY2XgMGDRkzCy+IsXKVbg0f/d0I6dhP11eN3zx1W8jQUgaKYGAQqqD0YhITklFx8qlW48BcZhN+LdQ+ffo9mvuDir8YY9AqEOUsRDrVjBgEpIcDXl0+rhvZHQMhdD/zyQfU1dIgWcucql7KUqzYGSYj2meBZbStYYKLRsJCIkgeAjz8unTuoXqtUqe/Q6oFJul+zr0+UTso89+hGHUOImmYiVK+9tXWEjIpBinlUSAm5fPIIXhIN4j6DTXB4t9s8xPy/2yxHcr/LHSMP1SQTsAzC4NlI0xLxtMywTLcsGiHLCrMNvAOVTd5ha0parWV9S2EO2sNqfqcwmVcw3tDp1r2NzD5xYuzwhFJa4nUf3JGk7daNpG0jSevqmcm8ypiQwtzq1FubYwqq1FNF9oy+K2pfA2FdLmwtrZv+0rvv0ul9rV0rtSWiFxKsi/DHpZl59ZWbCjmtJzaa5rHJ8vf8hye91PoqQapi7wFpI1L9ClkV4vyFRhvYdBmpk/M6H50buNEwhFYrlCrdHqDB7D/hoxasyUSRNBWWQ5wacVKg1ksXl8gVBsYGhkbGJqETK3ZtsOh2uXbtXK+0D/78WWLNtSF+mbwdJ78PQ+In2ATB/uP8b+Zyqlj5TTxyrpE1Wnas5QztEuMC5xrvFuCG6J7sIZqzwoK7odRbUrXgXemO0dWfrJM0iBIYqIyDGApAsdIQbdpOhBQ0CnJNArBQwDgqoJ6qZomKZphppJm6psQ+UFxSw4dj5R8ouaf7QCoudbc6Fx64xfV4K6ExaN18p8Wp1fawtofUFt6J82Fty6AjtYYgdK6FBJHS75LIhpUQ1FRIZjPbV84TdK2T7ehDAACIJAwoFgqJlBo0Y0a9SqgVgQ3+82udzwCn+X+LXU74XEZvwvyZCIxUiLRiZWN2tgLPKGSPqLvbfATMT1EfT+hV/lm14QLAb9eG8ifkiLcnyTetWT8U94nBOuC2+gKGBOITG8zauRFs258e2t8Z0RE14JG/bSD4YK6ni1uLaXS+N566/jetML0wYX1fKiJI72UNaynp2ya3bJztn3kgsz/ZDwmwdzLvXT3w7wBUKRWCKV6XVajVqlNDg6OSs89Hqkz2P9egx4IGRMeMwFZfCgBQvigVPCHrgPIGlul2VDy/A6sQUIghk3eh5etRqTmE8vaEJPLHzPORrC5vL2F1EpRxZfA52Qvd+TxX0kErdBfPZdBZbPkW4u09z/9Dw64s5rGCJ9fiFHvPDlVMQDOTDWEt+Jh9KpQYUdXIsE9nXoAoZYAuipgOpIbd8rXJslEfI7Z95uu7zZf1jJnREYex/ajhXlZlRzr8euyNXlEzvFmMo63Wk8eIKhQlxdahmHyvl45w+1bpQzI1KhkjU9Qz1plNA31qACfzul/Kx3NGF30KXpvKUK3frlCz2TvvX2u5uz5iodnh33nr0qMmRjxR1SPJCLLMSCivwuwxDpZ9xIqIVA9HgRHiMn5MQLqmV3QA7GHBAfPPFyoVmfG4p01d15PM9lEHk351oi1SoqKVWFJ7oJNhSnLWqgC0rEag48bngO3NFn31hbzmtSN0UNTLKYvYVDCMpqGN7xMJe6dgfUc0sekcxmfzUyL4ablLLpw4aJW+pFrWrf3ftGGJ0ofKzXogcGbNbgMib+xoE7AbHuInkxJP0MHr15mw4AQStTDs5ForSk064quKFjvboQdbAldte9t7WGRI21yIgZ+JQSCygRvH1pvaEqaAez0oAdlnFXWB5VZI1O+seTxLW58YCipU1SlKbXUbIh2+6Gt0asvreiJkPmXse/a7It5mg5IJ1xKbb0hWKuEfTQDzQHtAusrEB64VwkTuuNBQPSD8WLJJGeFss7PstvR18yWcooIOXspl/eXtnGttFy+woZtr3L7VxHao5FqjxFDpezNc1rSLsCqhhELjqLck6nn8gym8+t3BlzDRNFWLJsm1dm7DeAUqRJSS2m/O40A5B0SCSualLdXLYaRYa7O57WHbpM3TFx6uoQzsb7DQDFncI5pzypwkktVyu3+E/z6IVSWYOMuunIKEJkHGEyiSgyjQiZRTRpI4bMIx7pIj5ZiQQ33ILoflWaurzjBSXps6VA0347ZLDp+xt9Z3Cr7/9LrUdBK1WcJbWTFcJXDlSzqrfGrDMbzCazxWwzO8wus8fIOHMXmKqt5F5l4LiiLUe9XZ6ctLhrrtYCGZ4tn698v+D5QR8VmZM4Jp364iOFUZwcyMtcTkedsa3F/XnWutP1H1VB87BoFh09cwR8E3r6GAUco8svQ0oxWuIm0NxO1TkzMpaPtFbzS+UEmEJfdI94qKDJn6J8MLWc0BkZOIhKpbUDMgv6CqVME+stJb+YfvbdFCP8gelxa93VZ0o7d99T5RJEw9FoS7wZiZdjOYZGbB6muw5MpTN4FOcTKFlZNMEYJRzEj/6k1t36I7GrvZmL5epUXS9bCom0Tm1JrzulYVMVoaeTR6QuwlAJNWPVcVk0s4vQyzWl96OgsqxIL46ZNh2yN1q5IXO41QBbCGgSFaEkfB3RNiVIUwoHkdDUrPSiC/LhOiYv9KAhktIFPJkaux68dBlG8R5ghliBySs8k0TWMgQ7ffIlpsQadSUgkimhtgmvY3HaIpdgS0NXKkp4fU9e3zPNK1sRLm6ayjtWvpbDKkoNgu09ot8wW+oxpWVeaNXMPPL9Z94yG8d+kGzR1J/rh+AyM+OPksF5pj5A87qN6YwMclmWXFTrj+UVMiGQte5FxvdkubF2cinfg1LGWAdPkMM606EjWp//VPQNGNXBPuwzT8mYsaaSsioieXoDlk2NaM886FNWZooiqvz0uVE3eadG6+Z3YrGT+WPyIv8SGXSwecr8VV4bFvL6bGi6ghK9tN405XijyGozJKStQmIW4ZIyRy5JmYBQC2lBuNFLQhMQRvGpyWwCU2A52VMQjsk9Sxh4Tv4URGBjmB9nOc6RogmIuFAShIe0pGwCIi96IRKHy7mlagqitt7AHGiduimI3j4MzCRupddHjxyucdPECdvtucBbhN3WcukgOqwEJphAON0OJbBiCBet4KOVBWjvEOUuJIIhE9Qy7rJGjdZo0Ro9WmMIhEkwLIK6YZcNTrTBFW1wRxs8AuElGD6CT39c15Paf6zKxb8TTKz7umqFsars4YvC/zdb/Xk0UP8P1QIEKhIHAORpAdS7AeTUYNYbwMpHgMHXAnreCrjjIxhcHv5AIEClyyV+X00RledlAv2cdwKjINMfh1XzS0iXBIFyXmaXn4iFbmfFOedzn4Lfhhh9PXaxCZ4P+tP2BSAWekCw3uCzc25q2vnnT09/jGABpxFxsdD5TY14ZWyvsMOXEn5ngndoAaOpo9ao4LA4rSR+liAefxMIMXATPkh6IFkm4fzXCGvHWaFQfpzJJWUt/EOpErGGkZBTWaYmVnmg8ipd99pgWMmmLrT4j0jLIik8II5dpBvhCQQZSSXCTxbLRuoWwA0jGXEpYSfyQS+LAzJpGSgTmWZBS3B+wtCgl29qi376c9GrxjGqg1LNlMVoWozk4OuEy6ofIyFF62qcX+b8NvxmXFtOaBejiIp8ibpcpDJ5BnIA+Iv60RKSdkmD2aEYNuLX18AArj4DW1SrMg7N3l51OkuFOYdd7uWllBGHESPhgo1spJ1xz+aB4d4OiTP6GXPOmN68mHY0zRepGH1X5qzL3YAqrDHI9NbLqOMkgoZEsUJWbW3NL5dty7DbrKcOmcNqyCE3DaInhFkjeXmzrFBdPbdQic2mrTreYzbe0W3J0Ay7bCRV5eWmvXXd4/y6dLcTcABOQ0+R9DzlqyxdHnNbIJsbhYAUWJogbSIPHsX99Iofe63kpAt8ICZ4Mf14TpBvB5DAHMKR6JCT0uggkebkHBEEuMMyTc+f6zZmEbalFzLE+56rdwsxSWVoS6cJpC0bwZGobhZCkyXhhtMBI8DHWRGS+8s8BbFx/P73BIk/OBD9/v6U7Ee9wPNTZB5ahrYsVjVBHGqNs6Tum9P3fzcyEz3wI28inzbbE3ZZbB/xcg0CzBA1yeuOQVuWAzBzB9iyrlEEOW2AJT9kI85U6e73nnFBmFlL0FgJdt5/gUj6qiJ8ZVkEV9hy6qxhYllQ5QkRO62Hu7Kz46BoFi2hJMuUQMEAciqLa7j0tmOQIqkWSf3EyvjvXnV2nuWV3BsIDYcWy8JAEk8ktg/fUpN0V8t5dVC02Eb5ZJtsBK4AlIgT+IvK/5fAVyvc400K5HoZc88CAe9dg7Ca5pRbDKGB3Z1FhVdeYV0SJRMhpJcYNL24TRIllnS6ghoE4cSM9ksUE2dwKxloD+LUgoE9S5ZBW8dxckIKjFJT8kazwPbxqQy+UkJWFB5DoZIYvAeh7laa0MLiiFJMnNWV1ZyQNoqRU3yaEhbDV7JbXqI1qwXJnIqzMRUOoDyxUBYJff08stSys72ZTtdsJVDtE+FNDckZNGLIaqBt1ryYEne79VIs5JMeWiNYqK8VpPRigiE12Ecg0kl0nUWF8BSue/NwT2D/akpqufnvF7mp1D1pamqZoarMy7UNPCUlVXOzamx0lwubdfQmC25XpCTa1SjU5KAGaVeSTHMSGmR2FOlbvZWxngnz9dNQ1KBhvoXpHm88+pHztoqKjGNhOVnu9ul7VoyVQQsjC1VABqeWJiqYQv3VIuqATsofeWFRnpY6moIZtW1tFv3McN0cNfyhx0orQPeczzSQCblFmtIDuI/evReks4KeLZdoKrsNOXy+S05kJor/8TklprpBlaMUjvVkHVjIYaP9qfl+iaozV4mc1OqWpqOGfM5O5GzE9I7XC5+5L4K8wsv7uFW8+5qDRc0g7mCUiWSubdtWckcNlJsn2qywXMuYS5E1IS/XYqBGARhItR7n9kTTLj4WS2HtVEo94HYspS9kvGgyZKMD6ReSj4R8T5swlCanJL3Etkt1XjF4RAfgCbZCpKuL7HIKDqLdOjTXLCXDtefvzPabuIN3VikRqz26w3DxbC7yDKHRrzTzlI74Ri1C37q8Ts1dqDUvkVY9Bslszd8cl7JXUC3421WBpHX6DkOYqGb8nxD57PR/d5E2O7KuRcdyM7yNNvLO8zpSlG1iLX0bYu0dIPtEprujzENoXR74W8JOQDFlfWTXYMuDAmaQ0za0PYIMcbVgNPFUn1y6LO8vPo2nhd0GbbMu4/lNCHsRkjsUZlvySPPBOOwlG5zH+qlIdY1kxW2IupPWPQKXGjuCTrc49SSiWbFzI63Uv0qGIQbBfY/6h3eS5nqIsS7kq2GptePpjqh7u546NwtvgnUtmAF0fhxBSEy6JDI6I6KMwyEVWLG1ZHaQF6hJTQdsV+ORH7WzHXtFYDUDwilltxlMXeyUZrWaUqRNYPfduDKVJxyVk/catsEaHY6Gdo+lsTFGklF6oli7fvay7fKU3YW+gEhdxySB04uR+mLf+xgkj2pNIYMMAoatWd0gKzs22LopC+tZ/VBOqXZakHKRQPO9QjuWzCBXLaRWoyiStA1xUNtqrqgzFohy8eWSLAcblD3HmhWwqBlNSpa3aj2bFmUE2H5WnhqxLlD2zKJBG9kWehF5TF1h4NGeSEtFpCSl+FIJNVOtkFTZxuKigaAhgjbicI6XOfspi4zd7v6mH6+fL9nZtQJF058peHCTFaDaEJvoQuKQeG/GHLALTv2sJLk5hVskIkWaGiFDRDHTkcPsdv3rU27Py1R+46LVvjx838Y3fuAzM+eN4RHfuNAJ3U4ILhij5kMdDVIxLflscqImbrjFyRsReXIgnSSlThvkpMfIao5aQ3RVoMyOlg1886WTJeyoL5TKxC4Ohq5WPyhH+Dbjy0A7Gc0Z1htnypTEzxven3GiTAAJTXUvN9J+NaIY+zECMaL71EPGu1AJa5KuDejDJFAHTsaMDXpYJxwYNBolZ1JgAx1SMaYzFpeOxZ9gKOJQreU8wTmBQ4Vm48AoyQxwGr2RbDW6si4kW5MnkGHwGYegJy50L1sCa7MxHEbOYeJGEAQs1q6jEMP5g9AaNdTlVq19Ef0TpPOFc1BGGcwVLZZRQkm5vggJZKm2WPOOnQcYqCPfvHvnYUJOzWBs5alomgCtBjIqnzTL7UgOoJu4HBfxwiZKTVBc9NBlzTK6YUqJqnIn2Bi2L8iUsNALhIm54JpeJimu3aLC/muv+Q9yLck/3Nc47TP2zjw+C27YFzRroQA7lJN6JnRqKYvuxIh8M0DcSCM+ydLOUETyMJeg/tIUDnSgllUtFE5Xtk/B1gYjv0JktaSce9Ev4G0nlUgz1ggc+zILK72e3yyO2FUVsgK3upcl+UAYVKQJX1GnWe90T2znd77yX+DP55tErds/ZCw+PN5ucdN5o4n1LfP1CzI2eaKuKc9VU/rV7P6lVERcE+dEe4MMC3Uv+n6MpgsQUQPlCN000GClw5uAIY/t3FyPixaMe5Qn0cWJWm+kNqw1qFr/0hdODCJf/pgg2Unjn8iXGvm4dhkVXy8OFVZSY4c0u6N0CzBat8v+ZNEX1pa6hYG/2mfN5py+mYrqq8+aFj4RCPbZLVKtF7d71dRG85KL+CUWCkZeiqK57ekOvQg0NuVvlSkFtT7i8Hbkc5DC4u4iczbh/dIiBxwEpPAvaE4LTpGoX1o+NcfE3ZgwaAfPx6FzVE/JWY2do5sw+zTg9lGLrEU9cj0/wEt5rml68AAoKHwQMXLoeu6xjSs54JcVQO1kC02g2HqBM5G4zu1FTKR/vjJO+C9+GE6ZB9SUWQxcivOvaxMZjMQH/hSD7NPhiW5JeqI7ogtbhN3ILplV4yW4B/KADKi4Fucc8rP3f0SHKkBWMX3m9+3/eFDGWqKGDfcOwhfU8qs5BVaomjJPbha59bB2W6tMNCsE1Z2Q9hs+Xl3t2YKEN79eYLyDV2WsZxcaoUbXU+QeFUMWSRJBkenuyOyJcm71OERa4LyfcSJwkq6mJqoDCuLmB8JByS1W8BAp0UZ5hDd+oMon7BRfwUELeyw6dE7ZElGfeSfweGRv3YN77WrSJPu4rmVYxa7waFxOKiiasA/3n/YYom3l67efc+tcvXkVVrWRF+jND2rcW9d0Vbpy4wm5YaCi7gncJU65eHQgvMqVg/cxDB7rMvgOrxRoYYqDvOZ32SuDoL4LLAogXA9Y0YVVZ+QvhMKyvc7+zF7YA3v7O5x1Xd1iha8q7gVX3tEbsHZB0QyHDL0Rz7enIezDb1aT8VfB6ZVq0rmJlwwg1k7X6JsF606/qmgw8pJ/ImcWNwe10bVm4x7W9ndVt34XMr44IVMe4qCEy8dxoSZTslhmeb6F3RZHMRItXp7N7/B0QHMeNGHDXu5L9zHh5Jpyy4XD6DsOOvlSglVdgr2ouEeTEssjvaKNWUELe71bZUHZ8OdTDnv8hRjBvV61XfXaU8g9zzQ9wcthfFZ6ujCwr1C8O7CBuIX1jbDdvI8vWzk+SCVAdDawG34qjXIIVFmZXGNYzPyabtbuEGdc03nB2PCvHZ/LyiCksuaU98dFh3WfSErVqkoMsqarWX5PyQu/0krK2IMCa0aKOsSTImCKPf9/Sytk0OU69L+vJTyFQo+K57BSAntwBg4rKaCwEyhUBYMLJjh7kdT1xbUQO+CV7B2fdgj5UkKkB2pOZDCw8hWn8WWw+yJ/IICwDUfyNQ8fxiYjDcSaQ/BhpWWuKGXVhJmmItm1w/hBX4qzItZwHs0Piq5Qh/dM3FdL9n7gGUxxa/NK37j11PU7rLqwCvtxg9k3xx2YAutPTlo/3qmA16xn8fbh/lD6IMi9ipjPHZf3LYJr2guadXSPPaR7ed+FVVGOcy6DtYa4fQ7PwmW4DYFCcjVDiD4n4XCl97N05vTo7OwL4+qijmR/CJOK084sc//MdzroooTAt5PGvkDs8Nrn3cdEMDjXDhQuMFhCEfD08t56Y8onPJS0k7Zt6nvb8Mor8HKYXoFXwmWX+x5vlOdwG86cVefw7DYXLw3m/10TxJmvSQbhGD8LQFSEHZ7T7Y/RQyyR1xpAHw7lg3J4Luh4jLFyyqCwH/bJax+5KDp+3qkvqYNX3dyNFwX7EoqD5NHr9OpikSgW3aPq0M0GFqrVnLXbIMVNuftjqyIdYVFbuxL/bNMBHsshniAZ4jb0B6fZDaA0NF90+i6OvDBzqbW+KeP595L//gFXsxm3ZFzQnqOfjuYsL4txPeXGi7GxAFIxklwuag79c+CNrBNQqd0hSOHNfJU87mOyXMWuWAEv7qWmdr/IA+GtZC0piY0/9V/2nFdmTd7/LrWMAbO+HrsrS09E40+1SbxW3JSo64ptW4CLnIa2GFCaBlm9EGb5x+CV7CWcUDbjQSqZOhuqTCvqQdsGkvoTpkQ9afqNEbl7ePOlvwtVePqDgOxPY+aqzrTazeLwUjTYJfWdBatMjUSvg0NagHWqWM8XLlU1BFMRyIr4DPtyR7pCJCM8eVvUr4y6Kt52arUGDVkuBJiM0Nbiquwnxz1VdM53lc7VPKVAUiAIPOxzoUZnqWOXY6xvmiqtDcgpQqdG0LTCAbN58pOgzIqBI+yYukLUrDLbzmMGLcYXTiLk23N7U85VwlVFUrU2jvOUDMgUrCBYaiejPmvcf79gTrvJ0KYmPy5h3cua8/8NXEQbsDzz/vfUmtTmWSxMIt9yg0kFGq2zmIDOo9WklB5KVh/ghevQcbsa4gyfvahhWp3QFQsuvof0cXmE/SuWq3X/KA9YLJU19zAjuHqJ/G94aI2ajTJps9EB1ADiIfPTxYndCQ71E1PIMBWqNTmZtq++tQhG8bl8U619a4LI3C10TRdeo6Z67gF2dB3VQXCqxpoSj2jeyOKpU/alMS/DqObcyYDO2r1uqGUNkWq5mvCveOlqBrqeas8Gp5LPA1LgZ2q+3kfAN7Lc3ia4hklwfBmHkWvPTnBzXh5Wl+s1rUzq9ZNX0cY3mKJVHo+fNKl+V4TmCjZ+Km424ifkO9qXnqvlKOWQmXn+9IiFZqTqqpQPDEryTybqyCy41Cx3FV+rrcTb3e/Ucft4SSrIllOIgBCqEB/ANi2V38SIx5WPBEgoC9u03md/827VNelQO0ItteOUYnwkqvYaVuYgRp7qWtjNrconZ+fFpBSRoB1e9xRSbVb+SNqfHOPBvlVfdAmWPJ5IEpWpWMZFF+CoObGwRIw93oSh3fKdUn5rV6hDK4yxQAsmzyz4gvOeBZr6lNViqk6efnTSsMZD8YxSW4OxDt2eaQQW9tDPbJ7mE3Gk63g2jYA1R1dEWPP1qcmrt6dFrGs3nph6X2fkW/2py9EGfcAWn4+kDqsxhEQqIwPlipEIh4yxfEvsZH2sfWauhNEEfcrJtjOFqGptVDJqZWAk6HIqjP87kYDSnfeWdyTGDwJ67VA8BCVQPqKFj00UXYIZdCf5nSh92QwdHS+8CKqV+LBEWrO6i1Vc3CbNo3YC6JR0tST37RsN2v6wuxS6NW3B9HqH+cY8TmFgFWnDpC2iJ6bSbxkazcrawNqgVT46q1kZCKypGgskFxIciybxQcUqlFkYRYxbX8pkfSx56SDqVdmPvlobyQ0OAhOLgbsAoLQPjL1DA2Yx8fNZYReU7qr9Q6bdRHW6K3Mu7l6kdrozHYpO9IodnqFBi6CNnbgcl01tMiaqJTKSo554/G5i4pZJK7VK455eRRTAIbOdRsL61bqF7mgjLpoBMkj6n5I+OorLojW0uzDaM5pPVIoyeudja4z2nCirNNp4PxO6ufqtpVf5UvNZMiy5GpYOLXBHPp+lV+dVppv7fnT7xqjbTu5oY+kqNWHRGi29ypcqSiMsFUZ7RvPS4T6mm6ufxdHWbhlOZO066JyX6yb4ptN1sKV7TRv3FyP27Ssy8jcdKGna6zuGETccKvLKj6BZ6w++PnxLsWbD5jdKvHVriWz9vG+qXLIZoN24Iylrsswn31ohmp+P5Kki8LGPVPAbcNB7GMU5VGMibDpQwlu/17jxVDFxw74iXtIyPw1b/+qrcJt5UedZ4SVwNd4aj3rd0bXJRPZgaIte60dVBn6Rx7a+7A8K7MKJ9HVGYZY4wE2hXXHdvPN5HxaBNNoZq1cfgImuan3/IQPalFeGlnQwY2EYWRjv8MwAORRae4OhYMV81iYFw/Bd/oTPo5z8w55lSl3Hzh3r51ECz3eUmIBh+KdpRZR086YejWlskz9nSBibEI9y2GW6UZJYCEwrFtuREisylq4WcYNu/lSxhDCFoCfaUxIDXHUYsJea5USr0XbvapRbl8SUkyAcd7jYNUrEfzDf4ZkUkRUyN02RHa9t8XxRMOJULGip2yBcntBC8UcF2fkwLhqXFpY2/jLhLXpN6it2j2Hb8AbypqZZvS9rX3lNT570kMlb6oKfrof+UUOWw+aN7PI58gxSdhimlY5llXAQVZUvgH3UKeOuS4UwDrXqydNKUuiCIzu6ZCla4oiQojVuhAIZWBGk94c+C1wKuvStwKzHMW2HQ8u8FP0+5usDDs2lsfMkUWgn0gykmQhfS6uyBWV1Ujhj2lypwkovUDYklULyditNEbgyG5vjdTHmGlTHQqsyKoJf0kgcX2LndPNmTYJb4XbfHPjpSNH3hN2HnSWX9xRcT0onjaqDJ34e3+6IvJfNdyEvKLGueH8B5X1vsMK+o7ijaRYdWvAz6N6U4xS+IIjENcto4TQ9qleRkdKcF29sjTYTysa7LCfFSz5kugKRf9fv0wyaNOsfj7+MNfODJ/y9N2+lSD3Wenk397uHht4mLS4GavuWZiM97FaV4E/zic+7djqRUbUmPpmjvoG+xWaRbnNJnmjQaRR+nk8b7Y+Sk2BGRr+4MIex5xaMTW9wU5bJq7YchpKgFJGfN4zhyucGDvsY2Fck/NZT092iPhXQq/b65sFHiz/+3ovvfedAtrz/ndj1k5f+fckWzOwPzzy/aP5t7+KvljeVd2eH+jcUV+qrnUDu2eXkM68E3Ypu5aAh8V7/UNBBF+k+U2fobSL3ZKhvdL6VfxPfdJPfmjwu5FOaSEIafzyAzTMP2Fj7Yr2s/QM2s29mvKg3mpYrkyuJKu3KmRntclWzypCtjaQWDC1avCHDN8qQeNG9VC/fEYvJty/VuQV+njc8PjkZnvTypKkfpTXxakDxPsfL+dAQsILQtytCnnnQytkVIR8R1rRJGUSqSPm4K7MyPDnomF596XiMvz9uU/mk+t4gPWSKrfInzvsMn/G8PLQKlafqNwpeGOrl7B+wGVqmJorbI8BcrlhFU+pWzMwYl6lF6lCycZvjabsp2d6lp3+N3vOoPOOYTbQv1iPYP+owyVoZ3HCuMAL8Sajh6KzrxscsawyeGumUeFP9gi16AAEjSoWJm8rNg8Zr1EQYX4wPz2uTiklSEEgdOAzoCpz/k1KC0LmD8zrGFyf3taYn6bkawczOW+Fbg2NzIhDo5sVTZ6gmnjanrRh5hym13eOB/IlwwBBggDJSTJ3vIoOJ5V3Xu64vTwSR3jytMDH5Pb6p1bLYIFK8Xd/laVWiNleASgQu8MPM6LyJuYvHT8xdmnDepRPH95Bxn0Izt3ixZqkC6NLlcx165vmG5ANejBt5vrbXTp1qu+CDr7A3JAV2vb/eu/7Dg4GMBvuKah8VvWjJMh2jNseWLQl9HnVJ/F/eSWb6hUIb2kmS9+Z0tyklLAbT/mJQtmnMifD4wNBMLNg60z80sK7vm/5f+teMDDiFeisWqV6SIVHjVkTbV4d7lmoWyvGrbPVxec1QgM9vU1sFiS+6p3r8XLE1l6aUFvwvnHeS1MAfLYrH+CIWlSZi8mM2EIiUp4qxBJ1psg5ghsKgEfLEBHz1u+o6OURaaCeg5M3O8Z7urrHxjFBH2qhIyWUIm3HVp0XVd43FAQZaT2ewrJ14Y7301Y9CXb2+2va3T8gBnQSWncVn+rspmqnAuETJptH1HIPGeubkXvIKxoPAX4EPAiDqyQah83oml46+H76hFukFAptX3wi/PxoYvKLNPn/68UykbYTLFV4IufRqZcn6Jot6ugz34cZtoxNLjVUg2bLHH13t2k2TvMuF0NsUV8NkNv+xs4eOhw/eEvrLRmipahrPtZz2xhfmwyb6T/vOBeJzkCUQ3l/Ij3b3rSWbvX0f7kYy8+2Ob4k/CwW+bBl4NhFQ+7/hU7tyrq1oX5F9rUyYuBeb7GlVKlyC0r0Nvash40XxIcm/dBqXKR6ygUDkPNOYTdgWrs0RdkS5xHpGucHt3OpMIuxftHtLLVL/str0j6N7WQQNAsvDCPVyQ/4RxGiEMDYfBuYqel2OUHtv6CPw4/wqg3Z3jr1AmUSx41F6mUzOaVi34G9jNfzmc0JqVRZFJtHxFUZ+pjZbfgdavcrsSis7PK31XFQrbVOLMb8lK+pUsPIro770AqtCyfdh/M/4xPXilckydiUMe5aFgkvEkAei76A1926bsmh6QjhZ604EnxL0RGoovn5qKr5+wMkR+c0WkY8lUPosZqV/S3OWvEvIGjUaWaNdQrljuCXXFgIe41FwQoXfbFb4hXgh9UAoLdc+FmEkZaWxcYiqJxKeBhPuZG1YT6hz8us2tCh9ApbIZzGL/FtuZznbG7AVLoKQWPgMNkzRM0SEj65VgDxEEL2DzK/dxvc1NzF6MPzPiXljljzKYvRoNAjuYsvgV3aqzL3oEp6w7HdeWplhnwepmGkq5QVrq9AvhkyMeJQjdfCkRotUquPxnaVW4x8ANj5L0SlkjhqNjNGoUC6O8Jhj1sqRVKVcxcF9/mobsFjRb/9amp0qkPAoVImAnbF8xUEZtdVxH5QmEP9JjQ8uLjctr5TLFOqjpj3VH1VXfGz6+KKlfrc9bsgXhYG7W5oFYgpVXa/FkfkhLr1Xoab2Bbm8ZhMBDTjyfdsy0dFVwlZYAGqARmnl8MRWrUZiWVI7K93CK/FXk5+RLOYcSlmknOuSiamL+7n2uRLBFI0OQzFaumyWIEtK4BNoIqmIrs0AKU0ftCdMmIvHTbLwBtOehgD+6AOTNl1jMFhqtIng6z9lTb3/1SdN8b0/uvzLZCCq6YPPqsHQYdPCbdtunTDJQBlIiDVZ/bm6Rl0YSLqzr4FDNftb/Wbu7srKWpbRa2bNLqiksIxDWogrySO2kagMNanOTrMEWcvam5USESOCPaOLp1WLzCZVxd1KXnjIHDpL3ilgjppMFly73C2XOQVSn8WCpgCFNIJBx7I01jWzs3BGjQIjaZTo1JaFs+iGMnJj1BsmVwoanuj1CYQT1oG8GAgXDIZ0OxxI1/UfVoLm2EyjZMNhL8A0oW9qVvmUuDGFgsCFq8h6tPmLpd9yJR6bDXwuR/Fsc3JnRLrB2fovSYejqr3KxnG5AjuG7yQFVYe2fLnw26aPKgwEUoXxoybCzQVGQtMCwz1+3obgF2Y9mqz0pwvQS9msb5oAmLw/vcGVO53OweRk8NdX0Gha3L7Y9HFaa1lrqMca7Z/8br/JTMySBHHN2qZQ2sgvDMqLUAjdL1Pn2FCqRnGbMyRx4gjqaCht4BKBklGFnJBka3OsdWiMNK5jiH/oGBppC3aHjM00db4gT+cVuWbah7gerkTVTKdrmOpGN5r6cRM6SKPyRZyHc4O7NtceNB0cC469b3ofJhMvMbla/lb0DvuLwzsVO504vr7q+9rXPcxY8NRLfipnxHnTRp9mqRytXmuQLW3iEak8mZAehHhs6JbuD7PUgdHQUDPfoAwPm7Oy15bhwSfvegBWVMs0+MeLhdE1Bw2PuhD6UKiwnb1FpDH30JW1BwtjPAr98U+Lu5x/Ojk2dWH8Qt+p1Iu5vXNvL3mbN7nBxKvYFcuFXU6KbNyzfE/khua5nRrVoPbwPFTTYQ/fozCp72Q1qRCNHfVXKXakmuQOSm3/HLIzJ0vuk+HH1GoL7r0qZ6gxVoCsBeJOVtp0WLiz6V6loYlQabrXRPiowkRsqjB+dHCNXCGT3H3ZBCGx6FtMMtBFXJXIgrx9+tqaNF8ltiLvshibTS/IlDLJaWUGOOPnOIWLRWNXyyNF0LsVxJ3ulEXaZr5SIRbGc5dmZHKhTdnlm3RJZ1dvR36PhCjzf4Ajj6PjWpdbq3F5tFqXR7NfZI2odiOhaVNt3Ry+aTFKmtgbYByZjS/sbwst7I3P+KfXxkfWTlu9iWsBT4AGwsCzNfxMVQq9NUqnUnTx58PXD5wPanQFG/4WW8Nq/F1hQPJ3eKN/o/yvDwBj9YuU1jYQqC+6zr/cHx03mlpM48bocv86f3Shydxi5jfmabpILBe6I00oYsl5KjqDLmxu7nP10bhoFkHMkyj5TFM70Ep3RSl6TWcz3UmbmqriFvC1AgbV3d28SJhobfoeP3nQ2ZPFzeqzdGO1frx/rEhv4IAqAyXl5ySU6pHL7oFXsVc6qkRH8RJq4vvjr5fiANPl9RWtnHNCE4DOrbs37e6835H3KckA+ifP1js2PzU1Nt9r8z/XPIzZ+U5Jp+Qz9DBf2D3zwohEOJAZCCv8RltfRDyxw+jOaCCSHU4SniCTjbUHaeGEDpkIBPoDXlseSAgLEv5AVnPDPF+A/3dwo5fKCZR8w3hjY8tGpTQRfjIbXzjY3bUwHp/xT8lkHKFIzpNOacoTLU9IvePxnp7x/t76REviop8oFrLEYiFXTAz2BfyB609aBhLxAc/xSYHIevmsGYGcssNFlbCcJxBLVP0hG4v2WfoDhqK3UsxMgVDtL6xfIRZTufWF7vJEAL8SHwBX0qxoglfV2dVhmiCtJP3sr0D18fHrjldWdDbd4myD9EbS8u6OINLE0sNpRZ4iYETTK77RqQEPLVw8UZMXmmEFDwKI8OaaD+5JbwN6fWLCI3hYHUmD9M6Oe5l++P7eGGtfMAFaGTBfK1IDOedOKKsaSfoGnJ4DDReR1fX1QsQ6ngucCOLVafvd8w6/+9gbl92v+B2ezWn7UlWkHHV1d2G8vb1wsKe6uqdwcL1/Ot69g3KgWJlvCtl6lkTi3ybCOV27std2jv0+JlHSuBwl3RXPy/ft9u/6NY/I5amVHCER8V+1uDWwLHAz8PXxsSdIf+9wfKBn7EIvLOwM28K2N51v2rrjC/u6uxb2xrv8nTIpkz+7tnNdugT9prIhc9fNACSw52YGinVFig4S/+jqr4BiAhhYRZ+X+MelFZtuNnmuQb6pf36ljIS6WVh5NGVYMyrhqVpBwdu3O3zTkCup8dISiBxSkvPDX6mD6qElH1282r2GNvi/QoWUSK4LlJSeWrGTFY5E1vqX+aNjRlPANG6MLPOHn5uP+zdWLDSZA2ZrZatY9/Pn//HwRmqR3uAsvzKzA8zTekxSMcmt+8K+7dqKKfLdvbVim33/l+Ev9eXnWk55B6bS/iJAZSEnalC3blll6HZAnHyZrfxEeHkrOtCNV/mMUB0DdpHesFgC2E66ebL4ltat7mkF5edjsvpHN2/wVU5xtWG8Ku8qH9LKPHGujpehaahVMDEWAs0/MDEkp3S2s9UOtlSm00pVLIbcINdJZG4T5G+rXSlEZW2RMwTE1af3kWfwG6DVM3Ur2negd9UgvsNtDIxCVloaLjAwaIgEr6jK0N7Pxi3j98Jvt8vXWNZ8ZijruMLjIaRASVUZ64LkSiDijgw5whXStPdDs86MjMG2edDKzLahJ396/xx60rYycx7UNvPHE+8TPjor2OnIULemSDHsfg3ikyan1oXthiHKmMwUZ2tqhrBLE2iL2gU4yL/Z4wRJn1UthwTjfw8EDxZbTBfnv7v/jv6ZkZQx+uCffzkGa2mhEYtaNgYJXngTIYzk8mTlkKH57aZ8CBJwTjjcotbJ10KCHz7+MEiVjx4/khohr9SFfHuB/feFs5ZPLGen0H83bBSEGex+q4U9wOGC497jgnYGa8BiZfW7EMFGz+9mhkxrt1tzK2QYMWx8wJ7KK8GIcsPVY7Jigtmr810NzoEix2Kl1b88CkJ0GIjnQs8FL2Q9EGHZweq+ALTrINQVT0RvjF8O2RcJRTqVWH55RajVqVJieGi5eTn1el3d29TlmltoQfIhe9kbaIkDzAY8Zg/cwuMuOG+5d3kmxt7vL7QEpxcbTduvWEvBRmzlsrTLNUaPAtvDuPCCrligwvK4dgS6vWKjDjSiFQzxfTj7oe9yrT8oAUP8ix/NPrpvrmk+l1vjteaaFcQsVZeQcREP7qKpvCO+bH0bcERIJNElUhA/9T39e+lCiYJJEpJ72tKyDcNhKSLLJ0GDx3vCBoq4VMF4duJIGzBbP+LzMnwnM0c7hdKMcojvjiA90jKmZ5oFjaMmU+OoWcDUB0ZA4VTBl0naRqzHZsN6Gp130y79yMVdTDPb0GoPfQ0JnezqfjWQNXpslJiDQuV6NBvMlRXfw/lT9LMGhUw5kxqkbpJvmprCb9qr4nLUI8tfd5vdQ6GhHeYdI+FQm00qsdD+8czUTv4WWfMtub0DbPj8W3N1xtr1pr9Ma9aDqs3fGj7vYB+PV0MKPvd/DobkxdnHEa8vXbd03egF9tfRl2wNkgXCqprsNUl6qZNHEbIPp/b918Qnf5DCBVaAS9YgCsVpConB9vh/hZ3zh8bNBT9jKi1Zuc+Doq2inrZNoBWZbfE/nnieDP7RtjIzdEx4xRVZMH02qRe2gXVfPD54JRBhPfjn3ziqjtsXlNhF/ejxI+vf7xVG1/+sF32/cGNwgd0ydvS8N//i+XHLrvZ2G83wiz5/6rT1kUBd+J2HbuDqMWkxweTR+a62XKDQsY3mDKtmTD5HfVd3i9PNG/qRIBkC4ovldLpIOlFPE0tB3FRIukAsp4FLb18dfnvBl2zcG5bpWrKUbYVFqK3yHdM2k0mBs1qpPoSbWjrn+te9RiCtG5ZrcHGDgNpsFOCfNRp53ZBAtsbdSL78a7F8+GgF08DmiJjF0rlTS7eVI421HCGrWCq6O9eKHXyjzUgxBupgECjUVG1SGmQ1L76BbspT9ZK5HrZI6ZVBxpGDzXRDG1YsmKKMcFTfePAYtoSMRfXehkKtUEmSScykmyRSQpTEYGp26PH+cgk6T91tY+6L9TL3d9vUrre/N0YA3f/fY8O+P1lKEChWrVzz+b8OTdqxH0zUD1ADn246ZbPTERxrYH9Ai9dgR3ojrZRTc6vhxGdsoVKSwY8AM9sWj/b3DMVczQi1QSitdeBtDsRIYLgmr3+kO9XWDnQqCbQ6QckMhqtj8ZrdzUQJtpl0j8780NEBzNAPBtvDIyF7LF4jKFB4hEKup4/w2sBGvUN8s+99k8+00fDkocDUkCdpIzJt8ggwJKJQOTKlRCxRc+oEtV91JjWuWRzAFF/aIimvEQVZ1KhEyop2shc15o3M7t1sXbCZ1xvhqf1hT6G8A7ReSZbaopk9yasNKKqklUHtkGrY3T0suZ+v1MiEUjVbYNII+Crz+jN7Z2i9swOB+06zP3KR8O4QH50ni+F4LpFI7vkjmSalUamWAIHHCxCoFiqNJk3+Q+4RiXiuGE56mniDhL1KIl3Fkm4QTGw9jUOXCSUSmZDO0dM2Ntzi6kmJ264XSDU90HnWCZtofywm2jdhtyK3OxnCzAfklg6329yuUFhAwF/AANPbGxabStGo5FLswOWVqDldsh944ZdVs8yGLzDldD+ATfHbsy9fzuKfKZh+f8OpYhxBwGHzJAK7JDmdxyn9p7Rc/lL56d05XMnut32WAzwNhwLXZ5bWIXBcmoDJZ7jlqZBPKyqPFJd+XFbOKq/hlFewYIiHNbJk+OeOVH4hY76sMpF4pB/VJ36jnwxxQwsXGeh+e+o4IFCLOTSmjE0YynLs5t4v+Uqy67ey6u+rEAIoZassBS+mOPj97ZzAIOEJVXxm9dXV8LdqyQdFwJ13mXQJHRpg27UOEQcxmJS0EKaQwgdty5+4G19WhNg76FJKJv8UWUR/gVF+fwxTyOlk5En3p8U1OC5JwOeRcDXFn0b3I8lyuvw3KqGRSm0kNJ9A2CsrjAiEsaLSbk9pd+CAiEmhDNdDT+10xBd51pHCT9oyHsrReYs2Xz52zJqLnPKFwmDf1rVrwQzCb+9Cfwh1DjsbFpDQaawPXhYD5yk1H8N3JqpZSr6QZ5BwOchBuFQBW5iUNNfe3TgqXx/Dp0kTUGx6crwj++cSZmnqLyQ+5l3CMp7x6uLnpjefWcizFc+sGVs138dR7emEaHpr+1/X9TNJ/ZcrykyL640e0xx6eVL/lUYyiP+7H0Avx3zRwJxFvMDH5nB3ny5/SV5e+k8pJ50nSbZLBDy2gEPAFZ/a8P50wRk+FkVXfw6XJdc8RMBYFeWcmnJWednHpcVHKis+hchT3XwGU8Cl4RB1pZl6OEXDWUzkm07SX/1N9SOJRzKd2NC6iFBHZ4kpXHnKVgpUgKj6vrr83i5JyVf3ubuzHEMEFlNG46jEKhRdzSe/6+SFPORZ6S+QRaf4mRS6lL0jVIOmm+nw/uhH8kh8AfcpdJ/8RSnCvCvUOuxsaEBCpzPv7hQBD5Jr34LvPAVlqnK73IPChlzrcesZ6zErKjNH69KzFHcIvnmGcqaeU8Yl5NuCTADqZBZA8E4sToFw+3nMM/WJty1dkU+tPZ1JSQXQ1Rp5azsUPtj6LBC+E7fr/qspt7veUe+6gmQYbqWZ5BQArbL6O10ulEuxiNl8a9rPgbXyoUVTYMStnoVWG3dyW8Dl5wguWK6wbKYBOrsaZywAt2hWG6txgzaaqRGnpSgkAqoG4NEkCWgSOQWnNTXSPrAeE10naAUS22DKvMgh0BGui45ZZwFKr1M61GZ7zabp3nnklSNfWfsfqrYUkIvEORtFy3awfSvmFuzCTB2wJVBDv1jzUCMu1Mg163cNQwU2fOPUktdKRR+YfyxXgky15Sqe2VMqdpWKPzA/LldlmOrKlXyzt0T08q9R8D2nNwj/xpqKGsLZ1O4c0vezc7P4h7ubd9NnZ4dYR50ZGRm3YemuNH/9/dD9+jQ/0NUUvJ0P1N8h5pbPBNMLm4Ah7410l+vPd+QoM8ekv1qJfZ0uEgmB/Pa0NB47GKEphEEixcng0NXfbb5G6n1ndm52cw+sqyVeCQ23mvl0bexHmcD7JSgD26y/VoV5gxY3rBOEfh3q/gMK+91te6p/h0H/UFf/r4SH9kzPa+cFfPf7lvuXc08BYJhfu6CU9VbI9tZHhzCUC37emK03V+62vgI7/JKxSfTDLpm44eiYFgRwWxKw/Hwf9Dwur09l+g+1aEay6ZJfo6tQbwE6A2apqjLDYGautpRnZHRlQL3DUKix3WX49q0QigfdTOHnzAm/av9KuLx4Ch/+ZQorMehGz8qkL8Vkz5GwHgPcbWjrwyAEhYXmF2+NNLI8u/W34z+l79F6sUH9v7sirirfH871zqpCJPhNKRzOS87aF25TBChJI5ZB1D9+wfOS0SaqRhY9XudlNNuiCqFxJXS1TGbBwV4bkop1q2ArpVLkOvXhkqqn0RCsio+vynSEaN8TpWuHHBq/ugWFFxK9RCEe1aLWBBw2l7ZRibHIWCZxWroYyDLKzVgHRutkvTlkc46BAmuWhxAD5GnZ7wuZBaNs1LpsDk0gjbyfdSOqraw2P3rlEXwm+rg5s9ZZf3DNP18h/vpy9LMrd/6fAL60ZpT5nZ2PBusigIceaPDGT/9Fvvid0/M6u2iwyLKSjqGjS5ezLasYJjhC+LNQdeh7HW7XqmMD9epjq9Rf4F58CLojTtRamxm4tvrays3QhrtRK7VaCfSJb45kUDc+b143DbJeXP50kxXc81mbKxNmgBWH3jJBbPkBrmjjPOfJRxSxFRKQxwIXeiRa9obUWqwpkfaukqe/U2hXe0oEnWTNed5GRlUNMd1z/MbxjxwAety6ehOJcruLYq5GdJkG9el8tZgP8AFsrmaLbKfpIAzju1sBYBk7cdQj9QbSQwEjXfwpisviGA5Fkh1Sh3Be9LbocdDmy3wL8tvjHtFtUVaUwKV9ePuXb+3d7Vkc+QDWm/BaHfhe+II6Bm0fWI+JzxF0ApFjPmVQYhNoOzzjgw5ybblESFMnedQAIVWi+NNtBUDt9AqOJbwJiz2nbsBVDz9VN4jvqQOAHJD+UopVe/WoSz15Y/ROAVNnq5vA0z8/ndnMYUpgBy1tFr8WIFbuTIFWEOheYtTVzWECZ5t8uPeI0KiDG74f7+IB3lPjTMVunLI1+PPNKSkg3DdOhaASvQeWUn/Ffv/FORkSSe0MYOFq4+QkMHwF0uCQecyOUxsRHttQt9M2MrKWGqpv3HpPa+obikAdgeWoOu+dv+Yg1BEYSqEJj2oGU1IBOPe2IHt+71Qfkj/ubhcIY4GsQnj+bWF7lzC/8nD3Rks86HvNaq6qktgr65xVxU6QgBd6MqIrFuqf28GEe49qf4aGZ2MjI0+Ed5O/5fsX+CkpaSA8+67QieMsEHoCUQXwnFNBuHc5f/NgCrfwLMwm2lAXGxFWq1YbKbvUNw6ZlpAHAETUvfp3BIXUavWyT9zHQ9c7/jDPUlC/gnJb6GQLn3wskQrCHg5TqSDgM7tn9td/3kvtgu4YCGEKvAlxRMrW5ZYFMxmu9E946/9WlfTXXCNbuSWCVKl/E39bULJjnOPMBM5O1czZxbMH9tkBugfUxeHT6uz4ssBLBNRmD1QnvGKf44YWFnvkOZ3eCidmGyz/JDePzKtwP1WJZygxZ2jgxGkqb7YtoGFLTK+1i1+geolu/dRXLm/KQAtvsOaDUuS1943wKqht8uHuo5+dCq6gdHaF1oKs9r59I0OHQN+rnz2b1nxYLQw+GnsXvi0dPSYFmcSMmdcVe9Je29AL9/4tVK4X3/5z+x7q8qH+uViI2O8kcexEZJmpbNLLZ+Lf0wgNPRVhv+y6+p9JqZEqKjklz9jn7uffFWxnAbU+gM7fJhnd5pr7VI0zzZp7hZ7k/PL9sDGq1NyV7B4hPMuD6d//aMF9msmWaujsTuhUJoCt34nf77H8HMENyxU29DZU96329IGnQLHVGgsynCveEuO5zWK+roP//otnFgQ5OzfAq4I7Of3gAhNuZz/MinJiqzTvArBf8em+oy/GU1JTU+NJSQO1JQd3zdfC+lbjTAXgfs3qlip3kLN6ycsHV/NOnYwMkvsBqcIeePjo3r8dAbDA26pgs6vwRh8tCi/jOBy2QY3gsuvxPGEZgV6r6SvM98GqWib3ATBgpOUNnJyF1c6/fLAE1R94pSJwbs+53QDY7rVcfnp2CHktoCFYM0vm07z89NxQ7cqHmgJQCmONhpmyXCHMRThXXnBKIb73NA3jWfX9pa5RF8r1Ry0BBVMWfJveWV1Wrk9xJjsblpiUHLqZiHdkJb+xGta/CmcqKNl1aFct4Ky7ZtXCr3GVqc2AY8nYmNhgjnuYh1O6ky2oyEecH4I3Ipn8inpNGhfIK9NWVqK0abw0boXm8k0PnW/tJ6joxiIRVFCtKiKq/Cy8iy60DjZp6KaLkWo+tKvcxWoKrLWcsjC8787rTLrIZ87cKjAOQ4RXLmt79XlW91U39DbkCmFuwrny3Cxn9XrYJbBSD+pbVnH7wNq//xmoRzcopn7QM6QXQGwnXqkC0oDVOVZVefjsao4xvuH/iOQ0APWjSg6+PF8Lm53MTRa2mIFSlYpLCqtX90Ebesvy+PGvl4Exth6OPDTkBUg5Mu5nEBxw/L338NGBlJTUlLYwKoRatP+b9/zIkVsxzIsyXY1C1ivlbRvfontvRZtd16Wnrvf1IGa5NPSC6+uTbg1CiVS7VljbzReiKqx9CkWGO2cVBgbOzT+SGzDFzSs8gg4z+8WZzS0LjSwBYmITBA4xk11NRXkQFY64TPEgr7XXZ8eVS1hcYkaNHKfx2s1mi1HCEDlUhBWnFgCufJnl9ZH7pnAf6qwXyr7KOY2A8WE1A/AKE2xZ48m8bW/9tBPVeOr6MyLZgMfbWWyC3YQn/5dwR4VRDYXbPtqSrg4DI1wik5lateCBOi8IsUizAB+sdZZ6sazf6HP12zP1bWkdPCwJ3VJZlc/PVxQ4UduxGh10XQemkSLw1tazMBJ41S1BAbxuuKp4/1/bUVnWaZdkXzQq2T/ttFpnnNL9e7h034zLwhP55eTFTieAK4hEPjkJAbkP3kOuJiUJ7WSz0C4luYnr0QKF2lTxNTgaI2WxMFI04gu7NhUkdRvDmKP0AEqhQLXQaKgAAVh0GnG5TwNDLfKQxVwPg9zCZJIDVMblehmUAFmUFvi1EE6Mbqfxm9DV/34sHZZyeupjgL2NFd9A6uiNKdLqGINb3cjFMlCxfawuXuG9ikYrMOSRGoAmoMTDP8U4yWKeOv1TtYp7h6upFqCXN8pQGDkOa4FqGhvlKLQciwOAEIwB9giJ/BEGfSrP9RHt3h3UNyHyN2X/Rp1eZ9V/SwPugOsvnov757Vttm3HW45D4jWl67B52isfrSMt5sI/inOZTr2O6eJyWG6tnuXMiCcGPM/Bs8L6CyVFRGJRSWkx4fXGGX80fGr4E/n6RUO0LWq4KFOj5e8Q552riKvmrt3fznmzczVx9ZwpN8FM/Co9TDo8/OKc1Wazbbbc2sWtNntvO33HZu/mluOJSSmVRB0u31xbMFssls1Ybh40my3WJWwxz6X48XxwvWS4tAFtty0KuTlDLEgDM5/jTTBQubXUWsolWs3jwjrOFufQpAl3QaIypGAe3SJrlv5leLP7J9Dl+yVu4i9Ed4noXhbIpytyrwhrKPEWCT8t3SVN90qyvN5sdSgNrBGAqzouc6n7QsBc+1iHA5BuXdQ5o6lb4GHQXPPmjrjDUcaEw1hlDueA07HmDRjsoymnY5HTWcaCwZllTsdih2PNFTj8yppBFPIKs6aGcQVZc4JRU8M8oUizadzZvZPpgTAwf8RT9nVbhdelNLSH3SCHyunIbOsHOcJpOjz/+qfaYjelQUXTD7T6gaqX3bVbp6/e4sEGy4urv/ywJ0Oc/kBJTi3Oy00jKRkFw6NL232z45BPFvekC3TZqpTrmYpEHrgoJflC/+kOZcsEalqz+r33r12tbSOz4P57BdPKzZHLEMw1KUfQfK8dBLEMhiM98Q5z8Z4OqhK+UhrBMgz0PK0MrSQp97Tbc3AKMpOiI1VG0yGGpS2LQr1KsRJn/zCYP6LvVELkFrEyIzs7K0kptkJkUZWe/3krbf9Bef/67IxTuFNZp5bwZKf3b2yPqdVq4AdhP7Nqn3pf7MOw38FbVfh81/XhYkOSU+2CmMevu6DKOdoKh9qZbZhwtynI+bJjaPOtIxUAlWDGi7Ra0ZbEU5FGK9pg3lSZVHG4e1+DcxXDxcgAl/UovYl8fhWt2eYjcuR+PFkfGwAe/aKe+BOhNOvkYeVOgAwTOroq+IJkTveK8BX90qOmt7qzR0xL9Se4uOWS8JIO+h/OK1f+WnUKr+KSs0q/bNMQcHmb5gXMzBVcqAai56GmqgXX7mssqDJl7LbftP/wPtKhOIehfrHFPvvxJxynXm3bWTN+1XYH2mWWyYUnpHvD7pi4ItC9p3t34H/XhoD5FTMgnPhu5QDF/0cmMKv639o+8hbEdN1U/8vAs7Pdj+Gf+N2uw58OnDrrOHvSeXJ+D5yCDJjeM/kLZh7BD75SK/w9k+C36qUtTOTbK1d2g5v8VoM0ED3KO2oyHHyODOyb0w40njfwH4fUbYw2cFFIaWOjArdeA0pHWrVKT0RPPjjnD/iSGwk9U3pCjWXBQRzu4IKKUii0lLsrHVqdvuuVMxruGdWeDSyQjVCe4HB46XylSOhddizVzOUB+QoROtP9bevAt63u3xx7PyxqHNoAwJwkZ9Dr4MFl1JeoX8JX7fWpV7j1LSp8e5PEDbwfPFhXJR4+A7fdAJ1IIRg3HA5S1oYYfLWAEoT4DNmiJjRC+841NzKztW8qKiV3+Oi8emHlq2WOpa1TxUXWSMEqlaEPsdHmYIyFeQJd/WW4RsQRCJgsgV4uZ+iZ81GWwWqxWJ/F1gNAfl9071Udzyt+paqOTK6rOqQEZ0JMNuFyJn9TuD0bZUoFWJPp5C9Fd16VdhXMVyjRKAWzT89g6ZcAnxlLePiQ4PZs4BfI+UxuQb6WybfvybfvCW1+AfdAucASHM09bjfWh1W/Xu7aU91efYt92dZIlPzVZ7Hy2atXn/tsCHYMON7ebuu0KxGSN9oF1nuEl3d6CgQlnB2vNnZPAWD7OmdswuHvwSG2qXzSsSwzzz1gvgpCRZjD3PqZjYzJkATcNsm/6wNU0txxwFdIGN9T37Aymk1OBKdULHggjFV6qaR8+66uHt6yN4/4wiHoisUsw529NNXPv9g9k/4t78avGUePdk+lf5eW1k0XAqFnP9xBt0edkfzTjjCG+50A+AFZRK89SI/8bNJiPwsW/WrA1/O7ScWF/Yt0i76u+N/+a/tHnlqf0gX9x4KOGAYMEx8J32ACqq/vwIF9+/uHh8/WXqYikNTLtXXWOk6QyvAxmQyvq+OcbsP0DY2cXlMv9UlZqXAIieBnb/H+u5s7cKDrTsG7h985POH6wbYmFdNv+8E14UFgAczd8vgJ7AYH918b2dtpfeu/IQD0zomUsYbs3DELl8+g2PXsqeVPLDvCpOk1M2vIlOcgmLjX691xwMejCKBSabWBSkozZ1j3AfNI1hjzPKaozGY98x/bHW22kgzg7TvBOxMfW+sDXllmaQDIQmDST4rAY7eqazXnSjNBJaloX1LtO69e3ZvYO3R+6MOvquD1BnSm8IfWDIWAvdcNlRlfsL5QZRRZRSXG763fy/hS69J4o7Ux/r71/XjMGssC0iBWdkooIcWqPdY9VedUwdbJjU8DXw1gBuIDb0RyJtEGgt3ZBib+UszSSzwIis1YSF+xwKMtBR0lAvoYBQoDKyXrJQfXsiRaQoHBHgK+si1PmPe3/WN39NT+mCXzi0zo+AhiGT+6P2YcTvGgi0lr1FEJ7VsStl/EmTa0eHGWJ1us41ksWgcMjd55fGcVWwxDMwr3LR1d/UxqAeArS4ufe/OfvT/z45Lin+64o4du07Aus1g+ySXlH05xr59Ja6sDAu07E7afwZlGtHhxlmfqrOOaLIAGNPrA8R1TbDEMzRjct3R09TM5FEBd6YI/hv9tf+CO7rxNC6WZOSU/LRmc4v/jTFq7HRlgHkjYtFRMJVq8OMuLpNZxDRVAAxp9/Pj2K7YYhuYw3Ld0dPUz2QQAo9ZOieVjWr18dEqi1U5KnKXX+ulJcSlW8mJanQKxMR0fdbUaA9WKJ1qoNFtmbaJSbU1g0ajwZ44N3/S79PDXyYA49/jC7BP7Ly9L+v7Jf5qkT7/4QzK3oHZOc+reJy+8vcOAwwwsm0vZhXUmhsHLn3r+k56BTnT2K8I3SRX2I50IBY8NBTPLHf8wQosUB6ET2fLtT7tCztND62Xb+G/iVtiHiR/GNxM6fpSab7UfSPr0i5eLfwHdt7yw/5KHlXvs8qGvC4d/Psg7yIvPChd4039OmS4wEPwvxF9F5Lm/KACmX5Uccnkr5iS28GEPPKtr3JiGRIfN0Z1tTNsISu/IBxv2b0iLEYRUJW2SektA7+T4nt7RTQGBvmRP2aUGWvFcSzronM0fr7mdgSaLkfo4qb19//GUt1chNdrOFeRE07m/xG+rZnSnuffDveC2U9sCiDOiynHPfbRSW/Op0zkQ3/0QZCZnQrcwYFIH9CzEXNsmTZBMGbJWc+kSd/CSEAK96HECOyf5lA1wsXyoRRWZiLLHjG/FHPPzlK3stvXjmiChBJDIrETJu7VU6jpgdgw42WOGEjEvjxyTKKe82wnFqSioxDgRmOUoeaergst+DBgoD9hEQlrLAUFTp1RbOmkuMHkWmwvz3c4phg/MlOvvBWx51xr7pJ/nRGbHRE527fmJkHbi+77gcUzrmfuoXAGCyv9A/9RUbX/2q1wMPzVMo16auS/TOOTOPzePkS7eYjSc7zAddR+lZ8KWzFM8lsXIHVF+m1S0pKg3jGV2RFjF1Mi8Ii0eTOVBrF6MlrfRogcODlUqwojGCkzmPk6SS1FBkuhyq3hcGi4XJ1KSZ2QYJ0JWhsQZxDY5XPiMzlMOegqeUw+fE4lw+IXuQlGc6LATB0U9yAgXfQt2+yBRpDk/BWnOj+xOBbrCHRV32OMBUgYUlej2JOOQIJt8duD4926c4+FD+7C7XX6wf2B5Dde8p0BCMYwqe85a8AK/85xi+lDGsn4PsOVdi/ZJP48AdxAou/bJiphGPnIDqPXMhNw0rlyLjALfP8Wq7c9aiynGsaEbNgAsDr+b/XN8LOmiNZpSHDu0vAEgKUGl9u9Ttpe31Hwjd7StyKIXHFadhlbmVabgUD/mweqVo5lXQkX7OlaFhKw6sbEYUg5B2KRMyirZGK7hWK1oBGoV6hKneICwsalVvw+cUd7S2MGuuMSyZ78t1FosThRyQXrWuDUFsmvmcGjMmAyPsnnLVJly2ILGhcEKMOsUj922nCFPJBUMa6BjSucqaZwcDxd8TwNDBj3p9Bi/bfpV2CnTWxOIXl32YwEgC2/zOIZLgJw40rWG6MMujzQEf8jKg8YXcLnYqPwhKw/KL+CG4rsMxMOxnsEQ9WYYW8zCh0vvFl+stMy/a9mcmbHeu5Z5L1j6TCej9go3Uf1Nx0fH2QpVNtgWdnEX1t4wcB2x9QA/Pr8A5KOAyjYbXEvbOk/Ls3KmbvOXSNOerxAMbeaopI18wg4odAeB36iSNqE5DcGG+lBDQ6i+ITgLbgWDQ9bfPFpprW5Idc5/9NyCoWRarhNVBl1wCgJGI2gLSNxVezp0YF2tQilGrAfn/lKY/+o0d7qwhJiog/+rL5kpaXbX+KIOXovpwy+ClNKTlSWzPKt6uowmbGJi/trkDXlrv/qt2VXj73TyAybsnabzx/vTsaUnwIUHsD/TpP8mf12L5RP7UTcwFbUVHBlInVVRdz67ckHWxkVjr1URV+EUVEVtAdBOstcuQ6g4cRVQkdeF03bhqoF3mmIt4ljDGo5KiuETtkOh2wl8jErqSbszvfSWplj96uea5F1Ovi8/58uCvJkeWs/NIuwMoupj1DKSTW/1P6v55GFGTp6wmlGibCiuzP6sIbPgd9hhiu17he6aFbDwn4yvEBe1KxdxQ47J6NvTcxUcENe+ogyhbe+CnzFzx5GCQH7244K8mRij514RrhdRfe0h2hf5BkUCj2o+eViWk0eqZpQyGkqzs9cXFNyHMdLZT14QvLP1dDyl2cThxXV2qb1qSa5RsNcE5Bz/xiV2xaIdZT9WlD0u23zFj+XobTQyiUYjkcsRvwW+WSH/ppb4W5/8+wMPCs7IPJzjwdi8nuc2ubfHfTb1BBd8zPTe9JJrQYBqIUWD62wje8YIuK5bPr4sUE5HtbMH2h+81zkod3I8Iysfb2cw6tGqujJGGSsti8IzOlAbggN0GfVjJSlhTqduaFOdCKxs0PP5jAJ4kxNlBovupmjtcYi27+d6AIpnGZgTcQBWw4H/VcOjpys84uou2xbcMKs1k+5mKO4Z1rGR4x7VAG0cGou6R1QCI+mxgtnWoodZHeNFRmhnSAMjuyqfUUorE19JhrnDDoGeVSkazDAqtzmphi0Yj8RNY7bnl7HLdyPAwUKYjdmYbdh5JUP8Y3HULdkuoxS27/ES54GLX2DXLi1/73YVbfFwz1jp+/DZPnbWL0UNK5+eFyBWAmXkI24Dk1gkkJW9GBdzMRdzMdflYq7DFRyUKatBpdU7vawQ5NIPL2uGkvAgXd7fLcu7E02Zge4+uzyqZOIygDmefJj4uDTjCcPbMr6wTjI+kMwLkl7U/+aI4VKsquoyU30UaRWy9b9k9orfT7ImApgEMi+Xj/mYHwtcG9eobSjeNAVZp6DRZdwbD2MX56/yRUuTjTGyvzHfFEeNkAy3WiyQgcYVLbhitSKQmIIrVisEosm5JGg4IPsoWfZ0ieN1AKu8HhzdX0fxF9SYiLMVxhxHGBvFF/a4R6RDEzrunuURZz0u1zEk+SJfzLBcUxfoCe27wW48Cii0mWG2YkUPYwKwnN19kl0XLT2XBvbX19vTjRIal/NZj/jS4nRIlhczf6miIO3jS8rHNVnXzvlMB0Mi0a+2+4vf0ZM/Vh71KEOf+79Kl7KBwOWE/XLKjBUdrMzifkRsJ+J+U4h8s2BGng1ac6OS5is1eyKfWoh0MsFXQucR3oXURVhnwN1va881SRYkG8nR66kzINwus2a+N2OyUpnFE4jYIcQFQS6xJy8kJUvez9BMZyDKTWOt+ccSL5ThilyBXE4YukQurhR9gS1rpd1nYWGKuhcq4ufDQiJ0Dc1KFg1PucfKxBtTKjPyDxE9Yqwa2A267bOSwwH2Cu8Q/Fac7acILCI3ZPFNLWRe21DdNmV+m2VwvshNgBG7pQxtt3tJ+sah80kBhBe3ChKIhE7WrGTNXO+n4coiHneEGhSIk0WIqSVRvYuFlr9VxSIGoy/StqT/+QYVbkCeuoH+eSZ/Gumd5sOZ5coPDrCqZKjpgCsJqGZ0w0T4+Kr6OegInUq4Sf0fwlRVDVZSn1pVF4CL0DEk+p+w/zQq6QoIeb3SDQgS+iepvGTJNZ7rvFDJ53uXcfB2sW/pCip4IbIT8umKTibd4zzT8wUsQrwC8RmdAsK0QP7IyIqH+nij8z7RUUk/mhCUYLnCBvq3Gty5cIPL1C+Cmp5IlLYbfoEmXdE9cgcuJyxOmYVCgzSLJ4G4iotIxTPyYahV8NQgq1zEjYw8a21RowKJ/jHdVt/k9xXdIzL4V/OSZjhlpggNVmbxULjOQb5BYMkrflipe8CVcgsXGW2KL21i0DAvQW35kuI+EntuOskp3FAEVfdFr/2qwdflJpB5ucpRD7dt3zqjuPnJJ2MvkVdqZfCVxGSG+ebumdOvHFLphkloKL3iehhb7bBDk9XtidTdVJ/adPeKZOnqrmGo9fcCJBCsk5cGpfr4CW5Rm6+8SWBi5rUmo56lkyCLw1Jw2+Mtg6+L76AHouRkWNsMV6l1aH0waVQD8XYHAuczF+HaXnowRv9TWfInwHp03y7ctnkmv8tV9J2MqYyb16rBcm9zO/NQcxCefMNx+uWzRg+uKdrHEK4ofxpK1Mx14tcS4VyuQHzrFXIy03970n8ryhi+URvnapO66dr4t/am2YWccAPAhQUBUjd5r4BpxoHVoV28jSNe8CNFz10DbsEn+2wJi9pb42J0d/O9dSJQWCEVRJV4Qkm3osHXT10mNxd18vXNwAio6OwZR6F3jpU7x/HIE884CXROQZtmEMUMhD19mHmw74pRxhhngkmmSsU0D8eZ/HB0idnlUY953BOe9JSnNfNzUPGx4j0AZW9tj3gS135QWOJSZtb3AHR8vIRac+0gr2++eoLA8YkSN+tCSqJ1Dk0mibdtW39ePUPi8mTZI9kFZcN4G/9jfLpE2o+HMt1UKCgoKCgoKFy9v54CFd9ofAQXh1rnCSNVDudTBelinktiQFM0ChKfPQIw9aH1LIu8O5K2WojKRINPQ61rhC5exczd1oXAzOUM3MZ7p5MbLqp9TB3lOpoVELzpbBchVJnpiRHSCZ4N37+K3sM3PwE5IjKGKPjwCx+sNXbzIukhuxOVitIxttJTA4uxsgb1SGQ8yMbyATY8vk3s6i1VKqFqvCQMb3ki1nZXFSNMa4zn1pHW4+FL3ziKh2m4sFqie3xhElx6+HD9teKTu230PrI2yKiua/RmsRmS6HbYwCJgsLsMIz2CLqBL6Ap6/X30hhzxbESS4D7ImVCbIll+2POV5ieNCMvfnccW/3306LdXfu63JD/+auobJcnl7nyseQE1GX9U/CuxbE/f2UHJ5ifVH9fGN6i7dz7JlJzDV66tJVHv1vEA23/e7xv89czKH3wDTQKQFGCAxA9WJNcePjfZ9+hcHrv7cfXu0n6GXEDwWH8p1/iDlkJC/jdR8WyM80skesdDe+x6aFqtf0Xb27aJ3c0RGOoWZi6o7R2bHmm7SodYwHq8crx5fvjM3W0A0xzi94GOvEuzDoYl6Vn16qTlsrb7qLN4PgbNMYnaVYzSxhMSUbXv6J4dC1OWl5zGwuhupO5QoEPaVZ009tHVXJOMNt5VuabH9gF209Tg3+qqTJynrCUvJxOO5CMKuJtKKY+o3CoHQmxXyAXxa94hZh3OL2FK0NO4UnLC0kAzH2AismSu2fKsfRQD7qbHLEJL92eZgKF+iplP9FZ94KKbabeYOm1ImkjpXbYwE80I0QkMc5onlJacSaAzQyC1IkUDiPNNL+fOKIEXQoR9pwSnPwRh6OxGsqEaPX10phG4YxIIu7ZXFj3h90D3gNMqtIAcgUFzzNzb4J0wyk666USYk6AELl5b6a4fc0k4QFvvL4RpNckcx5Pey71iXQIjHkXB+75Yc5j1LGBKGVskwXuak32+bWPixhjusbhCLiA9Vi8BzS20FBLQJXFXnHXQ2z8C5EO7qfX/2sBVpJsjCNVBLmg2Ia3EY2Hn2NgcNCxzPQG0DDqP2gHWvuKuA0l6w+v41F70o7iUEoYL0Nwj0ObvJCMwSk4EwOmUNXb0iAxyiUYKvwYOfajkpFU+Gtau98bJ8ax83PerIa/36SDvdhvR9lo+NYeWOEB73E/+zO60JBwaeGRdczcwZU8kenLQc6TLyOcozjqQmHzc38stmUsLeSahooFsSH3kmTxVjTHgLgXaQ3V/W9BPsky4gxpD84lUVzWavEYTbZ1WzyUXAUVpFoNgHcw5/KH5WnlnEuhuIZBakaIw7pw0oKRHr2j/LNCd/u3Sh1gNBSIosG6/Rh+zcDclk0B3fv96f9YfPo+IF3h1r1qQxBjNO2YhF4r6izZ7M3S3FAIhc6nWB2tDvWSX9LESJRNowrYcJd9jcROCWL0Yur/LApeICsRd1dZBL8iHli3R/yxc0ZuO4m4W++g+UXbyOLvXjVx24BTQX9t1YxURh13jhvQySggaq/Cu0KsoJSsrm3NeOfFaUjC1nlbVDPgc/F3PcER8H61mmf0osy4ltgSZhbFY7kYwuGr5ij1sCExx71XPtOTu23XvfjnKTuuO7gavodzBzFySK/z1uxSQfDdDvbt1F5tWUIew3H3VVYe7m1whkUJR1uACnbgTZE65mu/BEldNZjh49dR1cu6nyV/G5rPEvd2Vd2AbrS/ecJhFv7/KwPW7u24d9Mrp1FVRrqYdrtdGkZ5+QaqTXhv0VPHQnzf7/6EKVvp2/HfOMqb3tI+zANpUs1QC6P5TizKctxQ0GfynZw1H9bJwbn8K77pbmRzLv6GXnScLvec2ArKX2W9xUvmT5H2G5+2/oK+Of+fPGv4jf1m7ToutY+jJvyEb9MbRb5Fe/rjJkJiXWzz9XmEAL/N7JZkj2Eh5L4fNGZc6gb73IOXF9rKd5Yg2qXC2FHERlEry/5MvyvC+nYK+5fyXv2N4NP9YeG5XtVgcyz3R29B8CQ4E2NpHgK56jWtfDtBb7mpLC/7oatTBD13NWbsuch3x3v31vLuouOdHyDRcumKMdyWhXicrpkrwKkP+85nv7OTTZd2OCZXucB3PMeiz7Zc4uFD/p6y0TA7uabYUlyV+3N4ABbqjJ63GsuJmv8e/NKT7rkNPiptcwUdq1e0Aud6pDyzkacnqlCG9TLvrNbfyvb110c2scKHX13G810563YP4SPu8W+c9wJBttdwz7DdH73iAEw7VST+gprC0FxleKqjmkJPOvwNb+mIq/bIzQUjDmndP/03A5QAowXpEaonElUHxBHgZDoNNs95d/v1IXl8gFgLRdQlwYnJR5CHrLMH87z5RWRA2KCjTAc9+f/kJfv/m1zFiKUZ0JvprHr4leBiUtiYGfIMDMKzKeirSa/aLi8QKm2R/gwD3WA1TxGFeJx3ML59IyImF3DNJClZWmNpbrXy2TJMQF1mjlgxXrDJLZYorR9NBQ0WRA/Xy+jIKfAFbmWD8tnnpIXyDHbCFKTZUt/ArzLiGTJzA+hjgkjeTiyUtwidPmGjDPCQFuHcgLxFNcj/2ONm0rinY07X5neUHnQdzuAgRTkVRO0Uh6AKlyf2+S2dd0aJ5O/vdP9F9p6WwwcC+FYkhSjhwKMxZXpOI0FVlbeZ7ouO3GieWUvCGgb3XvG32xNqDsA+CkP0lW2P2IAqU7dVVKIimgdSHIFiULM8cL1+ELftZkIUZJdPRGbir80lw1suIGsvn9MN1mNaJh/kmiUoCBGim/cXsB8t0Rwq5sPoX54EtTbnBEZ7R196JmDRDuNKItF7KIf3ippFisJYmLOJpiIPTxedCUzTbTzKDaNQCfopv6cGlszUSj9HCxXVSPpUOE6hQ+zWUrOVms2GhLB4SOvU4EvzjqjHaQyvrxUKZ5MOxyLNUVeqDRvoIkh/rZZUteiHBjd4LZT8zn2V2GEEfCPMALWzp6ClmCApSIiGdmgVow/pgfevV6d9M+Gqi1nh2KiZ2Lbt5gMRa9an6hc7+8FAJdG1NTDjxWnF1xEqT5gJLr0zxzMxGSYdhVM9gnh4LpErH7c7w5PfnWYF6gIQuRGzVL+6ReDYaMR2Pfk+csX8c/YoD97ogFGlvyGmcoGMjhkdqwenyMxCWvK3nYpOYzgSPvNtUKSe6CglB2s0tjBgcE5orXeBlf/RijsBMF0g//PYKNnUuxDxssY0WBFyY64ARvp8dyCGJgVZkO4xPiOaUpJMvPWnETWd13s8to2OXrzOV/YlZedyE/z3+VfwrH7YKyy8SdxrvIKnF1LGq0WBlv4DQynmJvJEFQaRH3ylh3m4OE5My9UQU+VgtDuAmaBovAmJEwO4xDUGt5yIc2HbwOKmgF7esyL9488GmV2+C0BibIX7IWKHR43OJVTPq1cNpaMtbZWgiIzijQP4//Fi/BO7pog28/RQo47nuov/oT4uuBJVG7W17b7zkg8Oz37vU5VVQoQddzA3IQv1zJQ/GDhYlyPa7zqQdKKx+c7OTGKP3DuD6/QXxc6KPCBPfcs8WJCzcNutAW2pUwhp4zrssNuAEg7J4eAsVLdnSl/Ew9wRnm14CN7R9ETt+jtyRZJs0nB1RzAs++hAp/UD1D61NPW6VlF0oZ3ueZ3SAwKOKgrpSgm27SSB5S1qQtvHdi4e3UAhqzg9HoS/mPO34VAsIRtMSV9oRDhykZa5FZ6mEEurgkbKt3TJ6+tbIimrX97/NpRiAVvXuZBuYfwDMOenn0qUCxBUKqterJFcNyA66UBmejMV64ZhqZL89TMBlpmsCSVceHUK/vodTb6w9Ke4Otfptf7v/yT/UnXYqfkV2demT6YLYgUKJssnBXvyuDvTnG+QuUfbvZWZJECxvzDCGk/g1XaAAkrJzahmwJCV38yNQnAbN3+8+AC2ju3zU3bm9/N46NyWhXGS7vBRItmqxukCxFVxLblcEBxMcIyCVtbJh/1l2o98lTiSMPE1ljPH0DFwnV+xSX1dki0UqWigYiaGAJbFJShEP/yPdTy9hGJUIp6QMrf19aVDDX1tuvvlpJWDIbEY+n4Lr0ZUjzjKhXKgcXw71B0haq75hLuflmZsaYDrlGwrpyfQvx6KqaGvV5IvLLRNDRcAufePGZHqY7DmYF2siDnflwAuM1jmXkvJLETe0Le8eZsyS0Kct9Em8o0fejpDf+5uANWtjhVXfPi3yRw3TEEA4k5V6Q+VEVrdzN9fwa2TRXUo1D8gXIuQHu278k3Y9xAjYpR/VaVtPtOE31Fjsbfny+/Ax9m1jVBqHgWCwzdmOD/W8b43ExDAuFOfT6iuoDGEl4p0rYR64aDUsZUCcCshDnQ867Ys5V1U6CQsn3AshocmqKICrN7QFJ4MDzWHKL+A0Sj7KEDhwT/s8vgBD0ew91jQD2ujggHPKHBAouBLI3QQnzHDKL6L/bOB5rgitjNuwjTjYeJvdp1OK0V02gpVpF+gP1MjkIR9e2ezDOE+LGhRukDmTFA40AkBdcT8VhVcAB9WSd7t2pIZ/lFO/Oo4Y5GedGfseoxLFzbc8Fk+3uNzb8uFQ9LInwqjph9MQmbhsqJbz/qsyMyy7tVekvVu8N3tNURaKBCSO/vWf8UTiUViw11b/fuqFpf9OJnP1E0QqsqnO9CIrJ/G4bKWMJAU4O8eogi3k0bFA5qFuAkbBnLPC915SOkxqgC0Rv0RLR0stGuI75YNMRm26hDFtoBRfV9x/4SexWfebyTIx3GTE0RF1SbzXN5Hc57Z80Odd0cWRL7a9phsjioUlAruO2tGC8ffZsNQs/R4VxmoDXZecjnWFvRgiYd+m6zpWy6IGp/li79qm0idz+n+vQyaQ6AJuiMvtMJeH14KhRnOJgdSfdObKHSanpZXgVXnPkK/ZqwodYt/RMTMqK6W2/qT+bRWaSBnkLCH8kG52R4LRdCelsq+DRUo1Fzlih9WA8Eo/mcCVHSR9jwd3kWKye9CqChC3pLLrNkfG4wzp3UoQMJiihTHCWUaVTlA48obkL16wEJjbyakOY80kOraO0TD3WXUjY9O9FUtkqOqWljC0YY+D9HtaTvc5J/wOCsSZellqiko/3DCmn+WuQ9GHD5hbqZm+T2DGrJeVXoVhSlW8nNjy3e4GJIa4b4c7rdguGomeJeDdOixSeGfvJNtH3BZUmFfrO6WUvEMwirFC+GHqy2PocYQbBZxLmt0SG7PdS6THlOBiU9FRRowmX0lrpMcv59s6Dd3fCxg00aQ6SlRsy2nMMp5ZFjvqbxfPFcH78PYf9AL0dH/alCmuroFvSSEypajM0FqREPPABNkEwDk1lVDGopfFI/xdPt2lMscal8xazIUGvdcTZfqBLm4f4f9Rs6IMgU5LqnC3BYUrFaxkoC6K/yKo7bA8Ek6k2al9old6rdsWhvACk9tgrhNA4+tQ0TFdsldNnJ/GqQC0I4ZnNaqQyc9tmUQv3U4DSS8nZdc126YR+1y5iFGDwFGwZHIhMZrVtqmM6qMZphpDse3F/P06dK1KRemvkatFLwAXNM2hr9OH+UtOxACYMImEgul759G93qEAGkRwAwHpYB+Y+cpx9yd0MRQR4dEELp+j6ARULBnP5qTfznvLDKuqAWCUSP5Is2QeNZ5bli83IrjufhhVrnitJwfO7VRK0S0Z2Lar+ZTb3bVzM0fQZ8k7ftuqi5SoSsRt4+77Ep8rysnRWa4WI15TbBRWTq/gGmz45h6GNAxtCKLAGnQY0kB9s5sqyPXVJXWRSUAudrj/kE6UQIKITaQSItKze062O5gMpKca0tHQjy57vzt3Y6jyn6UOZlAh1bsFcMQS1giWtlF4M+SQjr8GgTHnqjyXmEXzHvSx8YRyoH5fl8BgsO64gTj7BYRRAFukFCCB5c69Pdq7o/GK2XSHuq7blC6Ek2xrWX6L2bI4hvX0gc5SUb2ja0p+nxFHVSRPycINxFLPHWzswMHzP8VfZv1pPAP2yN0tFXuX7qj278eCbsqw2GXru50FjXJB1ftYb7RO9DTheFmx9il9wYWiphwKgjDq7NANsKTnVSNfB6bUG83eTJ/GgactFADq6dDTyAnhJft006e6jrZC52uI1UMaU7QdZnvxnhQAJFBAyTCYMV7VK52xtPnd2wNmdt+P1K5FPdfaIwjFymXoaInZpHuKyRbTB16LKxSziSkwgbMBG3S5W2o2RiITkJDluCCSmHa0H4ihsCfsc5AtCHS6OONExhKMiQAYv5jlqCVwdbkHx3wQIPt57nsL1KplmT1MH1qPVsDSIww24yZsNLZJIsdzPB3AYW57VlRHkBibWh5J7qpRidLdu3LJmnUiftSDlTXvPS42/2l98mz7y/SUEbr6Akx4pG8kVOJjgKQ1X6esKeWRuGz30rU/9GUDkSWGWHJjrJ2eJ3mrjKPAo2TbR9sSbjqLh9i0c6+HV4PN9mBP1LsvzC61M0S76y8pVpRV6GUBwOuaLuGw1DDSn4KZHHaMKRjfRql2SiMPsGfMOWBC/R9h5ttIJR3ERKV2KQ9gj3Evk6KuW77cDjoDa8kZwjdMV7BhSZahkU5EYugEu+FE7GVwHh6GllBdsWooTpJybrxSRqHvCW4VFH57xaUgImWmp0+TceHXZT9n+gXuDxOx0O9FXA+Y+dongZHgcnwgCYnML2RAhEGpKlku6qmKr96kaEuqjpZKSjCipFKUAAX5pW2ZnCBxftxgZsAHy0Xjmv8yOy/IfKjDprhYa/TAGcedrWayiblxUBAKEoBnF8ZhacgWYUxoCY7PAqWzJE5P0+WYqU+x4mMQ6ToiVJwWLTxaMTDNDR2/t4UCQgZz0ORdJUIXLRW72iI7rMyrk5EZjLjwNB9VYKxruE5MeTy6QXyu0CRBwTXApl4VEHxHtZfXS3cVqAzimlfNA6h1y9qjBo7O4WSouC5Qr2GlCH2roXaMZHJeyjmrBuBZtSbFImpwfil+0VUNddkQwZNVaGkGKVov0JPzzOP60t5SQmJhWTK+i81NdxaRUfIGUXzUMgPfJtMfWmi+Zaw1Mrcjs5yZErjcOj04bb866Ih3P7rvsX3U1nR7JkYwllvAjWF3SaFdUTb/2Cc0mVKhzGeLIBH2LmCcKGI+1N/DmHHHNVYtox0YOVUK1jV5CCPzA97KThFKKFHZTHVSe3QskkAOX2DnOq9RIVs/XL1CSpnZ72gCM//LUt03uBZ6X22N8k7dWybGxW9K9vBjU2PPETUWpR6BbY3ZDCbbAJZqZydnz8lRucaz/RdTuSSUGylQRtAW8wiskFCW3kPGWKTIXrxGBMkSI0aRXjDSojCstppsIWMmdPKiEt6jZgriM9EuMuJSllkW/O+dv5dNq4m3bwdB8dB6RU4E0ROoJWq/mwdKyYvO/GX7Kw2oGlQVLiQCzOzsqfunsZB9lkKA+ZMvVPlUEXTLDJJu8IFa2+chzMIID8qPVsHao7AIiXfevb6y5swb0ExRvbDZguTlzon6+M7R0glm+wFCyfY1x5BhSeo4OTgVJ8J3XFy39ADPoWRfnIbzZN1GxV6JKpI+7X1Byeq6XwsTXlemJbpNxSondKN1gW3PMvV0nAGRFgk8Hp3zoDaU6TbUwP2vSzF5+8kkEvuZH+70uNhd0IoBrct6SNX56R6sBswPJCJmYFzyk3Xt4XLvHGVMaADJqSwx+Q7g7T1I+PoszzIyPiM6zFJLV27doA7pJFVoFk0RVxz1FW1Xw3v0KnWmZxhWT1n72uAVIGrNgF8Kj+QA9ibJM4xeRzl8FCtJBWCk70aIbfQ7siR4IQhpWmwGCiJYFIFIJhVwAHZuABSSmVp3PpHduUqdiZT3jhgRk5cBUtAnadxF8zFQZi1PsPfKhkB85TdFpvLTRsKpB5FT2YSdokJEdCnQvMIWnEWTobwrbZMrtuW9kEU8Itu22+duhI24ldZmR7WlWT2dynVXlcBwkw8sTdMM63oroUcb5XWkGpLGf2bYlcyW97uszdvAW1XMdGt2Z8FWSot7wUNhJnkmYYiVGxGaj6Kgs1WP9Yf0PSSBPxag35Ag/TENNXZNhDZQkpnwSoSUff021MHSuIcJ2H9oEzr3BasSOBRmrCyJ9imqA1+TgsCHlH15pAc13Db9ULxeytvFNSMIqmi3d5wbmf4EUQKktvIPeiCF/vbFlcBX2B90X39SHm6TYXKje12lIVbJ5UTc1COYSQV61+4A080QirW4pw9cegbA/BQPqa0aoD/4GyK39A51G1zDNuWAxRI3uFZgq8UqXhnt0MzgkPCVOOGVudEwCEI+IjXTjPU2S73EJAPfqnOhvq0HKzYaY/+pVPwk+CDBMGubasF4Nei+PBUaDNbKl/DgGAmG+SdkVb/wW7N1hsAsgDIBybkixMxfF4pUKfBaluWZzu1xqwmWLTG0umHwVj0dHgh2lHcE2pgUbTxQmGjtdUGSmqGRJj4eUzgIg/Wdd5GAD+QMWnWtSG3wUJgpmobto/cOT5tphxQuFA6D7uvDwx+welhVsFKmNYbB2iB6CS1cSASYcRmnZ5bc3jpGPli4qoxIeRvWgqgW6BrtHGT0OgJp1yTGyjRy/IB2z+90toO+je8ERNMfukdew5O+xGi/CW0FUlp9RKjD6uly0YYVCtY1Wi1JLqU365pai3PDvSMAgvWgaR6aCyiQLSjliFavbHjbbGKdtQ4PrMNKubRH1GGCuhaXbaMpnIiqAnYYFHmQLU99eTZI3iOVC0EbnYXVK3zjPAvjVwOBO3U/JIrofjO5LrPQ1aZV/DaWfWdKM/wpbL9tlx7sPfVtWEte7IAs+GQuTTbmo9pgiqSQmjWp4vTApLP1D4BZWFHZ4nrluMcLlq9SUCZQHwjzYEKyGFbuTLnb66KIypEEHqZy20ZpgyWBCSA/d6guNiTFXtSLJiobOApm2sGxiZKJyItMw+yHYd1ZeOg5i7JhE3Jh32ywcKFVdI4iqu50fBZGtJZsx5TJXtxdlo3mlNiGFKrjSvFVddp4oqMFDYOZRpwObDjcubrnd8BWY08yFL1gUUEYTpdTrCNBHuae4q2fNpqR+c1R0xBcAOyaNlr/lNXUBaYwjWJoqzDno2M+yUZc0eDTNxZgm+2wAvBrmE+zBaPGDroUQ7c/Vl7U1zW98yKY2ZTSPE8P5CFfB3HE9icKGXtdy7lPtWADbak8hunNw5Va7kQVun303MluCwhlwC16mA8EoM+x96gGzuTvE/I0iQTbtFmKoHMRu7tl9JEAiJnY57K+AzNxB58QzSm5pVLnO76jrVQm0BkW60s4EyhdrDOgD5EHIe+WZwl4sh1tLNXcZG0+WixzRZuVCE9eABKGXYAwacLL/bkdXaJoZ826/TFxpXC8omOIHyjFGW7KYvGA3h5YaTnDrRf5eDnxLuRCAn19xDtF686zOI2Me/uy8p18gegDnfmUxqy4Q4uW6DA7zTucE8sxdYjRrCsN26TAvNhApmLNryjCoqr5Iq+8l+jnhSVA7W0dNtckWifTLnlWdBGOyMi2HcShiwBZWJ9NwCgJWvRcs3xBNl72tFEtWEs1wyFpX6ceSxs7IfpYO/Abt72F6KR13QPfmQM7Z7liboqa9lGi+iAEDJX5eePl3SZNbPnyaM7tWcukTuttx56uy/nnnYkx6qR1NUxhBZPGbJnv+4ktmEz2ooAP0MpH4Ch4HLic31XcczfVQ3YucAvz2DQhC11BmOdzDHy+2HqbFs6urTNKT+bdxbQyt/+2GhxZHF9kMZ7b461a4rlFnLXQmgL8TKPsvgLSw5POn2tXmNz8n+1JH+KxznutLLJkb9TZFxxZcnFfCCqQZJbIV+poqjc9BVWlDku+zMUctHsjDt7Px7HvGqOKPI3JO7xf1hjNOVAoxT3bvvFumvHfdKZII/tQMmq2GXNmy15huMFGS0rNFgQ0EZNwk1HyiXuXtETFU8VTLhSnkgGG7enOYOdEv4+Zrt05XLm0TJUc+kXNbjb3zu7+xXx1tufurGUaw3kNNEbXGFR2Sq9gQ3Q1HK80Mph9M/LJnJuNY14zdjvFCMPKusQ07i3aZj/j8P3wdfyig82+3cvvXUOdONPn5gdPney6MhaWQ/SnJY6QR067vzzuj1FZEnjE90CNcwyBPleeI/Mi1hPwuU/WvPtokjDby17xio9ZG68DDUo2ZXkySFvrB+7vh8FIZZGWv6/T19BVpsiCQ3gwLExM8kx0GqOf+3GB6D/+D0CCfa5cjkwb0xNwntsxuhZbBsdv1bMTWx/T1JHmdAS6dk8XuC06O7vlnEcHxZf4dmWP2IILqgk8I9NfbJBdrWIi7JiDhtlzXdFlJQFSXNmVUK/8xKxrPwdPh70sirk1xLJyOTI9VKqB1EXNUNX5bCVPDlimW9NgE/nmLGT0lGGG97+HE5UttzIRw9Ymlk2+chORmvSrQA0nfAIisXuAuiZGXGzKKZy4QDmwbqKge67sJ0oD6jcpvvHMU+M5vg/HrqrQnN8Srk7SnbcZsZK7PtILrymJZBWxN3+FE/UJag23WD8Mxxf/ld+dxjO5y55NelfCDfu6ufXcRaLIdIPd8+XzUk/hvb4usRZM/izLhJm/wkmm6QvRQp3EJcr4/rxX6qn1fo7vaBjsudjprqusylMavOV1voufaUG3xw0shf1zVaMbwZMu2cS2BMFlHL3OarlYxt5t035dv6td25xhuFMvCdKYzTYG27JzlpOmdcLJyh80UQMaHNW4SDn95vbaOEkNdGxhcAXLtRW9S8v79siZcB03k1zMxFb6sKacdEZpjC67X5etchLh7/PN0B+MFfS4svxK7jgXADm+Dj9TYu7vDX3bchGatyob6L5Sx+Ay7xEYovRuLI+sulVTM09ubNnywWJOaGqjBKPknrX39XRx8duyAeCTCfaklVwaaqMxK7JgqyyrhZLlZG01PhzvmLUn43o3WnIKGMsvs5Fb+BIVWjx57oZkJ+vRbojUur/f9Ug/br4hP0fXWLLCFgasRENczT06qnjhUM75fJhifg2ZRQkTDvMMOdRM8Oyfxpf+KBG5sBSCctW87FgbP9EvMLLGyUlk3l2Z8fiwPx1CmMjrOFnk9kC6855ElNwZqzwyDlomFbceNq1nrSxsZyt3wuWkuy0Hg17clOmxDrdJAubIOq/yV7FiDeCsojBK9eOi0E4CT5V5uPna8UJoG5bj0vcYlqVcFmZOWeXjZeVHPsX0eEWIIebOSJZDc1JyG6Nxa7CUV+v2hjOBRfbuhQG+wLxYnpsiPSdECV7lhBNTZlq+Egk4kJd/snIfeXRNWHQp8bN05jC/Ui1RR3BCXcU3S9qIUoekvIWFcee5IGcy89TCvDbJPLPa6Y62ro+Ko225NA5ArkQQrHaLvgRxgZ4H0h/kRn5QFQf3tb7R2ENCp03aLPQ33R/l+7bhTB0Z/+YG0R6d20mCXEycFWGS0cpozR89HY+3fIvjidLcZh/Jm60BWp7tGLCYu2zUX08/dXHUCh3RO+4Hx8qkmkpEPo0dHatJ6LrDWvaWG0SRhBE050nE8FDuvJZ/VQNWStD3TwNMhjIZ/XuXGsXyMoqr32y54/cW5EuNzyrm/KBjCzG7y70jn9NY11GIc1oqykAmsYjYgOFAK0UYYhqYRUGXSZpp/UZJj2VdClBY5XbdS4Dm1hPayHEmdbnr1zoj+AOHkhikeb0SqoBdZ90ShKHpOxADIhnh6yn3x9YfVCgJlLdMh93PudGmTda80Tj2CBrDNqhounIAitSP+PNu4z/YujZi9FF7cZ+yrzyVWKl5G/95MhqmwJT0rtTmtRXxCP3o9FIkjDelY8GJKilQC4ywcyU4Dl1YW9bl/ujsjLsmDLd0mvXObc8vKOI1keXZCqfbYmHEc6wQz3V2axRhNNDSN3eGhCflpn6OoIe8DQEk6zjHeZzBYwAOpGPQ9wCUKlDOhnf3oaP7p5Di0r3HjWEnaxUevsbBb2Yje2jMX4puy8HBk653RfQy11ymBLqyim36Et5pkLeKsRX8ZlhSpheQlnTM5RxfWs9vgLM0ojwuG2YIsgJ3gC5U7hEjokI4BpXVYuHdTKLaZUfRLVnP8PcZ/sKw0pXuziAFF/yrC+iCLGOYm7c2F0cSkX8dKAWcBP8cOU06CI0t/5yCrpW0G2pfwLyI00SsZ4A3NpRQzhoYLki3nDl83mDKbtIoC7CrKLsqp9iJOqC3Ap7KcMgrLsRWXGs480k/5GSTlGby7F1J6YhqokwsuWgCsWPTlk60qwVpCuZuzTexuNhdRogscz5o1dpzmyjYXQ6farDVCT1szILXJ1yKHvu77BrmoXIKaJsLldikmZ1fgSFWG4C3MuOCQ+GSIhQSzollB/GeKGGVcOFU5ugJY4dKbQm8cjzPkdjPnJwda9iCFn48VLYFmED2RMNaog6DIpXzQSlaL0kqOgM7U1UqWeTDbT+ronKSa6z0wTJVWKGoaDvNGnWuII5VQBsu6YvgfcPByIce/DpijPjoMiIcd7KBX57kP5SP57rCdHyK7X7Hdtu6IGhTIvhZJ0YkzidAJMWR5Kvvf1LH6yPeR10t16xWAj3e2uhNOeLvQmX3vVtvPEwGyegSI4972Kwh8DUR4oWN7jOidl+XFE+KGuJXBWw3CN6tbVWaNJ09TbxwGHiKDVbFkDmXULng6FL4lGWj+xDkyhDitmOcaP2Wkwno12oD395dmNYmJRsyzUPbes6SP0MgRHKi+qxBb50SdQQ3qCjpzZ0LB0EsCQivWdWH6d+rW83dNHz9bKn+MMqG21mUzoUCXeQVq6GnvCcRzOjVjw93bftaPG0ekTP5gfXWQXPgogNLg4IhS2Wy2nomoVxQ1qXZjLOgOgIZAiRwmZBsr/ulTkr+5U2+dOibBcf5LMjKH9zwpCmMc8IZSLhf2kx0Fo8b/dhAcKvDpCSPaa26aMCzjKbqZ7CT7n3BpOEar27qul1NdKnCknRwhkPFxVC6UVpYOlYcZKsFvg+9j/V4DQpbycC4cE4PmaodAqxXpt4CSubPuEiDY0GpVXqERsWlO/g23iNRoqK0q0RNiZ9DOC8r8+MKPoPcgjz7/jJtCUm6hON7wAkbtDbVmjUYocDls+xYmKUfwlWu5iurtSG1P55wg3TEnIRCtLncJONIBLav2KauxNQb2HdHzKubi2TaxGRXVv8if4NlPX9n2JNHx/qoFvhqKdKvpPHl7/ww+ifDcj86NraremhUssmvZ4N85YgfRhAmRHG6KDoKcWtG/3VvCS5GEo5DxCc0YvfNZDLdjHvqCoZd5lZnCieUtt2q5v8GAXo9RC1xyRFLTFmy0E6OW89zZjsMDmElb1yqQm2GebPvo2XLsgeSWjO7xUTLSlCypBVIMN2ZaMrOacbxFgSFYR1yHipbNcyVG36z4Tx9A9zrl1svAOiP3SiIOCqIVBTPAyhxOdY62sdKq+VQDywA7picxknGesfHfpaFkx7RpwqXJCcubMkQ+kg/q/2+noH5bEkUZOnPse2ek6rm8oxD9Q0DnxRBL6tjI2teeZJq1bnLiI3Xg6p69uDsctoN6vqMqlKyGgY+QS8TavqG0LVaNCBcY7Bj222OzY53zdZn0o1NGFGjV5HN2HY8335g2K23rFvH7gzgBxfv3l1fnh7v726uLy9Oz99fL2dh/lQ9Un6fxoMcXX+qTEOCN95uRdPyC4TYNtd7sTtjdbJuaOoW9cL55zun9vlh2qxV++z9+5urs5ODva2NlaXZxfvr6Xj1RkkJ9Q9ZFohjtKaJmEg/gqzAuXe63r16V2OgGwfHATlfpfJycJxd21DcHipmPpNtF+CFE/5LiWsCs19QHKD84W0hgrPzQSAmDScDDbI2OQxqYViN4TAJZni+nqwcjUOYwETEfIDgvX6JgucbKTl5eeN483h5abJ8Oe9Hhp3bgYg5Anf6t/LdFmRV/idSG7KkDYQcauWSzK6BayoQHlLi/TtpfZEkw31nkkomuZel61NeoKnR6/fTxpQCgwtab69XHbttW8hFhONVNwUZ5/88GFzrvjHPAK64+vv6fDfVQBVrrXcbtiQIlUnkgHQkeK64fuvhxYJijR1zXMtbt7V8en88vUuFui5AC268bf8UAjbgZsdg/LXZba3uN2+qhoPeWQM255+1hs8b+DvR8BnAnzx/7/7q4uRob2djbQlNlq8X3uiqWjHv0sDagYyDNLLpXimcbDC154odTjwntz58FhW/jbY/MMkWFUeb3g6LK42qqVdUwMdLB88v8sDWxxd/FyfPps+cnxxT9aqSrgax2qgt9hG9vWQ2uc3cnPkcYygkZEQwNRENfnF+9E1EiToEpEOIxdUexZDQdZFqSOdcrkP96tg7gy2fvY8vdZnEm+bGL3vR2VAyaJMAcyVXZ9WFyA/yhJm3XYF0d28z5p9AInyzm5Ao4WVDZJS86iQjebVmpi3MV/rPr1uhqY3r0keXo/MXAXxuXbBfeMZbyQdHW44+j79Pv21WmYHBnb7SO8WZBvXPfAeyNCWbDb2Wpl7ZwtGN0vDU1hFd1Y2L3onLPRBbjr5eL4fd0Ld18SW/Qp/kkL/b4xuUxz/f5DXEpJWL1RSpDFuwrLXdL22gIqNm37i2IXgeDlxO5miOOex3Y12uspFY+qh2N5n17JQg4+LKU7IWr8KotzCAOTo7s5A6sDc7My7R+8xizEbzRyFehzE1bqHQ1gkRWDqS6s2Yv9eB5Fb/GqTsNrFUlv/SgqEUT4FZTdMcRH5UZVablOcQrykckXMrvsaiQS7TJNVNy0wesY4w32qD9V9VJ1RmFxvQNiuXMv2Wn/vS4cOJwkHAPIjceBr8FC079EYPYnxDYrIlamKgjtl4bfq52J4G9rpKZGmB5VYH6yr5E5hOhZfLzJi7rWDxJHRb0GBOmOhFeWvK91aNeGcwZaPnnA2v9kBtqLLpZnpG45DOpt5kEr9BMy4h7cIw2ul0/Dffk+pCYNA/Ox7heJb0slk0tdmuGsjNEt7DQHpkT6m1LCmlrqilnowChDfLY76yLsS7VlrqB1XbppO42/Iw39U4/Oqw307D8Xl5XzTh8F2QOtiVPjYF09e7NSuL87cAdSHCg+AdxUO9S6tITyAc9B4YhiF6TLLlOgEfAtNJ92bqYwgANtO9BZcymHNRgOO6+PqYE5vM/8XM9Gus04Ez5XhlUlzmcoevibn+HpG4Hw54qPDYMTF1xwrA0svVPeSvAE56pBhbrGiobq4MLl7DyX67lBMqjB8uEXedT+XdQP7MrffXuZTx8F3fqEXB8MB3g8vevY3tRNnimF244/gc8aSCqoPhV85tfY2XKZ5d3xh7cy7PMh+fHD7ay+4YNkn8/GnoJugLCwbSzReIoLABirArGHT6C8we6wqwymrKDRtKLYLlugEX7YGj9zSEcroxP9S70dZNRSSYfYDxSLVBvcR9gvQaTdOt6bqfRriX7MfOOt3QXkSJey2cZT8eAwehgQWLrw94JXUJBpSiyoeNP5prcXfgF3g2AgVsn3vhPVRoTukhczM71gsRj+u56E1u6tAVpI0SyZPAwq3F6AkBsgmeaY0YBWUJ4LxY5raiLBvnmH5vv2+JGxPubMkOmnanGXbURmNyL7jHGpX2sKwzBsw3SmR3mYW7x9CNUYxlKlOuNV9u3AQDVC5QLc6fnpwFD8ayDug4tTqmdbC1y0MiwFy4ayv4oyFjUEkAX4BrKSqfQuXr9maQRtvmGszrHRVOo/b4lYgi4J4ApkxbGAZpqmqpaUW25LrV3uf55Sh1YFiaf+Nu9VEE4M8xkYiNWncVr2L4ooaGk48peH2FdAOke5vrq0Bw2MoYo5sHWDh3Ph+1ICz6zblW0ZR6Nfp+QwOA2xm2pXVIFlU2e3mOihgeCubk3psv+ZvhgVCsaq2FQiPqD9EoGaNn+cuHXtd2rVpvTKEJwTFMtFw1fbqhCbhXpOD0aDPIkDmsn91/E0dp5W8CM16g1at3/DwyMPLbKio9/KUDrMxMX40wump7boQlrU/azLkhaYd0aqvfqKXU14Yi8+AvuxQsHcBbDVdBOfl7w+lEuu7BqFtPx3uBetdkJmDGP2jHZDcRBcclsntYaUt7L13TAYG+BgG9I0fFClOtbts8VdUXt7Z0+kRriEiY3yARZ9om6wwXNJFdOXpdmQk/J55cmA5IRYyNdy+447mo7Gdr428z2jXE4cIGkB1yHY85iKdVEtJcbhvr4qLx8UXDvk/NuWJQwYWEojJndjvh2vn7ToTDeEVbzZVwmTy4EFg4Z2dyaGPpZp8Fd+l3M46z+Wb0mBr+MKyuqo7vWjk6GKTFjZQ4s13Y1Zzh5oR+oilhwK2MWVy55YS7m94srxf52DmPW9Be9iXUIx0/SNNzpZCUnloT0j0di1XbHZx5m0oUlg5iQWDTMPtfds5yrfJRyhAZZlCapXlnxE1FYtBUGGB2sPUpzhzzNRNjr/CzipNMRUoDjAxhzBLRjaM7YApmE/yRHYYYudjv4rGgZ5+eRbqZrwPtKu7oTOfgoLZ5HOMtURwDRR4vvVoX/vd7cCxTq633tKMXy3XQhTVYVorJQ+xMyMNkPnbZjjgD54SdragpccKlNCcNETN2NsIfqOUTYqtF7pIXqJnHJs+uUcbs2tLtZ9DxHEurHqMPPXF/uWEs34NZ4fExnfDRlvMGzkVmj+0P7+MQBvt/l1/+3/8OH7b3h7fxra21zNOgD3vBiA9+xp1bVnDFj6y28ftxoqKDLGFiu5zJQ5I0YikLHgm9UsFxAbhp25Y6pqv4p9fGE9yKRZtnINjqTRYHTrfwvJP5tUYpH+vDkwZuTlJ/t+2kNYPHwgHE78pWhAk6xmmszBPUmurb5PmST1LQvVn79rWj5CPhQLmY0e8jbq+hwOUWfoHTT6dTxWMWuqZtPTmKT55F8ZJ3NQq3BT0Ngwc5PjdzMmqesfsqIJd297IZOaQfSzMrwgBMSrsjSVCRaHmpE7KJE2BfYZON4IL2TkE2i0VnPtKjQQdeO+T1Iu53pbggFKcTpZ9RGxjS9nAi7NnBTFPyrPvuZ7rFkLiaC5GZv7GmAD5Up/pxY3tCSXOgk4ot4IfGlKlzM0b03+CAEECUFgKOobgFVi1T/hFHCvag9+tA72ASvQaprHxxfe54x7cIkw9VwBN1OJ0nr7m+qgCxHcgsPBqYqNjpOv3ASqEvEMI/fSb8HbajKD+uOPy6gOG6Nl3HrwDrDib94+zia4RjHsQrMfYl57FHiN+X+vsXxXhX5TG9QDgFim9XeVxvRYdTgZy/ysITZn+yFKVsNwoPuBPLFwVEsOmZzt1Jj0UocdQO6ZYOmpnLriFllRomrf1hzeMjyInS8WqnLm56Hk2fB+exVUPxW8ugduXoa0NgSlMoYi+Q7DKoh16I63xmffBYK7O/C0nhLlGU+vRyCNGnqW23DX5lmwWWNHs5BwQz1GSBMtZiJfSC73IF28ackvlEnU/73di1WhVZJJbbwF8+f/34wd3N9dnp8eHe7vrayhIl8a8fP8lk94UjGmUbb9yvmJnArASN8+51zDz74n3v5P830+/jBzQ/+aoCc5NvaRaMJpVi4jwLgRtQBLeyjSHvGihrnQwcUPEwfWFCArwqJbqC3wBicdH2T6kK9bB0CSJ6MzVaWNwog7vbczm9hFtjDhLZ7D6U5wzTqxwB2x1lXwt3Wo3ysDemWCvSqHbXOLtgYtypQvR6Xgsv4SrN7lgdoyvOQe8HyEC/uWd60D5dACVtFGW/umNWE9WUg3AyS0mSkJ2xaDG9Z9987mYs611BWbx+YcCip3Wu4wfK3WEFHE/QEnRJmxkYGhOQgdyyVt95CmcZet12diZWs24VxzEyFarvzViW5bJVydUgS57sbOZqNqILjKQtpHpbg3grGarD2kQsqkoUV0/EUbEiMsZvlXmDbPJFXOI8EJhYuoJpaaf1E2QupxDbtsnLrqMDFwmponhiTAaf+YvPMg6WW9+NY8kDvr1NnTQKp7+g9NuheMH4H6ojQgKVvnLLMItM5MW2EQjmiQUsruA7AGVrx3fmTKgKHoRRhGdMllOCUBUS/gUCUwBfS45r8yU9pqtAzCgcrZU/NY31vlM671qiZ0xOlBRhwOxbFmqKOCJagKWhKmjPXMY20lz9kH2GVHj4SgzO64WKAEcxO/aduSXT2ZybJLsIfdKHu9hidbeWq4Vaoo5a2hsMJ1AzR8BtaQIoaUd7Zr2HyVT7nSigOqPl27LWIf5ouV1j4ddNxN9jBm0Itk1YJEkJVLpLGjIfaxk+tewol6Gt5e3RNz7dvHU4NDUkl9nezr1iT8OjpsfwCAnlqzdVgd253lMQErk1KcVeXllZPx9U4guNjb8eZEsYnCANF1/9vSZ8G22WSJViF78bg8NcUywSI2lWrtADO2phvSgZJErWecyylhbT0DXoDp66ibSLVJv+B1l5UcmScW6si2euZP2BcW6ss9H4VG3Rxrm55mD7+NYBLBQTPyw8U69SZNyVxMSY8ApOWtsmTbIOLlQWY14JbhFXvjUr7B8+WZCIEDzia1L6EMQJy38UgOAk/UwZPG7lN9uUDII6cSGaJOqGIUlRIL/trQo+vpWhV71tqOwmaYKPCjOIGdiTQ0CJKlvMVHssmO579XFX0Xy73YMlveR+LWjZvW0xqMHY3pYYvvu0Tb4K2tXaD0J3yzMxx+GF6fCv4UHbX4udTHAHPMrsYjPSTXYnMmW4dkQqZENmDW9leG4ET4pBUm8WoNNXu0KJcSOWyW2tDhlHr7Wm2vvbtaSfxFqkptPiRX0mKMZ2EDoCqQdf7dj6q//29mj28HFDg2Y7hxh7ujQE1dSK8JZpzs0e0GsyoF8DbMi9ochWKvKodiqe8gMe8uzHFpvGVu+5i6aWcHPKUou2rDEoZ00EZfvOOIQicN8fJ9DSg7BGSvKedH6LOJCH3L9ZgpH7oStxi7BepHtEzKExx2FBFW4ehf/D8wXgdl4Gn0eV5+fWXgjaxNbDZzON5jEQ2uIaZVm8srMiifPXbVzHc9ISrJvB2SXaWmdH4ZVUm3E0S9bm4nivsbgu4dFavGIUWz31kPmH87Sw5aowWPZ4VX5L/rYKTDvcw8gL+ouR5nN8lswwuQ0ePtNKEr89cMnXPTsL/ElRILAB0Sl3E1WUiLs6fq34G+zRagLX9byS8V/RWMM6WDT7N9PIT8WCUVcCt7UH8oaeb7PxVG2+GY/XfdttZ4xbOj2z+jOfXiM0jcwgIfgaZhFBF/xivVCulxWzAz3irHVdOs030Z40KQgiSOfM5d1LyCajthaf5vHtTL50tnOYjmXQ3gEJ4g0CXRyIQgt76bgfzOdB24IID5cjNv6EC8y/JSITYFbFFVLO2D5fosfgqZu/UqrmeZZEgc+lkGVJXAuiFjXxzJupViiOV9SOWfNlp5QDS07BJShhEdE1m5nwqURFqZs4uWT3HOs9M+xccTZnAdGVLzDTNs/QG3X1MltCnvov+yfes3grJmEVVVhNrNcnSPo2g43A+vEMnmS0LeiKZA6nlLVyxtvxhJi5MSErjwdlsUCMfq24qlrE5QCOzXx0xXIh2NBwX6hcOq4YzuDQm8hy/18pMzXQAnU1DIthE2hfL5+IrbiFKjVsBaVcCYeH0vV7w/m3WKL2bPRwUsmyrW1ojLwo80CrzbQF5IrwRl1UU5Br5+bDbl7Ey4vIS6SOA1vulYbW+aeH+vCqoYNVQXBCwYkENwrycywRwYmGj7NTNt+sAPNJ1Qmj4p7RuH9nYSgsbSJsgVzH6fkUuU5ZsIsLJaIAoSwuwjMW1CfxSYxZgQD09S/Lpdm/XIv5t9RW4mMAXz1uWQLANweOG7d2zG3lVQ2oggFAwH8W+GFvXvwGHLbunjcMfvhPzYP8nv5Yq+2VHjIYFkE2Q8tftxWSf1GkQtSA489SY7J2kjrLrxx+EeEYkYfMZoacJVgErXpe/TL0BcBP81R8qxIal6mZhfcn/zzhIlWTpd9E+mY45yGGo36tUpOqsRIP+fRzuVeh5Y+FDsJFKUhcYACrVM5q77Rvnv+J/wJQAbmIdoyUQyYpGews4yIK4nn4ZUwL1D/N+57GtYP7ESzNUvsTdWxa746pCbOU35KHb3G9/L0UD/bzfmwOX4Dt+tixDBtXSspQvUcgctWKpEtXIRpVZcV7v1L3+tfqd75GiGDPKeCSKgeWkXJK3TG41gCegX1/RdKDLAGofFa+/66S/MLfmcPrrVptw2Cqo4far5XPKfn8KqcmPqdavvKMRboL+1nV/DUghkkZtyrHSU6kCOMY+CKwXtGnirUHUgZhRR2BExc1euT8e2w+lO/vSsg1f1c8o6Z+9n1rP+LPyD1WkQ1vqf322mbCThscsPFnbeKolS4t+bGDvHw+o/r3/jcacN8rmgG4faZX/966FZ/tbuWOp9++fNZjHenovw86+dEzrqF6tN5lHP2buAU/597x/f2DeEmT9ViN5VS0mmASPCa/eYaivu0SBvhBKAEzH1qkzXpJ3OGM98yK3ER71YM6TX52n4i4HbXF71Wxbzv24b/Bw2dvHv5jffnfO3SvHD37iP1eYtPQ1mF+32fn46WeHjrnc/hM+PI/7nP7lt0us/sXalezu5pFbU7qbv+SbCS9UA815dNn4y+f/s+AgOUTklbQHVF25uyw3X+exn0AqaGRm9SzVCRM1RXdp5bfe0H2Gvqdw4AfzTEpUU+UgTKrNiChZMqHeWaKLAH43h6HVCmTH0SuOem9JWdcKpCj5QG3yuQGyaYqUq5N1QxZi3+xDhAOhXnnnPRh9R4vS9zM1IFdA9sQqRKpHI1NszMI93ZZD29SCpHLczmBYtsBoGSn1XN3C7/EibMpcJ93xZr28oH+iNLStOXcTPNKmramkdB3VftNCbautjZA7wGJIqlc4PcAULicNNY65PrRTinSYr+K9EKz8YihRqv8zAKHWgSF/PGk5nAveVYrNnz+XUm39knGoHZmB6duRbTQRAU1tDam+1C61P/JidcNORCQpxlLXZBMMFO5OgC80stsIEDAITTheOdfwwNTyoM0pY+1v/HC7eOjYBwYIQKU0uUGAGKls2AUaIDAWFck69BwKRs6rPxIkV860ngNGFl0JxblgLxWbg8KGG9vwjRn+6cqkUuFBgH0WuUgkElNYTMWYbYibTM0mLOM0GHeaoMBrDWOFJiuHS6dvd7OXpduQ2LCWrXpA6X/fzKus1UWpxeCdYNgZb0P3d6rXdrNAo9qp39r27vG9MpUBVJo91HpdObdQOFq6rzth+UbGk3ejhEUO5qgSB8oXhsFuHbejm1abehtjhXrCm8HtQirRukfbdVfR/jENNFmRndWCy55FVCqCJTH5kaYWb+FK6vQYKxx7ob4BtWusLA+hsWw1HTB8L+mx5gWf34UhtQ6Vj6fa/D24MDMs/5a4rcYLC4mca52HW0Z9oPVzp6b+RrvhmFmhX5rMcjWE2I8YfPV1NHu9gniritfaaNVl+Evr+Wr9/7y0sPO+O4+vQznP7buCNT6FrrLNXRbXJbdmasaui0gYb3mApoetCDmPCe/vYuMct/dppu3ILrq0AzMMkfwIYuxrGdRUr0NmIX9qP7BRY9dA65wz7s8upTeoA/a4hHqZBmGehh23X6E1oal67T4MPXknKee9Slvr/Y9d4Xu2rlrA89lI6ZLfEuvMge0sC+tT752aqws4gBv+7C9dnuXCCfrtMfCG8OgY2hgWNdMmk6t3Gi+oZtegr6l6KHeZEdZrHYjmR87u+1O5TL6vj3xJZmnBYzRGEYEIhEN0REDSUF90kgGySI5JA8+5cKVFBFTQb5ekm8NZdMkTIEVphJEUZ+o8q+4huZDkD60FTW1xIKaW6YaFAw8NerG2gOpRq069WnUAJWmd6s50b5emDLedSxcWuE1pR0BMZ1IyCiJ6dKrGVUq8d8N6XvpVRaYWNg4BcbtRnb4BIRExCSkZK1xTRUD3xgySk5BGSVV900mpaGtOR09A2NUHTl3S1DmbreblY2dg5OLm4eXjz8a8wJaBIVisPSlwF4rSFi7jlhF+rYwnbp06xHTq0+/AXGDhgwbMWrMuAmT0qTLkClLDvZQWitsBxsuJLJ7uNAoFzwvt3BRu6wj9iwc7GcIG2lD/F4QfLZRd/uKkoS5/Zvh9oTweT2r6jaR+7tLIDC3LXm1OfgYz4B459wr2gVWzjFuW1NuW47pje10eK/h4mKddhoyAvgaLjHK7Q2jmAkvxoHKJPFO2+UxJ6Y+16c/l77snalmDcW3u68AGR/GOMb7plRpvS+l73z0yWdffPXNdz/89NqbKHZTxudAbpweNdrdxqxas55H//WhaUkfWyuiJJMrlCqqatSq00hjTbSjG2FY2tOO+7SnPe0XXu0pqmBnNKFg4PKMC2vU2jPy6NisERYOXhOCdtUkKw6NPNtrXNu55AAiERo2C9I4USCScitxr6K6S4cYYBE3totXCpRhXy4mUplcoVSpNVqd3mA0mS1W2MnZxdXN3cPTy9sHCAJDoDCJmN70lB62I8j4StoXCEViiVQmVyhVao1WpzcYzS0sraxtbO3sHRydnF1cARCCEZRAJJEpVBqdwWSxOVwM1PqZPNsbcWfjRpHnjop2V6Vmjp242uwOJ2Rk7I9hWSPgsf8XYdyESVOmzZB8EMEY1LLZHTE2d+anROFye7w+gGI4weMLhCKxRCqTK0iKDv2VKrVGq9MbjHb2Do5Ozi5evHrz7sOnL5EUyLNTlSNSnQC3xxXfyQkAIuE0bdY8ZGtn7wCG6LgT+JHZIouKmgA3Co3B4vAEIomcRx674qRTTjvksNddlAYfoiagJ5wOMZgsNofL4wuEjiKxRCqTK5QqtUar0xuMJrPFCjs5u7i6uXt4ennzpr5CAQRCBodFllkaarmZsHAecVZvRJFR0TGxcfFmXZBeSUxKTkm10Ea5/m+ZAGoVmGobrLfOAT4n8bhsS7PFZvvSzQP5LlxnO/OncOy+SCCS3lWFSqMzmCy2uoamljaHy3NxWIDDcRQIwSOt/zoLRBKZQqXRGUwWm8Pl8QVCkVgijcMfuUKpUmu0Or3BaDJbrDa7w2k0mS1Wm93hdLk9Xp9fZKQzkUrTDdOyHdfzARCCERTDCZKiGZbjr2CGadmO6/lBGMX1haTRbLU73V5/MByNJ9PZHG13+wMkKZphOV4QJVlRNR0ZpmU7WuH+4TGKX2Wa5UVZ1Y1SjWPVTpyXFZ/MJWlPe9q/aB/P1/uDYjhBUjTDcnwkB8R6Db/tmpbHdxAlWVE1/d/j9XxyVwfxUOPV03uHIgwBgmyxxxHWfBVbxAgUIehxctj21QZP9zmPcf5xu9x3VJR6dXxqsbf+XDT/cn4YHP7NVlWcXqZ8xngF9PxdPIqinix2hiycXMpZhhBmbdBxs1imR2M3KpcvLCmBuuC/IjpTDOcE8NSSLzp/8IUlPXchFDpLdWCyNOYdgDnXnXVL+5+CdGDAC7ucr7CeYmu8iT56doDnzDHj0cSq+BrRTziU96PZOigILBUe8evTQKr8NERYOKwExEpxO+hWOdX/Vprp0nfmcoaSfHOgClRVH1VrGuarlpqEmZCzp3J96Xn1F4EeJxtF/7A3VEPzYs4PxDcStVwqb+RNoiuGH6drZAmVh6G9AH070vsAlcocmLxWzL/PTVu7n+PXNHFdOZlrxfZsF6zZWz+VcBaqOWl9eeEYz/OhjPGoxnO/X5nmxffwyXuZ6H1AfdBzuRRo53ZabUHXom03e416XNiF0lPrrj9NuD3TtSa3J2sPY+5CvE5/1Do+xANx30re7jr8iY7WHi32oxtVrMOwo7tFeGKoVV6aZDXMLTJfrPB+PtVdRerX5SIfi/AF07X2dESx+XV3O8loN0LVOAf90Wkb8KUW9bFkSDAUzoKTINFE4Ak9RETVpJJYupF1rmRIMPSU/JyhJxHM4qxIbiLNVtQXp+RzAV6lX2Wl3J9XrWP59/O6U+Qs9aHKXFU3W1Tdes7e3ZrV1+TYWxu142p91F9rnxkYDYUjSU7OgoEISkK2Hd8GBpujeextqV/uz68VRSu8bTQMP1l+YzSYiGR7tsZgcIEN27l6PnK2c/11G29X5Fi3W+2NqqsjthVdjZfI3UYPHejaaD+6ucuQEYZ3DbiFLzz/SrDCbIOjKIlkEd19j4plBS8saKMNB2/6HXj7b2HvHBW8Ezfa76BTvEpViiiiiCKKqJYiiiiiiGoooipFFFGFqnQVtfZqvrTu9kOsceYKvPnUmVPVa6EfEYvkEnxG8fPxSEaxmYwVZ1//yEZL0zXFvFXx4+rCvZ9cyamIdO0hu7gb9Thq+hYHo7eII2645nyLV+M1t41XK3OfF3FfIDZ/bF5lgC8lUk+3RDH16P6RfCkIEYSMgZCQahKYBoAkgclBKDlM9ZzSQEKCFmxngghCSbNzAwmK4QpKmpI0xUgaEyflaOphEwCAAaSSNm0YDRatByeTkOY1ujrlAQRhDlUoZ+RFRJxYK/97zf+mhVczQwQhYzQkij8kMA0KSQKTg1BymOo5pYGEBC3YzgIRhJJmLZIQiuFE0pSkKUbSmDgpR1MPmyiKDiqVtGkjucQ42BBHKeTwGj33TSDs3NFo3cImYdI22lF8ElnkRby68abPrdm8yD1bu3uUILhztew9cTecIOkMilmssaweDEAIRlAM34vTtw4PSSoUckdfJO7UbBjcurzefPbim31nC2v+lb+LY6W+0py31Hf2BcfzDfu+4vnmvL4eOHv6InIJ+BMBgQDacaA1BwICthZAOwEEHGjNtQ6XlR3kXj0NyZZ2r1rl4u7eacnc4fwqXd+0SZYQ4IAQjKAYTljOvN0uYSRAzgrHcRyXJ1UXLVNYf8gfFlj8f0/ZM99+ndqUeUic58gC1goK4u++3kf+RjL41yC/g5Ib+6Jvit7fbSMLjEW/Due4vFL0mzfB6Kump693/ms/CieVwpdK3/qPHjo41n9p9t7uA77m9UPaXdo1/DvW/TRs/S+Z3t9bYEHSYNYSl9EkSuyKCypHJeW7r99ve12GwKmf5i6BKvxnS9etq0reihdlwmXd/+asLU/fv6ftjTxc5J2uwod1cOm7sw9U4IwgAx5EnaC8Uvw17vtlEONjw77/Lriokn5Sw2Z5ePx3c0+zfC9Dj8wDIRfPT+t0WaSXF7sWSuh/7Xs1nBwBDcIEG4tqhN8D+btsmvfafjeDPpCRYs/SXcvDonJLINySD0IR9/NeECYwQNS5Is34EGaqRvVfhoczGbSDSy4K57ukDDaw2lZDgGqUCYolupoO5VeEOOAX8S1ZEhlMSjkgToHZ9UtgQVdjZwJncZ3HBtlA/chiQvspMbq4o8vKgAe+CSljZObmyfKAQi3txEChwqFwCbcNQy0DFNRXi9HAmmAG1rrxHh0gU+5xIWpMgwVDE0kqlEYI1IBMQouskHPRl99ElN9I8vHrYrCiTf5xESTfQYf9jrvK1AXh14jefjkCJ/DzCWBMNIuvAQcSC6h4wuQMs1yLZm98/b5P2uV0l1gg0/JE71Mhm4DM1Ltku0jQ9HrnZtpuu78pPjf52+Uo3CL97G27Or8/EadmiPC1ZdOpOpg1v+0AzVMbLOVsOmGJaehpPQwA4a+Q+w9x8KIp3Q9jwNPIfs2kGaOmB+e9hbWH+CshRVy4K7KytuxVWgGzXrnutJexhfZOOplERzrNtT92AYMolv17vn6kCClsLedP89AWjBj0P+VhPrOQIgwnSDqDYrIe24f2/OPe3nfBfAHTFrqI+2uDlx6H7vT+gmuJNUG5qsnLYdkONUFJDHnQhGFpNtI2IgKQTDqoAgyYTn8cHuASqSTPsEq2syA8P4yWAaZTFu+JoKKgGW1nH1pgR4BtGDy0AsmwHkDlJefAA3LTKGlkY0mABiqhNsX5YYasDxLTLFiaSKMLAEPJShW0gnmm0g6okKSQVLII0DEEk8Y0ktcyBiVuGtVqIE7SKitpkeeHGbQcJJqUFkErkYG4VpJl7MSScQk8BWUOSXviDEVJI4qQVgNKWpI2Nppmrh7AY+v8HsRgv//+Q13PCmffT+9BrP6GEM/P30lojo6fj4tzvga2zhUhCtvrp4F9JeGr5FZ63/6acT6KyUjWs+Oa+vOPGuEjIRfJHtC/weU4ObIIrBie48LRabuObhWqCa8TbZWqtEW65t387hL9JPJqzODFL4fCN14Kt74Dbu8zXOKthO4dzjzKsbTywIpP7Ste/ZwT9HiMOMkeTl6j3/PkW9fI4OlP4E/V/SXl/5Opr+LqDr78BcQffwBcX/JJPoG7eUb+bF/bB9Mzu7Dcnq/xWr6Xj/XNfJ//bLz+8Q/685orfd7/N0igE2RLgWf/yHCH/4kCj762+ed1/wP9v/CSP0f8qb+LY1aFRyn/+3xR9m/xjuI1k493AvFh04hc5Vv5SF/kq5wnn/zL9pry8DWnqr/NTS7//BI=) format('woff2');font-weight:500}
@page{size:A4;margin:14mm 16mm}*{box-sizing:border-box;margin:0;padding:0}
body{font:9.2pt/1.45 Geist,sans-serif;color:#1c1d1f}
h1{font-size:23pt;font-weight:550;letter-spacing:-.02em;line-height:1.15}
.sub{margin-top:3px;font-size:10.5pt}.m{font:7.8pt/1.6 'Geist Mono',monospace;color:#55575c}
a{color:inherit}header{padding-bottom:10px;border-bottom:1px solid #1c1d1f}
h2{font:500 7.8pt 'Geist Mono',monospace;text-transform:uppercase;letter-spacing:.1em;margin:13px 0 7px}
article{display:grid;grid-template-columns:36mm 1fr;padding:6px 0;border-top:1px solid #d9d8d4;break-inside:avoid}
h3{font-size:9.6pt;font-weight:600}.o{color:#55575c}
footer{margin-top:10px;padding-top:7px;border-top:1px solid #1c1d1f}
</style></head><body>
<header><h1>Katia Danishevska</h1><div class="sub">Strategic Talent Partner · Digital Assets &amp; FinTech · Executive Search</div>
<div class="m">Zürich Metropolitan Area · <a href="https://www.linkedin.com/in/katia-danishevska-122224445">linkedin.com/in/katia-danishevska-122224445</a></div></header>
<h2>Profile</h2><p>Talent acquisition professional with around 10 years of experience across financial services, technology and digital assets, in Europe and international markets, including Switzerland. Focused on connecting companies with experienced specialists, managers and senior leaders across fintech, blockchain and digital-asset businesses.</p>
<h2>Core skills</h2><p>Strategic Sourcing · Executive Search · Senior-Level Recruitment</p>
<h2>Experience</h2><article><div class="m">Oct 2025 – Present</div><div><h3>Senior Talent Acquisition Partner</h3><div class="o">SwissChain · Ljubljana</div><p>End-to-end recruitment for senior, specialist and leadership positions across digital assets, fintech and financial services. Targeted international sourcing; pipelines in business development, technology, compliance, operations and finance.</p></div></article><article><div class="m">Jun 2023 – Oct 2025</div><div><h3>Talent Acquisition Partner, Digital Assets &amp; FinTech</h3><div class="o">AMINA Bank · Zug</div><p>Recruitment for senior professionals, department heads and selected leadership roles. Recruitment insight and support through evaluation, interviews and offer negotiations.</p></div></article><article><div class="m">Dec 2021 – Jun 2023</div><div><h3>Talent Acquisition Partner, Banking &amp; Digital Assets</h3><div class="o">AMINA Bank</div><p>Full-cycle recruitment for specialist and professional roles across banking, technology and digital assets through direct sourcing, referrals and networks.</p></div></article><article><div class="m">Jan 2020 – Dec 2021</div><div><h3>Talent Acquisition Specialist</h3><div class="o">AMINA Bank · Zug</div><p>Sourcing, screening and pipeline building for business, technology and financial services roles, from identification through offer coordination.</p></div></article><article><div class="m">Jan 2018 – Dec 2019</div><div><h3>Recruitment Consultant, IT &amp; Technology</h3><div class="o">ManpowerGroup · Ljubljana</div><p>Sourced and interviewed candidates for technical and business roles.</p></div></article><article><div class="m">Jun 2015 – Dec 2017</div><div><h3>Recruitment Consultant &amp; Talent Acquisition Specialist</h3><div class="o">ISG International Service Group</div><p>Specialist and management recruitment across different industries.</p></div></article><article><div class="m">Jun 2014 – Mar 2015</div><div><h3>Recruitment Specialist</h3><div class="o">Adecco Slovenia · Ljubljana</div><p>Recruitment across different business functions.</p></div></article>
<h2>Education</h2><article><div class="m">2012 – 2014</div><div><h3>Master's Degree in Human Resource Management</h3><div class="o">University of Ljubljana</div></div></article>
<footer class="m">Draft for Katia Danishevska's approval · Prepared from her LinkedIn profile</footer>
</body></html>
```
